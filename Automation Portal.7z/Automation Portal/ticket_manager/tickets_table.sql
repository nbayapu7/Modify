-- Table: public.tickets

-- DROP TABLE public.tickets;

CREATE TABLE public.tickets
(
    id bigint,
    created_at bigint,
    updated_at bigint,
    subject character varying(255) COLLATE pg_catalog."default",
    status character varying(255) COLLATE pg_catalog."default",
    sw_version character varying(255) COLLATE pg_catalog."default",
    patch character varying(255) COLLATE pg_catalog."default",
    configfile_path character varying(1024) COLLATE pg_catalog."default",
    interfacemappingfile_path character varying(1024) COLLATE pg_catalog."default",
    summaryfile_path character varying(1024) COLLATE pg_catalog."default",
    source_model character varying(255) COLLATE pg_catalog."default",
    target_model character varying(255) COLLATE pg_catalog."default",
    s3_bucket character varying(255) COLLATE pg_catalog."default",
    s3_key character varying(1024) COLLATE pg_catalog."default"
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.tickets
    OWNER to postgres;