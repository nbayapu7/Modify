package main

import (
	"bytes"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"github.com/aws/aws-sdk-go/service/sqs"
	jwt "github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/contrib/static"
	"github.com/gin-gonic/gin"
	"github.com/hirochachacha/go-smb2"
	_ "github.com/lib/pq"
	"github.com/spf13/viper"
)

type Config struct {
	DBDriver      string `mapstructure:"DB_DRIVER"`
	DBHost        string `mapstructure:"DB_HOST"`
	DBPort        string `mapstructure:"DB_PORT"`
	DBName        string `mapstructure:"DB_NAME"`
	DBUser        string `mapstructure:"DB_USER"`
	DBPassword    string `mapstructure:"DB_PASSWD"`
	S3Region      string `mapstructure:"S3_REGION"`
	S3Bucket      string `mapstructure:"S3_BUCKET"`
	SQSTicket     string `mapstructure:"SQS_TICKET_QUEUE"`
	SQSDelivery   string `mapstructure:"SQS_TICKET_DELIVERY"`
	AWSAccessKey  string `mapstructure:"AWS_ACCESS_KEY"`
	AWSSecretKey  string `mapstructure:"AWS_SECRET_KEY"`
	ServerAddress string `mapstructure:"SERVER_ADDRESS"`
	KafkaEndpoint string `mapstructure:"KAFKA_ENDPOINT"`
}

var colForQuery = [...]string{
	"id",
	"created_at",
	"updated_at",
	"subject",
	"status",
	"sw_version",
	"patch",
	"configfile_path",
	"interfacemappingfile_path",
	"summaryfile_path",
	"source_model",
	"target_model",
	"s3_bucket",
	"s3_key",
}

type Ticket struct {
	id          int64
	subject     string
	status      string
	version     string
	patch       string
	sourcemodel string
	targetmodel string
	created     int64
	updated     int64
	configfile  string
	intfmapfile string
	summaryfile string
	s3bucket    string
	s3key       string
}

type TicketSummary struct {
	ID          int64  `json:"id"`
	Subject     string `json:"subject"`
	Patch       string `json:"patch"`
	SourceModel string `json:"sourcemodel"`
	TargetModel string `json:"targetmodel"`
	Firmware    string `json:"firmware"`
	Created     int64  `json:"created"`
	Updated     int64  `json:"updated"`
}

type TicketDisplay struct {
	ID           int64  `json:"id" binding:"required"`
	Subject      string `json:"subject" binding:"required"`
	Status       string `json:"status" binding:"required"`
	Version      string `json:"version" binding:"required"`
	Patch        string `json:"patch" binding:"required"`
	SourceModel  string `json:"sourcemodel" binding:"required"`
	TargetModel  string `json:"targetmodel" binding:"required"`
	Created      int64  `json:"created" binding:"required"`
	Updated      int64  `json:"updated" binding:"required"`
	FileServer   string `json:"fileserver" binding:"required"`
	BaseDir      string `json:"basedir" binding:"required"`
	SourceConfig string `json:"sourceconfig" binding:"required"`
	IntfmapFile  string `json:"intfmapfile" binding:"required"`
}

type Joke struct {
	ID    int    `json:"id" binding:"required"`
	Likes int    `json:"likes"`
	Joke  string `json:"joke" binding:"required"`
}

type LOGIN struct {
	ID       string `json:"id" binding:"required"`
	PASSWORD string `json:"password" binding:"required"`
}

type TicketStatusEnum string

const (
	New                      TicketStatusEnum = "New"
	InProgress               TicketStatusEnum = "In Progress"
	PendingCustomerFeedback  TicketStatusEnum = "Pending Customer Feedback"
	ReceivedCustomerFeedback TicketStatusEnum = "Received Customer Feedback"
	OnHold                   TicketStatusEnum = "On Hold"
	ServiceDelivered         TicketStatusEnum = "Service Delivered"
	PendingCloseConfirm      TicketStatusEnum = "Pending Close Confirmation"
	Closed                   TicketStatusEnum = "Closed"
	ReOpened                 TicketStatusEnum = "Re-Opened"
)

type TicketDelivery struct {
	TaskID     int              `json:"taskid" binding:"required"`
	TicketID   int64            `json:"ticketid" binding:"required"`
	ConfigFile string           `json:"configfile" binding:"required"`
	Comments   string           `json:"comments"`
	Status     TicketStatusEnum `json:"status" binding:"required"`
	S3Bucket   string           `json:"s3bucket"`
	S3Key      string           `json:"s3key"`
}

type TicketChangeStatus struct {
	TicketID int64            `json:"ticketid" binding:"required"`
	Status   TicketStatusEnum `json:"status" binding:"required"`
}

type JWTtoken struct {
	TOKEN string `json:"token" binding:"required"`
}

/** we'll create a list of jokes */
var jokes = []Joke{
	{1, 0, "Did you hear about the restaurant on the moon? Great food, no atmosphere."},
	{2, 0, "What do you call a fake noodle? An Impasta."},
	{3, 0, "How many apples grow on a tree? All of them."},
	{4, 0, "Want to hear a joke about paper? Nevermind it's tearable."},
	{5, 0, "I just watched a program about beavers. It was the best dam program I've ever seen."},
	{6, 0, "Why did the coffee file a police report? It got mugged."},
	{7, 0, "How does a penguin build it's house? Igloos it together."},
	{8, 0, "Dad, did you get a haircut? No I got them all cut."},
	{9, 0, "What do you call a Mexican who has lost his car? Carlos."},
	{10, 0, "Dad, can you put my shoes on? No, I don't think they'll fit me."},
	{11, 0, "Why did the scarecrow win an award? Because he was outstanding in his field."},
	{12, 0, "Why don't skeletons ever go trick or treating? Because they have no body to go with."},
}

// LoadConfig reads configuration from file or environment variables.
func LoadConfig(path string) (config Config, err error) {
	viper.AddConfigPath(path)
	viper.SetConfigName("app")
	viper.SetConfigType("env")

	viper.AutomaticEnv()

	err = viper.ReadInConfig()
	if err != nil {
		return
	}

	err = viper.Unmarshal(&config)
	return
}

// Predefined ID and password. (THIS IS THE PROTOTYPE.)
var authID = "admin"     //os.Getenv("USER_ID")
var authPassword = "123" //os.Getenv("USER_PASSWORD")

var db *sql.DB
var config Config

func main() {
	// Initial log output file
	var logfilename string
	logfilename = time.Now().UTC().Format("2006-01-02T15:04:05.999Z") + ".log"
	f, err := os.OpenFile(logfilename, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		log.Fatalf("error opening file: %v", err)
	}
	defer f.Close()

	log.SetFlags(log.LUTC | log.Ldate | log.Ltime | log.Lmicroseconds)
	log.SetOutput(f)
	log.Println("Ticket manager process started....")

	config, err = LoadConfig(".")
	if err != nil {
		log.Fatal("cannot load config:", err)
	} else {
		log.Println("DB_DRIVER", config.DBDriver)
		log.Println("DB_HOST", config.DBHost)
		log.Println("DB_PORT", config.DBPort)
		log.Println("DB_NAME", config.DBName)
		log.Println("DB_USER", config.DBUser)
		log.Println("DB_PASSWD", config.DBPassword)
		log.Println("S3_REGION", config.S3Region)
		log.Println("S3_BUCKET", config.S3Bucket)
		log.Println("SQS_TICKET_QUEUE", config.SQSTicket)
		log.Println("SQS_TICKET_DELIVERY", config.SQSDelivery)
		log.Println("AWS_ACCESS_KEY", config.AWSAccessKey)
		log.Println("AWS_SECRET_KEY", config.AWSSecretKey)
		log.Println("SERVER_ADDRESS", config.ServerAddress)
		log.Println("KAFKA_ENDPOINT", config.KafkaEndpoint)
	}

	// set aws static access key
	os.Setenv("AWS_ACCESS_KEY", config.AWSAccessKey)
	os.Setenv("AWS_SECRET_KEY", config.AWSSecretKey)

	// open postgres database connection
	psqlInfo := fmt.Sprintf("host=%s port=%s user=%s "+
		"password=%s dbname=%s sslmode=disable",
		config.DBHost, config.DBPort, config.DBUser, config.DBPassword, config.DBName)

	db, err = sql.Open("postgres", psqlInfo)
	if err != nil {
		log.Fatal("Failed to open a DB connection: ", err)
	}
	defer db.Close()

	// test kafka topic creation and list
	// kafka producer and consumer routines
	/* createTopic("test-topic")
	listTopics()
	go producer()
	go consumer() */
	createTopic(string(TicketDeliveryTopic))
	go deliveryMsgHander()

	// ticker every minute
	ticker := time.NewTicker(1 * time.Second)
	go tick(ticker)

	// Set the router as the default one shipped with Gin
	router := gin.Default()
	router.Use(CORSMiddleware())

	// Serve the frontend
	router.Use(static.Serve("/", static.LocalFile("./views", true)))

	api := router.Group("/api")
	{
		api.GET("/", func(c *gin.Context) {
			c.JSON(http.StatusOK, gin.H{
				"message": "pong",
			})
		})
		api.GET("/jokes", authMiddleware(), JokeHandler)
		api.POST("/jokes/like/:jokeID", authMiddleware(), LikeJoke)
		api.GET("/tickets", authMiddleware(), listAllTickets)
		api.GET("/tickets/:ticketID", authMiddleware(), getTicketDetail)
		api.POST("/tickets/:ticketID", authMiddleware(), ticketDelivery)
		api.POST("/tickets/:ticketID/changestatus", authMiddleware(), changeTicketStatus)
		api.POST("/auth", auth)
	}
	// Start the app
	router.Run(":4000")
}

func CORSMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "timeZone, timezone, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	}
}

func auth(c *gin.Context) {

	fmt.Println("auth function call")

	var login LOGIN
	c.BindJSON(&login)

	// To-Do: Check ID and password is right or not.
	if authID != login.ID {
		c.Header("Content-Type", "application/json")
		c.JSON(http.StatusBadRequest, "")
		return
	}
	if authPassword != login.PASSWORD {
		c.Header("Content-Type", "application/json")
		c.JSON(http.StatusBadRequest, "")
		return
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"user":      login.ID,
		"timestamp": int32(time.Now().Unix()),
	})

	// Sign and get the complete encoded token as a string using the secret.
	tokenString, err := token.SignedString([]byte(login.PASSWORD))

	if err != nil {
		log.Fatal("Faile to generate signed string.")
	}

	fmt.Println("user : " + login.ID + " / " + "pw : " + login.PASSWORD + "/" + "token string:" + tokenString)

	var jwtToken JWTtoken
	jwtToken = JWTtoken{tokenString}

	c.Header("Content-Type", "application/json")
	c.JSON(http.StatusOK, jwtToken)
}

// authMiddleware intercepts the requests, and check for a valid jwt token
func authMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {

		// Get the JWT token sting in Authorization header.
		var header = c.Request.Header.Get("Authorization")
		fmt.Println("auth : " + header)
		var tokenString = header[7:]

		// Parse and validate JWT token.
		token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
			// Don't forget to validate the alg is what you expect:
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
			}

			// hmacSampleSecret is a []byte containing your secret, e.g. []byte("my_secret_key")
			return []byte(authPassword), nil
		})

		if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
			fmt.Println(claims["user"], claims["timestamp"])
		} else {
			fmt.Println(err)
			c.Abort()
			c.Writer.WriteHeader(http.StatusUnauthorized)
			c.Writer.Write([]byte("Unauthorized"))
			return
		}
	}
}

// JokeHandler returns a list of jokes available (in memory)
func JokeHandler(c *gin.Context) {
	c.Header("Content-Type", "application/json")
	c.JSON(http.StatusOK, jokes)
}

// LikeJoke ...
func LikeJoke(c *gin.Context) {
	// Check joke ID is valid
	if jokeid, err := strconv.Atoi(c.Param("jokeID")); err == nil {
		// find joke and increment likes
		for i := 0; i < len(jokes); i++ {
			if jokes[i].ID == jokeid {
				jokes[i].Likes = jokes[i].Likes + 1
			}
		}
		c.JSON(http.StatusOK, &jokes)
	} else {
		// the jokes ID is invalid
		c.AbortWithStatus(http.StatusNotFound)
	}
}

// getJokesByID returns a single joke
func getJokesByID(id int) (*Joke, error) {
	for _, joke := range jokes {
		if joke.ID == id {
			return &joke, nil
		}
	}
	return nil, errors.New("Joke not found")
}

func getTicketsFilterCommand(parameter map[string][]string) string {

	command := `SELECT id, subject, status, source_model, target_model, sw_version, patch, configfile_path, 
	interfacemappingfile_path, summaryfile_path, created_at, updated_at FROM tickets`

	if len(parameter) > 0 {

		var conditionList []string
		for col, valueList := range parameter {

			dbCol := ""
			for _, colName := range colForQuery {
				if strings.ToLower(col) == colName {
					dbCol = colName
					break
				}
			}
			if len(dbCol) == 0 {
				continue
			}

			var subConditionList []string
			for _, value := range valueList {
				if len(value) == 0 {
					continue
				}

				subConditionList = append(subConditionList, fmt.Sprintf("%s='%s'", col, value))
			}

			subCondition := strings.Join(subConditionList, " OR ")
			if len(valueList) == 1 {
				conditionList = append(conditionList, subCondition)
			} else if len(valueList) > 1 {
				conditionList = append(conditionList, "("+subCondition+")")
			}
		}

		command += " WHERE " + strings.Join(conditionList, " AND ") + ";"
	}

	return command
}

func listAllTickets(c *gin.Context) {
	// debug print out
	fmt.Println("listAllTickets function call")

	c.Header("Content-Type", "application/json")
	// Read all tickets from database
	var displays []TicketDisplay
	var tickets []Ticket
	parameter := c.Request.URL.Query()
	sqlStatement := getTicketsFilterCommand(parameter)
	rows, err := db.Query(sqlStatement)
	if err != nil {
		log.Fatal(err)
		c.Header("Content-Type", "application/json")
		c.JSON(http.StatusBadRequest, "Database error!")
		return
	}
	defer rows.Close()
	for rows.Next() {
		var ticket Ticket
		err := rows.Scan(&ticket.id, &ticket.subject, &ticket.status, &ticket.sourcemodel, &ticket.targetmodel,
			&ticket.version, &ticket.patch, &ticket.configfile, &ticket.intfmapfile, &ticket.summaryfile, &ticket.created, &ticket.updated)
		if err != nil {
			log.Fatal(err)
			c.Header("Content-Type", "application/json")
			c.JSON(http.StatusBadRequest, "Database error!")
			return
		}
		log.Printf("Read ticket %v\n", ticket.id)
		tickets = append(tickets, ticket)

		var display TicketDisplay
		display.ID = ticket.id
		display.Subject = ticket.subject
		display.Version = ticket.version
		display.Patch = ticket.patch
		display.SourceModel = ticket.sourcemodel
		display.TargetModel = ticket.targetmodel
		display.Status = ticket.status
		display.Created = ticket.created
		display.Updated = ticket.updated

		// Extract server ip from path
		parts := strings.Split(ticket.configfile, "/")
		server := parts[0]
		fmt.Println("Server", server)
		display.FileServer = server

		// Extract base dir from path
		parts = parts[1 : len(parts)-1]
		basedir := strings.Join(parts, "/")
		fmt.Println("BaseDir", basedir)
		display.BaseDir = basedir

		// read file name from smb server path
		parts = strings.Split(ticket.configfile, "/")
		file1name := parts[len(parts)-1]
		fmt.Println(file1name, len(parts))
		fmt.Println(parts)
		display.SourceConfig = file1name

		// read file name from smb server path
		parts = strings.Split(ticket.intfmapfile, "/")
		file2name := parts[len(parts)-1]
		fmt.Println(file2name, len(parts))
		fmt.Println(parts)
		display.IntfmapFile = file2name

		displays = append(displays, display)
	}
	err = rows.Err()
	if err != nil {
		log.Fatal(err)
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "Database error!",
		})
	} else {
		c.JSON(http.StatusOK, &displays)
	}
}

func getTicketDetail(c *gin.Context) {
	// Check ticket ID is valid
	if ticketid, err := strconv.Atoi(c.Param("ticketID")); err == nil {
		// find ticket by ticketID
		sqlStatement := `SELECT id, subject, status, source_model, target_model, sw_version, patch, configfile_path, 
						interfacemappingfile_path, summaryfile_path, created_at, updated_at FROM tickets WHERE id=$1;`
		var ticket Ticket
		row := db.QueryRow(sqlStatement, ticketid)
		err := row.Scan(&ticket.id, &ticket.subject, &ticket.status, &ticket.sourcemodel, &ticket.targetmodel, &ticket.version, &ticket.patch,
			&ticket.configfile, &ticket.intfmapfile, &ticket.summaryfile, &ticket.created, &ticket.updated)
		switch err {
		case sql.ErrNoRows:
			c.Header("Content-Type", "application/json")
			c.JSON(http.StatusBadRequest, "")
		case nil:
			log.Println(ticket)
			var display TicketDisplay
			display.ID = ticket.id
			display.Subject = ticket.subject
			display.Version = ticket.version
			display.Patch = ticket.patch
			display.SourceModel = ticket.sourcemodel
			display.TargetModel = ticket.targetmodel
			display.Status = ticket.status
			display.Created = ticket.created
			display.Updated = ticket.updated

			// Extract server ip from path
			parts := strings.Split(ticket.configfile, "/")
			server := parts[0]
			fmt.Println("Server", server)
			display.FileServer = server

			// Extract base dir from path
			fmt.Println(parts)
			parts = parts[1 : len(parts)-1]
			basedir := strings.Join(parts, "/")
			fmt.Println("BaseDir", basedir)
			display.BaseDir = basedir

			// read file name from smb server path
			parts = strings.Split(ticket.configfile, "/")
			file1name := parts[len(parts)-1]
			fmt.Println(file1name, len(parts))
			fmt.Println(parts)
			display.SourceConfig = file1name

			// read file name from smb server path
			parts = strings.Split(ticket.intfmapfile, "/")
			file2name := parts[len(parts)-1]
			fmt.Println(file2name, len(parts))
			fmt.Println(parts)
			display.IntfmapFile = file2name

			c.JSON(http.StatusOK, &display)
		default:
			panic(err)
		}
	} else {
		// the ticket ID is invalid
		c.AbortWithStatus(http.StatusNotFound)
	}
}

func ticketDelivery(c *gin.Context) {
	fmt.Println("deliver config file to service ticket!")
	log.Println("deliver config file to service ticket!")

	var ticketDelivery TicketDelivery
	c.BindJSON(&ticketDelivery)

	// Change ticket status to assigned
	if ticketid, err := strconv.ParseInt(c.Param("ticketID"), 10, 64); err == nil {
		if ticketDelivery.TicketID != ticketid {
			c.AbortWithStatus(http.StatusNotFound)
		} else {
			// find ticket by ticketID
			sqlStatement := `SELECT id, s3_bucket, s3_key FROM tickets WHERE id=$1;`
			var ticket Ticket
			row := db.QueryRow(sqlStatement, ticketid)
			err := row.Scan(&ticket.id, &ticket.s3bucket, &ticket.s3key)
			switch err {
			case sql.ErrNoRows:
				c.AbortWithStatus(http.StatusNotFound)
			case nil:
				ts := time.Now().UnixNano()
				sqlStatement := `UPDATE tickets SET status = $1, updated_at = $2 WHERE id = $3`
				_, err = db.Exec(sqlStatement, string(InProgress), ts/1000000, ticket.id)
				if err != nil {
					panic(err)
				} else {
					// Send ticket delivery to kafka topic
					ticketDelivery.S3Bucket = ticket.s3bucket
					ticketDelivery.S3Key = ticket.s3key
					ticketDelivery.Comments = "Dear Customer, please be noted that your configuration is now delivered."

					var reqjson []byte
					reqjson, err = json.MarshalIndent(ticketDelivery, "", " ")
					if err != nil {
						panic(err)
					}

					err = requestDelivery(reqjson)
					if err != nil {
						// Revert ticket status from "Service Delivered" to "New"
						sqlStatement := `UPDATE tickets SET status = $1, updated_at = $2 WHERE id = $3`
						_, err = db.Exec(sqlStatement, string(New), ts/1000000, ticket.id)
						if err != nil {
							panic(err)
						}
						log.Fatal(err)
					}
				}
			default:
				panic(err)
			}
			c.JSON(http.StatusOK, gin.H{
				"message":  "OK",
				"ticketid": ticket.id,
			})
		}
	} else {
		// the ticket ID is invalid
		c.AbortWithStatus(http.StatusNotFound)
	}
}

func changeTicketStatus(c *gin.Context) {
	fmt.Println("changeTicketStatus function call")
	log.Println("changeTicketStatus function call")

	var changestatus TicketChangeStatus
	c.BindJSON(&changestatus)

	// Change ticket status to assigned
	if ticketid, err := strconv.ParseInt(c.Param("ticketID"), 10, 64); err == nil {
		if changestatus.TicketID != ticketid {
			c.AbortWithStatus(http.StatusNotFound)
		} else {
			// find ticket by ticketID
			sqlStatement := `SELECT id, status FROM tickets WHERE id=$1;`
			var ticket Ticket
			row := db.QueryRow(sqlStatement, ticketid)
			err := row.Scan(&ticket.id, &ticket.status)
			switch err {
			case sql.ErrNoRows:
				c.AbortWithStatus(http.StatusNotFound)
			case nil:
				sqlStatement := `UPDATE tickets SET status = $1 WHERE id = $2`
				_, err = db.Exec(sqlStatement, string(changestatus.Status), ticket.id)
				if err != nil {
					panic(err)
				}
			default:
				panic(err)
			}
			c.JSON(http.StatusOK, gin.H{
				"message": "OK",
			})
		}
	} else {
		// the ticket ID is invalid
		c.AbortWithStatus(http.StatusNotFound)
	}
}

func tick(ticker *time.Ticker) {
	for t := range ticker.C {
		log.Println("Tick at", t)
		ReceiveSQS()
	}
}

func GetQueueURL(sess *session.Session, queue *string) (*sqs.GetQueueUrlOutput, error) {
	// Create an SQS service client
	svc := sqs.New(sess)

	result, err := svc.GetQueueUrl(&sqs.GetQueueUrlInput{
		QueueName: queue,
	})
	if err != nil {
		return nil, err
	}

	return result, nil
}

func GetMessages(sess *session.Session, queueURL *string, timeout *int64) (*sqs.ReceiveMessageOutput, error) {
	// Create an SQS service client
	svc := sqs.New(sess)

	msgResult, err := svc.ReceiveMessage(&sqs.ReceiveMessageInput{
		AttributeNames: []*string{
			aws.String(sqs.MessageSystemAttributeNameSentTimestamp),
		},
		MessageAttributeNames: []*string{
			aws.String(sqs.QueueAttributeNameAll),
		},
		QueueUrl:            queueURL,
		MaxNumberOfMessages: aws.Int64(1),
		VisibilityTimeout:   timeout,
	})
	if err != nil {
		return nil, err
	}

	return msgResult, nil
}

func DeleteMessage(sess *session.Session, queueURL *string, messageHandle *string) error {
	// snippet-start:[sqs.go.delete_message.call]
	svc := sqs.New(sess)

	_, err := svc.DeleteMessage(&sqs.DeleteMessageInput{
		QueueUrl:      queueURL,
		ReceiptHandle: messageHandle,
	})
	// snippet-end:[sqs.go.delete_message.call]
	if err != nil {
		return err
	}

	return nil
}

func ReceiveSQS() {
	// Create a single AWS session (we can re use this if we're uploading many files)
	sess, err := session.NewSession(&aws.Config{Region: aws.String(config.S3Region)})
	if err != nil {
		log.Fatal(err)
	}

	// Get URL of queue
	urlResult, err := GetQueueURL(sess, aws.String(config.SQSTicket))
	if err != nil {
		fmt.Println("Got an error getting the queue URL:")
		fmt.Println(err)
		return
	}

	// snippet-start:[sqs.go.receive_message.url]
	queueURL := urlResult.QueueUrl
	// snippet-end:[sqs.go.receive_message.url]

	var timeout int64
	timeout = 5
	msgResult, err := GetMessages(sess, queueURL, &timeout)
	if err != nil {
		fmt.Println("Got an error receiving messages:")
		fmt.Println(err)
		return
	}

	if len(msgResult.Messages) == 0 {
		log.Println("No ticket available at this time!")
		return
	}

	fmt.Println("Message ID:     " + *msgResult.Messages[0].MessageId)
	fmt.Println("Message Handle: " + *msgResult.Messages[0].ReceiptHandle)

	attrs := make(map[string]string)
	for key, attr := range msgResult.Messages[0].MessageAttributes {
		fmt.Println("key: " + key + " value: " + *attr.StringValue)
		attrs[key] = *attr.StringValue
	}

	var pathoffset int
	pathoffset = len("s3://" + config.S3Bucket + "/")
	fmt.Printf("path offset %d", pathoffset)

	// ticket id
	var ticketid string
	ticketid = attrs["Ticket"]
	fmt.Println("Ticket Attribute: " + ticketid)

	localtmppath := filepath.Join(".", "tickets", ticketid)
	err = os.MkdirAll(localtmppath, os.ModePerm)
	if err != nil {
		log.Printf("Cannot create temporary ticket folder %s", localtmppath)
	} else {
		log.Printf("created temporary ticket folder %s", localtmppath)
	}

	// file 1 - config file
	var configfile string
	configfile = attrs["Config"]
	fmt.Println("Config Attribute: " + configfile)
	configsubstr := configfile[pathoffset:]
	fmt.Println("Config substring: " + configsubstr)

	parts := strings.Split(configsubstr, "/")
	file1name := parts[len(parts)-1]
	fmt.Println(file1name, len(parts))
	fmt.Println(parts)
	savedconfigfile := filepath.Join(localtmppath, parts[len(parts)-1])
	_, err = DownloadFromS3Bucket(savedconfigfile, configsubstr)
	if err != nil {
		log.Println(err)
		return
	}

	// Extract s3 dir from path
	var s3key string
	parts = parts[:len(parts)-1]
	s3key = strings.Join(parts, "/")
	fmt.Println("s3key", s3key)

	// file 2 - interface mapping json file
	var intfmapfile string
	intfmapfile = attrs["InterfaceMapping"]
	fmt.Println("InterfaceMapping Attribute: " + intfmapfile)
	intfmapsubstr := intfmapfile[pathoffset:]
	fmt.Println("InterfaceMapping substring: " + intfmapsubstr)

	parts = strings.Split(intfmapsubstr, "/")
	file2name := parts[len(parts)-1]
	fmt.Println(file2name, len(parts))
	fmt.Println(parts)
	savedintfmapfile := filepath.Join(localtmppath, parts[len(parts)-1])
	_, err = DownloadFromS3Bucket(savedintfmapfile, intfmapsubstr)
	if err != nil {
		log.Println(err)
		return
	}

	// file 3 - summary json file
	var summaryfile string
	summaryfile = attrs["Information"]
	fmt.Println("Information Attribute: " + summaryfile)
	summarysubstr := summaryfile[pathoffset:]
	fmt.Println("Information substring: " + summarysubstr)

	parts = strings.Split(summarysubstr, "/")
	file3name := parts[len(parts)-1]
	fmt.Println(file3name, len(parts))
	fmt.Println(parts)
	savedsummaryfile := filepath.Join(localtmppath, parts[len(parts)-1])
	_, err = DownloadFromS3Bucket(savedsummaryfile, summarysubstr)
	if err != nil {
		log.Println(err)
		return
	}

	// upload file to smb server
	var ret bool
	var file1path, file2path, file3path string
	CreateFolderOnSMBServer(ticketid)
	ret, file1path = UploadFileToSMBServer(file1name, savedconfigfile, ticketid)
	if ret == false {
		log.Println("Upload config file to smb server failed!")
		return
	}
	ret, file2path = UploadFileToSMBServer(file2name, savedintfmapfile, ticketid)
	if ret == false {
		log.Println("Upload interface mapping json file to smb server failed!")
		return
	}
	ret, file3path = UploadFileToSMBServer(file3name, savedsummaryfile, ticketid)
	if ret == false {
		log.Println("Upload summary json file to smb server failed!")
		return
	}

	var summaryjson TicketSummary
	b, err := ioutil.ReadFile(savedsummaryfile) // just pass the file name
	if err != nil {
		fmt.Print(err)
		return
	}
	err = json.Unmarshal(b, &summaryjson)
	if err != nil {
		log.Println(err.Error())
		return
	}
	fmt.Println(summaryjson)

	// insert ticket into postgresql
	var ticket Ticket
	ticket.id, _ = strconv.ParseInt(ticketid, 10, 64)
	ticket.status = string(New)
	ticket.subject = summaryjson.Subject
	ticket.patch = summaryjson.Patch
	ticket.version = summaryjson.Firmware
	ticket.sourcemodel = summaryjson.SourceModel
	ticket.targetmodel = summaryjson.TargetModel
	ticket.created = summaryjson.Created
	ticket.updated = summaryjson.Updated
	ticket.configfile = file1path
	ticket.intfmapfile = file2path
	ticket.summaryfile = file3path
	ticket.s3bucket = config.S3Bucket
	ticket.s3key = s3key
	ret, err = createTicket(ticket)
	if ret == true {
		err = DeleteMessage(sess, queueURL, msgResult.Messages[0].ReceiptHandle)
		if err != nil {
			fmt.Println("Got an error deleting the message:")
			fmt.Println(err)
			panic(err)
		} else {
			fmt.Println("Deleted message from queue with URL " + *queueURL)
		}
	}
}

func createTicket(ticket Ticket) (bool, error) {
	sqlStatement := `SELECT id FROM tickets WHERE id=$1;`
	var record Ticket
	row := db.QueryRow(sqlStatement, ticket.id)
	err := row.Scan(&record.id)
	switch err {
	case sql.ErrNoRows:
		// newly created ticket, insert record and check if ticket status
		sqlStatement := `INSERT INTO tickets (id, subject, status, source_model, target_model, sw_version, patch, configfile_path, 
			interfacemappingfile_path, summaryfile_path, s3_bucket, s3_key, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`
		_, err = db.Exec(sqlStatement, ticket.id, ticket.subject, ticket.status, ticket.sourcemodel, ticket.targetmodel,
			ticket.version, ticket.patch, ticket.configfile, ticket.intfmapfile, ticket.summaryfile, ticket.s3bucket,
			ticket.s3key, ticket.created, ticket.updated)
		if err != nil {
			panic(err)
		}
	case nil:
		log.Println(record)
		log.Fatalf("duplicate service ticket %v", record.id)
		return false, err
	default:
		panic(err)
	}
	return true, nil
}

func CreateFolderOnSMBServer(ticketid string) {
	fmt.Println("CreateFolderOnSMBServer: " + ticketid)
	// smb path
	// smb:\\10.160.10.10\swap\users\FortiConverter\auto-demo\<ticketid>\files
	conn, err := net.Dial("tcp", "10.160.10.10:445")
	if err != nil {
		panic(err)
	}
	defer conn.Close()

	d := &smb2.Dialer{
		Initiator: &smb2.NTLMInitiator{
			User:     "Guest",
			Password: "",
		},
	}

	c, err := d.Dial(conn)
	if err != nil {
		panic(err)
	}
	defer c.Logoff()

	fs, err := c.Mount(`\\10.160.10.10\swap`)
	if err != nil {
		panic(err)
	}
	defer fs.Umount()

	// create folder name - ticketid
	localtmppath := filepath.Join("users", "FortiConverter", "auto-demo", ticketid)
	err = fs.MkdirAll(localtmppath, os.ModePerm)
	if err != nil {
		log.Printf("Cannot create temporary ticket folder %s", localtmppath)
	} else {
		log.Printf("created temporary ticket folder %s", localtmppath)
	}
}

func DownloadFileFromSMBServer(filename string, localfile string, ticketid string) (error, string) {
	fmt.Println("DownloadFileFromSMBServer: " + filename)

	// smb path
	// smb:\\10.160.10.10\swap\users\FortiConverter\auto-demo\<ticketid>\files
	conn, err := net.Dial("tcp", "10.160.10.10:445")
	if err != nil {
		panic(err)
	}
	defer conn.Close()

	d := &smb2.Dialer{
		Initiator: &smb2.NTLMInitiator{
			User:     "Guest",
			Password: "",
		},
	}

	c, err := d.Dial(conn)
	if err != nil {
		panic(err)
	}
	defer c.Logoff()

	fs, err := c.Mount(`\\10.160.10.10\swap`)
	if err != nil {
		panic(err)
	}
	defer fs.Umount()

	sourcefile := filepath.Join("users", "FortiConverter", "auto-demo", ticketid, filename)
	f, err := fs.Open(sourcefile)
	// read input file into byte stream
	b, err := ioutil.ReadAll(f) // just pass the file name
	if err != nil {
		fmt.Print(err)
		log.Print(err)
		return err, ""
	}
	defer f.Close()

	err = ioutil.WriteFile(localfile, b, 0644)
	if err != nil {
		panic(err)
	}

	output := filepath.Join("10.160.10.10/swap", sourcefile)
	log.Printf("Downloaded file from smb://%s", output)
	log.Printf("Local file %s", localfile) // "/home/dzhang/.../ticket_manager/manager/tickets/123456/xxx.conf"
	return nil, localfile
}

func UploadFileToSMBServer(filename string, localfile string, ticketid string) (bool, string) {
	fmt.Println("UploadFileToSMBServer: " + localfile)

	// smb path
	// smb:\\10.160.10.10\swap\users\FortiConverter\auto-demo\<ticketid>\files
	conn, err := net.Dial("tcp", "10.160.10.10:445")
	if err != nil {
		panic(err)
	}
	defer conn.Close()

	d := &smb2.Dialer{
		Initiator: &smb2.NTLMInitiator{
			User:     "Guest",
			Password: "",
		},
	}

	c, err := d.Dial(conn)
	if err != nil {
		panic(err)
	}
	defer c.Logoff()

	fs, err := c.Mount(`\\10.160.10.10\swap`)
	if err != nil {
		panic(err)
	}
	defer fs.Umount()

	createdfile := filepath.Join("users", "FortiConverter", "auto-demo", ticketid, filename)
	f, err := fs.Create(createdfile)
	if err != nil {
		panic(err)
	}
	//defer fs.Remove("hello.txt")
	defer f.Close()

	// read input file into byte stream
	b, err := ioutil.ReadFile(localfile) // just pass the file name
	if err != nil {
		fmt.Print(err)
		return false, ""
	}

	_, err = f.Write(b)
	if err != nil {
		panic(err)
	}

	output := filepath.Join("10.160.10.10/swap", createdfile)
	fmt.Printf("Uploaded file to smb://%s", output)
	return true, output
}

func DownloadFromS3Bucket(savefile string, docPath string) (bool, error) {
	file, err := os.Create(savefile)
	if err != nil {
		log.Println(err)
		return false, err
	}
	defer file.Close()

	sess, _ := session.NewSession(&aws.Config{Region: aws.String(config.S3Region)})
	downloader := s3manager.NewDownloader(sess)
	numBytes, err := downloader.Download(file,
		&s3.GetObjectInput{
			Bucket: aws.String(config.S3Bucket),
			Key:    aws.String(docPath),
		})
	if err != nil {
		log.Println(err)
		return false, err
	}
	log.Println("Downloaded", file.Name(), numBytes, "bytes")
	return true, nil
}

// SendMsg sends a message to an Amazon SQS queue
// Inputs:
//     sess is the current session, which provides configuration for the SDK's service clients
//     queueURL is the URL of the queue
// Output:
//     If success, nil
//     Otherwise, an error from the call to SendMessage
func SendMsg(sess *session.Session, ticketDelivery TicketDelivery, queueURL *string) error {
	// Create an SQS service client
	// snippet-start:[sqs.go.send_message.call]
	svc := sqs.New(sess)

	ticketNum := strconv.FormatInt(ticketDelivery.TicketID, 10)
	msgbody := fmt.Sprintf("Ticket %v delivered", ticketDelivery.TicketID)

	_, err := svc.SendMessage(&sqs.SendMessageInput{
		DelaySeconds: aws.Int64(10),
		MessageAttributes: map[string]*sqs.MessageAttributeValue{
			"Ticket": {
				DataType:    aws.String("Number"),
				StringValue: aws.String(ticketNum),
			},
			"Config": {
				DataType:    aws.String("String"),
				StringValue: aws.String(ticketDelivery.ConfigFile),
			},
			"Comments": {
				DataType:    aws.String("String"),
				StringValue: aws.String(ticketDelivery.Comments),
			},
			"Status": {
				DataType:    aws.String("String"),
				StringValue: aws.String(string(ticketDelivery.Status)),
			},
			"S3Bucket": {
				DataType:    aws.String("String"),
				StringValue: aws.String(string(ticketDelivery.S3Bucket)),
			},
			"S3Key": {
				DataType:    aws.String("String"),
				StringValue: aws.String(string(ticketDelivery.S3Key)),
			},
		},
		MessageBody: aws.String(msgbody),
		QueueUrl:    queueURL,
	})
	// snippet-end:[sqs.go.send_message.call]
	if err != nil {
		return err
	}

	return nil
}

func SendSQS(ticketDelivery TicketDelivery) (error, bool) {
	// Create a single AWS session (we can re use this if we're uploading many files)
	sess, err := session.NewSession(&aws.Config{Region: aws.String(config.S3Region)})
	if err != nil {
		log.Fatal(err)
	}

	// Get URL of queue
	result, err := GetQueueURL(sess, aws.String((config.SQSDelivery)))
	if err != nil {
		fmt.Println("Got an error getting the queue URL:")
		fmt.Println(err)
		return err, false
	}

	queueURL := result.QueueUrl

	err = SendMsg(sess, ticketDelivery, queueURL)
	if err != nil {
		fmt.Println("Got an error sending the message:")
		fmt.Println(err)
		return err, false
	}

	log.Printf("Delivered ticket %v to queue ", ticketDelivery.TicketID)
	return nil, true
}

func UploadToS3Bucket(docName string, s3dstfile string) (bool, error, string) {
	// Create a single AWS session (we can re use this if we're uploading many files)
	sess, err := session.NewSession(&aws.Config{Region: aws.String(config.S3Region)})
	if err != nil {
		log.Fatal(err)
		return false, err, ""
	}

	// Upload file to s3 bucket
	err = AddFileToS3(sess, docName, s3dstfile)
	if err != nil {
		log.Fatal(err)
		return false, err, ""
	}
	return true, nil, "s3://" + config.S3Bucket + "/" + s3dstfile
}

// AddFileToS3 will upload a single file to S3, it will require a pre-built aws session
// and will set file info like content type and encryption on the uploaded file.
func AddFileToS3(s *session.Session, fileName string, targetPath string) error {

	// Open the file for use
	file, err := os.Open(fileName)
	if err != nil {
		return err
	}
	defer file.Close()

	// Get file size and read the file content into a buffer
	fileInfo, _ := file.Stat()
	var size int64 = fileInfo.Size()
	buffer := make([]byte, size)
	file.Read(buffer)

	// Config settings: this is where you choose the bucket, filename, content-type etc.
	// of the file you're uploading.
	_, err = s3.New(s).PutObject(&s3.PutObjectInput{
		Bucket:               aws.String(config.S3Bucket),
		Key:                  aws.String(targetPath),
		ACL:                  aws.String("private"),
		Body:                 bytes.NewReader(buffer),
		ContentLength:        aws.Int64(size),
		ContentType:          aws.String(http.DetectContentType(buffer)),
		ContentDisposition:   aws.String("attachment"),
		ServerSideEncryption: aws.String("AES256"),
	})
	log.Println("Uploaded", file.Name())
	return err
}
