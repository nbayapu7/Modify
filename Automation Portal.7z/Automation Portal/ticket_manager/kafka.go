package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
	kafka "github.com/segmentio/kafka-go"
)

const (
	testGroupID = "test-consumer"
	testTopic   = "test-topic"
)

type KafkaConsumerGroupEnum string

const (
	SchedulerGroupID     KafkaConsumerGroupEnum = "scheduler-consumer"
	DeviceManagerGroupID KafkaConsumerGroupEnum = "device-manager-consumer"
	TicketManagerGroupID KafkaConsumerGroupEnum = "ticket-manager-consumer"
)

type KafkaTopicEnum string

const (
	TicketDeliveryTopic KafkaTopicEnum = "ticket-delivery"
)

func newKafkaWriter(kafkaURL string, topic string) *kafka.Writer {
	return &kafka.Writer{
		Addr:     kafka.TCP(kafkaURL),
		Topic:    topic,
		Balancer: &kafka.LeastBytes{},
	}
}

func producer() {
	log.Println("call producer!")
	writer := newKafkaWriter(config.KafkaEndpoint, testTopic)
	defer writer.Close()
	log.Println("start producing ... !!")
	for i := 0; ; i++ {
		key := fmt.Sprintf("Key-%d", i)
		msg := kafka.Message{
			Key:   []byte(key),
			Value: []byte(fmt.Sprint(uuid.New())),
		}
		err := writer.WriteMessages(context.Background(), msg)
		if err != nil {
			fmt.Println(err)
		} else {
			log.Println("produced", key)
		}
		time.Sleep(1 * time.Second)
	}
}

func getKafkaReader(kafkaURL, topic, groupID string) *kafka.Reader {
	brokers := strings.Split(kafkaURL, ",")
	return kafka.NewReader(kafka.ReaderConfig{
		Brokers:  brokers,
		GroupID:  groupID,
		Topic:    topic,
		MinBytes: 10e3, // 10KB
		MaxBytes: 10e6, // 10MB
	})
}

func consumer() {
	log.Println("start consuming ... !!")
	reader := getKafkaReader(config.KafkaEndpoint, testTopic, testGroupID)
	defer reader.Close()
	for {
		m, err := reader.ReadMessage(context.Background())
		if err != nil {
			log.Fatalln(err)
		}
		log.Printf("message at topic:%v partition:%v offset:%v	%s = %s\n", m.Topic, m.Partition, m.Offset, string(m.Key), string(m.Value))
	}
}

func createTopic(topicname string) (bool, error) {
	// to create topics when auto.create.topics.enable='true'
	conn, err := kafka.DialLeader(context.Background(), "tcp", config.KafkaEndpoint, topicname, 0)
	if err != nil {
		panic(err.Error())
	}
	defer conn.Close()
	return true, nil
}

func listTopics() {
	conn, err := kafka.Dial("tcp", config.KafkaEndpoint)
	if err != nil {
		panic(err.Error())
	}
	defer conn.Close()
	partitions, err := conn.ReadPartitions()
	if err != nil {
		panic(err.Error())
	}

	m := map[string]struct{}{}

	for _, p := range partitions {
		m[p.Topic] = struct{}{}
	}
	for k := range m {
		fmt.Println("topic name: " + k)
	}
}

func requestDelivery(jsondata []byte) error {
	writer := newKafkaWriter(config.KafkaEndpoint, string(TicketDeliveryTopic))
	defer writer.Close()
	msg := kafka.Message{
		Key:   jsondata,
		Value: []byte(fmt.Sprint(uuid.New())),
	}
	err := writer.WriteMessages(context.Background(), msg)
	if err != nil {
		fmt.Println(err)
		return err
	} else {
		log.Println("=========  message sent  =========")
		log.Println(string(jsondata))
		return nil
	}
}

func downloadConfigFile(configfile string, ticketid int64) (error, string) {

	ticketNum := strconv.FormatInt(ticketid, 10)
	localtmppath := filepath.Join(".", "tickets", ticketNum)
	err := os.MkdirAll(localtmppath, os.ModePerm)
	if err != nil {
		log.Printf("Cannot create temporary ticket folder %s", localtmppath)
	} else {
		log.Printf("created temporary ticket folder %s", localtmppath)
	}

	savedconfigfile := filepath.Join(localtmppath, configfile)
	err, _ = DownloadFileFromSMBServer(configfile, savedconfigfile, ticketNum)
	if err != nil {
		log.Fatalln("download config file from smb server returned failure!!!")
		return err, savedconfigfile
	}
	return nil, savedconfigfile
}

func generateRandomInRange(min int, max int) int {
	return rand.Intn(max-min) + min
}

type TaskChangeStatus struct {
	TaskID int    `json:"taskid" binding:"required"`
	Status string `json:"status" binding:"required"`
}

type ServiceEndpointEnum string

const (
	SchedulerEndpoint     ServiceEndpointEnum = "http://127.0.0.1:3000/api"
	TicketManagerEndpoint ServiceEndpointEnum = "http://127.0.0.1:4000/api"
	DeviceManagerEndpoint ServiceEndpointEnum = "http://127.0.0.1:5000/api"
	WorkerServiceEndpoint ServiceEndpointEnum = "http://127.0.0.1:8000"
	ReportServiceEndpoint ServiceEndpointEnum = "http://127.0.0.1:7000"
	ControlPlaneEndpoint  ServiceEndpointEnum = "http://127.0.0.1:8080"
)

func changeTaskStatus(taskid int, status string) error {

	fmt.Println("sending a message from ticket manager to scheduler ...")
	log.Println("sending a message from ticket manager to scheduler ...")
	var taskstatus TaskChangeStatus
	taskstatus.TaskID = taskid
	taskstatus.Status = status

	reqjson, err := json.MarshalIndent(taskstatus, "", " ")
	if err != nil {
		panic(err)
	}

	// Create a Bearer string by appending string access token
	var bearer = "Bearer " + "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lc3RhbXAiOjE2MjE3MDI0MjAsInVzZXIiOiJhZG1pbiJ9.v8s2YlF9RePYloJV1o1bUZG2pOjTbQJ8Fq5lKUgjLu4"

	// Create a new request using http
	url := fmt.Sprintf(string(SchedulerEndpoint)+"/tasks/%v/changestatus", taskid)
	// fmt.Println("http post", url)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(reqjson))

	req.Header.Set("Content-Type", "application/json")

	// add authorization header to the req
	req.Header.Add("Authorization", bearer)

	// Send req using http Client
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Println("Error on response.\n[ERROR] -", err)
		return err
	}
	defer resp.Body.Close()

	log.Println("response Status:", resp.Status)
	log.Println("response Headers:", resp.Header)
	body, _ := ioutil.ReadAll(resp.Body)
	fmt.Println("response Body:", string(body))
	return nil
}

func simulateServiceDelivery(taskid int, ticketid int64) {
	// simulate device preparation process by sleeping random [10 .. 60] time
	n := generateRandomInRange(30, 40)
	time.Sleep(time.Duration(n) * time.Second)

	// Update ticket and task status
	ts := time.Now().UnixNano()
	sqlStatement := `UPDATE tickets SET status = $1, updated_at = $2 WHERE id = $3`
	_, err := db.Exec(sqlStatement, string(ServiceDelivered), ts/1000000, ticketid)
	if err != nil {
		log.Println(err.Error())
	}

	// update task status
	err = changeTaskStatus(taskid, string(ServiceDelivered))
	if err != nil {
		log.Println(err.Error())
	}
}

func deliveryMsgHander() {
	fmt.Println("start delivery message consuming ... !!")
	reader := getKafkaReader(config.KafkaEndpoint, string(TicketDeliveryTopic), string(TicketManagerGroupID))
	defer reader.Close()
	for {
		m, err := reader.ReadMessage(context.Background())
		if err != nil {
			log.Fatalln(err)
		}
		log.Printf("message at topic:%v partition:%v offset:%v	%s = %s\n", m.Topic, m.Partition, m.Offset, string(m.Key), string(m.Value))
		// json message unmarshal and update task status
		var jsonMsg []byte
		jsonMsg = m.Key

		var deliveryMsg TicketDelivery
		err = json.Unmarshal(jsonMsg, &deliveryMsg)
		if err != nil {
			panic(err)
		}

		// Download config file from smb server
		var localfile string
		err, localfile = downloadConfigFile(deliveryMsg.ConfigFile, deliveryMsg.TicketID)
		if err != nil {
			panic(err)
		}

		// Upload config file to S3 bucket
		var targetpath string
		targetpath = fmt.Sprintf("%s/%s", deliveryMsg.S3Key, deliveryMsg.ConfigFile)
		log.Println("upload file ", localfile, "to s3 bucket s3://", deliveryMsg.S3Bucket, "/", targetpath)
		_, err, path := UploadToS3Bucket(localfile, targetpath)
		if err != nil {
			fmt.Printf("Upload config %s to s3 bucket failed!", deliveryMsg.ConfigFile)
		} else {
			log.Printf("Copied %s to s3 bucket %s", localfile, path)
		}

		// Send SQS message
		_, ret := SendSQS(deliveryMsg)
		if ret == true {
			log.Println("ticket delivery done!")
			// update task status to "Ticket Delivering"
			err = changeTaskStatus(deliveryMsg.TaskID, "Ticket Delivering")
			if err != nil {
				log.Println(err.Error())
			}

			// simulate ticket scanner returned the delivery confirmation.
			go simulateServiceDelivery(deliveryMsg.TaskID, deliveryMsg.TicketID)
		} else {
			log.Println("ticket delivery failed!!!")
		}
	}
}
