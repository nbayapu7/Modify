package main

import (
	"bytes"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"github.com/aws/aws-sdk-go/service/sqs"
	_ "github.com/lib/pq"
	"github.com/spf13/viper"
)

type Config struct {
	DBDriver              string `mapstructure:"DB_DRIVER"`
	DBHost                string `mapstructure:"DB_HOST"`
	DBPort                string `mapstructure:"DB_PORT"`
	DBName                string `mapstructure:"DB_NAME"`
	DBUser                string `mapstructure:"DB_USER"`
	DBPassword            string `mapstructure:"DB_PASSWD"`
	S3Region              string `mapstructure:"S3_REGION"`
	S3Bucket              string `mapstructure:"S3_BUCKET"`
	SQSTicketQueueDemo    string `mapstructure:"SQS_TICKET_QUEUE_DEMO"`
	SQSTicketDeliveryDemo string `mapstructure:"SQS_TICKET_DELIVERY_DEMO"`
	SQSTicketQueueTest    string `mapstructure:"SQS_TICKET_QUEUE_TEST"`
	SQSTicketDeliveryTest string `mapstructure:"SQS_TICKET_DELIVERY_TEST"`
	AWSAccessKey          string `mapstructure:"AWS_ACCESS_KEY"`
	AWSSecretKey          string `mapstructure:"AWS_SECRET_KEY"`
	ServicePortalURL      string `mapstructure:"SERVICE_PORTAL_URL"`
	DeliveryEndpoint      string `mapstructure:"DELIVERY_ENDPOINT"`
}

type Ticket struct {
	ID               int64
	subject          string
	sourceDeviceID   int64
	devicesn         string
	ticketStatus     string
	swVersion        string
	patch            string
	interfaceMapping string
	createTime       int64
	updateTime       int64
}

type Device struct {
	ID       int64
	devicesn string
	model    string
}

type TicketAttachment struct {
	ID              int64
	docExt          string
	docName         string
	docPath         string
	docTitle        string
	careID          int64
	type1           string
	model           string
	firmwareVersion string
	configuration   string
	deleted         bool
	createTime      int64
	updateTime      int64
}

type TicketSourceDevice struct {
	ID         int64
	type1      string
	createTime int64
	updateTime int64
}

type TicketQueue struct {
	ID           int64
	ticketStatus string
	createTime   int64
	updateTime   int64
}

type InterfaceMapping struct {
	Type      string `json:"Type"`
	Source    string `json:"source_interface"`
	IP        string `json:"IP"`
	FortiGate string `json:"FortiGate_interface"`
	Access    string `json:"Access"`
}

type TicketSummary struct {
	ID          int64  `json:"id"`
	Subject     string `json:"subject"`
	Patch       string `json:"patch"`
	SourceModel string `json:"sourcemodel"`
	TargetModel string `json:"targetmodel"`
	Firmware    string `json:"firmware"`
	Created     int64  `json:"created"`
	Updated     int64  `json:"updated"`
}

var db *sql.DB
var config Config

// LoadConfig reads configuration from file or environment variables.
func LoadConfig(path string) (config Config, err error) {
	viper.AddConfigPath(path)
	viper.SetConfigName("app")
	viper.SetConfigType("env")

	viper.AutomaticEnv()

	err = viper.ReadInConfig()
	if err != nil {
		return
	}

	err = viper.Unmarshal(&config)
	return
}

func main() {
	// Initial log output file
	var err error
	var logfilename string
	logfilename = time.Now().UTC().Format("2006-01-02T15:04:05.999Z") + ".log"
	f, err := os.OpenFile(logfilename, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		log.Fatalf("error opening file: %v", err)
	}
	defer f.Close()

	log.SetFlags(log.LUTC | log.Ldate | log.Ltime | log.Lmicroseconds)
	log.SetOutput(f)
	log.Println("Ticket scanner process started....")

	config, err = LoadConfig(".")
	if err != nil {
		log.Fatal("cannot load config:", err)
	} else {
		log.Println("DB_DRIVER", config.DBDriver)
		log.Println("DB_HOST", config.DBHost)
		log.Println("DB_PORT", config.DBPort)
		log.Println("DB_NAME", config.DBName)
		log.Println("DB_USER", config.DBUser)
		log.Println("DB_PASSWD", config.DBPassword)
		log.Println("S3_REGION", config.S3Region)
		log.Println("S3_BUCKET", config.S3Bucket)
		log.Println("SQS_TICKET_QUEUE_DEMO", config.SQSTicketQueueDemo)
		log.Println("SQS_TICKET_DELIVERY_DEMO", config.SQSTicketDeliveryDemo)
		log.Println("SQS_TICKET_QUEUE_TEST", config.SQSTicketQueueTest)
		log.Println("SQS_TICKET_DELIVERY_TEST", config.SQSTicketDeliveryTest)
		log.Println("AWS_ACCESS_KEY", config.AWSAccessKey)
		log.Println("AWS_SECRET_KEY", config.AWSSecretKey)
		log.Println("SERVICE_PORTAL_URL", config.ServicePortalURL)
		log.Println("DELIVERY_ENDPOINT", config.DeliveryEndpoint)
	}

	// set aws static access key
	os.Setenv("AWS_ACCESS_KEY", "AKIAXAOXSZ3YQ2VYHQMZ")
	os.Setenv("AWS_SECRET_KEY", "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")

	// open postgres database connection
	psqlInfo := fmt.Sprintf("host=%s port=%s user=%s "+
		"password=%s dbname=%s sslmode=disable",
		config.DBHost, config.DBPort, config.DBUser, config.DBPassword, config.DBName)

	db, err = sql.Open("postgres", psqlInfo)
	if err != nil {
		log.Fatal("Failed to open a DB connection: ", err)
	}
	defer db.Close()

	// ticker every minute
	ticker := time.NewTicker(10 * time.Second)
	go tick(ticker)

	// forever loop for main process, never stop ticker
	for {
		time.Sleep(1 * time.Second)
	}
}

func tick(ticker *time.Ticker) {
	for t := range ticker.C {
		log.Println("Tick at", t)
		ticketRetriever()
		ReceiveSQS(config.SQSTicketDeliveryDemo)
		ReceiveSQS(config.SQSTicketDeliveryTest)
	}
}

func ticketRetriever() {
	// query customer_care table every minute
	now := time.Now()
	count := 5
	then := now.Add(time.Duration(-count) * time.Minute)
	log.Println("Retrieve updated tickets during last 5 minutes: ", then)

	start := then.Unix()

	// retrive all tickets which updated timestamp during last 24hrs
	var tickets []Ticket
	rows, err := db.Query("select id, subject, device_sn, source_device_id, ticket_status, sw_version, patch, interface_mapping, "+
		"create_time, update_time from customer_care where subject is not NULL and interface_mapping is not NULL and update_time >= $1", start*1000)
	if err != nil {
		log.Fatal(err)
	}

	defer rows.Close()
	for rows.Next() {
		var ticket Ticket
		err := rows.Scan(&ticket.ID, &ticket.subject, &ticket.devicesn, &ticket.sourceDeviceID, &ticket.ticketStatus, &ticket.swVersion,
			&ticket.patch, &ticket.interfaceMapping, &ticket.createTime, &ticket.updateTime)
		if err != nil {
			log.Fatal(err)
		}
		log.Println(ticket.ID)
		tickets = append(tickets, ticket)
	}
	err = rows.Err()
	if err != nil {
		log.Fatal(err)
	}

	var filtered []Ticket
	// filter out exist or processed tickets
	for i := 0; i < len(tickets); i++ {
		log.Printf("Process ticket %v with status %s\n", tickets[i].ID, tickets[i].ticketStatus)
		ret, prevStatus := checkTicketQueue(tickets[i])
		if ret == true {
			log.Printf("Ticket %v is newly created, previous ticket status %s, new status %s.\n",
				tickets[i].ID, prevStatus, tickets[i].ticketStatus)
			filtered = append(filtered, tickets[i])
		}
	}

	var fgtTickets []Ticket
	// filter out FGT-FGT tickets
	for i := 0; i < len(filtered); i++ {
		ret, srcDevice := checkTicketSrcDevice(filtered[i])
		log.Printf("Ticket %v is %s migration.\n", filtered[i].ID, srcDevice)
		if ret == true {
			fgtTickets = append(fgtTickets, filtered[i])
		}
	}

	if len(filtered) == 0 || len(fgtTickets) == 0 {
		log.Printf("No eligible ticket found.\n")
	}

	// copy attachment to destination s3 bucket
	for i := 0; i < len(fgtTickets); i++ {
		ticketNum := strconv.FormatInt(fgtTickets[i].ID, 10)
		localtmppath := filepath.Join(".", "tickets", ticketNum)
		err := os.MkdirAll(localtmppath, os.ModePerm)
		if err != nil {
			log.Printf("Cannot create temporary ticket folder %s", localtmppath)
			continue
		} else {
			log.Printf("created temporary ticket folder %s", localtmppath)
		}

		var s3files []string

		// 1st config file - source config
		log.Printf("Copy config for ticket %v.\n", fgtTickets[i].ID)
		var attachment TicketAttachment
		var targetpath string
		var configpath string
		ret, attachment := findTicketAttachment(fgtTickets[i])
		if ret == true {
			savedfile := filepath.Join(localtmppath, attachment.docName)
			targetpath = getTicketFilePath(attachment.careID, attachment.docName)
			log.Printf("Ticket %v with attachment s3 bucket path %s.\n", fgtTickets[i].ID, attachment.docPath)
			ret, configpath = copyTicketAttachment(attachment.careID, attachment.docName, attachment.docPath, savedfile, targetpath)
			if ret == true {
				log.Printf("Success! Ticket %v attachment %s copied over!\n", fgtTickets[i].ID, attachment.docName)
				s3files = append(s3files, configpath)
			}
		} else {
			log.Printf("No eligible config found for ticket %v.\n", fgtTickets[i].ID)
			continue
		}

		// 2nd json file - interface mapping
		var intfs []InterfaceMapping
		var jsontest []byte
		jsontest = []byte(fgtTickets[i].interfaceMapping)
		log.Printf("Copy interface mapping file for ticket %v.\n", fgtTickets[i].ID)
		err = json.Unmarshal(jsontest, &intfs)
		if err != nil {
			panic(err)
		}
		fmt.Println(intfs)

		var intfjson string
		intfjson = "interfacemapping.json"
		mappingpath := filepath.Join(localtmppath, intfjson)
		fmt.Println("Write interface mapping json into this file: " + mappingpath)
		intffile, _ := json.MarshalIndent(intfs, "", " ")

		err = ioutil.WriteFile(mappingpath, intffile, 0644)
		if err != nil {
			panic(err)
		} else {
			targetpath = getTicketFilePath(attachment.careID, intfjson)
			_, err, path := UploadToS3Bucket(mappingpath, targetpath)
			if err != nil {
				fmt.Printf("Upload interfacemapping.json failed!")
			} else {
				log.Printf("Copied %s to s3 bucket %s", mappingpath, path)
				s3files = append(s3files, path)
			}
		}

		// 3rd json file - ticket summary information
		log.Printf("Copy ticket summary file for ticket %v.\n", fgtTickets[i].ID)
		var device Device
		ret, device = findTicketDevice(fgtTickets[i])
		if ret == false {
			log.Printf("No eligible device found for ticket %v.\n", fgtTickets[i].ID)
			continue
		} else {
			var summary TicketSummary
			summary.ID = fgtTickets[i].ID
			summary.Subject = fgtTickets[i].subject
			summary.Patch = fgtTickets[i].patch
			summary.SourceModel = attachment.model
			summary.TargetModel = device.model
			summary.Firmware = fgtTickets[i].swVersion
			summary.Created = fgtTickets[i].createTime
			summary.Updated = fgtTickets[i].updateTime
			fmt.Println(summary)

			var summaryjson string
			summaryjson = "summary.json"
			summarypath := filepath.Join(localtmppath, summaryjson)
			summaryfile, _ := json.MarshalIndent(summary, "", " ")
			err = ioutil.WriteFile(summarypath, summaryfile, 0644)
			if err != nil {
				panic(err)
			} else {
				targetpath = getTicketFilePath(attachment.careID, summaryjson)
				_, err, path := UploadToS3Bucket(summarypath, targetpath)
				if err != nil {
					fmt.Printf("Upload summary.json failed!")
				} else {
					log.Printf("Copied %s to s3 bucket %s", summarypath, path)
					s3files = append(s3files, path)
				}
			}
		}

		// Send new ticket to SQS queue name - converter-ticket-queue
		SendSQS(fgtTickets[i], s3files, config.SQSTicketQueueDemo)
		SendSQS(fgtTickets[i], s3files, config.SQSTicketQueueTest)
	}
}

func checkTicketQueue(ticket Ticket) (bool, string) {
	sqlStatement := `SELECT id, ticket_status, create_time, update_time FROM ticket_queue WHERE id=$1;`
	var record TicketQueue
	row := db.QueryRow(sqlStatement, ticket.ID)
	err := row.Scan(&record.ID, &record.ticketStatus, &record.createTime, &record.updateTime)
	switch err {
	case sql.ErrNoRows:
		// newly created ticket, insert record and check if ticket status
		sqlStatement := `INSERT INTO ticket_queue (id, ticket_status, create_time, update_time) VALUES ($1, $2, $3, $4)`
		_, err = db.Exec(sqlStatement, ticket.ID, ticket.ticketStatus, ticket.createTime, ticket.updateTime)
		if err != nil {
			panic(err)
		}

		if ticket.ticketStatus == "processing" {
			return true, ticket.ticketStatus
		} else {
			return false, ticket.ticketStatus
		}
	case nil:
		log.Println(record)
		// exist ticket, check if ticket status has been changed from init to processing
		if ticket.ticketStatus != record.ticketStatus || ticket.createTime != record.createTime || ticket.updateTime != record.updateTime {
			sqlStatement := `UPDATE ticket_queue SET ticket_status = $1, create_time = $2, update_time = $3 WHERE id = $4`
			_, err = db.Exec(sqlStatement, ticket.ticketStatus, ticket.createTime, ticket.updateTime, ticket.ID)
			if err != nil {
				panic(err)
			}
		}

		if record.ticketStatus == "init" && ticket.ticketStatus == "processing" {
			return true, record.ticketStatus
		} else {
			return false, record.ticketStatus
		}
	default:
		panic(err)
	}
}

func checkTicketSrcDevice(ticket Ticket) (bool, string) {
	sqlStatement := `SELECT id, type, create_time, update_time FROM customer_device WHERE id=$1;`
	var record TicketSourceDevice
	row := db.QueryRow(sqlStatement, ticket.sourceDeviceID)
	err := row.Scan(&record.ID, &record.type1, &record.createTime, &record.updateTime)
	switch err {
	case sql.ErrNoRows:
		log.Println("No rows were returned!")
		return false, ticket.ticketStatus
	case nil:
		log.Println(record)
		// exist ticket, check if ticket status has been changed from init to processing
		if record.type1 == "fortiGate" {
			return true, record.type1
		}
	default:
		panic(err)
	}

	return false, "hmmm. incredible error"
}

func findTicketDevice(ticket Ticket) (bool, Device) {
	sqlStatement := `SELECT id, sn, model FROM customer_device WHERE sn=$1;`
	var record Device
	row := db.QueryRow(sqlStatement, ticket.devicesn)
	err := row.Scan(&record.ID, &record.devicesn, &record.model)
	switch err {
	case sql.ErrNoRows:
		return false, record
	case nil:
		log.Println(record)
		return true, record
	default:
		panic(err)
	}
}

func findTicketAttachment(ticket Ticket) (bool, TicketAttachment) {
	var attachments []TicketAttachment
	rows, err := db.Query("select id, doc_ext, doc_name, doc_path, doc_title, care_id, type, model,"+
		"firmware_version, configuration, deleted from customer_care_attachment where model is NOT NULL and care_id = $1 and deleted = false", ticket.ID)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	for rows.Next() {
		var attachment TicketAttachment
		err := rows.Scan(&attachment.ID, &attachment.docExt, &attachment.docName, &attachment.docPath, &attachment.docTitle,
			&attachment.careID, &attachment.type1, &attachment.model, &attachment.firmwareVersion,
			&attachment.configuration, &attachment.deleted)
		if err != nil {
			log.Fatal(err)
		}
		log.Printf("Ticket %v, with attachment ID %v, file name %s\n", ticket.ID, attachment.ID, attachment.docName)
		attachments = append(attachments, attachment)
	}
	err = rows.Err()
	if err != nil {
		log.Fatal(err)
	}

	// If there are multiple config files submitted, filter out the right one to process
	return decideSourceConfig(attachments)
}

func getUTCYear() int {
	t := time.Now()
	//z, _ := t.Zone()
	//log.Println("ZONE : ", z, " Time : ", t) // local time

	loc, err := time.LoadLocation("UTC")
	if err != nil {
		log.Println(err)
	}
	t.In(loc)
	//log.Println("ZONE : ", loc, " Time : ", t.In(loc)) // UTC
	return t.Year()
}

func getUTCMonth() int {
	t := time.Now()
	//z, _ := t.Zone()
	//log.Println("ZONE : ", z, " Time : ", t) // local time

	loc, err := time.LoadLocation("UTC")
	if err != nil {
		log.Println(err)
	}
	t.In(loc)
	//log.Println("ZONE : ", loc, " Time : ", t.In(loc)) // UTC
	return int(t.Month())
}

func getUTCDay() int {
	t := time.Now()
	//z, _ := t.Zone()
	//log.Println("ZONE : ", z, " Time : ", t) // local time

	loc, err := time.LoadLocation("UTC")
	if err != nil {
		log.Println(err)
	}
	t.In(loc)
	//log.Println("ZONE : ", loc, " Time : ", t.In(loc)) // UTC
	return t.Day()
}

func getTicketFilePath(ticketid int64, filename string) string {
	// upload config file to s3bucket/automation folder
	var year int = getUTCYear()
	var month int = getUTCMonth()
	var day int = getUTCDay()
	return fmt.Sprintf("automation/%v/%02d/%02d/%v/config/%s", year, month, day, ticketid, filename)
}

func copyTicketAttachment(ticketid int64, filename string, s3srcfile string, savefile string, s3dstfile string) (bool, string) {
	log.Printf("Copy ticket %v attachment %s to destination s3 bucket\n", ticketid, filename)
	var err error
	_, err = DownloadFromS3Bucket(savefile, s3srcfile)
	if err != nil {
		log.Println(err)
		return false, ""
	}

	var path string
	_, err, path = UploadToS3Bucket(savefile, s3dstfile)
	if err != nil {
		log.Println(err)
		return false, ""
	} else {
		log.Printf("Copied %s to s3 bucket %s", savefile, path)
		return true, path
	}
}

func decideSourceConfig(attachments []TicketAttachment) (bool, TicketAttachment) {
	var attachment TicketAttachment
	for i := 0; i < len(attachments); i++ {
		attachment = attachments[i]
		if attachment.docTitle == "ConfigSource" && attachment.type1 == "config" {
			return true, attachment
		}
	}
	return false, attachment
}

func DownloadFromS3Bucket(savefile string, docPath string) (bool, error) {
	file, err := os.Create(savefile)
	if err != nil {
		log.Println(err)
		return false, err
	}
	defer file.Close()

	sess, _ := session.NewSession(&aws.Config{Region: aws.String(config.S3Region)})
	downloader := s3manager.NewDownloader(sess)
	numBytes, err := downloader.Download(file,
		&s3.GetObjectInput{
			Bucket: aws.String(config.S3Bucket),
			Key:    aws.String(docPath),
		})
	if err != nil {
		log.Println(err)
		return false, err
	}
	log.Println("Downloaded", file.Name(), numBytes, "bytes")
	return true, nil
}

func UploadToS3Bucket(docName string, s3dstfile string) (bool, error, string) {
	// Create a single AWS session (we can re use this if we're uploading many files)
	sess, err := session.NewSession(&aws.Config{Region: aws.String(config.S3Region)})
	if err != nil {
		log.Fatal(err)
		return false, err, ""
	}

	// Upload file to s3 bucket
	err = AddFileToS3(sess, docName, s3dstfile)
	if err != nil {
		log.Fatal(err)
		return false, err, ""
	}
	return true, nil, "s3://" + config.S3Bucket + "/" + s3dstfile
}

// AddFileToS3 will upload a single file to S3, it will require a pre-built aws session
// and will set file info like content type and encryption on the uploaded file.
func AddFileToS3(s *session.Session, fileName string, targetPath string) error {

	// Open the file for use
	file, err := os.Open(fileName)
	if err != nil {
		return err
	}
	defer file.Close()

	// Get file size and read the file content into a buffer
	fileInfo, _ := file.Stat()
	var size int64 = fileInfo.Size()
	buffer := make([]byte, size)
	file.Read(buffer)

	// Config settings: this is where you choose the bucket, filename, content-type etc.
	// of the file you're uploading.
	_, err = s3.New(s).PutObject(&s3.PutObjectInput{
		Bucket:               aws.String(config.S3Bucket),
		Key:                  aws.String(targetPath),
		ACL:                  aws.String("private"),
		Body:                 bytes.NewReader(buffer),
		ContentLength:        aws.Int64(size),
		ContentType:          aws.String(http.DetectContentType(buffer)),
		ContentDisposition:   aws.String("attachment"),
		ServerSideEncryption: aws.String("AES256"),
	})
	log.Println("Uploaded", file.Name())
	return err
}

// GetQueueURL gets the URL of an Amazon SQS queue
// Inputs:
//     sess is the current session, which provides configuration for the SDK's service clients
//     queueName is the name of the queue
// Output:
//     If success, the URL of the queue and nil
//     Otherwise, an empty string and an error from the call to
func GetQueueURL(sess *session.Session, queue *string) (*sqs.GetQueueUrlOutput, error) {
	// Create an SQS service client
	svc := sqs.New(sess)

	result, err := svc.GetQueueUrl(&sqs.GetQueueUrlInput{
		QueueName: queue,
	})
	if err != nil {
		return nil, err
	}

	return result, nil
}

// SendMsg sends a message to an Amazon SQS queue
// Inputs:
//     sess is the current session, which provides configuration for the SDK's service clients
//     queueURL is the URL of the queue
// Output:
//     If success, nil
//     Otherwise, an error from the call to SendMessage
func SendMsg(sess *session.Session, ticketid int64, path []string, queueURL *string) error {
	// Create an SQS service client
	// snippet-start:[sqs.go.send_message.call]
	svc := sqs.New(sess)

	ticketNum := strconv.FormatInt(ticketid, 10)
	msgbody := fmt.Sprintf("Ticket %v information", ticketid)

	_, err := svc.SendMessage(&sqs.SendMessageInput{
		DelaySeconds: aws.Int64(10),
		MessageAttributes: map[string]*sqs.MessageAttributeValue{
			"Ticket": {
				DataType:    aws.String("Number"),
				StringValue: aws.String(ticketNum),
			},
			"Config": {
				DataType:    aws.String("String"),
				StringValue: aws.String(path[0]),
			},
			"InterfaceMapping": {
				DataType:    aws.String("String"),
				StringValue: aws.String(path[1]),
			},
			"Information": {
				DataType:    aws.String("String"),
				StringValue: aws.String(path[2]),
			},
		},
		MessageBody: aws.String(msgbody),
		QueueUrl:    queueURL,
	})
	// snippet-end:[sqs.go.send_message.call]
	if err != nil {
		return err
	}

	return nil
}

func SendSQS(ticket Ticket, path []string, sqspullticket string) bool {
	// Create a single AWS session (we can re use this if we're uploading many files)
	sess, err := session.NewSession(&aws.Config{Region: aws.String(config.S3Region)})
	if err != nil {
		log.Fatal(err)
	}

	// Get URL of queue
	result, err := GetQueueURL(sess, aws.String(sqspullticket))
	if err != nil {
		fmt.Println("Got an error getting the queue URL:")
		fmt.Println(err)
		return false
	}

	queueURL := result.QueueUrl

	err = SendMsg(sess, ticket.ID, path, queueURL)
	if err != nil {
		fmt.Println("Got an error sending the message:")
		fmt.Println(err)
		return false
	}

	log.Printf("Sent ticket %v to queue ", ticket.ID)
	return true
}

func GetMessages(sess *session.Session, queueURL *string, timeout *int64) (*sqs.ReceiveMessageOutput, error) {
	// Create an SQS service client
	svc := sqs.New(sess)

	msgResult, err := svc.ReceiveMessage(&sqs.ReceiveMessageInput{
		AttributeNames: []*string{
			aws.String(sqs.MessageSystemAttributeNameSentTimestamp),
		},
		MessageAttributeNames: []*string{
			aws.String(sqs.QueueAttributeNameAll),
		},
		QueueUrl:            queueURL,
		MaxNumberOfMessages: aws.Int64(1),
		VisibilityTimeout:   timeout,
	})
	if err != nil {
		return nil, err
	}

	return msgResult, nil
}

func DeleteMessage(sess *session.Session, queueURL *string, messageHandle *string) error {
	// snippet-start:[sqs.go.delete_message.call]
	svc := sqs.New(sess)

	_, err := svc.DeleteMessage(&sqs.DeleteMessageInput{
		QueueUrl:      queueURL,
		ReceiptHandle: messageHandle,
	})
	// snippet-end:[sqs.go.delete_message.call]
	if err != nil {
		return err
	}

	return nil
}

func ReceiveSQS(sqsdelivery string) {
	// Create a single AWS session (we can re use this if we're uploading many files)
	sess, err := session.NewSession(&aws.Config{Region: aws.String(config.S3Region)})
	if err != nil {
		log.Fatal(err)
	}

	// Get URL of queue
	urlResult, err := GetQueueURL(sess, aws.String(sqsdelivery))
	if err != nil {
		fmt.Println("Got an error getting the queue URL:")
		fmt.Println(err)
		return
	}

	// snippet-start:[sqs.go.receive_message.url]
	queueURL := urlResult.QueueUrl
	// snippet-end:[sqs.go.receive_message.url]

	var timeout int64
	timeout = 5
	msgResult, err := GetMessages(sess, queueURL, &timeout)
	if err != nil {
		fmt.Println("Got an error receiving messages:")
		fmt.Println(err)
		return
	}

	if len(msgResult.Messages) == 0 {
		log.Println("No delivery message available at this time!")
		return
	}

	fmt.Println("Message ID:     " + *msgResult.Messages[0].MessageId)
	fmt.Println("Message Handle: " + *msgResult.Messages[0].ReceiptHandle)

	attrs := make(map[string]string)
	for key, attr := range msgResult.Messages[0].MessageAttributes {
		fmt.Println("key: " + key + " value: " + *attr.StringValue)
		attrs[key] = *attr.StringValue
	}

	var pathoffset int
	pathoffset = len("s3://" + config.S3Bucket + "/")
	fmt.Printf("path offset %d", pathoffset)

	// ticket id
	var ticketid string
	ticketid = attrs["Ticket"]
	fmt.Println("Ticket Attribute: " + ticketid)

	localtmppath := filepath.Join(".", "tickets", ticketid)
	err = os.MkdirAll(localtmppath, os.ModePerm)
	if err != nil {
		log.Printf("Cannot create temporary ticket folder %s", localtmppath)
	} else {
		log.Printf("created temporary ticket folder %s", localtmppath)
	}

	// Comments
	var comments string
	comments = attrs["Comments"]
	fmt.Println("Comments Attribute: " + comments)

	// Status
	var status string
	status = attrs["Status"]
	fmt.Println("Status Attribute: " + status)

	// S3 Bucket
	var s3bucketname string
	s3bucketname = attrs["S3Bucket"]
	fmt.Println("S3Bucket Attribute: " + s3bucketname)

	// S3 Key
	var s3key string
	s3key = attrs["S3Key"]
	fmt.Println("S3Key Attribute: " + s3key)

	// file 1 - config file
	var configfile string
	configfile = attrs["Config"]
	fmt.Println("Config Attribute: " + configfile)
	configsubstr := fmt.Sprintf("%s/%s", s3key, configfile)
	fmt.Println("Config Upload Back to S3 folder: s3://", s3bucketname, "/", configsubstr)

	savedconfigfile := filepath.Join(localtmppath, configfile)
	fmt.Println("saved config file to", savedconfigfile)
	_, err = DownloadFromS3Bucket(savedconfigfile, configsubstr)
	if err != nil {
		log.Println(err)
		return
	}

	// Update ticket status
	//ticketNum, err := strconv.ParseInt(ticketid, 10, 64)
	err = deliverConfig(ticketid, savedconfigfile)
	if err != nil {
		log.Fatalln("cannot deliver config to ticket", ticketid)
	} else {
		err = DeleteMessage(sess, queueURL, msgResult.Messages[0].ReceiptHandle)
		if err != nil {
			fmt.Println("Got an error deleting the message:")
			fmt.Println(err)
			panic(err)
		} else {
			fmt.Println("Deleted message from queue with URL " + *queueURL)
		}
	}
}

func deliverConfig(ticketid string, filepath string) error {
	fmt.Println("deliver config to ticket", ticketid, "with filename", filepath)

	//prepare the reader instances to encode
	values := map[string]io.Reader{
		"file": mustOpen(filepath),
	}

	// Send req using http Client
	deliveryURL := fmt.Sprintf("%s/%s", config.ServicePortalURL, config.DeliveryEndpoint)
	err := Upload(ticketid, deliveryURL, values)
	if err != nil {
		log.Println("Call delivery API failure!", err.Error())
	}
	return nil
}

func Upload(ticketid string, url string, values map[string]io.Reader) (err error) {
	// Prepare a form that you will submit to that URL.
	var b bytes.Buffer
	var client *http.Client
	client = &http.Client{}

	w := multipart.NewWriter(&b)
	for key, r := range values {
		var fw io.Writer
		if x, ok := r.(io.Closer); ok {
			defer x.Close()
		}
		// Add an image file
		if x, ok := r.(*os.File); ok {
			if fw, err = w.CreateFormFile(key, x.Name()); err != nil {
				return err
			}
		} else {
			// Add other fields
			if fw, err = w.CreateFormField(key); err != nil {
				return err
			}
		}
		if _, err = io.Copy(fw, r); err != nil {
			return err
		}

	}
	// Don't forget to close the multipart writer.
	// If you don't close it, your request will be missing the terminating boundary.
	w.Close()

	// Now that you have a form, you can submit it to your handler.
	req, err := http.NewRequest("POST", url, &b)
	if err != nil {
		return err
	}
	// Don't forget to set the content type, this will contain the boundary.
	req.Header.Set("Content-Type", w.FormDataContentType())

	// add customized header to the req
	req.Header.Add("id", ticketid)

	// Submit the request
	res, err := client.Do(req)
	if err != nil {
		return err
	}

	// Check the response
	if res.StatusCode != http.StatusOK {
		err = fmt.Errorf("bad status: %s", res.Status)
		return err
	}
	return nil
}

func mustOpen(f string) *os.File {
	r, err := os.Open(f)
	if err != nil {
		panic(err)
	}
	return r
}
