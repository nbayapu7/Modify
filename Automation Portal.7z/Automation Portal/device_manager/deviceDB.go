package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	_ "github.com/lib/pq"
)

type DeviceStatusEnum string

const (
	DeviceIdling    DeviceStatusEnum = "Idling"    // Not using
	DeviceOffline   DeviceStatusEnum = "Offline"   // Unreachable
	DevicePreparing DeviceStatusEnum = "Preparing" // Initiating the device for specified ticket
	DeviceReady     DeviceStatusEnum = "Working"   // Worker is manipulating the device
	DeviceError     DeviceStatusEnum = "Error"     // Error occured
	DeviceOccupied  DeviceStatusEnum = "Occupied"  // Used by others and cannot do automations
)

type Device struct {
	id          int       // device ID
	uuid        uuid.UUID // device UUID
	name        string    // user specified device name
	sn          string    // device SN
	model       string    // device model name
	mgmtIP      string    // management IP
	mgmtIntf    string    // management interface
	mgmtPort    int       // management Port
	telnetPort  int       // telnet port through console server
	tftpPort    int       // port number used to transfer image
	line        int       // line id on console server
	lab         string    // lab name which the device locates in
	status      string    // device working status
	occupant    string    // the one who is currently using this device
	username    string
	password    string
	createdAt   int64
	updatedAt   int64
	description string // description
}

type DeviceDisplay struct {
	ID          int       `json:"id"`
	UUID        uuid.UUID `json:"uuid"`
	Name        string    `json:"name" binding:"required"`
	SN          string    `json:"sn"`
	Model       string    `json:"model" binding:"required"`
	MgmtIP      string    `json:"mgmt_ip" binding:"required"`
	MgmtIntf    string    `json:"mgmt_intf" binding:"required"`
	MgmtPort    int       `json:"mgmt_port" binding:"required"`
	TelnetPort  int       `json:"telnet_port" binding:"required"`
	TftpPort    int       `json:"tftp_port" binding:"required"`
	Line        int       `json:"line" binding:"required"`
	Lab         string    `json:"lab" binding:"required"`
	Status      string    `json:"status"`
	Occupant    string    `json:"occupant"`
	Username    string    `json:"username"`
	Password    string    `json:"password"`
	CreatedAt   int64     `json:"created_at"`
	UpdatedAt   int64     `json:"updated_at"`
	Description string    `json:"description"`
}

var db *sql.DB

func connectToSQL() (*sql.DB, error) {
	// open postgres database connection
	psqlInfo := fmt.Sprintf("host=%s port=%s user=%s "+
		"password=%s dbname=%s sslmode=disable",
		config.DBHost, config.DBPort, config.DBUser, config.DBPassword, config.DBName)
	log.Println("driver", config.DBDriver)
	log.Println("connInfo", psqlInfo)
	return sql.Open(config.DBDriver, psqlInfo)
}

func initializeDBIfNeeded(db *sql.DB) error {

	var rows *sql.Rows
	var err error
	row := db.QueryRow(`SELECT 1 FROM information_schema.tables 
	WHERE table_schema='public' AND table_catalog='postgres' AND table_name='devices'`)
	var result string
	err = row.Scan(&result)
	empty := len(result) == 0
	if err != nil && err != sql.ErrNoRows {
		log.Println(err)
		return err
	}

	if empty {
		_, err = db.Exec(`CREATE TABLE devices (
			id SERIAL PRIMARY KEY,
			uuid VARCHAR(255) DEFAULT '',
			name VARCHAR(100),
			sn VARCHAR(32) DEFAULT '',
			model VARCHAR(16) NULL,
			mgmt_ip VARCHAR(16) NULL,
			mgmt_intf VARCHAR(16) NULL,
			mgmt_port INTEGER NULL,
			telnet_port INTEGER NULL,
			tftp_port INTEGER NULL,
			line INTEGER NULL,
			lab VARCHAR(32) NULL,
			status VARCHAR(32) DEFAULT 'Offline',
			occupant VARCHAR(32) DEFAULT '',
			username VARCHAR(32) DEFAULT 'admin',
			password VARCHAR(32) DEFAULT '',
			created_at BIGINT NULL,
			updated_at BIGINT NULL,
			description VARCHAR(255) DEFAULT '');`)

		if err != nil {
			log.Println(err)
			return err
		}

		log.Println("Device table is created in Postgres.")
	}

	rows, err = db.Query("SELECT * FROM devices")
	if err != nil {
		rows.Close()
		log.Println(err)
		return err
	}

	empty = true
	for rows.Next() {
		empty = false
	}
	rows.Close()

	if empty {
		var labData []byte
		labData, err = ioutil.ReadFile("firewall_device.json")
		var data map[string]map[string]string
		json.Unmarshal([]byte(labData), &data)

		now := getTimeStamp()

		for name, value := range data {
			model := name
			idx := strings.Index(name, "-")
			if idx >= 0 {
				model = name[:idx]
			}

			command := `INSERT INTO devices (uuid, name, model, mgmt_ip, mgmt_intf, mgmt_port, telnet_port, line, tftp_port, lab, created_at, updated_at) 
						VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`
			_, err = db.Exec(command, uuid.New(), name, model, value["ip"], value["interface"], "443", value["port"],
				value["line"], value["img_port"], value["lab"], now, now)
			if err != nil {
				log.Println("Insert device", name, "failed")
			}
		}

		log.Println("Devices in lab QA are inserted.")
	}

	return nil
}

func getTimeStamp() int64 {

	return time.Now().UnixNano() / int64(time.Millisecond)
}

func getDeviceFromDBRow(rows *sql.Rows) []Device {

	var err error
	var foundDeviceList []Device
	for rows.Next() {
		var row Device
		err = rows.Scan(&row.id, &row.uuid, &row.name, &row.sn, &row.model, &row.mgmtIP, &row.mgmtIntf,
			&row.mgmtPort, &row.telnetPort, &row.tftpPort, &row.line, &row.lab,
			&row.status, &row.occupant, &row.username, &row.password, &row.createdAt, &row.updatedAt,
			&row.description)

		if err != nil {
			log.Println("Read row error: ", err)
		} else {
			foundDeviceList = append(foundDeviceList, row)
		}
	}

	return foundDeviceList
}

var colForQuery = [...]string{
	"id",
	"name",
	"sn",
	"model",
	"mgmt_ip",
	"mgmt_intf",
	"mgmt_port",
	"telnet_port",
	"tftp_port",
	"line",
	"lab",
	"status",
	"occupant",
	"username",
	"password",
	"created_at",
	"updated_at",
	"description",
}

func getDeviceFilterCommand(parameter map[string][]string) string {

	command := "SELECT * FROM devices"

	if len(parameter) > 0 {

		var conditionList []string
		for col, valueList := range parameter {

			dbCol := ""
			for _, colName := range colForQuery {
				if strings.ToLower(col) == colName {
					dbCol = colName
					break
				}
			}
			if len(dbCol) == 0 {
				return ""
			}

			var subConditionList []string
			for _, value := range valueList {
				if len(value) == 0 {
					continue
				}

				subConditionList = append(subConditionList, fmt.Sprintf("%s='%s'", col, value))
			}

			subCondition := strings.Join(subConditionList, " OR ")
			if len(valueList) == 1 {
				conditionList = append(conditionList, subCondition)
			} else if len(valueList) > 1 {
				conditionList = append(conditionList, "("+subCondition+")")
			}
		}

		command += " WHERE " + strings.Join(conditionList, " AND ") + ";"
	}

	return command
}

func deviceToDisplay(device *Device) DeviceDisplay {

	var display DeviceDisplay
	display.ID = device.id
	display.UUID = device.uuid
	display.Name = device.name
	display.SN = device.sn
	display.Model = device.model
	display.MgmtIP = device.mgmtIP
	display.MgmtIntf = device.mgmtIntf
	display.MgmtPort = device.mgmtPort
	display.TelnetPort = device.telnetPort
	display.TftpPort = device.tftpPort
	display.Line = device.line
	display.Lab = device.lab
	display.Status = device.status
	display.Occupant = device.occupant
	display.Username = device.username
	display.Password = device.password
	display.CreatedAt = device.createdAt
	display.UpdatedAt = device.updatedAt
	display.Description = device.description
	return display
}

func getDevices(context *gin.Context) {

	fmt.Println("getDevices")
	parameter := context.Request.URL.Query()
	command := getDeviceFilterCommand(parameter)
	if len(command) == 0 {
		log.Println("Invalid parameter.")
		context.JSON(http.StatusBadRequest, gin.H{
			"message": "Invalid parameter.",
		})
		return
	}

	rows, err := db.Query(command)
	defer rows.Close()
	if err != nil {
		log.Println("FAILED to SELECT: ", err)
		context.JSON(http.StatusInternalServerError, "")
		return
	}

	devices := getDeviceFromDBRow(rows)
	var displays []DeviceDisplay
	for i := 0; i < len(devices); i++ {
		display := deviceToDisplay(&devices[i])
		displays = append(displays, display)
	}

	log.Println("Get devices by command: ", command)
	context.JSON(http.StatusOK, &displays)
}

func getDeviceByID(context *gin.Context) {

	id := context.Param("id")
	field := getIDType(id)
	if len(field) == 0 {
		log.Println("Get device failed: invalid ID", id)
		context.JSON(http.StatusNotFound, gin.H{
			"message": "Invalid ID: " + id,
		})
		return
	}

	command := fmt.Sprintf("SELECT * FROM devices WHERE %s='%s'", field, id)
	rows, err := db.Query(command)
	defer rows.Close()
	if err != nil {
		log.Println(err)
		context.JSON(http.StatusInternalServerError, gin.H{"message": err})
		return
	}

	devices := getDeviceFromDBRow(rows)
	if len(devices) > 0 {
		log.Println("Get device", id, "succeeded.")
		display := deviceToDisplay(&devices[0])
		context.JSON(http.StatusOK, &display)
	} else {
		log.Println("Get device failed: device", id, "is not found.")
		context.JSON(http.StatusNotFound, gin.H{"message": fmt.Sprintf("Device %s is not found.", id)})
	}
}

func checkDeviceExistsByID(field string, id string) (bool, error) {

	command := fmt.Sprintf("SELECT 1 FROM devices WHERE %s='%s'", field, id)

	row := db.QueryRow(command)
	var result string
	err := row.Scan(&result)
	exist := len(result) > 0
	if err != nil && err != sql.ErrNoRows {
		return false, err
	}

	return exist, nil
}

func isUUID(id string) bool {

	return len(id) == 36 && id[8] == '-' && id[13] == '-' && id[18] == '-' && id[23] == '-'
}

func getIDType(id string) string {

	if isUUID(id) {
		return "uuid"
	} else if _, err := strconv.Atoi(id); err == nil {
		return "id"
	}
	return ""
}

func isDeviceExisting(id string, action string) (string, string) {

	field := getIDType(id)
	if len(field) == 0 {
		log.Println(action, "device failed: invalid ID", id)
		return field, "Invalid ID: " + id
	}

	exist, err := checkDeviceExistsByID(field, id)
	if err != nil {
		log.Println(err)
		return field, fmt.Sprintf("%s", err)
	}

	if !exist {
		log.Println(action, "device failed: device", id, "is not found.")
		return field, fmt.Sprintf("Device %s is not found.", id)
	}

	return field, ""
}

func deleteDeviceByID(context *gin.Context) {

	id := context.Param("id")
	field, errMsg := isDeviceExisting(id, "Delete")
	if len(errMsg) > 0 {
		context.JSON(http.StatusNotFound, gin.H{"message": errMsg})
		return
	}

	command := fmt.Sprintf("DELETE FROM devices WHERE %s='%s'", field, id)

	_, err := db.Exec(command)
	if err == nil {
		log.Println("Device", id, "is deleted.")
		context.JSON(http.StatusOK, gin.H{
			"message": "OK",
		})
	} else {
		errorMessage := fmt.Sprintln("Failed to delete: ", err)
		log.Println(errorMessage)
		context.JSON(http.StatusInternalServerError, gin.H{"message": errorMessage})
	}
}

func getMissingFieldMessage(newDevice *Device) string {

	var missingField []string
	if len(newDevice.name) == 0 {
		missingField = append(missingField, "name")
	}

	if len(newDevice.model) == 0 {
		missingField = append(missingField, "model")
	}

	if len(newDevice.mgmtIP) == 0 {
		missingField = append(missingField, "management IP")
	}

	if len(newDevice.mgmtIntf) == 0 {
		missingField = append(missingField, "management interface")
	}

	if newDevice.mgmtPort == 0 {
		missingField = append(missingField, "HTTPS port")
	}

	if newDevice.telnetPort == 0 {
		missingField = append(missingField, "telnet port")
	}

	if newDevice.line == 0 {
		missingField = append(missingField, "line")
	}

	if len(newDevice.lab) == 0 {
		missingField = append(missingField, "lab")
	}

	if len(missingField) == 0 {
		return ""
	} else if len(missingField) == 1 {
		return "The following fields cannot be empty: " + missingField[0] + "."
	} else {
		lastIdx := len(missingField) - 1
		return "The following fields cannot be empty: " +
			strings.Join(missingField[:lastIdx], ", ") + " and " + missingField[lastIdx] + "."
	}
}

func editDeviceByID(context *gin.Context) {

	id := context.Param("id")
	field, errMsg := isDeviceExisting(id, "Edit")
	if len(errMsg) > 0 {
		context.JSON(http.StatusNotFound, gin.H{"message": errMsg})
		return
	}

	var devicereq DeviceDisplay
	context.BindJSON(&devicereq)
	device := displayToDevice(&devicereq)

	missingFieldMessage := getMissingFieldMessage(&device)
	if len(missingFieldMessage) > 0 {
		log.Println("Edit device", id, "failed:", missingFieldMessage)
		context.JSON(http.StatusBadRequest, gin.H{
			"message": missingFieldMessage,
		})
		return
	}

	command := fmt.Sprintf(`UPDATE devices SET name='%s', sn='%s', model='%s', mgmt_ip='%s', mgmt_intf='%s', mgmt_port='%d', telnet_port='%d', tftp_port='%d',
		line='%d', lab='%s', username='%s', password='%s', updated_at='%d', description='%s' WHERE %s='%s'`,
		device.name, device.sn, device.model, device.mgmtIP, device.mgmtIntf, device.mgmtPort, device.telnetPort, device.tftpPort, device.line, device.lab,
		device.username, device.password, getTimeStamp(), device.description, field, id)

	_, err := db.Exec(command)
	if err == nil {
		log.Println("Updated device", id)
		context.JSON(http.StatusOK, gin.H{
			"message": "OK",
		})
	} else {
		log.Println(err)
		context.JSON(http.StatusInternalServerError, gin.H{"message": err})
	}
}

func changeDeviceStatus(context *gin.Context) {

	id := context.Param("id")
	field, errMsg := isDeviceExisting(id, "Edit")
	if len(errMsg) > 0 {
		context.JSON(http.StatusNotFound, gin.H{"message": errMsg})
		return
	}

	mapBody := make(map[string]string)
	context.BindJSON(&mapBody)
	newStatus, ok := mapBody["status"]
	if ok {
		if len(newStatus) > 1 {
			newStatus = strings.ToUpper(newStatus[:1]) + strings.ToLower(newStatus[1:])
		}

		if newStatus != string(DeviceIdling) && newStatus != string(DeviceOffline) && newStatus != string(DevicePreparing) &&
			newStatus != string(DeviceReady) && newStatus != string(DeviceError) && newStatus != string(DeviceOccupied) {
			context.JSON(http.StatusBadRequest, gin.H{
				"message": "Improper status.",
			})
			return
		}

		command := fmt.Sprintf("UPDATE devices SET status='%s' WHERE %s='%s'", newStatus, field, id)

		_, err := db.Exec(command)
		if err == nil {
			log.Println("Updated device", id)
			context.JSON(http.StatusOK, gin.H{
				"message": "OK",
			})
		} else {
			log.Println(err)
			context.JSON(http.StatusInternalServerError, gin.H{"message": err})
		}

	} else {
		context.JSON(http.StatusBadRequest, gin.H{
			"message": "Should contain device status in request body.",
		})
	}
}

func changeDeviceOccupant(context *gin.Context) {

	id := context.Param("id")
	field, errMsg := isDeviceExisting(id, "Edit")
	if len(errMsg) > 0 {
		context.JSON(http.StatusNotFound, gin.H{"message": errMsg})
		return
	}

	mapBody := make(map[string]string)
	context.BindJSON(&mapBody)
	newOccupant, ok := mapBody["occupant"]
	if ok {
		command := fmt.Sprintf("UPDATE devices SET occupant='%s' WHERE %s='%s'", newOccupant, field, id)

		_, err := db.Exec(command)
		if err == nil {
			log.Println("Updated device", id)
			context.JSON(http.StatusOK, gin.H{
				"message": "OK",
			})
		} else {
			log.Println(err)
			context.JSON(http.StatusInternalServerError, gin.H{"message": err})
		}

	} else {
		context.JSON(http.StatusBadRequest, gin.H{
			"message": "Should contain occupant in request body.",
		})
	}
}

func displayToDevice(devicereq *DeviceDisplay) Device {

	var device Device
	device.name = devicereq.Name
	if devicereq.SN == "" {
		device.sn = "FGT61FTK19000013"
	} else {
		device.sn = devicereq.SN
	}

	device.model = devicereq.Model
	device.mgmtIP = devicereq.MgmtIP
	device.mgmtIntf = devicereq.MgmtIntf
	device.mgmtPort = devicereq.MgmtPort
	device.telnetPort = devicereq.TelnetPort
	device.tftpPort = devicereq.TftpPort
	device.line = devicereq.Line
	device.lab = devicereq.Lab
	device.status = string(DeviceOffline)
	device.occupant = devicereq.Occupant
	if devicereq.Username == "" {
		device.username = "admin"
	} else {
		device.username = devicereq.Username
	}

	// for demo only, test device 61f, default username is admin, password is fortinet
	if devicereq.Password == "" {
		device.password = "fortinet"
	} else {
		device.password = devicereq.Password
	}

	device.createdAt = devicereq.CreatedAt
	device.updatedAt = devicereq.UpdatedAt
	device.description = devicereq.Description

	return device
}

func updateDeviceStatus(device *Device) {

	if device.status == string(DeviceIdling) || device.status == string(DeviceOffline) {
		telnetDevice := NewTelnetDevice(device.lab, device.telnetPort)
		command := ""
		if telnetDevice.isAccessable() {
			command = fmt.Sprintf("UPDATE devices SET status='Idling' WHERE ID='%d' AND status='Offline'", device.id)
		} else {
			log.Printf("Device %s is offline\n", device.name)
			command = fmt.Sprintf("UPDATE devices SET status='Offline' WHERE ID='%d' AND status='Idling'", device.id)
		}

		db.Exec(command)
	}
}

func updateAllDeviceStatus() {

	parameter := map[string][]string{}
	parameter["status"] = append(parameter["status"], "Idling", "Offline")
	command := getDeviceFilterCommand(parameter)

	rows, err := db.Query(command)
	if err != nil {
		log.Println("FAILED to SELECT: ", err)
		return
	}
	defer rows.Close()

	devices := getDeviceFromDBRow(rows)
	for _, device := range devices {
		updateDeviceStatus(&device)
	}
}

func createDevice(context *gin.Context) {
	var devicereq DeviceDisplay
	context.BindJSON(&devicereq)
	device := displayToDevice(&devicereq)

	missingFieldMessage := getMissingFieldMessage(&device)
	if len(missingFieldMessage) > 0 {
		log.Println("Create device failed:", missingFieldMessage)
		context.JSON(http.StatusBadRequest, gin.H{
			"message": missingFieldMessage,
		})
		return
	}

	now := getTimeStamp()
	// insert new task into datebase tasks table
	sqlStatement := `INSERT INTO devices (uuid, name, sn, model, mgmt_ip, mgmt_intf, mgmt_port, telnet_port, tftp_port, line, lab, status,
			username, password, created_at, updated_at, description) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17) 
			RETURNING id`
	row := db.QueryRow(sqlStatement, uuid.New(), device.name, device.sn, device.model, device.mgmtIP, device.mgmtIntf, device.mgmtPort, device.telnetPort,
		device.tftpPort, device.line, device.lab, device.status, device.username, device.password, now, now, device.description)
	err := row.Scan(&device.id)
	switch err {
	case sql.ErrNoRows:
		context.Header("Content-Type", "application/json")
		context.JSON(http.StatusBadRequest, "")
	case nil:
		log.Println("Inserted device", device.id)
		updateDeviceStatus(&device)
		// Return http 200 success to the control plane
		context.JSON(http.StatusOK, gin.H{
			"message":  "OK",
			"deviceID": device.id,
		})
	default:
		panic(err)
	}
}
