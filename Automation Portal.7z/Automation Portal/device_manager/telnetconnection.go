package main

import (
	"fmt"
	"strings"
	"time"

	"bufio"
	"bytes"
	"errors"
	"io"
	"log"
	"net"

	"github.com/reiver/go-oi"
)

var (
	errCorrupted          = errors.New("Corrupted")
	errOverflow           = errors.New("Overflow")
	errPartialIACIACWrite = errors.New("Partial IAC IAC write.")
)

var iaciac []byte = []byte{255, 255}

type internalDataReader struct {
	wrapped  io.Reader
	buffered *bufio.Reader
}

func newDataReader(r io.Reader) *internalDataReader {
	buffered := bufio.NewReader(r)

	reader := internalDataReader{
		wrapped:  r,
		buffered: buffered,
	}

	return &reader
}

func (r *internalDataReader) Read(data []byte) (n int, err error) {

	const IAC = 255

	const SB = 250
	const SE = 240

	const WILL = 251
	const WONT = 252
	const DO = 253
	const DONT = 254

	p := data

	for len(p) > 0 {
		var b byte

		b, err = r.buffered.ReadByte()
		if nil != err {
			return n, err
		}

		if IAC == b {
			var peeked []byte

			peeked, err = r.buffered.Peek(1)
			if nil != err {
				return n, err
			}

			switch peeked[0] {
			case WILL, WONT, DO, DONT:
				_, err = r.buffered.Discard(2)
				if nil != err {
					return n, err
				}
			case IAC:
				p[0] = IAC
				n++
				p = p[1:]

				_, err = r.buffered.Discard(1)
				if nil != err {
					return n, err
				}
			case SB:
				for {
					var b2 byte
					b2, err = r.buffered.ReadByte()
					if nil != err {
						return n, err
					}

					if IAC == b2 {
						peeked, err = r.buffered.Peek(1)
						if nil != err {
							return n, err
						}

						if IAC == peeked[0] {
							_, err = r.buffered.Discard(1)
							if nil != err {
								return n, err
							}
						}

						if SE == peeked[0] {
							_, err = r.buffered.Discard(1)
							if nil != err {
								return n, err
							}
							break
						}
					}
				}
			case SE:
				_, err = r.buffered.Discard(1)
				if nil != err {
					return n, err
				}
			default:
				// If we get in here, this is not following the TELNET protocol.
				//@TODO: Make a better error.
				err = errCorrupted
				return n, err
			}
		} else {

			p[0] = b
			n++
			p = p[1:]
		}
	}

	return n, nil
}

type internalDataWriter struct {
	wrapped io.Writer
}

func newDataWriter(w io.Writer) *internalDataWriter {
	writer := internalDataWriter{
		wrapped: w,
	}

	return &writer
}

func (w *internalDataWriter) Write(data []byte) (n int, err error) {
	var n64 int64

	n64, err = w.write64(data)
	n = int(n64)
	if int64(n) != n64 {
		panic(errOverflow)
	}

	return n, err
}

func (w *internalDataWriter) write64(data []byte) (n int64, err error) {

	if len(data) <= 0 {
		return 0, nil
	}

	const IAC = 255

	var buffer bytes.Buffer
	for _, datum := range data {

		if IAC == datum {

			if buffer.Len() > 0 {
				var numWritten int64

				numWritten, err = oi.LongWrite(w.wrapped, buffer.Bytes())
				n += numWritten
				if nil != err {
					return n, err
				}
				buffer.Reset()
			}

			var numWritten int64
			//@TODO: Should we worry about "iaciac" potentially being modified by the .Write()?
			numWritten, err = oi.LongWrite(w.wrapped, iaciac)
			if int64(len(iaciac)) != numWritten {
				//@TODO: Do we really want to panic() here?
				panic(errPartialIACIACWrite)
			}
			n += 1
			if nil != err {
				return n, err
			}
		} else {
			buffer.WriteByte(datum) // The returned error is always nil, so we ignore it.
		}
	}

	if buffer.Len() > 0 {
		var numWritten int64
		numWritten, err = oi.LongWrite(w.wrapped, buffer.Bytes())
		n += numWritten
	}

	return n, err
}

type Conn struct {
	conn interface {
		Read(b []byte) (n int, err error)
		Write(b []byte) (n int, err error)
		SetReadDeadline(t time.Time) error
		Close() error
	}
	dataReader *internalDataReader
	dataWriter *internalDataWriter
}

func DialTo(addr string) (*Conn, error) {

	const network = "tcp"

	if "" == addr {
		addr = "127.0.0.1:telnet"
	}

	conn, err := net.Dial(network, addr)
	if nil != err {
		return nil, err
	}

	dataReader := newDataReader(conn)
	dataWriter := newDataWriter(conn)

	clientConn := Conn{
		conn:       conn,
		dataReader: dataReader,
		dataWriter: dataWriter,
	}

	return &clientConn, nil
}

func (clientConn *Conn) Close() error {
	return clientConn.conn.Close()
}

func (clientConn *Conn) SetReadDeadline(time time.Time) {
	clientConn.conn.SetReadDeadline(time)
}

func (clientConn *Conn) Read(p []byte) (n int, err error) {
	return clientConn.dataReader.Read(p)
}

func (clientConn *Conn) Write(p []byte) (n int, err error) {
	return clientConn.dataWriter.Write(p)
}

type TelnetDevice struct {
	host string
	port string
	tn   *Conn
}

func NewTelnetDevice(lab string, port int) *TelnetDevice {

	device := &TelnetDevice{}
	if lab == "qa" {
		device.host = "10.65.2.28"
	} else if lab == "qa2" {
		device.host = "10.160.16.3"
	}

	device.port = fmt.Sprintf("%d", port)

	return device
}

func (device *TelnetDevice) commandOutputUntil(command string, text string, timeout int) string {

	var n int
	var err error
	if len(command) > 0 {
		n, err = device.tn.Write([]byte(command))
		if err != nil {
			log.Println(err)
		}
	}

	p := make([]byte, 100)

	outputString := ""
	singleOutput := ""
	timeoutTime := time.Now().Add(time.Duration(timeout) * time.Second)

	for strings.Index(singleOutput, text) < 0 && timeoutTime.After(time.Now()) {

		deadlineTime := time.Now().Add(100 * time.Millisecond)
		device.tn.SetReadDeadline(deadlineTime)

		n, err = device.tn.Read(p)
		if err != nil && !isTimeoutError(err) {
			log.Println(err)
		}

		singleOutput = string(p[0:n])
		outputString += singleOutput
	}

	return outputString
}

func (device *TelnetDevice) CommandOutputEager(command string, timeout int) string {

	if len(command) > 0 {
		device.tn.Write([]byte(command))
	}

	output := make([]byte, 100)
	time.Sleep(time.Second) // Wait added to first print everything on console and then do a telnet read
	deadlineTime := time.Now().Add(time.Second)
	device.tn.SetReadDeadline(deadlineTime)
	_, err := device.tn.Read(output)
	if err != nil && !isTimeoutError(err) {
		log.Println(err)
	}
	return string(output)
}

func (device *TelnetDevice) CommandOutputStandard(command string) string {

	return device.commandOutputUntil(command+"\n", "#", 5)
}

func (device *TelnetDevice) ConnectDevice(port int) {
	var err error
	if len(device.port) > 0 {
		log.Println("******Connecting to the firewall  " + device.host + ":" + device.port + "...******")
		device.tn, err = DialTo(device.host + ":" + device.port)
		if err != nil {
			log.Println(err)
		}

	} else {
		log.Printf("******Connecting to the terminal Server %s...******", device.host)
		//device.tn, _ = telnet.DialTo(device.host + ":23")
	}

	log.Print(device.commandOutputUntil("\n\n", "login:", 5))
	device.tn.Close()
}

func (device *TelnetDevice) isAccessable() bool {

	var err error
	device.tn, err = DialTo(device.host + ":" + device.port)
	if err != nil {
		return false
	}

	output := device.commandOutputUntil("\n", "login:", 1)
	if len(output) == 0 {
		output = device.commandOutputUntil("\n", "login:", 1)
	}
	device.tn.Close()

	return strings.Index(output, "login:") >= 0 || strings.Index(output, "#") >= 0
}

func isTimeoutError(err error) bool {
	neterr, ok := err.(net.Error)
	return ok && neterr.Timeout()
}
