package main

import (
	"fmt"
	"log"
	"os"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
)

type Config struct {
	DBDriver      string `mapstructure:"DB_DRIVER"`
	DBHost        string `mapstructure:"DB_HOST"`
	DBPort        string `mapstructure:"DB_PORT"`
	DBName        string `mapstructure:"DB_NAME"`
	DBUser        string `mapstructure:"DB_USER"`
	DBPassword    string `mapstructure:"DB_PASSWD"`
	ServerAddress string `mapstructure:"SERVER_ADDRESS"`
	KafkaEndpoint string `mapstructure:"KAFKA_ENDPOINT"`
}

var config Config

// LoadConfig reads configuration from file or environment variables.
func LoadConfig(path string) (config Config, err error) {
	viper.AddConfigPath(path)
	viper.SetConfigName("app")
	viper.SetConfigType("env")

	viper.AutomaticEnv()

	err = viper.ReadInConfig()
	if err != nil {
		return
	}

	err = viper.Unmarshal(&config)
	return
}

func main() {

	var err error
	var logfilename string
	logfilename = time.Now().UTC().Format("2006-01-02.150405") + ".log"
	f, err := os.OpenFile(logfilename, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		log.Fatalf("error opening file: %v", err)
	}
	defer f.Close()

	log.SetFlags(log.LUTC | log.Ldate | log.Ltime | log.Lmicroseconds)
	log.SetOutput(f)
	log.Println("Device manager process started....")

	config, err = LoadConfig(".")
	if err != nil {
		log.Fatal("cannot load config:", err)
	} else {
		log.Println("DB_DRIVER", config.DBDriver)
		log.Println("DB_HOST", config.DBHost)
		log.Println("DB_PORT", config.DBPort)
		log.Println("DB_NAME", config.DBName)
		log.Println("DB_USER", config.DBUser)
		log.Println("DB_PASSWD", config.DBPassword)
		log.Println("SERVER_ADDRESS", config.ServerAddress)
	}

	db, err = connectToSQL()
	if err != nil {
		fmt.Println("Failed to open a DB connection: ", err)
		return
	}
	defer db.Close()

	err = initializeDBIfNeeded(db)
	if err != nil {
		fmt.Println("Failed to initialize the DB: ", err)
		return
	}

	// kafka message handler
	go schedulerMsgHander()
	go deviceMonitor()

	server := gin.Default()
	server.Use(CORSMiddleware())

	api := server.Group("/api")
	{
		api.GET("/devices/:id", getDeviceByID)
		api.DELETE("/devices/:id", deleteDeviceByID)
		api.PUT("/devices/:id/changestatus", changeDeviceStatus)
		api.PUT("/devices/:id/changeoccupant", changeDeviceOccupant)
		api.PUT("/devices/:id", editDeviceByID)
		api.GET("/devices", getDevices)
		api.POST("/devices/new", createDevice)
	}

	fmt.Println("Gin server starts!")
	server.Run(config.ServerAddress)
}

func deviceMonitor() {

	ticker := time.NewTicker(1 * time.Minute)
	for t := range ticker.C {
		log.Println("Device monitor wakes up at:", t)
		updateAllDeviceStatus()
		log.Println("Device update finished.")
	}
}

func CORSMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "timeZone, timezone, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	}
}
