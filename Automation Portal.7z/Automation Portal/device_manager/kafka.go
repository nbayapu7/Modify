package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/hirochachacha/go-smb2"
	kafka "github.com/segmentio/kafka-go"
)

const (
	testGroupID = "test-consumer"
	testTopic   = "test-topic"
)

type KafkaConsumerGroupEnum string

const (
	SchedulerGroupID     KafkaConsumerGroupEnum = "scheduler-consumer"
	DeviceManagerGroupID KafkaConsumerGroupEnum = "device-manager-consumer"
)

type KafkaTopicEnum string

const (
	SchedulerDeviceTopic KafkaTopicEnum = "scheduler-device"
	DeviceSchedulerTopic KafkaTopicEnum = "device-scheduler"
)

type TaskStatusEnum string

const (
	DevicePending    TaskStatusEnum = "Device - Pending"
	DeviceInProgress TaskStatusEnum = "Device - In Progress"
	DeviceCompleted  TaskStatusEnum = "Device - Completed"
	WorkerInProgress TaskStatusEnum = "Worker - In Progress"
	WorkerCompleted  TaskStatusEnum = "Worker - Completed"
	DeviceFailed     TaskStatusEnum = "Device - Failed"
	DeviceRetry      TaskStatusEnum = "Device - Retry"
	WorkerFailed     TaskStatusEnum = "Worker - Failed"
	WorkerRetry      TaskStatusEnum = "Worker - Retry"
)

type DeviceRequest struct {
	TaskID       int       `json:"task_id" binding:"required"`
	TaskUUID     uuid.UUID `json:"task_uuid" binding:"required"`
	DeviceID     int       `json:"device_id" binding:"required"`
	DeviceUUID   uuid.UUID `json:"device_uuid" binding:"required"`
	TicketID     int64     `json:"ticket_id" binding:"required"`
	Status       string    `json:"status" binding:"required"`
	TargetModel  string    `json:"target_model" binding:"required"`
	Version      string    `json:"version" binding:"required"`
	Patch        string    `json:"patch" binding:"required"`
	FileServer   string    `json:"file_server" binding:"required"`
	BaseDir      string    `json:"base_dir" binding:"required"`
	SourceConfig string    `json:"source_config" binding:"required"`
}

type DeviceReply struct {
	TaskID        int       `json:"task_id" binding:"required"`
	TaskUUID      uuid.UUID `json:"task_uuid" binding:"required"`
	DeviceID      int       `json:"device_id" binding:"required"`
	DeviceUUID    uuid.UUID `json:"device_uuid" binding:"required"`
	Status        string    `json:"status" binding:"required"`
	Host          string    `json:"host" binding:"required"`
	Interface     string    `json:"interface" binding:"required"`
	Username      string    `json:"username" binding:"required"`
	Password      string    `json:"password" binding:"required"`
	HttpsPort     int       `json:"https" binding:"required"`
	FileServer    string    `json:"file_server" binding:"required"`
	BaseDir       string    `json:"base_dir" binding:"required"`
	DefaultConfig string    `json:"default_config" binding:"required"`
	SourceConfig  string    `json:"source_config" binding:"required"`
}

func newKafkaWriter(kafkaURL string, topic string) *kafka.Writer {
	return &kafka.Writer{
		Addr:     kafka.TCP(kafkaURL),
		Topic:    topic,
		Balancer: &kafka.LeastBytes{},
	}
}

func producer() {
	fmt.Println("call producer!")
	writer := newKafkaWriter(config.KafkaEndpoint, testTopic)
	defer writer.Close()
	fmt.Println("start producing ... !!")
	for i := 0; ; i++ {
		key := fmt.Sprintf("Key-%d", i)
		msg := kafka.Message{
			Key:   []byte(key),
			Value: []byte(fmt.Sprint(uuid.New())),
		}
		err := writer.WriteMessages(context.Background(), msg)
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println("produced", key)
		}
		time.Sleep(1 * time.Second)
	}
}

func getKafkaReader(kafkaURL, topic, groupID string) *kafka.Reader {
	brokers := strings.Split(kafkaURL, ",")
	return kafka.NewReader(kafka.ReaderConfig{
		Brokers:  brokers,
		GroupID:  groupID,
		Topic:    topic,
		MinBytes: 10e3, // 10KB
		MaxBytes: 10e6, // 10MB
	})
}

func consumer() {
	fmt.Println("start consuming ... !!")
	reader := getKafkaReader(config.KafkaEndpoint, testTopic, testGroupID)
	defer reader.Close()
	for {
		m, err := reader.ReadMessage(context.Background())
		if err != nil {
			log.Fatalln(err)
		}
		fmt.Printf("message at topic:%v partition:%v offset:%v	%s = %s\n", m.Topic, m.Partition, m.Offset, string(m.Key), string(m.Value))
	}
}

func createTopic(topicname string) (bool, error) {
	// to create topics when auto.create.topics.enable='true'
	conn, err := kafka.DialLeader(context.Background(), "tcp", config.KafkaEndpoint, topicname, 0)
	if err != nil {
		panic(err.Error())
	}
	defer conn.Close()
	return true, nil
}

func listTopics() {
	conn, err := kafka.Dial("tcp", config.KafkaEndpoint)
	if err != nil {
		panic(err.Error())
	}
	defer conn.Close()
	partitions, err := conn.ReadPartitions()
	if err != nil {
		panic(err.Error())
	}

	m := map[string]struct{}{}

	for _, p := range partitions {
		m[p.Topic] = struct{}{}
	}
	for k := range m {
		fmt.Println("topic name: " + k)
	}
}

func schedulerMsgHander() {
	fmt.Println("start scheduler message consuming ... !!")
	reader := getKafkaReader(config.KafkaEndpoint, string(SchedulerDeviceTopic), string(DeviceManagerGroupID))
	defer reader.Close()
	for {
		m, err := reader.ReadMessage(context.Background())
		if err != nil {
			log.Fatalln(err)
		}
		fmt.Printf("message at topic:%v partition:%v offset:%v	%s = %s\n", m.Topic, m.Partition, m.Offset, string(m.Key), string(m.Value))
		// json message unmarshal and update task status
		var jsonMsg []byte
		jsonMsg = m.Key

		var request DeviceRequest
		err = json.Unmarshal(jsonMsg, &request)
		if err != nil {
			panic(err)
		}

		// prepare device ...
		go prepareDevice(request)
		/*if err != nil {
			fmt.Println("Cannot prepare device", request.DeviceID, "for task", request.TaskID)
		}*/
	}
}

func prepareDevice(request DeviceRequest) error {
	// simulate device preparation process by sleeping random [10 .. 60] time
	//n := generateRandomInRange(10, 60)
	//time.Sleep(time.Duration(n) * time.Second)
	defaultConfig := "FortiGate-61F_7-0_0012_202106091059.conf" // "FortiGate-61F_7-0_0012_202106041304.conf"
	sendDefaultFile(request, defaultConfig)

	command := fmt.Sprintf("SELECT * FROM devices WHERE id=%d", request.DeviceID)
	rows, err := db.Query(command)
	if err != nil {
		fmt.Println("FAILED to SELECT: ", err)
		return err
	}

	devices := getDeviceFromDBRow(rows)
	if len(devices) == 0 {
		// something went wrong, no such deviceID from devices table, ignore this message
		fmt.Println("No such device with id", request.DeviceID)
		return nil
	}

	var reply DeviceReply
	reply.TaskID = request.TaskID
	reply.TaskUUID = request.TaskUUID
	reply.DeviceID = request.DeviceID
	reply.DeviceUUID = request.DeviceUUID
	reply.Status = string(DeviceCompleted) // if failed, DeviceFailed
	reply.Host = devices[0].mgmtIP
	reply.Interface = devices[0].mgmtIntf
	reply.Username = devices[0].username
	reply.Password = devices[0].password
	reply.HttpsPort = devices[0].mgmtPort
	reply.BaseDir = request.BaseDir
	reply.FileServer = request.FileServer
	reply.DefaultConfig = defaultConfig
	reply.SourceConfig = request.SourceConfig

	var reqjson []byte
	reqjson, err = json.MarshalIndent(reply, "", " ")
	if err != nil {
		panic(err)
	}

	// send kafka message to scheduler
	sendMessage(reqjson, DeviceSchedulerTopic)
	return nil
}

func sendDefaultFile(request DeviceRequest, fileName string) {

	conn, err := net.Dial("tcp", "10.160.10.10:445")
	if err != nil {
		log.Println(err)
	}
	defer conn.Close()

	d := &smb2.Dialer{
		Initiator: &smb2.NTLMInitiator{
			User:     "guest",
			Password: "",
		},
	}
	s, err := d.Dial(conn)
	defer s.Logoff()
	if err != nil {
		log.Println(err)
	}

	idx := strings.Index(request.BaseDir, "/")
	shareName := request.BaseDir[:idx]
	dirName := request.BaseDir[idx+1:]

	fs, err := s.Mount(shareName)
	defer fs.Umount()
	if err != nil {
		log.Println(err)
	}

	//fs.Mkdir(dirName, os.FileMode(0777))
	content, err := ioutil.ReadFile(fileName)

	f, err := fs.Create(dirName + "/" + fileName)
	if err != nil {
		panic(err)
	}
	defer f.Close()

	_, err = f.Write([]byte(content))
	if err != nil {
		panic(err)
	}
}

func sendMessage(jsondata []byte, topicname KafkaTopicEnum) error {
	writer := newKafkaWriter(config.KafkaEndpoint, string(topicname))
	defer writer.Close()
	fmt.Println("sending a message to topic", topicname)
	msg := kafka.Message{
		Key:   jsondata,
		Value: []byte(fmt.Sprint(uuid.New())),
	}
	err := writer.WriteMessages(context.Background(), msg)
	if err != nil {
		fmt.Println(err)
		return err
	} else {
		fmt.Println("=========  message sent =========\n", string(jsondata))
		return nil
	}
}

func generateRandomInRange(min int, max int) int {
	return rand.Intn(max-min) + min
}
