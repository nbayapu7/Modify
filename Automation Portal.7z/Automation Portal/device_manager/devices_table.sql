-- Table: public.devices

-- DROP TABLE public.devices;

CREATE TABLE public.devices
(
    id integer NOT NULL DEFAULT nextval('devices_id_seq'::regclass),
    name character varying(100) COLLATE pg_catalog."default",
    sn character varying(32) COLLATE pg_catalog."default" DEFAULT ''::character varying,
    model character varying(16) COLLATE pg_catalog."default",
    mgmt_ip character varying(16) COLLATE pg_catalog."default",
    mgmt_port integer,
    telnet_port integer,
    tftp_port integer,
    line integer,
    lab character varying(32) COLLATE pg_catalog."default",
    status character varying(32) COLLATE pg_catalog."default" DEFAULT 'offline'::character varying,
    username character varying(32) COLLATE pg_catalog."default" DEFAULT 'admin'::character varying,
    password character varying(32) COLLATE pg_catalog."default" DEFAULT ''::character varying,
    created_at bigint,
    updated_at bigint,
    description character varying(255) COLLATE pg_catalog."default" DEFAULT ''::character varying,
    CONSTRAINT devices_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE public.devices
    OWNER to postgres;