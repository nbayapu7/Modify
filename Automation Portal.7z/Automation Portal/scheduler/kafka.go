package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strings"
	"time"

	"github.com/google/uuid"
	kafka "github.com/segmentio/kafka-go"
)

type ServiceEndpointEnum string

const (
	SchedulerEndpoint     ServiceEndpointEnum = "http://127.0.0.1:3000/api"
	TicketManagerEndpoint ServiceEndpointEnum = "http://127.0.0.1:4000/api"
	DeviceManagerEndpoint ServiceEndpointEnum = "http://127.0.0.1:5000/api"
	WorkerServiceEndpoint ServiceEndpointEnum = "http://127.0.0.1:8000"
	ReportServiceEndpoint ServiceEndpointEnum = "http://127.0.0.1:7000"
	ControlPlaneEndpoint  ServiceEndpointEnum = "http://127.0.0.1:8080"
)

const (
	testGroupID = "test-consumer"
	testTopic   = "test-topic"
)

type KafkaConsumerGroupEnum string

const (
	SchedulerGroupID     KafkaConsumerGroupEnum = "scheduler-consumer"
	DeviceManagerGroupID KafkaConsumerGroupEnum = "device-manager-consumer"
	TicketManagerGroupID KafkaConsumerGroupEnum = "ticket-manager-consumer"
)

type KafkaTopicEnum string

const (
	SchedulerDeviceTopic KafkaTopicEnum = "scheduler-device"
	DeviceSchedulerTopic KafkaTopicEnum = "device-scheduler"
)

type DeviceRequest struct {
	TaskID       int       `json:"task_id" binding:"required"`
	TaskUUID     uuid.UUID `json:"task_uuid" binding:"required"`
	DeviceID     int       `json:"device_id" binding:"required"`
	DeviceUUID   uuid.UUID `json:"device_uuid" binding:"required"`
	TicketID     int64     `json:"ticket_id" binding:"required"`
	Status       string    `json:"status" binding:"required"`
	TargetModel  string    `json:"target_model" binding:"required"`
	Version      string    `json:"version" binding:"required"`
	Patch        string    `json:"patch" binding:"required"`
	FileServer   string    `json:"file_server" binding:"required"`
	BaseDir      string    `json:"base_dir" binding:"required"`
	SourceConfig string    `json:"source_config" binding:"required"`
}

type DeviceReply struct {
	TaskID        int       `json:"task_id" binding:"required"`
	TaskUUID      uuid.UUID `json:"task_uuid" binding:"required"`
	DeviceID      int       `json:"device_id" binding:"required"`
	DeviceUUID    uuid.UUID `json:"device_uuid" binding:"required"`
	Status        string    `json:"status" binding:"required"`
	Host          string    `json:"host" binding:"required"`
	Interface     string    `json:"interface" binding:"required"`
	Username      string    `json:"username" binding:"required"`
	Password      string    `json:"password" binding:"required"`
	HttpsPort     int       `json:"https" binding:"required"`
	FileServer    string    `json:"file_server" binding:"required"`
	BaseDir       string    `json:"base_dir" binding:"required"`
	DefaultConfig string    `json:"default_config" binding:"required"`
	SourceConfig  string    `json:"source_config" binding:"required"`
}

type WorkerRequestInputs struct {
	FileServer      string `json:"server" binding:"required"`
	BaseDir         string `json:"base_dir" binding:"required"`
	SourceFile      string `json:"source" binding:"required"`
	TargetFile      string `json:"target" binding:"required"`
	IntfMappingFile string `json:"interface_mapping" binding:"required"`
}

type WorkerRequestConnectInfo struct {
	Host      string `json:"host" binding:"required"`
	Interface string `json:"interface" binding:"required"`
	Username  string `json:"username" binding:"required"`
	Password  string `json:"password" binding:"required"`
	HttpsPort int    `json:"https" binding:"required"`
}

type WorkerRequest struct {
	TaskUUID    uuid.UUID                `json:"task_uuid" binding:"required"`
	DeviceUUID  uuid.UUID                `json:"device_uuid" binding:"required"`
	TicketID    int64                    `json:"ticket_id" binding:"required"`
	Inputs      WorkerRequestInputs      `json:"inputs" binding:"required"`
	ConnectInfo WorkerRequestConnectInfo `json:"connect_info" binding:"required"`
}

type WorkerReply struct {
	TaskUUID     uuid.UUID `json:"task_uuid" binding:"required"`
	DeviceUUID   uuid.UUID `json:"device_uuid"`
	TicketID     int64     `json:"ticket_id"`
	Status       string    `json:"status"`
	TargetConfig string    `json:"config_file"`
	Report       string    `json:"report_file"`
	Error        string    `json:"error"`
}

func newKafkaWriter(kafkaURL, topic string) *kafka.Writer {
	return &kafka.Writer{
		Addr:     kafka.TCP(kafkaURL),
		Topic:    topic,
		Balancer: &kafka.LeastBytes{},
	}
}

func producer() {
	fmt.Println("call producer!")
	writer := newKafkaWriter(config.KafkaEndpoint, testTopic)
	defer writer.Close()
	fmt.Println("start producing ... !!")
	for i := 0; ; i++ {
		key := fmt.Sprintf("Key-%d", i)
		msg := kafka.Message{
			Key:   []byte(key),
			Value: []byte(fmt.Sprint(uuid.New())),
		}
		err := writer.WriteMessages(context.Background(), msg)
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println("produced", key)
		}
		time.Sleep(1 * time.Second)
	}
}

func getKafkaReader(kafkaURL, topic, groupID string) *kafka.Reader {
	brokers := strings.Split(kafkaURL, ",")
	return kafka.NewReader(kafka.ReaderConfig{
		Brokers:  brokers,
		GroupID:  groupID,
		Topic:    topic,
		MinBytes: 10e3, // 10KB
		MaxBytes: 10e6, // 10MB
	})
}

func consumer() {
	fmt.Println("start consuming ... !!")
	reader := getKafkaReader(config.KafkaEndpoint, testTopic, testGroupID)
	defer reader.Close()
	for {
		m, err := reader.ReadMessage(context.Background())
		if err != nil {
			log.Fatalln(err)
		}
		fmt.Printf("message at topic:%v partition:%v offset:%v	%s = %s\n", m.Topic, m.Partition, m.Offset, string(m.Key), string(m.Value))
	}
}

func createTopic(topicname string) (bool, error) {
	// to create topics when auto.create.topics.enable='true'
	conn, err := kafka.DialLeader(context.Background(), "tcp", config.KafkaEndpoint, topicname, 0)
	if err != nil {
		panic(err.Error())
	}
	defer conn.Close()
	return true, nil
}

func listTopics() {
	conn, err := kafka.Dial("tcp", config.KafkaEndpoint)
	if err != nil {
		panic(err.Error())
	}
	defer conn.Close()
	partitions, err := conn.ReadPartitions()
	if err != nil {
		panic(err.Error())
	}

	m := map[string]struct{}{}

	for _, p := range partitions {
		m[p.Topic] = struct{}{}
	}
	for k := range m {
		fmt.Println("topic name: " + k)
	}
}

func requestDevice(jsondata []byte) error {
	writer := newKafkaWriter(config.KafkaEndpoint, string(SchedulerDeviceTopic))
	defer writer.Close()
	//fmt.Println("sending a message from scheduler to device manager ...")
	msg := kafka.Message{
		Key:   jsondata,
		Value: []byte(fmt.Sprint(uuid.New())),
	}
	err := writer.WriteMessages(context.Background(), msg)
	if err != nil {
		fmt.Println(err)
		return err
	} else {
		fmt.Println("=========  message sent =========")
		return nil
	}
}

func requestWorker(requestBody []byte) error {

	//fmt.Println("sending a message from scheduler to worker service ...")
	url := string(WorkerServiceEndpoint) + "/worker/new"
	resp, err := http.Post(url, "application/json", bytes.NewBuffer((requestBody)))
	if err != nil {
		log.Println("Error on response.\n[ERROR] -", err)
		return err
	} else {
		defer resp.Body.Close()
		body, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			log.Fatalln(err)
			return err
		}
		log.Println(string(body))
	}

	return nil
}

func updateTaskStatus(reply DeviceReply) error {

	var status TaskStatusEnum
	if reply.Status == string(DeviceCompleted) {
		status = DeviceCompleted
	} else {
		status = DeviceRetry
	}

	sqlStatement := `UPDATE tasks SET status = $1, file_server = $2, base_dir = $3, default_config = $4, source_config = $5 WHERE id = $6`
	_, err := db.Exec(sqlStatement, string(status), reply.FileServer, reply.BaseDir, reply.DefaultConfig, reply.SourceConfig, reply.TaskID)
	if err != nil {
		return err
	}
	return nil
}

func deviceMsgHander() {
	fmt.Println("start device message consuming ... !!")
	reader := getKafkaReader(config.KafkaEndpoint, string(DeviceSchedulerTopic), string(SchedulerGroupID))
	defer reader.Close()
	for {
		m, err := reader.ReadMessage(context.Background())
		if err != nil {
			log.Fatalln(err)
		}
		fmt.Printf("message at topic:%v partition:%v offset:%v	%s = %s\n", m.Topic, m.Partition, m.Offset, string(m.Key), string(m.Value))
		// json message unmarshal and update task status
		var jsonMsg []byte
		jsonMsg = m.Key

		var reply DeviceReply
		err = json.Unmarshal(jsonMsg, &reply)
		if err != nil {
			panic(err)
		}

		err = updateTaskStatus(reply)
		if err != nil {
			panic(err)
		}
	}
}
