package main

import (
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strconv"
	"time"

	jwt "github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/contrib/static"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	_ "github.com/lib/pq"
	"github.com/spf13/viper"
)

type Config struct {
	DBDriver      string `mapstructure:"DB_DRIVER"`
	DBHost        string `mapstructure:"DB_HOST"`
	DBPort        string `mapstructure:"DB_PORT"`
	DBName        string `mapstructure:"DB_NAME"`
	DBUser        string `mapstructure:"DB_USER"`
	DBPassword    string `mapstructure:"DB_PASSWD"`
	S3Region      string `mapstructure:"S3_REGION"`
	S3Bucket      string `mapstructure:"S3_BUCKET"`
	SQSTicket     string `mapstructure:"SQS_TICKET_QUEUE"`
	ServerAddress string `mapstructure:"SERVER_ADDRESS"`
	KafkaEndpoint string `mapstructure:"KAFKA_ENDPOINT"`
}

type DeviceStatusEnum string

const (
	DeviceIdling    DeviceStatusEnum = "Idling"    // Not using
	DeviceOffline   DeviceStatusEnum = "Offline"   // Unreachable
	DevicePreparing DeviceStatusEnum = "Preparing" // Initiating the device for specified ticket
	DeviceWorking   DeviceStatusEnum = "Working"   // Worker is manipulating the device
	DeviceError     DeviceStatusEnum = "Error"     // Error occured
	DeviceOccupied  DeviceStatusEnum = "Occupied"  // Used by others and cannot do automations
)

type TaskStatusEnum string

const (
	DevicePending    TaskStatusEnum = "Device - Pending"
	DeviceInProgress TaskStatusEnum = "Device - In Progress"
	DeviceCompleted  TaskStatusEnum = "Device - Completed"
	WorkerInProgress TaskStatusEnum = "Worker - In Progress"
	WorkerCompleted  TaskStatusEnum = "Worker - Completed"
	DeviceFailed     TaskStatusEnum = "Device - Failed"
	DeviceRetry      TaskStatusEnum = "Device - Retry"
	WorkerFailed     TaskStatusEnum = "Worker - Failed"
	WorkerRetry      TaskStatusEnum = "Worker - Retry"
	ServiceDelivered TaskStatusEnum = "Service Delivered"
)

type Task struct {
	id            int
	uuid          uuid.UUID
	deviceid      int
	deviceuuid    uuid.UUID
	ticketid      int64
	name          string
	status        string
	fileserver    string
	basedir       string
	defaultconfig string
	sourceconfig  string
	targetconfig  string
	report        string
	createdAt     int64
	updatedAt     int64
}

type TaskDisplay struct {
	ID            int       `json:"id"`
	UUID          uuid.UUID `json:"uuid"`
	DeviceID      int       `json:"deviceid" binding:"required"`
	DeviceUUID    uuid.UUID `json:"deviceuuid" binding:"required"`
	TicketID      int64     `json:"ticketid" binding:"required"`
	Name          string    `json:"name" binding:"required"`
	Status        string    `json:"status"`
	SourceModel   string    `json:"sourcemodel"`
	TargetModel   string    `json:"targetmodel"`
	DeviceName    string    `json:"devicename"`
	DeviceSN      string    `json:"devicesn"`
	DeviceIP      string    `json:"deviceip"`
	DevicePort    int       `json:"deviceport"`
	FileServer    string    `json:"fileserver"`
	BaseDir       string    `json:"basedir"`
	DefaultConfig string    `json:"defaultconfig"`
	SourceConfig  string    `json:"sourceconfig"`
	TargetConfig  string    `json:"targetconfig"`
	Report        string    `json:"report"`
	CreatedAt     int64     `json:"created_at"`
	UpdatedAt     int64     `json:"updated_at"`
}

type ChangeStatus struct {
	TaskID int64  `json:"taskid" binding:"required"`
	Status string `json:"status" binding:"required"`
}

type TicketDisplay struct {
	ID           int64  `json:"id" binding:"required"`
	Subject      string `json:"subject" binding:"required"`
	Status       string `json:"status" binding:"required"`
	Version      string `json:"version" binding:"required"`
	Patch        string `json:"patch" binding:"required"`
	SourceModel  string `json:"sourcemodel" binding:"required"`
	TargetModel  string `json:"targetmodel" binding:"required"`
	Created      int64  `json:"created" binding:"required"`
	Updated      int64  `json:"updated" binding:"required"`
	FileServer   string `json:"fileserver" binding:"required"`
	BaseDir      string `json:"basedir" binding:"required"`
	SourceConfig string `json:"sourceconfig" binding:"required"`
	IntfmapFile  string `json:"intfmapfile" binding:"required"`
}

type DeviceDisplay struct {
	ID          int       `json:"id"`
	UUID        uuid.UUID `json:"uuid"`
	Name        string    `json:"name" binding:"required"`
	SN          string    `json:"sn"`
	Model       string    `json:"model" binding:"required"`
	MgmtIP      string    `json:"mgmt_ip" binding:"required"`
	MgmtIntf    string    `json:"mgmt_intf" binding:"required"`
	MgmtPort    int       `json:"mgmt_port" binding:"required"`
	TelnetPort  int       `json:"telnet_port" binding:"required"`
	TftpPort    int       `json:"tftp_port" binding:"required"`
	Line        int       `json:"line" binding:"required"`
	Lab         string    `json:"lab" binding:"required"`
	Status      string    `json:"status"`
	Occupant    string    `json:"occupant"`
	Username    string    `json:"username"`
	Password    string    `json:"password"`
	CreatedAt   int64     `json:"created_at"`
	UpdatedAt   int64     `json:"updated_at"`
	Description string    `json:"description"`
}

type Joke struct {
	ID    int    `json:"id" binding:"required"`
	Likes int    `json:"likes"`
	Joke  string `json:"joke" binding:"required"`
}

type LOGIN struct {
	ID       string `json:"id" binding:"required"`
	PASSWORD string `json:"password" binding:"required"`
}

type JWTtoken struct {
	TOKEN string `json:"token" binding:"required"`
}

/** we'll create a list of jokes */
var jokes = []Joke{
	{1, 0, "Did you hear about the restaurant on the moon? Great food, no atmosphere."},
	{2, 0, "What do you call a fake noodle? An Impasta."},
	{3, 0, "How many apples grow on a tree? All of them."},
	{4, 0, "Want to hear a joke about paper? Nevermind it's tearable."},
	{5, 0, "I just watched a program about beavers. It was the best dam program I've ever seen."},
	{6, 0, "Why did the coffee file a police report? It got mugged."},
	{7, 0, "How does a penguin build it's house? Igloos it together."},
	{8, 0, "Dad, did you get a haircut? No I got them all cut."},
	{9, 0, "What do you call a Mexican who has lost his car? Carlos."},
	{10, 0, "Dad, can you put my shoes on? No, I don't think they'll fit me."},
	{11, 0, "Why did the scarecrow win an award? Because he was outstanding in his field."},
	{12, 0, "Why don't skeletons ever go trick or treating? Because they have no body to go with."},
}

// LoadConfig reads configuration from file or environment variables.
func LoadConfig(path string) (config Config, err error) {
	viper.AddConfigPath(path)
	viper.SetConfigName("app")
	viper.SetConfigType("env")

	viper.AutomaticEnv()

	err = viper.ReadInConfig()
	if err != nil {
		return
	}

	err = viper.Unmarshal(&config)
	return
}

// Predefined ID and password. (THIS IS THE PROTOTYPE.)
var authID = "admin"     //os.Getenv("USER_ID")
var authPassword = "123" //os.Getenv("USER_PASSWORD")

var db *sql.DB
var config Config

func main() {
	// Initial log output file
	var logfilename string
	logfilename = time.Now().UTC().Format("2006-01-02T15:04:05.999Z") + ".log"
	f, err := os.OpenFile(logfilename, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		log.Fatalf("error opening file: %v", err)
	}
	defer f.Close()

	log.SetFlags(log.LUTC | log.Ldate | log.Ltime | log.Lmicroseconds)
	log.SetOutput(f)
	log.Println("Scheduler process started....")

	config, err = LoadConfig(".")
	if err != nil {
		log.Fatal("cannot load config:", err)
	} else {
		log.Println("DB_DRIVER", config.DBDriver)
		log.Println("DB_HOST", config.DBHost)
		log.Println("DB_PORT", config.DBPort)
		log.Println("DB_NAME", config.DBName)
		log.Println("DB_USER", config.DBUser)
		log.Println("DB_PASSWD", config.DBPassword)
		log.Println("S3_REGION", config.S3Region)
		log.Println("S3_BUCKET", config.S3Bucket)
		log.Println("SQS_TICKET_QUEUE", config.SQSTicket)
		log.Println("SERVER_ADDRESS", config.ServerAddress)
		log.Println("KAFKA_ENDPOINT", config.KafkaEndpoint)
	}

	// open postgres database connection
	psqlInfo := fmt.Sprintf("host=%s port=%s user=%s "+
		"password=%s dbname=%s sslmode=disable",
		config.DBHost, config.DBPort, config.DBUser, config.DBPassword, config.DBName)

	db, err = sql.Open(config.DBDriver, psqlInfo)
	if err != nil {
		log.Fatal("Failed to open a DB connection: ", err)
	}
	defer db.Close()

	// test kafka topic creation and list
	// kafka producer and consumer routines
	//createTopic("test-topic")
	createTopic(string(SchedulerDeviceTopic))
	createTopic(string(DeviceSchedulerTopic))
	listTopics()
	//go producer()
	//go consumer()
	go deviceMsgHander()

	// ticker every minute
	ticker := time.NewTicker(1 * time.Second)
	go tick(ticker)

	// Set the router as the default one shipped with Gin
	router := gin.Default()
	router.Use(CORSMiddleware())

	// Serve the frontend
	router.Use(static.Serve("/", static.LocalFile("./views", true)))

	api := router.Group("/api")
	{
		api.GET("/", func(c *gin.Context) {
			c.JSON(http.StatusOK, gin.H{
				"message": "pong",
			})
		})
		api.GET("/jokes", authMiddleware(), JokeHandler)
		api.POST("/jokes/like/:jokeID", authMiddleware(), LikeJoke)
		api.GET("/tasks", authMiddleware(), listAllTasks)
		api.GET("/tasks/:taskUID", authMiddleware(), getTaskDetail)
		api.POST("/tasks/new", authMiddleware(), createTask)
		api.POST("/tasks/:taskUID/changestatus", authMiddleware(), changeTaskStatus)
		api.POST("/tasks/:taskUID", authMiddleware(), updateTask)
		api.DELETE("/tasks/:taskUID", authMiddleware(), deleteTask)
		api.POST("/auth", auth)
	}
	// Start the app
	router.Run(config.ServerAddress)
}

func auth(c *gin.Context) {

	fmt.Println("auth function call")

	var login LOGIN
	c.BindJSON(&login)

	// To-Do: Check ID and password is right or not.
	if authID != login.ID {
		c.Header("Content-Type", "application/json")
		c.JSON(http.StatusBadRequest, "")
		return
	}
	if authPassword != login.PASSWORD {
		c.Header("Content-Type", "application/json")
		c.JSON(http.StatusBadRequest, "")
		return
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"user":      login.ID,
		"timestamp": int32(time.Now().Unix()),
	})

	// Sign and get the complete encoded token as a string using the secret.
	tokenString, err := token.SignedString([]byte(login.PASSWORD))

	if err != nil {
		log.Fatal("Faile to generate signed string.")
	}

	fmt.Println("user : " + login.ID + " / " + "pw : " + login.PASSWORD + "/" + "token string:" + tokenString)

	var jwtToken JWTtoken
	jwtToken = JWTtoken{tokenString}

	c.Header("Content-Type", "application/json")
	c.JSON(http.StatusOK, jwtToken)
}

// authMiddleware intercepts the requests, and check for a valid jwt token
func authMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {

		// Get the JWT token sting in Authorization header.
		var header = c.Request.Header.Get("Authorization")
		fmt.Println("auth : " + header)
		var tokenString = header[7:]

		// Parse and validate JWT token.
		token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
			// Don't forget to validate the alg is what you expect:
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
			}

			// hmacSampleSecret is a []byte containing your secret, e.g. []byte("my_secret_key")
			return []byte(authPassword), nil
		})

		if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
			fmt.Println(claims["user"], claims["timestamp"])
		} else {
			fmt.Println(err)
			c.Abort()
			c.Writer.WriteHeader(http.StatusUnauthorized)
			c.Writer.Write([]byte("Unauthorized"))
			return
		}
	}
}

// JokeHandler returns a list of jokes available (in memory)
func JokeHandler(c *gin.Context) {
	c.Header("Content-Type", "application/json")
	c.JSON(http.StatusOK, jokes)
}

// LikeJoke ...
func LikeJoke(c *gin.Context) {
	// Check joke ID is valid
	if jokeid, err := strconv.Atoi(c.Param("jokeID")); err == nil {
		// find joke and increment likes
		for i := 0; i < len(jokes); i++ {
			if jokes[i].ID == jokeid {
				jokes[i].Likes = jokes[i].Likes + 1
			}
		}
		c.JSON(http.StatusOK, &jokes)
	} else {
		// the jokes ID is invalid
		c.AbortWithStatus(http.StatusNotFound)
	}
}

// getJokesByID returns a single joke
func getJokesByID(id int) (*Joke, error) {
	for _, joke := range jokes {
		if joke.ID == id {
			return &joke, nil
		}
	}
	return nil, errors.New("Joke not found")
}

func tick(ticker *time.Ticker) {
	for ts := range ticker.C {
		// Get current unix timestamp in second
		//log.Println("Tick at", ts)
		processTasks(ts.UnixNano() / 1000000) // nanosecond to microsecond
	}
}

func processTasks(ts int64) {
	//log.Println("timestamp", ts)
	// Find out task with status - device pending
	// Initially push task to device manager, due to device was unavailable, this task had never scheduled
	processDevicePendingTasks(ts)

	// Find out task with status - device retry
	// Retry to push task to device manager, device manager had processed this task, but for some reasons it was failed
	processDeviceRetryTasks(ts)

	// Find out task with status - device completed
	// Initially push task to worker service, upon the completion of the task from device manager
	processDeviceCompletedTasks(ts)

	// Find out task with status - worker retry
	// Retry to push task to worker service, worker service had processed this task, but for some reasons it was failed
	processWorkerRetryTasks(ts)
}

func getDeviceByID(deviceid int) (error, DeviceDisplay) {

	//fmt.Println("sending a message from scheduler to device manager ...")
	var device DeviceDisplay

	// Create a Bearer string by appending string access token
	var bearer = "Bearer " + "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lc3RhbXAiOjE2MjE3MDI0MjAsInVzZXIiOiJhZG1pbiJ9.v8s2YlF9RePYloJV1o1bUZG2pOjTbQJ8Fq5lKUgjLu4"

	var url string
	url = fmt.Sprintf(string(DeviceManagerEndpoint)+"/devices/%d", deviceid)
	// Create a new request using http
	//fmt.Println("http get", url)
	req, err := http.NewRequest("GET", url, nil)

	// add authorization header to the req
	req.Header.Add("Authorization", bearer)

	// Send req using http Client
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Println("Error on response.\n[ERROR] -", err)
		return err, device
	} else {
		defer resp.Body.Close()

		body, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			log.Fatalln(err)
			return err, device
		}

		log.Println("test get device by id", string(body))
		err = json.Unmarshal(body, &device)
		if err != nil {
			panic(err)
		}
	}

	return nil, device
}

func convertToWorkerReq(task Task) (error, WorkerRequest) {

	var workerReq WorkerRequest
	var err error
	// retrieve device info by deviceid
	var device DeviceDisplay
	err, device = getDeviceByID(task.deviceid)
	if err != nil {
		return err, workerReq
	}

	// retrieve ticket info by ticketid
	var ticket TicketDisplay
	err, ticket = getTicketByID(task.ticketid)
	if err != nil {
		return err, workerReq
	}

	var reqInputs WorkerRequestInputs
	reqInputs.FileServer = task.fileserver
	reqInputs.BaseDir = ticket.BaseDir
	reqInputs.SourceFile = ticket.SourceConfig
	reqInputs.IntfMappingFile = ticket.IntfmapFile
	reqInputs.TargetFile = task.defaultconfig

	var reqConnInfo WorkerRequestConnectInfo
	reqConnInfo.Host = device.MgmtIP
	reqConnInfo.Interface = device.MgmtIntf
	reqConnInfo.Username = device.Username
	reqConnInfo.Password = device.Password
	reqConnInfo.HttpsPort = device.MgmtPort

	workerReq.TaskUUID = task.uuid
	workerReq.DeviceUUID = task.deviceuuid
	workerReq.TicketID = task.ticketid
	workerReq.Inputs = reqInputs
	workerReq.ConnectInfo = reqConnInfo
	return nil, workerReq
}

func getTicketByID(ticketid int64) (error, TicketDisplay) {

	//fmt.Println("sending a message from scheduler to ticket manager ...")
	var ticket TicketDisplay

	// Create a Bearer string by appending string access token
	var bearer = "Bearer " + "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lc3RhbXAiOjE2MjE3MDI0MjAsInVzZXIiOiJhZG1pbiJ9.v8s2YlF9RePYloJV1o1bUZG2pOjTbQJ8Fq5lKUgjLu4"

	// Create a new request using http
	url := fmt.Sprintf(string(TicketManagerEndpoint)+"/tickets/%v", ticketid)
	// fmt.Println("http get", url)
	req, err := http.NewRequest("GET", url, nil)

	// add authorization header to the req
	req.Header.Add("Authorization", bearer)

	// Send req using http Client
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Println("Error on response.\n[ERROR] -", err)
		return err, ticket
	} else {
		defer resp.Body.Close()
		body, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			log.Fatalln(err)
			return err, ticket
		}
		log.Println(string(body))
		err = json.Unmarshal(body, &ticket)
		if err != nil {
			panic(err)
		}
	}

	return nil, ticket
}

func convertToDeviceReq(task Task) (error, DeviceRequest) {
	var deviceReq DeviceRequest
	deviceReq.TaskID = task.id
	deviceReq.TaskUUID = task.uuid
	deviceReq.DeviceID = task.deviceid
	deviceReq.DeviceUUID = task.deviceuuid
	deviceReq.TicketID = task.ticketid
	deviceReq.Status = task.status

	err, ticket := getTicketByID(task.ticketid)
	if err != nil {
		log.Fatalln("Cannot find ticket by id", task.ticketid)
		return err, deviceReq
	}

	deviceReq.TargetModel = ticket.TargetModel
	deviceReq.Version = ticket.Version
	deviceReq.Patch = ticket.Patch
	deviceReq.BaseDir = ticket.BaseDir
	deviceReq.FileServer = ticket.FileServer
	deviceReq.SourceConfig = ticket.SourceConfig
	return nil, deviceReq
}

func getTaskByStatus(status TaskStatusEnum) (error, []Task) {
	var tasks []Task
	// Read all tasks from database
	sqlStatement := `SELECT id, uuid, device_id, device_uuid, ticket_id, status, file_server, 
	base_dir, default_config, source_config, created_at, updated_at 
	FROM tasks WHERE status=$1 and deleted = false;`
	rows, err := db.Query(sqlStatement, status)
	if err != nil {
		log.Fatal(err)
		return err, tasks
	}

	defer rows.Close()
	for rows.Next() {
		var task Task
		err := rows.Scan(&task.id, &task.uuid, &task.deviceid, &task.deviceuuid, &task.ticketid, &task.status, &task.fileserver,
			&task.basedir, &task.defaultconfig, &task.sourceconfig, &task.createdAt, &task.updatedAt)
		if err != nil {
			log.Fatal(err)
			return err, tasks
		}
		log.Printf("Read task %v\n", task.id)
		tasks = append(tasks, task)
	}
	err = rows.Err()
	if err != nil {
		log.Fatal(err)
		return err, tasks
	}
	return nil, tasks
}

func deviceAvailable(deviceId int) (error, bool) {
	var err error
	// retrieve device info by deviceid
	var device DeviceDisplay
	err, device = getDeviceByID(deviceId)
	if err != nil {
		return err, false
	}
	return nil, device.Status == string(DeviceIdling)
}

func processDevicePendingTasks(ts int64) {
	_, tasks := getTaskByStatus(DevicePending)
	for i := 0; i < len(tasks); i++ {
		fmt.Println("processDevicePendingTasks", tasks[i].id)
		// Check device availability
		if _, ret := deviceAvailable(int(tasks[i].deviceid)); ret == false {
			continue
		}

		// Update task status to "Device - In Progress"
		sqlStatement := `UPDATE tasks SET status = $1, updated_at = $2 WHERE id = $3`
		_, err := db.Exec(sqlStatement, string(DeviceInProgress), ts, tasks[i].id)
		if err != nil {
			panic(err)
		}

		var deviceReq DeviceRequest
		err, deviceReq = convertToDeviceReq(tasks[i])
		if err != nil {
			panic(err)
		}

		var reqjson []byte
		reqjson, err = json.MarshalIndent(deviceReq, "", " ")
		if err != nil {
			panic(err)
		}

		err = requestDevice(reqjson)
		if err != nil {
			// Revert task status from "Device - In Progress" to "Device - Failed"
			sqlStatement := `UPDATE tasks SET status = $1, updated_at = $2 WHERE id = $3`
			_, err = db.Exec(sqlStatement, string(DeviceFailed), ts, deviceReq.TaskID)
			if err != nil {
				panic(err)
			}
			log.Fatal(err)
		}
	}
}

func processDeviceRetryTasks(ts int64) {
	_, tasks := getTaskByStatus(DeviceRetry)
	for i := 0; i < len(tasks); i++ {
		fmt.Println("processDeviceRetryTasks", tasks[i].id)
		// Check device availability
		if _, ret := deviceAvailable(int(tasks[i].deviceid)); ret == false {
			continue
		}

		// Update task status to "Device - In Progress"
		sqlStatement := `UPDATE tasks SET status = $1, updated_at = $2 WHERE id = $3`
		_, err := db.Exec(sqlStatement, string(DeviceInProgress), ts, tasks[i].id)
		if err != nil {
			panic(err)
		}

		var deviceReq DeviceRequest
		err, deviceReq = convertToDeviceReq(tasks[i])
		if err != nil {
			panic(err)
		}

		var reqjson []byte
		reqjson, err = json.MarshalIndent(deviceReq, "", " ")
		if err != nil {
			panic(err)
		}

		err = requestDevice(reqjson)
		if err != nil {
			// Revert task status from "Device - In Progress" to "Device - Failed"
			sqlStatement := `UPDATE tasks SET status = $1, updated_at = $2 WHERE id = $3`
			_, err = db.Exec(sqlStatement, string(DeviceFailed), ts, deviceReq.TaskID)
			if err != nil {
				panic(err)
			}
			log.Fatal(err)
		}
	}
}

func processDeviceCompletedTasks(ts int64) {
	_, tasks := getTaskByStatus(DeviceCompleted)
	for i := 0; i < len(tasks); i++ {
		log.Println("processDeviceCompletedTasks", tasks[i].id)
		var workerReq WorkerRequest
		_, workerReq = convertToWorkerReq(tasks[i])

		// Update task status to "Worker - In Progress"
		sqlStatement := `UPDATE tasks SET status = $1, updated_at = $2 WHERE uuid = $3`
		_, err := db.Exec(sqlStatement, string(WorkerInProgress), ts, workerReq.TaskUUID)
		if err != nil {
			panic(err)
		}

		var reqjson []byte
		reqjson, err = json.MarshalIndent(workerReq, "", " ")
		if err != nil {
			panic(err)
		}

		log.Println("reqjson: ", string(reqjson))
		err = requestWorker(reqjson)
		if err != nil {
			// Revert task status from "Worker - In Progress" to "Worker - Retry"
			sqlStatement := `UPDATE tasks SET status = $1, updated_at = $2 WHERE uuid = $3`
			_, err = db.Exec(sqlStatement, string(WorkerRetry), ts, workerReq.TaskUUID)
			if err != nil {
				panic(err)
			}
		}
	}
}

func processWorkerRetryTasks(ts int64) {
	_, tasks := getTaskByStatus(WorkerRetry)
	for i := 0; i < len(tasks); i++ {
		log.Println("processWorkerRetryTasks", tasks[i].id)
		var workerReq WorkerRequest
		_, workerReq = convertToWorkerReq(tasks[i])

		// Update task status to "Worker - In Progress"
		sqlStatement := `UPDATE tasks SET status = $1, updated_at = $2 WHERE uuid = $3`
		_, err := db.Exec(sqlStatement, string(WorkerInProgress), ts, workerReq.TaskUUID)
		if err != nil {
			panic(err)
		}

		var reqjson []byte
		reqjson, err = json.MarshalIndent(workerReq, "", " ")
		if err != nil {
			panic(err)
		}

		log.Println("reqjson: ", string(reqjson))
		err = requestWorker(reqjson)
		if err != nil {
			// Revert task status from "Worker - In Progress" to "Worker - Retry"
			sqlStatement := `UPDATE tasks SET status = $1, updated_at = $2 WHERE uuid = $3`
			_, err = db.Exec(sqlStatement, string(WorkerRetry), ts, workerReq.TaskUUID)
			if err != nil {
				panic(err)
			}
		}
	}
}

func changeTaskStatus(c *gin.Context) {
	fmt.Println("changeTaskStatus function call")
	log.Println("changeTaskStatus function call")
	// Check task ID is valid
	taskUID := c.Param("taskUID")
	var sqlStatement string
	var row *sql.Row
	var task Task

	var changestatus ChangeStatus
	c.BindJSON(&changestatus)

	if len(taskUID) == 36 {
		// task uuid format
		sqlStatement = `SELECT id, status FROM tasks WHERE uuid=$1;`
		// find task by taskUUID
		row = db.QueryRow(sqlStatement, taskUID)
	} else {
		sqlStatement = `SELECT id, status FROM tasks WHERE id=$1;`
		taskid, err := strconv.ParseInt(taskUID, 10, 64)
		if err != nil {
			// Invalid parameter taskID
			c.AbortWithStatus(http.StatusNotFound)
			return
		}
		// find task by taskID
		row = db.QueryRow(sqlStatement, taskid)
	}

	err := row.Scan(&task.id, &task.status)
	switch err {
	case sql.ErrNoRows:
		c.AbortWithStatus(http.StatusNotFound)
	case nil:
		ts := time.Now().UnixNano()
		sqlStatement := `UPDATE tasks SET status = $1, updated_at = $2 WHERE id = $3`
		_, err = db.Exec(sqlStatement, changestatus.Status, ts/1000000, task.id)
		if err != nil {
			panic(err)
		}
	default:
		panic(err)
	}
	c.JSON(http.StatusOK, gin.H{
		"taskID":  task.id,
		"message": "OK",
	})
}

func updateTask(c *gin.Context) {
	fmt.Println("updateTask function call")
	log.Println("updateTask function call")

	var reply WorkerReply
	err := c.BindJSON(&reply)
	if err != nil {
		log.Println(err)
	}

	taskUID := c.Param("taskUID")
	log.Println("taskUID", taskUID)
	if len(taskUID) == 36 {
		if reply.TaskUUID.String() != taskUID {
			log.Println("task uuid: ", reply.TaskUUID.String())
			c.AbortWithStatus(http.StatusNotFound)
		} else {
			// find task by taskID
			sqlStatement := `SELECT id, status FROM tasks WHERE uuid=$1;`
			var task Task
			row := db.QueryRow(sqlStatement, taskUID)
			err := row.Scan(&task.id, &task.status)
			switch err {
			case sql.ErrNoRows:
				log.Println("no row error", taskUID)
				c.AbortWithStatus(http.StatusNotFound)
			case nil:
				ts := time.Now().UnixNano()
				var status string
				if reply.Status == string(WorkerCompleted) {
					status = string(WorkerCompleted)
				} else if reply.Status == string(WorkerFailed) {
					status = string(WorkerFailed)
				} else {
					status = string(WorkerRetry)
				}

				log.Println("Update task", task.id, "with status", status)
				sqlStatement := `UPDATE tasks SET status = $1, target_config = $2, report = $3, updated_at = $4 WHERE id = $5`
				_, err = db.Exec(sqlStatement, status, reply.TargetConfig, reply.Report, ts/1000000, task.id)
				if err != nil {
					panic(err)
				}
			default:
				panic(err)
			}
			c.JSON(http.StatusOK, gin.H{
				"taskID":  task.id,
				"message": "OK",
			})
		}
	} else {
		// Invalid parameter TaskID
		log.Println("task len: ", len(taskUID))
		c.AbortWithStatus(http.StatusNotFound)
	}
}

func deleteTask(c *gin.Context) {
	fmt.Println("deleteTask function call")
	log.Println("deleteTask function call")

	taskUID := c.Param("taskUID")
	var sqlStatement string
	var row *sql.Row
	var task Task

	sqlStatement = `SELECT id, status FROM tasks WHERE `

	if len(taskUID) == 36 {
		// task uuid format
		sqlStatement += `uuid=$1;`
		// find task by taskUUID
		row = db.QueryRow(sqlStatement, taskUID)
	} else {
		sqlStatement += `id=$1;`
		taskid, err := strconv.Atoi(c.Param("taskUID"))
		if err != nil {
			// Invalid parameter taskID
			c.AbortWithStatus(http.StatusNotFound)
			return
		}
		// find task by taskID
		row = db.QueryRow(sqlStatement, taskid)
	}

	err := row.Scan(&task.id, &task.status)
	switch err {
	case sql.ErrNoRows:
		c.AbortWithStatus(http.StatusNotFound)
	case nil:
		ts := time.Now().UnixNano()
		sqlStatement := `UPDATE tasks SET deleted = $1, updated_at = $2 WHERE id = $3`
		_, err = db.Exec(sqlStatement, true, ts/1000000, task.id)
		if err != nil {
			panic(err)
		}
	default:
		panic(err)
	}
	c.JSON(http.StatusOK, gin.H{
		"taskID":  task.id,
		"message": "DELETED",
	})
}

func createTask(c *gin.Context) {
	var taskreq TaskDisplay
	c.BindJSON(&taskreq)

	ts := time.Now().UnixNano()
	var task Task
	task.name = taskreq.Name
	task.uuid = uuid.New()
	task.status = string(DeviceInProgress)
	task.ticketid = taskreq.TicketID
	task.deviceid = taskreq.DeviceID
	task.deviceuuid = taskreq.DeviceUUID
	task.createdAt = ts / 1000000   // taskreq.CreatedAt
	task.updatedAt = task.createdAt // taskreq.UpdatedAt

	// insert new task into datebase tasks table
	sqlStatement := `INSERT INTO tasks (uuid, ticket_id, device_id, device_uuid, name, status, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`
	row := db.QueryRow(sqlStatement, task.uuid, task.ticketid, task.deviceid, task.deviceuuid, task.name, task.status, task.createdAt, task.updatedAt)
	err := row.Scan(&task.id)
	switch err {
	case sql.ErrNoRows:
		c.Header("Content-Type", "application/json")
		c.JSON(http.StatusBadRequest, "")
	case nil:
		log.Println("Inserted task ID : ", task.id)
		taskreq.ID = task.id
		sqlStatement = `UPDATE tasks SET status = $1, updated_at = $2 WHERE id = $3`
		ts := time.Now().UnixNano()

		// Check device availability
		if _, ret := deviceAvailable(int(task.deviceid)); ret == false {
			// Update task status to "Device - Pending"
			_, err = db.Exec(sqlStatement, string(DevicePending), ts/1000000, taskreq.ID)
			if err != nil {
				panic(err)
			}
		} else {
			// send a message for this task to a kafka queue, which device manager is mornitoring
			var deviceReq DeviceRequest
			err, deviceReq = convertToDeviceReq(task)
			if err != nil {
				panic(err)
			}

			var reqjson []byte
			reqjson, err = json.MarshalIndent(deviceReq, "", " ")
			if err != nil {
				panic(err)
			}

			err = requestDevice(reqjson)
			if err != nil {
				log.Fatal(err)
				// Update task status to "Device - Retry"
				_, err = db.Exec(sqlStatement, string(DeviceRetry), taskreq.ID)
				if err != nil {
					panic(err)
				}
				c.Header("Content-Type", "application/json")
				c.JSON(http.StatusBadRequest, gin.H{
					"message": err.Error(),
				})
				return
			}
		}

		// Return http 200 success to the control plane
		c.JSON(http.StatusOK, gin.H{
			"message": "OK",
			"taskid":  task.id,
		})
	default:
		panic(err)
	}
}

func listAllTasks(c *gin.Context) {
	// debug print out
	fmt.Println("listAllTasks function call")

	c.Header("Content-Type", "application/json")
	// Read all tasks from database
	var tasks []Task
	var displays []TaskDisplay
	sqlStatement := `SELECT id, uuid, device_id, device_uuid, ticket_id, name, status, file_server, base_dir, default_config, source_config, target_config, report, created_at, updated_at FROM tasks WHERE deleted = false;`
	rows, err := db.Query(sqlStatement)
	if err != nil {
		log.Fatal(err)
		c.Header("Content-Type", "application/json")
		c.JSON(http.StatusBadRequest, "Database error!")
		return
	}
	defer rows.Close()
	for rows.Next() {
		var task Task
		err := rows.Scan(&task.id, &task.uuid, &task.deviceid, &task.deviceuuid, &task.ticketid, &task.name,
			&task.status, &task.fileserver, &task.basedir, &task.defaultconfig, &task.sourceconfig, &task.targetconfig,
			&task.report, &task.createdAt, &task.updatedAt)
		if err != nil {
			log.Fatal(err)
			c.Header("Content-Type", "application/json")
			c.JSON(http.StatusBadRequest, "Database error!")
			return
		}
		log.Printf("Read task %v\n", task.id)
		tasks = append(tasks, task)

		var display TaskDisplay
		display.ID = task.id
		display.UUID = task.uuid
		display.DeviceID = task.deviceid
		display.DeviceUUID = task.deviceuuid
		display.TicketID = task.ticketid
		display.Name = task.name
		display.Status = task.status
		display.FileServer = task.fileserver
		display.BaseDir = task.basedir
		display.DefaultConfig = task.defaultconfig
		display.SourceConfig = task.sourceconfig
		display.TargetConfig = task.targetconfig
		display.Report = task.report
		display.CreatedAt = task.createdAt
		display.UpdatedAt = task.updatedAt

		err, ticket := getTicketByID(task.ticketid)
		if err != nil {
			log.Fatalln("Cannot find ticket by id", task.ticketid)
			c.JSON(http.StatusBadRequest, gin.H{
				"message": "ticket not found",
			})
		}

		err, device := getDeviceByID(task.deviceid)
		if err != nil {
			log.Fatalln("Cannot find device by id", task.deviceid)
			c.JSON(http.StatusBadRequest, gin.H{
				"message": "device not found",
			})
		}
		display.SourceModel = ticket.SourceModel
		display.TargetModel = ticket.TargetModel
		display.DeviceName = device.Name
		display.DeviceSN = device.SN
		display.DeviceIP = device.MgmtIP
		display.DevicePort = device.MgmtPort
		displays = append(displays, display)
	}

	err = rows.Err()
	if err != nil {
		log.Fatal(err)
		c.Header("Content-Type", "application/json")
		c.JSON(http.StatusBadRequest, "Database error!")
	} else {
		c.JSON(http.StatusOK, &displays)
	}
}

func getTaskDetail(c *gin.Context) {
	// Check task ID is valid
	taskUID := c.Param("taskUID")
	var row *sql.Row
	var task Task

	sqlStatement := `SELECT id, uuid, device_id, device_uuid, ticket_id, name, status, file_server, base_dir, default_config, source_config, target_config, report, created_at, updated_at FROM tasks WHERE `

	if len(taskUID) == 36 {
		// task uuid format
		sqlStatement += `uuid=$1;`
		// find task by taskUUID
		row = db.QueryRow(sqlStatement, taskUID)
	} else {
		sqlStatement += `id=$1;`
		taskid, err := strconv.Atoi(c.Param("taskUID"))
		if err != nil {
			// Invalid parameter taskID
			c.AbortWithStatus(http.StatusNotFound)
			return
		}
		// find task by taskID
		row = db.QueryRow(sqlStatement, taskid)
	}

	err := row.Scan(&task.id, &task.uuid, &task.deviceid, &task.deviceuuid, &task.ticketid, &task.name,
		&task.status, &task.fileserver, &task.basedir, &task.defaultconfig, &task.sourceconfig, &task.targetconfig,
		&task.report, &task.createdAt, &task.updatedAt)
	switch err {
	case sql.ErrNoRows:
		c.Header("Content-Type", "application/json")
		c.JSON(http.StatusBadRequest, "")
	case nil:
		log.Println(task)
		var display TaskDisplay
		display.ID = task.id
		display.UUID = task.uuid
		display.DeviceID = task.deviceid
		display.DeviceUUID = task.deviceuuid
		display.TicketID = task.ticketid
		display.Name = task.name
		display.Status = task.status
		display.FileServer = task.fileserver
		display.BaseDir = task.basedir
		display.DefaultConfig = task.defaultconfig
		display.SourceConfig = task.sourceconfig
		display.TargetConfig = task.targetconfig
		display.Report = task.report
		display.CreatedAt = task.createdAt
		display.UpdatedAt = task.updatedAt

		err, ticket := getTicketByID(task.ticketid)
		if err != nil {
			log.Fatalln("Cannot find ticket by id", task.ticketid)
			c.JSON(http.StatusBadRequest, gin.H{
				"message": "ticket not found",
			})
		}

		err, device := getDeviceByID(task.deviceid)
		if err != nil {
			log.Fatalln("Cannot find device by id", task.deviceid)
			c.JSON(http.StatusBadRequest, gin.H{
				"message": "device not found",
			})
		}
		display.SourceModel = ticket.SourceModel
		display.TargetModel = ticket.TargetModel
		display.DeviceName = device.Name
		display.DeviceSN = device.SN
		display.DeviceIP = device.MgmtIP
		display.DevicePort = device.MgmtPort
		c.JSON(http.StatusOK, &display)
	default:
		panic(err)
	}
}

func CORSMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "timeZone, timezone, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	}
}
