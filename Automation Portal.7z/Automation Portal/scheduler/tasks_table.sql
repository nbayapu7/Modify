-- Table: public.tasks

-- DROP TABLE public.tasks;

CREATE TABLE public.tasks
(
    id integer NOT NULL DEFAULT nextval('tasks_id_seq'::regclass),
    ticket_id bigint,
    device_id bigint,
    uuid character varying(255) COLLATE pg_catalog."default",
    device_uuid character varying(255) COLLATE pg_catalog."default",
    name character varying(255) COLLATE pg_catalog."default" NOT NULL DEFAULT ''::character varying,
    status character varying(255) COLLATE pg_catalog."default" NOT NULL DEFAULT ''::character varying,
    file_server character varying(255) COLLATE pg_catalog."default" NOT NULL DEFAULT ''::character varying,
    base_dir character varying(2048) COLLATE pg_catalog."default" NOT NULL DEFAULT ''::character varying,
    default_config character varying(255) COLLATE pg_catalog."default" NOT NULL DEFAULT ''::character varying,
    source_config character varying(255) COLLATE pg_catalog."default" NOT NULL DEFAULT ''::character varying,
    target_config character varying(255) COLLATE pg_catalog."default" NOT NULL DEFAULT ''::character varying,
    report character varying(255) COLLATE pg_catalog."default" NOT NULL DEFAULT ''::character varying,
    created_at bigint,
    updated_at bigint,
    deleted boolean DEFAULT false,
    CONSTRAINT tasks_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.tasks
    OWNER to postgres;