import uvicorn
from fastapi import FastAPI

from api.worker import worker_router

app = FastAPI()

app.include_router(
    worker_router,
    prefix="/worker",
    tags=["Worker"]
)


@app.get("/")
def read_root():
    return {"FortiConverter Automation Service Worker"}
