from datetime import datetime
from enum import unique

from sqlalchemy import Boolean, Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy.sql.schema import DEFAULT_NAMING_CONVENTION
from sqlalchemy.sql.sqltypes import DateTime

from .base_class import Base


class Worker(Base):
    __tablename__ = "worker"

    id = Column(Integer, primary_key=True, index=True)
    task_uuid = Column(String, unique=True, index=True)
    curr_worker_uuid = Column(String, unique=True, index=True)
    phase = Column(String)
    state = Column(String)
    update_time = Column(DateTime, onupdate=datetime.now, default=datetime.now)
