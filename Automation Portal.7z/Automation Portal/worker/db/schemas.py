from pydantic import BaseModel


class Worker(BaseModel):
    id: int
    task_uuid: str
    curr_worker_uuid: str
    phase: str
    state: str
    update_time: str

    class Config:
        orm_mode = True
