from contextlib import contextmanager
from typing import Callable

from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker

db_session = scoped_session(
    sessionmaker(autocommit=False, autoflush=False)
)
Session = sessionmaker(autocommit=False, autoflush=False)
