**Distributed Worker Service for FortiConverter Service Automation via FastAPI and Celery.**

/api
FastAPI API router endpoint

/celery_app
Celery async tasks

main.py
Backend starter

Compress

tar -cv directory | gzip > archive.tar.gz

Decompress the same
tar -zxvf archive.tar.gz

**Docker**

Build and run containers
$docker-compose up -d --build

Stop containers
$docker-compose down

Restart containers
$docker-compose up -d

To delete all containers including its volumes use,
$docker rm -vf $(docker ps -a -q)

To delete all the images,
$docker rmi -f $(docker images -a -q)

This will expost fastapi application on 8000 and celery flower on 5555

fastapi endpoint
10.160.53.227:8000

API Document
10.160.53.227:8000/redoc

Worker monitor - celery flower
10.160.53.227:5555



