
# from db.session import db_session
# from sqlalchemy.engine import create_engine

from celery import Celery
# from celery.signals import worker_init
from celery_app import config

celery = Celery(__name__)
celery.config_from_object(config)
# SQLALCHEMY_DATABASE_URL = "postgresql://postgres:fortinet@127.0.0.1/db"


# @worker_init.connect
# def initialize_session(**kwargs):
#     engine = create_engine(SQLALCHEMY_DATABASE_URL)
#     db_session.configure(bind=engine)
