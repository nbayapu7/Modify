import json
import time
import pickle
from pathlib import Path

import requests
from celery import Task, chain, chord
from celery.utils.log import get_task_logger
from celery_app.celery import celery
from celery_app.connector.fileserver import FileServer
from celery_app.connector.fortios import FortiGateConnector

from .core.convert_job import ConvertJob
from .core.import_job import ImportJob
from .decryption.worker import DecryptionWorker
from .model.fortigate import FortiGate

# from db.session import db_session


logger = get_task_logger(__name__)

TEST_TIME = 5


class BaseTask(Task):
    # _session = None

    # def __call__(self, *args, **kwargs):
    #     # TODO
    #     return super().__call__(*args, **kwargs)

    # def after_return(self, status, retval, task_id, args, kwargs, einfo):
    #     if self._session is not None:
    #         self._session.remove()
    #     return super(BaseTask, self).after_return(status, retval, task_id, args, kwargs, einfo)

    # @property
    # def session(self):
    #     if self._session is None:
    #         self._session = db_session()
    #     return self._session

    def on_success(self, retval, task_id, args, kwargs):
        return super(BaseTask, self).on_success(retval, task_id, args, kwargs)

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        for argument in args:
            if isinstance(argument, dict) and "task_uuid" in argument:
                notify_scheduler_task(("", ""), argument, "Failed", error=exc)
        return super(BaseTask, self).on_failure(exc, task_id, args, kwargs, einfo)


@celery.task(bind=True, base=BaseTask)
def get_files(self, task, local_dir):
    remote = task["inputs"]
    on_server_dir = remote["base_dir"]
    smb = FileServer(file_path=on_server_dir)
    try:
        smb.new_connection(remote["server"])
    except OSError:
        raise OSError(f'SMB server \"{remote["server"]}\" are not reachable')

    workflow_dir = Path(local_dir) / self.request.id
    workflow_dir.mkdir(parents=True, exist_ok=True)
    with open(workflow_dir / "source.conf", "wb") as source, open(workflow_dir / "target.conf", "wb") as target, \
            open(workflow_dir / "interfacemapping.json", "wb") as interface:
        smb.retrive_file(remote["source"], source)
        smb.retrive_file(remote["target"], target)
        smb.retrive_file(remote["interface_mapping"], interface)

    return source.name, target.name


@celery.task(base=BaseTask)
def parse_tasks(files, task):
    source_file, target_file = files
    return [parse_source(task, source_file), parse_target(task, target_file)]


@celery.task(base=BaseTask)
def parse_source(task, file_path):
    device = FortiGate(file_path=file_path)
    device.extract_header_version_info()
    return device


@celery.task(base=BaseTask)
def parse_target(task, file_path):
    return FortiGate(file_path=file_path, device="target")


@celery.task(bind=True, base=BaseTask)
def interface_mapping_task(self, dev_list, task, local_dir):
    print("Apply Interface Mapping")
    source_dev, target_dev = dev_list[0]
    with open(local_dir / self.request.root_id / "interfacemapping.json", "r") as intf_mapping:
        mp = json.load(intf_mapping)
        source_dev.apply_interface_mapping(mapping=mp)
        keep_interface = source_dev.swap_interface_to_prevent_disconnected(
            connect_info=task["connect_info"], target_dev=target_dev)

    with open(local_dir / self.request.root_id / "connected_intf", "wb") as connected_intf:
        pickle.dump(keep_interface, connected_intf, pickle.HIGHEST_PROTOCOL)

    return source_dev, target_dev


@celery.task(base=BaseTask)
def convert_task(dev_list, task):
    source_dev, target_dev = dev_list
    print("Conversion task")
    converted_dev = ConvertJob(source_dev, target_dev).do_conversion()
    return converted_dev


@celery.task(bind=True, base=BaseTask)
def decode_task(self, converted_dev, task, local_dir):
    print("Decode task")
    worker = DecryptionWorker(converted_dev)
    decrypted_device = worker.run()
    # Save decoded configuration for debug.
    worker.output_file(local_dir / self.request.root_id /
                       "decoded_config.conf")

    return decrypted_device


@celery.task(bind=True, base=BaseTask)
def import_task(self, device, task, local_dir):
    print("Import task")
    connect_info = task["connect_info"]
    worker_dir = local_dir / self.request.root_id
    import_job = ImportJob(device, worker_dir)
    import_job.logging = logger

    import_job.connector = FortiGateConnector.connect(
        connect_info["host"], connect_info["username"], connect_info["password"], connect_info["https"])

    import_record = import_job.run()
    return import_record


@celery.task(bind=True, base=BaseTask, default_retry_delay=15, max_retries=3)
def backup_device_task(self, import_record, task, local_dir):
    print("Backup task")
    connect_info = task["connect_info"]
    connector = FortiGateConnector.connect(
        connect_info["host"], connect_info["username"], connect_info["password"], connect_info["https"])

    try:
        connector.login()
        config_str = connector.download(
            "monitor", "system", "config", "backup", "", {"scope": "global"})
        connector.logout()
    except Exception as ex:
        print(ex)
        self.retry(countdown=3**self.request.retries)

    backup_file_name = f'backup_from_device_{time.strftime("%Y%m%d_%H%M%S")}.conf'
    backup_file_path = local_dir / self.request.root_id / backup_file_name
    with open(backup_file_path, "w", encoding="utf-8") as f:
        f.write(config_str)

    return import_record, backup_file_name


@celery.task(bind=True, base=BaseTask)
def recovery_interface_and_route(self, file_to_upload, task, local_dir):
    import_file, backup_file_name = file_to_upload

    backup_file_path = local_dir / self.request.root_id / backup_file_name
    backup_dev = FortiGate(file_path=backup_file_path)

    with open(local_dir / self.request.root_id / "connected_intf", "rb") as connected_intf:
        recovery_interface = pickle.load(connected_intf)

    node_config = backup_dev.config_root.find_tree_node(
        "config", ("config", "system", "interface"))
    node_edit = node_config.child_branch.find_branch_node_edit(
        task["connect_info"]["interface"])

    if recovery_interface:
        if node_edit.node_type.value != 0:
            backup_dev.recovery_interface_ip_allowaccess(
                node_edit, recovery_interface)
    else:
        print("No interface to recovery, remove the connected interface.")
        node_edit.remove_tree_node()

    backup_dev.remove_default_route()

    backup_dev.generate_config_file(
        local_dir / self.request.root_id / backup_file_name)

    return import_file, backup_file_name


@celery.task(bind=True, base=BaseTask, ignore_result=True)
def upload_task(self, file_to_upload, task, local_dir):
    print("Upload task")
    remote = task["inputs"]

    on_server_dir = remote["base_dir"]
    import_file, backup_config_file = file_to_upload

    smb = FileServer(file_path=on_server_dir)
    try:
        smb.new_connection(remote["server"])
    except OSError:
        raise OSError(f'SMB server \"{remote["server"]}\" are not reachable')

    worker_dir = local_dir / self.request.root_id
    with open(worker_dir / backup_config_file, "rb") as fb, open(worker_dir / import_file, "rb") as fi:
        smb.store_file(file_name=backup_config_file, file_io=fb)
        smb.store_file(file_name=import_file, file_io=fi)

    return file_to_upload


@celery.task(ignore_result=True)
def notify_scheduler_task(file_to_upload, task, status, error=None):
    import_file, backup_config_file = file_to_upload
    session = requests.session()
    session.verify = False
    session.headers.update(
        {'Authorization': 'Bearer ' + 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lc3RhbXAiOjE2MjE3MDI0MjAsInVzZXIiOiJhZG1pbiJ9.v8s2YlF9RePYloJV1o1bUZG2pOjTbQJ8Fq5lKUgjLu4'})

    url = f'http://10.160.53.227:3000/api/tasks/{task["task_uuid"]}'
    data = {
        "task_uuid": task["task_uuid"],
        "device_uuid": task["device_uuid"],
        "ticket_id": task["ticket_id"],
        "status": f'Worker - {status}',
        "config_file": backup_config_file,
        "report_file": import_file,
    }
    if error:
        data["error"] = str(error)

    print("Data send to scheduler")
    print(data)

    json_data = json.dumps(data).encode('utf-8')
    res = session.post(url, data=json_data)
    if res.status_code == 200:
        print(res.status_code)
    else:
        print(f"Notify scheduler reply failed. status: {res.status_code}")


@celery.task(ignore_result=True)
def workflow(task, local_dir):
    tasks = [
        get_files.subtask(args=(task, local_dir),
                          task_id=task["task_uuid"]),
        chord(parse_tasks.s(task),
              interface_mapping_task.s(task, local_dir)),
        convert_task.s(task),
        decode_task.s(task, local_dir),
        import_task.s(task, local_dir),
        backup_device_task.s(task, local_dir),
        recovery_interface_and_route.s(task, local_dir),
        upload_task.s(task, local_dir),
        notify_scheduler_task.s(task, "Completed")
    ]

    return chain(*tasks)
