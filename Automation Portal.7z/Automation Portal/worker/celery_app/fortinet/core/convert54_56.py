from celery_app.fortinet.model import utils
from celery_app.fortinet.model.config_tree import FGTNodeType


class Convert54_56:

    def __init__(self, fgt):

        self.config_root = fgt.config_root
        self.output_fgt = fgt
        self.curr_vdom = ""
        self.curr_vdom_root = None

    def convert_config_antivirus_profile(self):

        # config antivirus profile
        config = "config"
        key = "set"
        list_value = ["config", "antivirus", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_inspection = ["set", "inspection-mode"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_inspection = node_edit.child_branch.loose_find_tree_node(
                key, list_inspection)
            if node_inspection.node_type.value > 0:
                node_inspection.rename_option("flow-based")

    def convert_config_system_interface(self):

        config = "config"
        list_value = ["config", "system", "interface"]
        node_config = self.curr_vdom_root.loose_find_tree_node(
            config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_remote_ip = ["set", "remote-ip"]
        list_stp = ["set", "stp"]
        list_vdom = ["set", "vdom"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # For some lower-end model, they do not support VDOMs.
            node_vdom = node_edit.child_branch.loose_find_tree_node(
                key, list_vdom)
            if node_vdom.node_type.value == 0:
                node_edit.create_leaf_node(
                    key, ["set", "vdom", self.curr_vdom], 0)

            # remove "config dashboard"
            node_remote_ip = node_edit.child_branch.loose_find_tree_node(
                key, list_remote_ip)
            if node_remote_ip.node_type.value > 0 and len(node_remote_ip.list_value) > 2:
                if len(node_remote_ip.list_value) == 3 and utils.is_ip_address(node_remote_ip.list_value[2]):
                    node_remote_ip.list_value[2] += "/32"

            node_edit.child_branch.find_and_rename_field(
                key, list_stp, "stpforward")

    def convert_config_system_admin(self):

        # config system admin
        config = "config"
        list_value = ["config", "system", "admin"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_dash_board = ["config", "dashboard"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                # remove "config dashboard"
                node_edit.child_branch.find_and_remove_node(
                    config, list_dash_board)

    def convert_config_system_global(self):

        config = "config"
        key = "set"
        list_value = ["config", "system", "global"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove "set registration-notification"
        list_value = ["set", "registration-notification"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove "set phase1-rekey"
        list_value = ["set", "phase1-rekey"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove "set policy-auth-concurrent"
        list_value = ["set", "policy-auth-concurrent"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove "set service-expire-notification"
        list_value = ["set", "service-expire-notification"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove "set disk-usage"
        list_value = ["set", "disk-usage"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove "set explicit-proxy-auth-timeout"
        list_value = ["set", "explicit-proxy-auth-timeout"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove "set optimize"
        list_value = ["set", "optimize"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        list_value = ["set", "gui-local-in-policy"]
        node_gui_local = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        list_value = ["set", "gui-wan-load-balancing"]
        node_gui_wan = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        list_value = ["set", "gui-dhcp-advanced"]
        node_gui_dhcp = node_config.child_branch.loose_find_tree_node(
            key, list_value)

        if node_gui_local.node_type.value > 0 or node_gui_wan.node_type.value > 0 or node_gui_dhcp.node_type.value > 0:
            list_settings = ["config", "system", "settings"]
            node_settings = self.curr_vdom_root.find_or_create_config_node(config, list_settings,
                                                                           node_config.get_location_index() + 1)
            if node_gui_local.node_type.value > 0:
                node_settings.move_tree_node(
                    node_gui_local, node_settings.get_last_leaf_index())
            if node_gui_wan.node_type.value > 0:
                node_settings.move_tree_node(
                    node_gui_wan, node_settings.get_last_leaf_index())
            if node_gui_dhcp.node_type.value > 0:
                node_settings.move_tree_node(
                    node_gui_dhcp, node_settings.get_last_leaf_index())

    def convert_config_system_settings(self):

        config = "config"
        key = "set"
        list_value = ["config", "system", "settings"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # set inspection-mode to flow
        list_value = ["set", "inspection-mode", "proxy"]
        node_inspection = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_inspection.node_type.value != 0:
            node_inspection.rename_option("flow")
            print("We're not support proxy-based migration.")

        # remove "set gui-explicit-proxy xxx"
        list_value = ["set", "gui-explicit-proxy"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove "set gui-casi xxx"
        list_value = ["set", "gui-casi"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove "set gui-ipsec-manual-key xxx"
        list_value = ["set", "gui-ipsec-manual-key"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        list_value = ["set", "tcp-session-without-syn", "enable"]
        node_tcp = node_config.child_branch.find_tree_node(key, list_value)
        if node_tcp.node_type.value > 0:
            list_policy = ["config", "firewall", "policy"]
            node_policy = self.curr_vdom_root.find_tree_node(
                config, list_policy)
            if node_policy.node_type.value > 0:
                list_value = ["set", "tcp-session-without-syn", "all"]
                for node_edit in node_policy.child_branch.list_child:
                    if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                        continue

                    node_edit.create_leaf_node(
                        key, list_value, node_edit.get_location_index() + 1)

    def convert_config_system_fortiguard(self):

        config = "config"
        list_value = ["config", "system", "fortiguard"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_auto_join = ["set", "auto-join-forticloud"]
        node_config.child_branch.loose_find_and_remove_node(
            set, list_auto_join)

    def convert_config_system_ha(self):

        config = "config"
        list_value = ["config", "system", "ha"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_set_interface = ["set", "ha-mgmt-interface"]
        list_set_gateway = ["set", "ha-mgmt-interface-gateway"]
        list_config_interface = ["config", "ha-mgmt-interfaces"]
        list_interface = ["set", "interface", ""]
        list_gateway = ["set", "gateway", ""]

        node_interface = node_config.child_branch.loose_find_tree_node(
            set, list_set_interface)
        node_gateway = node_config.child_branch.loose_find_tree_node(
            set, list_set_gateway)

        if node_interface.node_type.value > 0 or node_gateway.node_type.value > 0:
            node_config_interface = node_config.child_branch.create_blank_config_node(list_config_interface,
                                                                                      node_interface.get_location_index())
            node_edit_interface = node_config_interface.child_branch.create_blank_edit_node(
                "1", 0)

            if node_gateway.node_type.value > 0:
                list_gateway[2] = node_gateway.list_value[2]
                node_edit_interface.create_leaf_node(set, list_gateway, 0)
                node_gateway.remove_tree_node()

            if node_interface.node_type.value > 0:
                list_interface[2] = node_interface.list_value[2]
                node_edit_interface.create_leaf_node(set, list_interface, 0)
                node_interface.remove_tree_node()

    def convert_config_system_snmp_community(self):

        config = "config"
        list_value = ["config", "system", "snmp", "community"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_hosts = ["config", "hosts"]
        list_interface = ["set", "interface"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_hosts = node_edit.child_branch.find_tree_node(
                config, list_hosts)
            if node_hosts.node_type.value == 0:
                continue

            for node_hosts_edit in node_hosts.child_branch.list_child:
                if node_hosts_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_hosts_edit.child_branch.loose_find_and_remove_node(
                    set, list_interface)

    def convert_config_system_centralmanagement(self):

        config = "config"
        list_value = ["config", "system", "central-management"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_allow = ["set", "allow-pushd-firmware"]
        node_config.child_branch.find_and_rename_field(
            set, list_allow, "allow-push-firmware")

    def convert_config_firewall_address(self):

        config = "config"
        list_value = ["config", "firewall", "address"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_fqdn = ["set", "fqdn"]
        list_type = ["set", "type"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_fqdn = node_edit.child_branch.loose_find_tree_node(
                set, list_fqdn)
            if node_fqdn.node_type.value == 0:
                continue

            domain = node_fqdn.list_value[2]
            if "*" in domain or "/" in domain or domain.startswith("\"."):
                node_type = node_edit.child_branch.loose_find_tree_node(
                    set, list_type)
                node_type.rename_option("wildcard-fqdn")
                node_fqdn.rename_field("wildcard-fqdn")

    def convert_config_firewall_policy(self):

        def convert_config_firewall_policy_content(node_config):

            list_casiprofile = ["set", "casi-profile"]
            list_action = ["set", "action"]
            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_casiprofile)
                node_action = node_edit.child_branch.loose_find_tree_node(
                    key, list_action)
                if node_action.node_type.value > 0 and node_action.list_value[2] == "ssl-vpn":
                    node_action.rename_option("accept")

        config = "config"
        key = "set"
        list_value = ["config", "firewall", "policy"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_policy_content(node_config)

        list_value = ["config", "firewall", "policy6"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_policy_content(node_config)

    def convert_config_firewall_sniffer(self):

        config = "config"
        key = "set"
        list_value = ["config", "firewall", "sniffer"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_casi_profile_status = ["set", "casi-profile-status"]
        list_casi_profile = ["set", "casi-profile"]

        list_application_list_status = ["set", "application-list-status"]
        list_application_list = ["set", "application-list"]
        list_application_list_default = [
            "set", "application-list", "sniffer-profile"]

        list_ips_sensor_status = ["set", "ips-sensor-status"]
        list_ips_sensor = ["set", "ips-sensor"]
        list_ips_sensor_default = ["set", "ips-sensor", "sniffer-profile"]

        list_av_profile_status = ["set", "av-profile-status"]
        list_av_profile = ["set", "av-profile"]
        list_av_profile_default = ["set", "av-profile", "sniffer-profile"]

        list_webfilter_profile_status = ["set", "webfilter-profile-status"]
        list_webfilter_profile = ["set", "webfilter-profile"]
        list_webfilter_profile_default = [
            "set", "webfilter-profile", "sniffer-profile"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove field casi-profile-status
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_casi_profile_status)

            # remove field  casi-profile
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_casi_profile)

            node_application_status = node_edit.child_branch.loose_find_tree_node(
                key, list_application_list_status)
            if node_application_status.node_type.value > 0 and node_application_status.list_value[2] == "enable":
                node_application = node_edit.child_branch.loose_find_tree_node(
                    key, list_application_list)
                if node_application.node_type.value == 0:
                    node_edit.create_leaf_node(key, list_application_list_default,
                                               node_application_status.get_location_index() + 1)

            node_ips_sensor_status = node_edit.child_branch.loose_find_tree_node(
                key, list_ips_sensor_status)
            if node_ips_sensor_status.node_type.value > 0 and node_ips_sensor_status.list_value[2] == "enable":
                node_ips_sensor = node_edit.child_branch.loose_find_tree_node(
                    key, list_ips_sensor)
                if node_ips_sensor.node_type.value == 0:
                    node_edit.create_leaf_node(key, list_ips_sensor_default,
                                               node_ips_sensor_status.get_location_index() + 1)

            node_av_profile_status = node_edit.child_branch.loose_find_tree_node(
                key, list_av_profile_status)
            if node_av_profile_status.node_type.value > 0 and node_av_profile_status.list_value[2] == "enable":
                node_av_profile = node_edit.child_branch.loose_find_tree_node(
                    key, list_av_profile)
                if node_av_profile.node_type.value == 0:
                    node_edit.create_leaf_node(key, list_av_profile_default,
                                               node_av_profile_status.get_location_index() + 1)

            node_webfilter_profile_status = node_edit.child_branch.loose_find_tree_node(key,
                                                                                        list_webfilter_profile_status)
            if node_webfilter_profile_status.node_type.value > 0 and node_webfilter_profile_status.list_value[
                    2] == "enable":
                node_webfilter_profile = node_edit.child_branch.loose_find_tree_node(
                    key, list_webfilter_profile)
                if node_webfilter_profile.node_type.value == 0:
                    node_edit.create_leaf_node(key, list_webfilter_profile_default,
                                               node_webfilter_profile_status.get_location_index() + 1)

    def convert_config_firewall_service(self):

        config = "config"
        key = "set"
        list_value = ["config", "firewall", "service", "custom"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_explicit_proxy = ["set", "explicit-proxy"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove field explicit-proxy
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_explicit_proxy)

    def convert_config_firewall_interface_policy(self):

        config = "config"
        key = "set"
        list_value = ["config", "firewall", "interface-policy"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_casi_profile_status = ["set", "casi-profile-status"]
        list_casi_profile = ["set", "casi-profile"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove field casi-profile-status
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_casi_profile_status)

            # remove field  casi-profile
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_casi_profile)

    def convert_config_firewall_explicit_proxy_policy(self):

        config = "config"
        list_value = ["config", "firewall", "explicit-proxy-policy"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value > 0:
            node_config.remove_tree_node()
        else:
            list_value = ["config", "firewall", "proxy-policy"]
            node_config = self.curr_vdom_root.find_tree_node(
                config, list_value)
            if node_config.node_type.value > 0:
                node_config.remove_tree_node()
            else:
                return

        # ignore explicit proxy policy (not supported temporarily)
        print(
            "We do not support explicit proxy migration, ignored explicit proxy settings.")

        '''
        # Change "config firewall explicit-proxy-policy" to "config firewall proxy-policy"
        list_value = ["config", "firewall", "proxy-policy"]
        node_config.rename_command(list_value)

        key = "set"
        list_proxy = ["set", "proxy"]
        
        # Rename "set proxy xxx"
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue
            
            node_proxy = node_edit.child_branch.loose_find_tree_node(key, list_proxy)
            if node_proxy.node_type.value != 0:
                node_proxy.rename_option("transparent-web")
        '''

    def convert_config_firewall_sslsshprofile(self):

        config = "config"
        list_value = ["config", "firewall", "ssl-ssh-profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_log = ["set", "ssl-invalid-server-cert-log"]
        list_certname = ["set", "certname"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_log = node_edit.child_branch.loose_find_tree_node(
                set, list_log)
            if node_log.node_type.value > 0:
                status = node_log.list_value[2]
                list_anomalies_log = ["set", "ssl-anomalies-log", status]
                list_exemptions_log = ["set", "ssl-exemptions-log", status]
                node_edit.create_leaf_node(
                    set, list_anomalies_log, node_log.get_location_index() + 1)
                node_edit.create_leaf_node(
                    set, list_exemptions_log, node_log.get_location_index() + 2)
                node_log.remove_tree_node()

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_certname)

    def convert_config_ftpproxy_explicit(self):

        config = "config"
        list_value = ["config", "ftp-proxy", "explicit"]
        node_config = self.curr_vdom_root.find_and_remove_node(
            config, list_value)

    def convert_config_log_threat_weight(self):

        config = "config"
        list_value = ["config", "log", "threat-weight"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_application = ["config", "application"]
        node_application = node_config.child_branch.find_tree_node(
            config, list_application)
        if node_application.node_type.value == 0:
            return

        # remove node if it contains set category 19
        key = "set"
        list_value = ["set", "category", "19"]
        category19_removed = False
        node_to_be_removed = None
        for node_edit in node_application.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_category = node_edit.child_branch.find_tree_node(
                key, list_value)
            if node_category.node_type.value > 0:
                node_to_be_removed = node_edit
                category19_removed = True

            if category19_removed:
                idx = int(node_edit.list_value[1])
                node_edit.list_value[1] = str(idx - 1)

        if node_to_be_removed:
            node_to_be_removed.remove_tree_node()

    def convert_config_log_syslogd_setting(self):

        config = "config"
        key = "set"
        list_value = ["config", "log", "syslogd", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set csv"
        list_value = ["set", "csv"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_log_guidisplay(self):

        config = "config"
        set = "set"
        list_value = ["config", "log", "gui-display"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_location = ["set", "location"]
        list_local_traffic = ["set", "fortiview-local-traffic"]
        node_location = node_config.child_branch.loose_find_tree_node(
            set, list_location)
        if node_location.node_type.value > 0 and node_location.list_value[2] == "fortiguard":
            node_location.rename_option("forticloud")

        node_config.child_branch.loose_find_and_remove_node(
            set, list_local_traffic)

    def convert_config_log_fortianalyzer_setting(self):

        list_postfix = ["", "2", "3"]

        config = "config"
        set = "set"

        for postfix in list_postfix:
            list_value = ["config", "log",
                          "fortianalyzer" + postfix, "setting"]
            node_config = self.curr_vdom_root.find_tree_node(
                config, list_value)
            if node_config.node_type.value == 0:
                continue

            list_enc_algorithm = ["set", "enc-algorithm"]
            node_enc_algorithm = node_config.child_branch.loose_find_tree_node(
                set, list_enc_algorithm)
            if node_enc_algorithm.node_type.value == 0:
                continue

            type = node_enc_algorithm.list_value[2]
            if type == "default":
                node_enc_algorithm.rename_option("high-medium")
            elif type == "disable":
                node_enc_algorithm.remove_tree_node()

    def convert_config_webfilter_profile(self):

        config = "config"
        list_value = ["config", "webfilter", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["edit", "\"block-security-risks\""]
        node_block_security_risk = node_config.child_branch.loose_find_tree_node(
            "edit", list_value)
        node_block_security_risk.remove_tree_node()

        key = "set"
        list_inspection = ["set", "inspection-mode"]
        list_flowbased = ["set", "inspection-mode", "flow-based"]
        list_post_action = ["set", "post-action"]
        list_options = ["set", "options"]
        removed_options = ["rangeblock", "d-url",
                           "https-urlscan", "javafilter", "https-scan"]
        removed_options_ftgd = ["rate-image-urls", "redir-block"]
        list_web = ["config", "web"]
        list_youtube_filter = ["set", "youtube-edu-filter-id"]
        list_youtube_restrict = ["set", "youtube-restrict", "strict"]
        list_ovrd_perm = ["set", "ovrd-perm"]

        list_dnsfilter = ["config", "dnsfilter", "profile"]
        list_ftgd = ["config", "ftgd-wf"]
        list_url_filter_table = ["set", "urlfilter-table"]
        list_category_override = ["set", "category-override"]
        list_sdns_action = ["set", "web-filter-sdns-action"]
        list_botnet = ["set", "block-botnet", "enable"]
        list_node_to_be_removed = []

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove "set post-action"
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_post_action)

            # insert command "set inspcetion-mode flow-based" if not exist
            node_inspection = node_edit.child_branch.loose_find_tree_node(
                key, list_inspection)
            if node_inspection.node_type.value == 0:
                node_edit.create_leaf_node(key, list_flowbased, 0)
            elif node_inspection.list_value[2] == "dns":
                # move node with "set inspection-mode dns" to "config dnsfilter profile"
                node_inspection.remove_tree_node()
                node_dnsfilter = self.curr_vdom_root.find_or_create_config_node(config,
                                                                                list_dnsfilter,
                                                                                node_config.get_location_index() + 1)
                node_dnsfilter.insert_tree_node(
                    node_edit, node_dnsfilter.get_last_leaf_index())

                node_ftgd = node_edit.child_branch.find_tree_node(
                    config, list_ftgd)
                node_ftgd.rename_field("ftgd-dns")
                node_ftgd.child_branch.loose_find_and_remove_node(
                    key, list_category_override)

                node_web = node_edit.child_branch.find_tree_node(
                    config, list_web)
                if node_web.node_type.value > 0:
                    node_web.rename_field("domain-filter")
                    node_web.child_branch.loose_find_and_remove_node(
                        key, list_url_filter_table)

                node_sdns_action = node_edit.child_branch.loose_find_tree_node(
                    key, list_sdns_action)
                if node_sdns_action.node_type.value > 0:
                    node_sdns_action.rename_field("block-action")
                    if node_sdns_action.list_value[2] == "block":
                        node_edit.create_leaf_node(
                            key, list_botnet, node_sdns_action.get_location_index() + 1)

                list_node_to_be_removed.append(node_edit)
                continue

            node_options = node_edit.child_branch.loose_find_tree_node(
                key, list_options)
            if node_options.node_type.value > 0:
                for option in removed_options:
                    if option in node_options.list_value:
                        node_options.list_value.remove(option)
                if len(node_options.list_value) == 2:
                    node_options.list_value[0] = "unset"
                    node_options.key = "unset"

            node_web = node_edit.child_branch.find_tree_node(config, list_web)
            if node_web.node_type.value > 0:
                node_youtube_filter = node_web.child_branch.loose_find_tree_node(
                    key, list_youtube_filter)
                if node_youtube_filter.node_type.value > 0:
                    node_youtube_filter.list_value = list_youtube_restrict

            node_ftgd = node_edit.child_branch.find_tree_node(
                config, list_ftgd)
            if node_ftgd.node_type.value > 0:
                node_options = node_ftgd.child_branch.loose_find_tree_node(
                    key, list_options)
                if node_options.node_type.value > 0:
                    for option in removed_options_ftgd:
                        if option in node_options.list_value:
                            node_options.list_value.remove(option)
                    if len(node_options.list_value) == 2:
                        node_options.list_value[0] = "unset"
                        node_options.key = "unset"

            node_edit.child_branch.loose_find_and_remove_node(
                key, list_ovrd_perm)

        for node in list_node_to_be_removed:
            node_config.child_branch.list_child.remove(node)

    def convert_config_webfilter_overrideuser(self):

        config = "config"
        list_value = ["config", "webfilter", "override-user"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # Not sure if we should remove this node or combine it into "config webfilter override".
        node_config.remove_tree_node()

    def convert_config_webfilter_ftgdwarning(self):

        config = "config"
        list_value = ["config", "webfilter", "ftgd-warning"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

    def convert_config_spamfilter_bwl(self):

        config = "config"
        list_value = ["config", "spamfilter", "bwl"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_name = ["set", "name"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_name = node_edit.child_branch.loose_find_tree_node(
                set, list_name)
            name = node_name.list_value[2]
            if len(name) > 35:
                node_name.list_value[2] = name[:35]

    def convert_config_webproxy_explicit(self):

        config = "config"
        list_value = ["config", "web-proxy", "explicit"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove config web-proxy explicit
        node_config.remove_tree_node()

    def convert_config_wireless_controller_widsprofile(self):

        config = "config"
        list_value = ["config", "wireless-controller", "wids-profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_roguescan = ["set", "rogue-scan"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_roguescan)

    def convert_config_wireless_controller_vap(self):
        config = "config"
        list_value = ("config", "wireless-controller", "vap")

        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_vdom = ("set", "vdom")
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_vdom = node_edit.child_branch.loose_find_tree_node(
                key, list_vdom)
            if node_vdom.node_type.value == 0:
                node_edit.create_leaf_node(
                    key, ["set", "vdom", self.curr_vdom], 0)

    def convert_config_endpoint_control_profile(self):

        # config endpoint-control profile
        config = "config"
        key = "set"
        list_value = ["config", "endpoint-control", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set forticlient-ui-options av wf af vpn vs"
        list_value = ["set", "forticlient-ui-options"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            ui_options = node_edit.child_branch.loose_find_tree_node(
                key, list_value)
            if ui_options.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                '''
                config forticlient-winmac-settings
                set forticlient-ui-options av wf af vpn vs
                set forticlient-wf-profile "default"
                end
                '''
                winmac_setting_node = ui_options.parent_branch.associate_node
                if "av" in ui_options.list_value:
                    # Insert new command "set forticlient-av"
                    av_option = ui_options.clone(ui_options.parent_branch)
                    av_option.list_value = ["set", "forticlient-av", "enable"]
                    winmac_setting_node.insert_tree_node(av_option, 0)

                if "wf" in ui_options.list_value:
                    # Insert new command "set forticlient-wf"
                    wf_option = ui_options.clone(ui_options.parent_branch)
                    wf_option.list_value = ["set", "forticlient-wf", "enable"]
                    winmac_setting_node.insert_tree_node(wf_option, 0)

                if "af" in ui_options.list_value:
                    # Insert new command "set forticlient-application-firewall-list "default" "
                    af_rule_list_option = ui_options.clone(
                        ui_options.parent_branch)
                    af_rule_list_option.list_value = [
                        "set", "forticlient-application-firewall-list", "\"default\""]
                    winmac_setting_node.insert_tree_node(
                        af_rule_list_option, 0)

                    # Insert new command "set forticlient-application-firewall"
                    af_option = ui_options.clone(ui_options.parent_branch)
                    af_option.list_value = [
                        "set", "forticlient-application-firewall", "enable"]
                    winmac_setting_node.insert_tree_node(af_option, 0)

                if "vpn" in ui_options.list_value:
                    # didn't find out the command
                    pass

                if "vs" in ui_options.list_value:
                    # Insert new command "set forticlient-vuln-scan"
                    vs_option = ui_options.clone(ui_options.parent_branch)
                    vs_option.list_value = [
                        "set", "forticlient-vuln-scan", "enable"]
                    winmac_setting_node.insert_tree_node(vs_option, 0)

                ui_options.remove_tree_node()

    def convert_config_vpn_ssl_web_portal(self):

        config = "config"
        list_value = ["config", "vpn", "ssl", "web", "portal"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_value_virtual_desktop = [
            ["set", "virtual-desktop"], ["set", "virtual-desktop-app-list"],
            ["set", "virtual-desktop-clipboard-share"], ["set",
                                                         "virtual-desktop-desktop-switch"],
            ["set", "virtual-desktop-logout-when-browser-close"], ["set",
                                                                   "virtual-desktop-network-share-access"],
            ["set", "virtual-desktop-printing"], ["set",
                                                  "virtual-desktop-removable-media-access"]
        ]

        list_ippools = ["set", "ip-pools"]
        list_ipv6pools = ["set", "ipv6-pools"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            for list_virtual_desktop in list_value_virtual_desktop:
                node_edit.child_branch.loose_find_and_remove_node(
                    set, list_virtual_desktop)

            node_ippools = node_edit.child_branch.loose_find_tree_node(
                set, list_ippools)
            if node_ippools.node_type.value > 0 and node_ippools.list_value[2] == "\"\"":
                node_ippools.remove_tree_node()

            node_ipv6pools = node_edit.child_branch.loose_find_tree_node(
                set, list_ipv6pools)
            if node_ipv6pools.node_type.value > 0 and node_ipv6pools.list_value[2] == "\"\"":
                node_ipv6pools.remove_tree_node()

    def convert_config_vpn_certificate_local(self):

        config = "config"
        list_value = ["config", "vpn", "certificate", "local"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_last_updated = ["set", "last-updated"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_last_updated)

    def convert_config_dnsfilter_urlfilter(self):

        config = "config"
        list_value = ["config", "dnsfilter", "urlfilter"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.rename_option("domain-filter")

        set = "set"
        list_url = ["set", "url"]
        list_entries = ["config", "entries"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_entries = node_edit.child_branch.loose_find_tree_node(
                config, list_entries)
            if node_entries.node_type.value == 0:
                continue

            for node_entry_edit in node_entries.child_branch.list_child:
                if node_entry_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_entry_edit.child_branch.find_and_rename_field(
                    set, list_url, "domain")

    def convert_config_application(self):

        config = "config"
        list_value = ["config", "application", "casi", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove config application casi profile setting
        node_config.remove_tree_node()

    def convert_config_gui_console(self):

        config = "config"
        list_value = ["config", "gui", "console"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove config gui console settings
        node_config.remove_tree_node()

    def convert_config_user_setting(self):

        config = "config"
        list_value = ["config", "user", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_auth_cert = ["set", "auth-cert"]
        node_auth_cert = node_config.child_branch.loose_find_tree_node(
            set, list_auth_cert)
        if node_auth_cert.node_type.value > 0:
            node_auth_cert.rename_option('"Fortinet_Factory"')

        list_auth_multigroup = ["set", "auth-multi-group"]
        node_config.child_branch.loose_find_and_remove_node(
            set, list_auth_multigroup)

    def convert_config_user_adgrp(self):

        config = "config"
        list_value = ["config", "user", "adgrp"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_pollingid = ["set", "polling-id"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_config.child_branch.loose_find_and_remove_node(
                set, list_pollingid)

    def convert_config_user_group(self):
        config = "config"
        list_value = ["config", "user", "group"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_guest = ["config", "guest"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_config.child_branch.loose_find_and_remove_node(
                config, list_guest)

    def convert_config_ips_global(self):

        config = "config"
        list_value = ["config", "ips", "global"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_app_cat_mask = ["set", "default-app-cat-mask"]
        list_algorithm = ["set", "algorithm"]
        node_config.child_branch.loose_find_and_remove_node(
            set, list_app_cat_mask)
        node_config.child_branch.loose_find_and_remove_node(
            set, list_algorithm)

    def convert_config_ips_dbinfo(self):

        config = "config"
        list_value = ["config", "ips", "dbinfo"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove config ips dbinfo settings
        node_config.remove_tree_node()

    def convert_netscan_settings(self):

        config = "config"
        list_value = ["config", "netscan", "settings"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove config netscan settings
        node_config.remove_tree_node()

    def convert_config(self):

        try:
            self.convert_config_antivirus_profile()
            self.convert_config_system_interface()
            self.convert_config_system_admin()
            self.convert_config_system_global()
            self.convert_config_system_settings()
            self.convert_config_system_fortiguard()
            self.convert_config_system_ha()
            self.convert_config_system_snmp_community()
            self.convert_config_system_centralmanagement()
            self.convert_config_firewall_address()
            self.convert_config_firewall_policy()
            self.convert_config_firewall_sniffer()
            self.convert_config_firewall_service()
            self.convert_config_firewall_interface_policy()
            self.convert_config_firewall_explicit_proxy_policy()
            self.convert_config_firewall_sslsshprofile()
            self.convert_config_ftpproxy_explicit()
            self.convert_config_log_threat_weight()
            self.convert_config_log_syslogd_setting()
            self.convert_config_log_guidisplay()
            self.convert_config_log_fortianalyzer_setting()
            self.convert_config_webfilter_profile()
            self.convert_config_webfilter_overrideuser()
            self.convert_config_webfilter_ftgdwarning()
            self.convert_config_spamfilter_bwl()
            self.convert_config_webproxy_explicit()
            self.convert_config_wireless_controller_widsprofile()
            self.convert_config_wireless_controller_vap()
            self.convert_config_endpoint_control_profile()
            self.convert_config_vpn_ssl_web_portal()
            self.convert_config_vpn_certificate_local()
            self.convert_config_dnsfilter_urlfilter()
            self.convert_config_application()
            self.convert_config_user_setting()
            self.convert_config_user_adgrp()
            self.convert_config_user_group()
            self.convert_config_gui_console()
            self.convert_config_ips_global()
            self.convert_config_ips_dbinfo()
            self.convert_netscan_settings()

        except Exception as e:
            print("Convert5.4_5.6 Error")
            raise e

    # Convert v5.4 to v5.6
    def convert_config_54_to_56(self):

        key = "config"
        list_global = ["config", "global"]
        list_vdom = ["config", "vdom"]

        node_global = self.config_root.find_tree_node(key, list_global)
        list_node_vdom = self.config_root.strict_match_tree_node(
            key, list_vdom)

        if node_global.node_type.value > 0 and len(list_node_vdom) > 0:
            # Enable VDOM mode
            self.curr_vdom = node_global.list_value[1]
            self.curr_vdom_root = node_global.child_branch
            self.convert_config()

            for node_vdom in list_node_vdom:
                for node_edit in node_vdom.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node_edit.get_last_leaf_index() > 0:
                        self.curr_vdom = node_edit.list_value[1]
                        self.curr_vdom_root = node_edit.child_branch
                        self.convert_config()

        elif len(list_node_vdom) == 0 and node_global.node_type.value == 0:
            # Disable VDOM mode
            self.curr_vdom = "root"
            self.curr_vdom_root = self.config_root
            self.convert_config()
