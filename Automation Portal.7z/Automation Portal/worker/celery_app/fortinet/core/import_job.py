import json
import time
from urllib.parse import quote

from celery_app.connector.fortios import login_required
from celery_app.fortinet.model.fortigate import FGTNodeType
from celery_app.fortinet.model.utils import remove_quota

from . import constants
from .import_helper import FGTPayloadHelper
from .import_node import ImportFGTNode, ImportStatus


class ImportJob:
    def __init__(self, device, worker_dir) -> None:
        self.fgt_device = device
        self.vdom_enable = self.fgt_device.is_vdom_enabled()
        self.worker_dir = worker_dir
        self.connector = None
        self.logging = None

        self.curr_index = 0

        self.import_node_list = []
        self.import_record = []
        self.vdom_mapping_param = {"root": "root"}
        self.payload = FGTPayloadHelper()

    def is_global_node(self, node):
        for cmdb in constants.GLOBAL_SCOPE_CMDB:
            compare_node = node.FGTNode if node.is_config_node else node.parent_node
            if compare_node.loose_compare_node_value("config", cmdb):
                return True

        return False

    def is_interface_node(self, node):
        return node.cmdb == "config system interface"

    def initialize_import_queue(self):
        return self.construct_import_queue_by_device_tree_multivdom(self.fgt_device) if self.vdom_enable \
            else self.construct_import_queue_by_device_tree(self.fgt_device.config_root)

    def construct_import_queue_by_device_tree(self, device, vdom="root"):
        import_node_list = []
        for node in device.list_child:
            if node.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            if len(node.child_branch.list_child) <= 1:
                continue

            cmdb = " ".join(node.list_value)
            path = ".".join(node.list_value[1:-1])
            name = node.list_value[-1]

            # if vdom == "global" and self.import_to_one_vdom:
            #     if cmdb != "config system interface":
            #         continue

            # Get keys in list_node
            key_set = set(node.key for node in node.child_branch.list_child)
            # TODO: "config system replacemsg *" is edit node, but would be determined to config node in current logic. [workaround for now]
            if key_set & {"edit"} or cmdb.startswith("config system replacemsg"):
                # If edit is the key in list_child, it means the cmdb is type of edit_node
                # config system interface
                #     edit xxx
                #     next
                # end
                node_type = "edit_node"
                for node_edit in node.child_branch.list_child:
                    if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                        continue

                    import_node = ImportFGTNode(vdom=vdom,
                                                cmdb=cmdb,
                                                node_name=node_edit.list_value[-1],
                                                type=node_type,
                                                status=ImportStatus.IMPORT_STATUS_PREVIEW,
                                                FGTNode=node_edit,
                                                path=path,
                                                name=name,
                                                parent_node=node)
                    import_node_list.append(import_node)

            elif key_set & {"set", "unset", "config"}:
                # If one of set, unset, or config is the key in list_child, it means the cmdb is type of config node
                # config system settings
                #     set xxx
                #     unset xxx
                # end
                node_type = "config_node"
                import_node = ImportFGTNode(vdom=vdom,
                                            cmdb=cmdb,
                                            node_name="",
                                            type=node_type,
                                            status=ImportStatus.IMPORT_STATUS_PREVIEW,
                                            FGTNode=node,
                                            path=path,
                                            name=name)
                import_node_list.append(import_node)

        return import_node_list

    def construct_import_queue_by_device_tree_multivdom(self, device):
        import_node_list = []

        for node in device.config_root.list_child:
            if node.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            if len(node.child_branch.list_child) <= 1:
                continue

            scope = node.list_value[-1]

            if node.key == "config" and scope == "global":
                import_node_list.extend(
                    self.construct_import_queue_by_device_tree(node.child_branch, scope))
            elif node.key == "config" and scope == "vdom":
                for vdom in self.vdom_mapping.values():
                    key = "edit"
                    list_value = [key, vdom]
                    find_node = node.child_branch.find_tree_node(
                        key, list_value)
                    import_node_list.extend(
                        self.construct_import_queue_by_device_tree(find_node.child_branch, vdom))

        return import_node_list

    def set_vdom(self):
        vdom_list = self.fgt_device.collect_vdom_list()
        self.vdom_mapping_param = {vdom: vdom.replace(
            " ", "%20") for vdom in vdom_list}

    def get_existing_entry(self, path, name):
        entry_list = {}

        try:
            for vdom in self.vdom_mapping_param.values():
                entry_list[vdom] = []
                getentry_result = self.connector.get(
                    "cmdb", path, name, "", "", {"vdom": vdom})
                data = json.loads(getentry_result)
                if "results" in data:
                    for item in data["results"]:
                        if "q_origin_key" in item:
                            entry_list[vdom].append(
                                str(item["q_origin_key"]))
        except Exception as ex:
            pass
        finally:
            return entry_list

    def check_global_obj_exist(self, edit_title, entry_list):
        for vdom in entry_list:
            if edit_title in entry_list[vdom]:
                return True
        return False

    def import_edit_node(self, node, cmd_node, path, name, entry_list, vdom="root"):
        node_api, import_status, message = self.get_restapi_supported_node(
            node, cmd_node)
        if not node_api:
            return import_status, message, None

        payload = self.payload.get(node_api, cmd_node)

        edit_title = remove_quota(node_api.list_value[1])

        try:
            if vdom == "global":
                if self.check_global_obj_exist(edit_title, entry_list):
                    res = self.connector.put("cmdb", path, name, quote(edit_title, safe=''),
                                             "", {"global": "1"}, payload)
                else:
                    res = self.connector.post("cmdb", path, name, "", "", {
                                              "global": "1"}, payload)
            else:
                vdom_param = self.vdom_mapping_param[vdom] if vdom in self.vdom_mapping_param else None
                vdom_payload = {"vdom": vdom_param} if vdom_param else {}

                if vdom in entry_list and edit_title in entry_list[vdom]:
                    res = self.connector.put("cmdb", path, name, quote(edit_title, safe=''),
                                             "", vdom_payload, payload)
                else:
                    res = self.connector.post(
                        "cmdb", path, name, "", "", vdom_payload, payload)

            if res.status_code == 200:
                self.logging.debug(
                    "{0} - {1} success, {2} {3}".format(cmd_node, edit_title, res.status_code, res.reason))

                calculate_status = import_status if import_status else ImportStatus.IMPORT_STATUS_SUCCESS
                return calculate_status, message, {"code": res.status_code, "reason": res.reason}
            else:
                self.logging.debug(
                    "{0} - {1} failed, {2} {3}".format(cmd_node, edit_title, res.status_code, ""))

                return ImportStatus.IMPORT_STATUS_ERROR, message, {"code": res.status_code, "reason": res.reason}
        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise Exception(
                f'Exception raised while importing {cmd_node}->{name}: {ex}')

    def import_config_node(self, node, path, name, vdom="root"):
        cmd_node = node.get_desp_string()

        node_api, import_status, message = self.get_restapi_supported_node(
            node, cmd_node)
        if not node_api:
            return import_status, message, None

        payload = self.payload.get(node_api, cmd_node)

        try:
            if vdom == "global":
                vdom_payload = {"global": "1"}
            else:
                vdom_param = self.vdom_mapping_param[vdom] if vdom in self.vdom_mapping_param else None
                vdom_payload = {"vdom": vdom_param} if vdom_param else {}

            res = self.connector.put(
                "cmdb", path, name, "", "", vdom_payload, payload)
            if res.status_code == 200:
                self.logging.debug("{0} success, {1} {2}".format(
                    cmd_node, res.status_code, res.reason))
                calculate_status = import_status if import_status else ImportStatus.IMPORT_STATUS_SUCCESS
                return calculate_status, message, {"code": res.status_code, "message": res.reason}
            else:
                self.logging.debug("{0} failed, {1} {2}".format(
                    cmd_node, res.status_code, res.reason))

                return ImportStatus.IMPORT_STATUS_ERROR, message, {"code": res.status_code, "reason": res.reason}
        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise Exception(
                f'Exception raised while importing {cmd_node}->{name}: {ex}')

    def import_node(self, import_node, vdom="root", entry_list=None):
        if import_node.is_edit_node:
            import_status, message, err = self.import_edit_node(import_node.FGTNode,
                                                                import_node.cmdb,
                                                                import_node.path,
                                                                import_node.name,
                                                                entry_list,
                                                                vdom)
        elif import_node.is_config_node:
            import_status, message, err = self.import_config_node(import_node.FGTNode,
                                                                  import_node.path,
                                                                  import_node.name,
                                                                  vdom)
        return import_status, message, err

    def get_cli(self, index):
        node = self.import_node_list[int(index)]
        return ''.join([node.category, node.cli, node.end]) if node.is_edit_node else node.cli

    def save_import_record(self, index: int, node: ImportFGTNode, import_status: str, message=None, api_response=None):
        _dict = {
            "index": index,
            "vdom": node.vdom,
            "cmdb": node.cmdb,
            "status": import_status.value,
            "node": {
                "cmdb": node.cmdb,
                "node_name": node.node_name,
                "node_type": node.node_type,
                "cli": self.get_cli(index)
            },
        }

        if message:
            _dict["hints"] = message

        if api_response:
            _dict["response"] = api_response

        self.import_record.append(_dict)

    @login_required
    def import_all(self):
        try:
            self.status = "running"
            exists_entry_mapping = {}
            for index, node in enumerate(self.import_node_list):
                if node.is_edit_node and \
                        node.cmdb not in exists_entry_mapping:
                    exists_entry_mapping[node.cmdb] = self.get_existing_entry(
                        node.path, node.name)

                # if self.is_interface_node(node):
                #     self.save_import_record(index, node, ImportStatus.IMPORT_STATUS_IGNORE, [
                #                             {"action": "Ignore Interface node", "message": ""}])
                #     continue

                import_status, message, api_response = self.import_node(
                    node, node.vdom, exists_entry_mapping.get(node.cmdb))

                if node.import_twice:
                    # Workaoround, there's bug in some cmdb and will fail in POST request.
                    # We have to import twice before FortiOS fix the issue.
                    exists_entry_mapping[node.cmdb] = self.get_existing_entry(
                        node.path, node.name)
                    import_status, message, api_response = self.import_node(
                        node, node.vdom, exists_entry_mapping.get(node.cmdb))

                self.save_import_record(
                    index, node, import_status, message, api_response)

                # Delay 0.05 seconds between RESTAPI call
                time.sleep(0.05)
        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise Exception(ex)
        finally:
            self.status = "finished"

    def get_restapi_supported_node(self, node, cmd_node):
        if cmd_node == "config system global":
            return self.get_restapi_supported_global_node(node)

        elif cmd_node == "config system settings":
            return self.get_restapi_supported_settings_node(node)

        elif cmd_node == "config system interface":
            return self.get_restapi_supported_interface_node(node)

        elif cmd_node == "config vpn ssl settings":
            return self.get_restapi_vpn_ssl_settings_payload(node)

        elif cmd_node == "config firewall ssl-ssh-profile":
            return self.get_restapi_supported_ssl_ssh_profile_node(node)

        elif cmd_node == "config user ldap":
            return self.get_restapi_supported_user_ldap_node(node)

        elif cmd_node == "config system admin":
            return self.get_restapi_supported_system_admin(node)

        elif cmd_node == "config wanopt settings":
            message = {"action": "Ignore an unsupported node",
                       "message": "WAN Optimization is available on models with internal storage, enable WAN Opt. & Cache in Feature Visibility. and fix with the CLI."}
            return None, ImportStatus.IMPORT_STATUS_IGNORE, [message]

        elif cmd_node == "config wanopt profile":
            message = {"action": "Ignore an unsupported node",
                       "message": "WAN Optimization is available on models with internal storage, enable WAN Opt. & Cache in Feature Visibility. and fix with the CLI."}
            message = "Ignore an unsupported node. WAN Optimization is available on models with internal storage, enable WAN Opt. & Cache in Feature Visibility. and fix with the CLI."
            return None, ImportStatus.IMPORT_STATUS_IGNORE, [message]

        elif cmd_node == "config system password-policy":
            message = {"action": "Ignore an unsupported node",
                       "message": "change the password policy may lead to device authorization failure and interrupt import process. Please directly fix this on device after the conversion. "}
            return None, ImportStatus.IMPORT_STATUS_IGNORE, [message]

        elif cmd_node == "config user fortitoken":
            message = {"action": "Ignore an unsupported node",
                       "message": "Please follow the external doc for migrate your FortiToken. https://docs.fortinet.com/document/forticonverter/6.2.0/online-help/674668/manual-configuration-migration-prerequisite"}
            return None, ImportStatus.IMPORT_STATUS_IGNORE, [message]

        elif cmd_node.startswith("config certificate"):
            message = {"action": "Ignore import the certificate",
                       "message": ""}
            return None, ImportStatus.IMPORT_STATUS_IGNORE, [message]

        elif cmd_node == "config vpn certificate setting":
            message = {"action": "Ignore import the certificate",
                       "message": ""}
            return None, ImportStatus.IMPORT_STATUS_IGNORE, [message]

        elif cmd_node.startswith("config vpn certificate"):
            message = {"action": "Ignore import the certificate",
                       "message": ""}
            return None, ImportStatus.IMPORT_STATUS_IGNORE, [message]

        elif cmd_node.startswith("config firewall ssh") and cmd_node != "config firewall ssh setting":
            message = {"action": "Ignore SSH setting",
                       "message": "Pleaes manually re-generate ssh-key after the conversion."}
            return None, ImportStatus.IMPORT_STATUS_IGNORE, [message]
        return node, None, []

    def get_restapi_supported_global_node(self, node):
        reason_list = []
        status = None
        key = "set"
        list_value_sport = ("set", "admin-sport")
        find_node = node.child_branch.loose_find_tree_node(
            key, list_value_sport)
        if find_node.node_type.value != 0:
            status = ImportStatus.IMPORT_STATUS_WARNING
            reason_list.append({
                "action": "Ignore \"set admin-sport <N>\"",
                "message": "Change the default admin access port 443 will disconnect device and interrupt import process, please manually fix this."
            })
            find_node.remove_tree_node()

        list_value_port = ("set", "admin-port")
        find_node = node.child_branch.loose_find_tree_node(
            key, list_value_port)
        if find_node.node_type.value != 0:
            status = ImportStatus.IMPORT_STATUS_WARNING
            reason_list.append({
                "action": "Ignore \"set admin-port <N>\"",
                "message": "Change the default admin access port 80 will disconnect device and interrupt import process, please manually fix this."
            })
            find_node.remove_tree_node()

        list_value_server_cert = ("set", "admin-server-cert")
        find_node = node.child_branch.loose_find_tree_node(
            key, list_value_server_cert)
        if find_node.node_type.value != 0:
            status = ImportStatus.IMPORT_STATUS_WARNING
            reason_list.append({
                "action": "Ignore \"set admin-server-cert <str>\"",
                "message": "Please fix this on device after re-upload the necessary certificate."
            })
            find_node.remove_tree_node()

        return node, status, reason_list

    def get_restapi_supported_settings_node(self, node):
        status = None
        reason_list = []
        # We can use RESTAPI to change opmode in multi-vdom case.
        if self.vdom_enable:
            return node, status, reason_list

        # For single VDOM, we should avoid to change opmode during the RESTAPI import to avoid disconnection.
        key = "set"
        list_value_opmode = ("set", "opmode")
        find_node = node.child_branch.loose_find_tree_node(
            key, list_value_opmode)
        if find_node.node_type.value != 0:
            status = ImportStatus.IMPORT_STATUS_WARNING
            reason_list.append({
                "action": "Ignore \"set opmode <str>\"",
                "message": "Change opmode will disconnect device and interrupt import process, please manually fix this"
            })
            find_node.remove_tree_node()

        list_value_manageip = ("set", "manageip")
        find_node = node.child_branch.loose_find_tree_node(
            key, list_value_manageip)
        if find_node.node_type.value != 0:
            status = ImportStatus.IMPORT_STATUS_WARNING
            reason_list.append({
                "action": "Ignore \"set manageip <str>\"",
                "message": "Change manageip will disconnect device and interrupt import process, please manually fix this"
            })
            find_node.remove_tree_node()

        return node, status, reason_list

    def get_restapi_supported_interface_node(self, node):
        # We can't new an interface which type is "tunnel" or "vap-switch".
        reason_list = []
        status = None
        key = "set"
        list_value = ["set", "type"]
        list_options = ["tunnel", "vap-switch"]
        leaf_node = node.child_branch.get_options_leaf_in_node(
            key, list_value, list_options)
        if leaf_node:
            status = ImportStatus.IMPORT_STATUS_IGNORE
            reason_list.append({
                "action": f'Skipped \"{leaf_node.list_value[2]}\" tunnel interface',
                "message": "No further action needed."})
        return (None, status, []) if leaf_node else (node, status, [])

    def get_restapi_vpn_ssl_settings_payload(self, node):
        reason_list = []
        status = None
        key = "set"
        list_value = ("set", "servercert")
        find_node = node.child_branch.loose_find_tree_node(key, list_value)
        if find_node.node_type.value != 0:
            status = ImportStatus.IMPORT_STATUS_WARNING
            reason_list.append({
                "action": "Ignore \"set servercert <str>\"",
                "message": "Fix this after re-upload the necessary certificate."
            })
            find_node.remove_tree_node()
        return node, status, reason_list

    def get_restapi_supported_ssl_ssh_profile_node(self, node):
        reason_list = []
        status = None
        key = "edit"
        if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node.key == key:
            if node.list_value[1] in ('"deep-inspection"', '"certificate-inspection"'):
                status = ImportStatus.IMPORT_STATUS_IGNORE
                reason_list.append({
                    "action": f'Ignore Read-Only default profile\"{remove_quota(node.list_value[1])}\"',
                    "message": "If you don't modify it, then you don't have to take action."
                })
                return None, status, []

        # remove certificate field if needed.
        key = "set"
        list_value = ("set", "caname")
        find_node = node.child_branch.loose_find_tree_node(key, list_value)
        if find_node.node_type.value != 0:
            status = ImportStatus.IMPORT_STATUS_WARNING
            reason_list.append({
                "action": "Ignore \"set caname <str>\"",
                "message": "Please fix this after re-upload the necessary certificate."
            })
            find_node.remove_tree_node()
        return node, status, reason_list

    def get_restapi_supported_user_ldap_node(self, node):
        reason_list = []
        status = None
        key = "set"
        list_value = ("set", "ca-cert")
        find_node = node.child_branch.loose_find_tree_node(key, list_value)
        if find_node.node_type.value != 0:
            status = ImportStatus.IMPORT_STATUS_WARNING
            reason_list.append({
                "action": "Ignore \"set ca-cert <str>\"",
                "message": "Please fix this after re-upload the necessary certificate."
            })
            find_node.remove_tree_node()

        return node, status, reason_list

    def get_restapi_supported_system_admin(self, node):
        reason_list = []
        status = None
        key = "edit"
        if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node.key == key:
            # Suppose user default use "admin" to perform RESTAPI connection.
            if node.list_value[1] == '"admin"':
                status = ImportStatus.IMPORT_STATUS_IGNORE
                reason_list.append({
                    "action": "Ignore admin user",
                    "message": "The admin user may used to communicated with device via REST API connection, please manually fix this."
                })

        return node, status, reason_list

    def dump_import_record(self):
        import_record = f'import_record_{time.strftime("%Y%m%d_%H%M%S")}.json'
        with open(self.worker_dir / import_record, 'w', encoding='utf-8') as f:
            json.dump(self.import_record, f, ensure_ascii=False, indent=4)

        return import_record

    def run(self):
        try:
            self.import_node_list = self.initialize_import_queue()
            self.set_vdom()
            self.import_all()
        except ConnectionError as ce:
            raise Exception(f'Lost connection while importing. {ce}')
        except Exception as ex:
            raise Exception(f'Exception raised while importing. {ex}')
        finally:
            return self.dump_import_record()
