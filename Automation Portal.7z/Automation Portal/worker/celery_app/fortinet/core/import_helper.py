from celery_app.fortinet.model.config_tree import FGTNodeType

OBJECT_ID_NAME_MAPPING = {"config router static": "seq-num",
                          "config firewall policy": "policyid",
                          "config webfilter ftgd-local-rating": "url",
                          "config webfilter ftgd-local-cat": "desc",
                          "config firewall address": "name",
                          "config firewall address tagging": "name",
                          "config firewall addrgrp": "name",
                          "config firewall service custom": "name",
                          "config firewall service group": "name",
                          "config firewall local-in-policy": "policyid",
                          "config firewall interface-policy": "policyid",
                          "config firewall DoS-policy": "policyid",
                          "config user group": "name",
                          "config user device": "alias",
                          "config user fortitoken": "serial-number",
                          "config ips custom": "tag",
                          "config system wccp": "service-id",
                          "config vpn ssl web realm": "url-path",
                          "config dlp filepattern entries": "pattern",
                          "config system virtual-wan-link members": "seq-num",
                          "config system replacemsg-group mail": "msg-type",
                          "config system replacemsg-group http": "msg-type",
                          "config system replacemsg-group webproxy": "msg-type",
                          "config system replacemsg-group ftp": "msg-type",
                          "config system replacemsg-group fortiguard-wf": "msg-type",
                          "config system replacemsg-group spam": "msg-type",
                          "config system replacemsg-group alertmail": "msg-type",
                          "config system replacemsg-group admin": "msg-type",
                          "config system replacemsg-group auth": "msg-type",
                          "config system replacemsg-group sslvpn": "msg-type",
                          "config system replacemsg-group ec": "msg-type",
                          "config system replacemsg-group device-detection-portal": "msg-type",
                          "config system replacemsg-group nac-quar": "msg-type",
                          "config system replacemsg-group traffic-quota": "msg-type",
                          "config system replacemsg-group utm": "msg-type",
                          "config system replacemsg-group custom-message": "msg-type",
                          "config system replacemsg-group icap": "msg-type",
                          "config endpoint-control profile": "profile-name",
                          "config endpoint-control profile forticlient-vpn-settings": "profile-name",
                          "config router ospf area": "id",
                          "config router bgp neighbor": "ip",
                          "config system admin login-time": "usr-name",
                          "config switch-controller qos ip-dscp-map map": "name"}

OBJECT_KEY_MAPPING = {"config system interface": {"member": "interface-name"},
                      "config system admin": {"vdom": "name"},
                      "config system zone": {"interface": "interface-name"},
                      "config system ntp": {"interface": "interface-name"},
                      "config system link-monitor": {"server": "address"},
                      "config system switch-interface": {"member": "interface-name"},
                      "config system object-tagging": {"tags": "name"},
                      "config system ddns": {"monitor-interface": "interface-name"},
                      "config firewall address tagging": {"tags": "name"},
                      "config firewall addrgrp": {"member": "name"},
                      "config firewall addrgrp6": {"member": "name"},
                      "config firewall service group": {"member": "name"},
                      "config firewall schedule group": {"member": "name"},
                      "config firewall vip": {"mappedip": "range",
                                              "src-filter": "range"},
                      "config firewall vipgrp": {"member": "name"},
                      "config firewall policy": {"srcintf": "name", "dstintf": "name",
                                                 "srcaddr": "name", "dstaddr": "name",
                                                 "service": "name", "poolname": "name"},
                      "config firewall local-in-policy": {"srcaddr": "name", "dstaddr": "name",
                                                          "service": "name"},
                      "config firewall DoS-policy": {"srcaddr": "name", "dstaddr": "name",
                                                     "service": "name"},
                      "config firewall interface-policy": {"srcaddr": "name", "dstaddr": "name",
                                                           "service": "name"},
                      "config user group": {"member": "name"},
                      "config user device-group": {"member": "name"},
                      "config vpn ssl settings": {"tunnel-ip-pools": "name",
                                                  "source-interface": "name",
                                                  "source-address": "name",
                                                  "source-address6": "name",
                                                  "groups": "name", "users": "name"},
                      "config vpn ssl web portal": {"split-tunneling-routing-address": "name",
                                                    "ip-pools": "name",
                                                    "ipv6-pools": "name"},
                      "config user security-exempt-list rule": {"srcaddr": "name", "devices:": "name",
                                                                "dstaddr": "name", "service": "name"},
                      "config endpoint-control profile": {"src-addr": "name", "device-groups": "name",
                                                          "users": "name", "user-groups": "name",
                                                          "on-net-addr": "name"},
                      "config firewall shaping-policy": {"srcintf": "name", "dstintf": "name",
                                                         "srcaddr": "name", "dstaddr": "name",
                                                         "service": "name"},
                      "config wireless-controller vap": {"selected-usergroups": "name"}}

VALUE_STAY_STRING = {"config wireless-controller vap": ["passphrase"],
                     "config vpn ipsec phase1": ["dhgrp", "dpd-retryinterval", "psksecret"],
                     "config vpn ipsec phase2": ["dhgrp"],
                     "config user group guest": ["expiration"],
                     "config firewall profile-protocol-options": ["ports"]}

VALUE_STAY_LIST = {"config application list entries": ["category"]}


class FGTPayloadHelper:
    def __init__(self):
        self.profile_payload_mapping = {
            "config waf profile": self.get_waf_profile_restapi_payload,
            "config firewall ssl-ssh-profile": self.get_ssl_ssh_profile_restapi_payload,
            "config webfilter profile": self.get_webfilter_or_endpoint_control_profile,
            "config endpoint-control profile": self.get_webfilter_or_endpoint_control_profile,
            "config antivirus profile": self.get_others_profile_restapi_payload,
            "config firewall profile-protocol-options": self.get_others_profile_restapi_payload,
            "config wireless-controller wtp-profile": self.get_ssl_ssh_profile_restapi_payload,
            "config voip profile": self.get_others_profile_restapi_payload,
        }

    def get(self, node, cmdb):
        return self.profile_payload_mapping.get(cmdb, self.get_restapi_payload)(node, cmdb)

    @staticmethod
    def handle_quotes(s):
        # return s.replace('"', '').replace("'", "") if isinstance(s, str) else s
        if isinstance(s, str):

            stripped = s
            while len(stripped) >= 2 and (
                    (stripped[0] == '"' and stripped[-1] == '"') or (stripped[0] == "'" and stripped[-1] == "'")):
                stripped = stripped[1:-1]

            if '\\"' in stripped:
                return stripped.replace('\\"', '"')
            else:
                return stripped
        else:
            return s

    @staticmethod
    def try_represents_Int(s, cmd, field):
        try:
            if cmd in VALUE_STAY_STRING:
                if field in VALUE_STAY_STRING[cmd]:
                    return s
            return int(s)
        except ValueError:
            return s

    def get_restapi_payload(self, node, cmd_node):

        payload = {}

        if node.key == "edit":
            edit_title = self.handle_quotes(node.list_value[1])
            try:
                id = int(edit_title)
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "id"
                payload[key] = id

            except ValueError:
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "name"
                payload[key] = edit_title

            except Exception as ex:
                raise ex

        for node_leaf in node.child_branch.list_child:
            if node_leaf.key in ("unset", "end") or len(node_leaf.list_value) < 2:
                continue

            field = node_leaf.list_value[1]
            if node_leaf.key == "set":
                item_list = node_leaf.list_value[2:]
                if cmd_node in OBJECT_KEY_MAPPING and field in OBJECT_KEY_MAPPING[cmd_node]:
                    api_field_name = OBJECT_KEY_MAPPING[cmd_node][field]
                    payload[field] = [
                        {api_field_name: self.try_represents_Int(
                            self.handle_quotes(item), cmd_node, field)}
                        for item in item_list]
                else:
                    if cmd_node in VALUE_STAY_LIST and field in VALUE_STAY_LIST[cmd_node]:
                        try:
                            payload[field] = [
                                {'id': int(item)} for item in item_list]
                        except ValueError:
                            payload[field] = [item for item in item_list]
                    else:
                        payload[field] = " ".join(
                            [self.handle_quotes(item) for item in item_list])
                        payload[field] = self.try_represents_Int(
                            payload[field], cmd_node, field)

            elif node_leaf.key == "config":
                if node_leaf.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                if len(node_leaf.child_branch.list_child) <= 1:
                    continue

                for node_grad_leaf in node_leaf.child_branch.list_child:
                    if node_grad_leaf.key in ("unset", "end") or len(node_grad_leaf.list_value) < 2:
                        continue

                    if node_grad_leaf.key == "edit":
                        if field not in payload:
                            payload[field] = []
                        payload[field].append(self.get_restapi_payload(
                            node_grad_leaf, cmd_node + " " + field))

                    elif node_grad_leaf.key == "config":
                        sub_field = node_grad_leaf.list_value[1]
                        if field not in payload:
                            payload[field] = {}

                        if node_grad_leaf.key == "config":
                            if node_grad_leaf.child_branch.list_child[0].key == "edit":
                                payload[field][sub_field] = [self.get_restapi_payload(node, cmd_node)
                                                             for node in node_grad_leaf.child_branch.list_child[:-1] if
                                                             len(node.list_value) > 0]
                        elif node_grad_leaf.key in ("set", "unset"):
                            payload[field][sub_field] = " ".join(
                                node_grad_leaf.list_value[2:])
                            payload[field][sub_field] = self.try_represents_Int(payload[field][sub_field], cmd_node,
                                                                                sub_field)

        return payload

    def get_waf_profile_restapi_payload(self, node, cmd_node):
        payload = {}

        if node.key == "edit":
            edit_title = self.handle_quotes(node.list_value[1])
            try:
                id = int(edit_title)
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "id"
                payload[key] = id

            except ValueError:
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "name"
                payload[key] = edit_title

            except Exception as ex:
                raise ex

        for node_leaf in node.child_branch.list_child:
            if node_leaf.key in ("unset", "end") or len(node_leaf.list_value) < 2:
                continue

            field = node_leaf.list_value[1]
            if node_leaf.key == "set":
                item_list = node_leaf.list_value[2:]
                if cmd_node in OBJECT_KEY_MAPPING and field in OBJECT_KEY_MAPPING[cmd_node]:
                    api_field_name = OBJECT_KEY_MAPPING[cmd_node][field]
                    payload[field] = [
                        {api_field_name: self.try_represents_Int(
                            self.handle_quotes(item), cmd_node, field)}
                        for item in item_list]
                else:
                    payload[field] = " ".join(
                        [self.handle_quotes(item) for item in item_list])
                    payload[field] = self.try_represents_Int(
                        payload[field], cmd_node, field)

            elif node_leaf.key == "config":
                if node_leaf.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                if len(node_leaf.child_branch.list_child) <= 1:
                    continue

                for node_grad_leaf in node_leaf.child_branch.list_child:
                    if node_grad_leaf.key in ("unset", "end") or len(node_grad_leaf.list_value) < 2:
                        continue

                    sub_field = node_grad_leaf.list_value[1]
                    if field not in payload:
                        payload[field] = {}

                    if node_grad_leaf.key == "config":
                        if len(node_grad_leaf.list_value) == 3:
                            # config signature
                            if node_grad_leaf.child_branch.list_child[0].key == "set":
                                if sub_field not in payload[field]:
                                    payload[field][sub_field] = []
                                payload[field][sub_field].append(
                                    self.get_restapi_payload(node_grad_leaf, cmd_node))
                                try:
                                    id = int(node_grad_leaf.list_value[2])
                                    payload[field][sub_field][-1]["id"] = id
                                except ValueError:
                                    name = node_grad_leaf.list_value[1]
                                    payload[field][sub_field][-1]["name"] = name
                                except Exception as ex:
                                    raise ex

                        elif len(node_grad_leaf.list_value) == 2:
                            # config constraint
                            if node_grad_leaf.child_branch.list_child[0].key == "set":
                                payload[field][sub_field] = self.get_restapi_payload(
                                    node_grad_leaf, cmd_node)

                    elif node_grad_leaf.key == "set":
                        # set disabled-signature
                        if len(node_grad_leaf.list_value) > 3:
                            for id in node_grad_leaf.list_value[2:]:
                                if sub_field not in payload[field]:
                                    payload[field][sub_field] = []
                                payload[field][sub_field].append(
                                    {"id": self.try_represents_Int(id, cmd_node, sub_field)})

        return payload

    def get_ssl_ssh_profile_restapi_payload(self, node, cmd_node):
        '''
        Support following items
        - config firewall ssl-ssh-profile
        - config wireless-controller wtp-profile
        '''
        payload = {}

        if node.key == "edit":
            edit_title = self.handle_quotes(node.list_value[1])
            try:
                id = int(edit_title)
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "id"
                payload[key] = id

            except ValueError:
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "name"
                payload[key] = edit_title

            except Exception as ex:
                raise ex

        for node_leaf in node.child_branch.list_child:
            if node_leaf.key in ("unset", "end") or len(node_leaf.list_value) < 2:
                continue

            field = node_leaf.list_value[1]
            if node_leaf.key == "set":
                item_list = node_leaf.list_value[2:]
                if cmd_node in OBJECT_KEY_MAPPING and field in OBJECT_KEY_MAPPING[cmd_node]:
                    api_field_name = OBJECT_KEY_MAPPING[cmd_node][field]
                    payload[field] = [
                        {api_field_name: self.try_represents_Int(
                            self.handle_quotes(item), cmd_node, field)}
                        for item in item_list]
                else:
                    payload[field] = " ".join(
                        [self.handle_quotes(item) for item in item_list])
                    payload[field] = self.try_represents_Int(
                        payload[field], cmd_node, field)

            elif node_leaf.key == "config":
                if node_leaf.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                if len(node_leaf.child_branch.list_child) <= 1:
                    continue

                for node_grad_leaf in node_leaf.child_branch.list_child:
                    if node_grad_leaf.key in ("unset", "end") or len(node_grad_leaf.list_value) < 2:
                        continue

                    sub_field = node_grad_leaf.list_value[1]
                    if field not in payload:
                        payload[field] = {}

                    if node_grad_leaf.key == "config":
                        if node_grad_leaf.child_branch.list_child[0].key == "set":
                            if sub_field not in payload[field]:
                                payload[field][sub_field] = []
                            payload[field][sub_field].append(
                                self.get_restapi_payload(node_grad_leaf, cmd_node))
                            try:
                                id = int(node_grad_leaf.list_value[2])
                                payload[field][sub_field][-1]["id"] = id
                            except ValueError:
                                name = node_grad_leaf.list_value[2]
                                payload[field][sub_field][-1]["name"] = name
                            except Exception as ex:
                                raise ex

                        elif node_grad_leaf.child_branch.list_child[0].key == "edit":
                            payload[field][sub_field] = [self.get_restapi_payload(node, cmd_node)
                                                         for node in node_grad_leaf.child_branch.list_child[:-1]]
                    elif node_grad_leaf.key in ("set", "unset"):
                        payload[field][sub_field] = " ".join(
                            node_grad_leaf.list_value[2:])
                        payload[field][sub_field] = self.try_represents_Int(payload[field][sub_field], cmd_node,
                                                                            sub_field)

        return payload

    def get_webfilter_or_endpoint_control_profile(self, node, cmd_node):
        '''
        Support following items
        - config webfilter profile
        - config endpoint-control profile
        '''
        payload = {}

        if node.key == "edit":
            edit_title = self.handle_quotes(node.list_value[1])
            try:
                id = int(edit_title)
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "id"
                payload[key] = id

            except ValueError:
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "name"
                payload[key] = edit_title

            except Exception as ex:
                raise ex

        for node_leaf in node.child_branch.list_child:
            if node_leaf.key in ("unset", "end") or len(node_leaf.list_value) < 2:
                continue

            field = node_leaf.list_value[1]
            if node_leaf.key == "set":
                item_list = node_leaf.list_value[2:]
                if cmd_node in OBJECT_KEY_MAPPING and field in OBJECT_KEY_MAPPING[cmd_node]:
                    api_field_name = OBJECT_KEY_MAPPING[cmd_node][field]
                    payload[field] = [
                        {api_field_name: self.try_represents_Int(
                            self.handle_quotes(item), cmd_node, field)}
                        for item in item_list]
                else:
                    payload[field] = " ".join(
                        [self.handle_quotes(item) for item in item_list])
                    payload[field] = self.try_represents_Int(
                        payload[field], cmd_node, field)

            elif node_leaf.key == "config":
                if node_leaf.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                if len(node_leaf.child_branch.list_child) <= 1:
                    continue

                if field not in payload:
                    payload[field] = {}

                subpayload = {}
                for node_grad_node in node_leaf.child_branch.list_child:
                    if node_grad_node.key in ("unset", "end") or len(node_grad_node.list_value) < 2:
                        continue
                    subfield = node_grad_node.list_value[1]
                    if node_grad_node.key == "set" and len(node_grad_node.list_value) == 3:
                        subpayload[subfield] = self.try_represents_Int(
                            node_grad_node.list_value[2], cmd_node, subfield)
                    elif node_grad_node.key == "config":
                        subpayload[subfield] = []
                        for node_grad_deep_node in node_grad_node.child_branch.list_child:
                            if node_grad_deep_node.key in ("unset", "end") or len(node_grad_deep_node.list_value) < 2:
                                continue
                            subpayload[subfield].append(
                                self.get_restapi_payload(node_grad_deep_node, cmd_node + " " + subfield))

                payload[field] = subpayload

        return payload

    def get_others_profile_restapi_payload(self, node, cmd_node):
        '''
        Support following items
        - config antivirus profile
        - config firewall profile-protocol-options
        - config voip profile
        '''
        payload = {}

        if node.key == "edit":
            edit_title = self.handle_quotes(node.list_value[1])
            try:
                id = int(edit_title)
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "id"
                payload[key] = id

            except ValueError:
                key = OBJECT_ID_NAME_MAPPING[cmd_node] if cmd_node in OBJECT_ID_NAME_MAPPING else "name"
                payload[key] = edit_title

            except Exception as ex:
                raise ex

        for node_leaf in node.child_branch.list_child:
            if node_leaf.key in ("unset", "end") or len(node_leaf.list_value) < 2:
                continue

            field = node_leaf.list_value[1]
            if node_leaf.key == "set":
                item_list = node_leaf.list_value[2:]
                if cmd_node in OBJECT_KEY_MAPPING and field in OBJECT_KEY_MAPPING[cmd_node]:
                    api_field_name = OBJECT_KEY_MAPPING[cmd_node][field]
                    payload[field] = [
                        {api_field_name: self.try_represents_Int(
                            self.handle_quotes(item), cmd_node, field)}
                        for item in item_list]
                else:
                    payload[field] = " ".join(
                        [self.handle_quotes(item) for item in item_list])
                    payload[field] = self.try_represents_Int(
                        payload[field], cmd_node, field)

            elif node_leaf.key == "config":
                if node_leaf.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                if len(node_leaf.child_branch.list_child) <= 1:
                    continue

                payload[field] = {}
                if len(node_leaf.list_value) == 2:
                    payload[field]["name"] = self.handle_quotes(
                        node_leaf.list_value[1])

                for node_grad_leaf in node_leaf.child_branch.list_child:
                    if node_grad_leaf.key in ("unset", "end") or len(node_grad_leaf.list_value) < 2:
                        continue

                    if node_grad_leaf.key == "set" and len(node_grad_leaf.list_value) == 3:
                        subfield = node_grad_leaf.list_value[1]
                        payload[field][subfield] = self.try_represents_Int(" ".join(node_grad_leaf.list_value[2:]),
                                                                           cmd_node,
                                                                           subfield)

        return payload
