from celery_app.fortinet.model import utils
from celery_app.fortinet.model.config_tree import FGTNodeType


class Convert52_54:

    def __init__(self, fgt):

        self.config_root = fgt.config_root
        self.output_fgt = fgt
        self.curr_vdom = ""
        self.curr_vdom_root = None

    def convert_config_antivirus_profile(self):

        # config antivirus profile
        config = "config"
        key = "set"
        list_value = ["config", "antivirus", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set scan-botnet-connections <xxx>"
        list_value = ["set", "scan-botnet-connections"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_dlp_sensor(self):

        # config system storage
        config = "config"
        key = "set"
        list_value = ["config", "dlp", "sensor"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["set", "extended-utm-log"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_endpoint_control_profile(self):

        # config endpoint-control profile
        config = "config"
        key = "set"
        list_value = ["config", "endpoint-control", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_provisioning = ["set", "forticlient-vpn-provisioning"]
        list_autovpn_offnet = ["set", "auto-vpn-when-off-net"]
        list_autovpn_name = ["set", "auto-vpn-name"]
        list_forticlient_ad = ["set", "forticlient-ad"]
        list_winmac_setting = ["config", "forticlient-winmac-settings"]
        list_vpn_setting = ["config", "forticlient-vpn-settings"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_winmac = node_edit.child_branch.find_tree_node(
                config, list_winmac_setting)
            if node_winmac.node_type.value > 0:
                node_winmac.child_branch.find_and_remove_node(
                    config, list_vpn_setting)
                node_winmac.child_branch.loose_find_and_remove_node(
                    key, list_provisioning)
                node_winmac.child_branch.loose_find_and_remove_node(
                    key, list_autovpn_offnet)
                node_winmac.child_branch.loose_find_and_remove_node(
                    key, list_autovpn_name)
                node_winmac.child_branch.loose_find_and_remove_node(
                    key, list_forticlient_ad)

    def convert_config_firewall_address(self):

        # config firewall address
        config = "config"
        list_value = ["config", "firewall", "address"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)

        if node_config.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
            return
        '''
        Remove these nodes.
        edit "live.com"
          set uuid e7b170b2-a039-51e5-9e31-fb1aefc7a82f
          set type wildcard-fqdn  ------- In 5.2, set type fqdn
          set wildcard-fqdn "*.live.com"  ----- In 5.2, set fqdn
        next */
        '''
        list_value = ["edit", ""]
        list_address_to_be_removed = ["\"apple\"", "\"applestore.com\"", "\"dropbox.com\"", "\"Gotomeeting\"",
                                      "\"icloud\"", "\"itunes\"", "\"android\"", "\"skype\"", "\"appstore\"",
                                      "\"eease\"", "\"google-drive\"", "\"google-play2\"", "\"google-play3\"",
                                      "\"microsoft\"", "\"adobe\"", "\"Adobe Login\"", "\"fortinet\"",
                                      "\"googleapis.com\"", "\"citrix\"", "\"verisign\"", "\"Windows update 2\"",
                                      "\"citrixonline\"", "\"firefox update server\"", "\"*.live.com\""]

        for address in list_address_to_be_removed:
            list_value[1] = address
            node_config.child_branch.find_and_remove_node("edit", list_value)

        set = "set"
        list_type = ["set", "type"]
        list_url = ["set", "url"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_type = node_edit.child_branch.loose_find_tree_node(
                set, list_type)
            if node_type.node_type.value > 0 and node_type.list_value[2] == "url":
                node_type.rename_option("wildcard-fqdn")
                node_url = node_edit.child_branch.loose_find_tree_node(
                    set, list_url)
                if node_url.node_type.value > 0:
                    node_url.rename_field("wildcard-fqdn")

    def convert_config_firewall_service_group(self):

        config = "config"
        list_value = ["config", "firewall", "service", "group"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_member = ["set", "member"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_member = node_edit.child_branch.loose_find_tree_node(
                set, list_member)
            if node_member.node_type.value > 0 and node_member.list_value[2] == '""':
                node_member.remove_tree_node()

    def convert_config_firewall_central_nat(self):

        config = "config"
        list_value = ["config", "firewall", "central-nat"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["config", "firewall", "central-snat-map"]
        node_config.rename_command(list_value)

    def convert_config_firewall_policy(self):

        config = "config"
        key = "set"
        list_value = ["config", "firewall", "policy"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_centralnat = ["set", "central-nat"]
        list_endpoint = ["set", "endpoint-compliance"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(
                key, list_centralnat)
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_endpoint)

    def convert_config_firewall_localinpolicy(self):

        config = "config"
        set = "set"
        list_value = ["config", "firewall", "local-in-policy"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_auto_asic_offload = ["set", "auto-asic-offload"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_auto_asic_offload)

    def convert_config_firewall_ssl_ssh_profile(self):

        # config firewall ssl-ssh-profile
        config = "config"
        list_value = ["config", "firewall", "ssl-ssh-profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            # edit "deep-inspection"
            edit = "edit"
            list_value = ["edit", "\"deep-inspection\""]
            node_deep_inspection = self.curr_vdom_root.find_tree_node(
                edit, list_value)
            if node_deep_inspection.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                # config ssl-exempt
                list_value = ["config", "ssl-exempt"]
                node_config_ssl_exempt = self.curr_vdom_root.find_tree_node(
                    config, list_value)
                if node_config_ssl_exempt.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                    # For each edit
                    for edit_node in node_config_ssl_exempt.child_branch.list_child:
                        if edit_node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                            # Replace the field set address "*.live.com" to "live.com"".
                            key = "set"
                            list_value = ["set", "address", "\"*.live.com\""]
                            live_fqdn = edit_node.child_branch.find_tree_node(
                                key, list_value)
                            if live_fqdn.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                                live_fqdn.rename_option("\"live.com\"")

    def convert_config_application_list(self):

        config = "config"
        list_value = ["config", "application", "list"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_entries = ["config", "entries"]
        list_inspectanyport = ["set", "inspect-anyport"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_entries = node_edit.child_branch.loose_find_tree_node(
                config, list_entries)
            if node_entries.node_type.value == 0:
                continue

            for node_entry_edit in node_entries.child_branch.list_child:
                if node_entry_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_entry_edit.child_branch.loose_find_tree_node(
                    set, list_inspectanyport)

    def convert_config_log_setting(self):

        config = "config"
        key = "set"
        list_value = ["config", "log", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "gui-location"
        list_value = ["set", "gui-location"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_log_fortianalyzer_setting(self):

        list_postfix = ["", "2", "3"]

        config = "config"
        set = "set"

        for postfix in list_postfix:
            list_value = ["config", "log",
                          "fortianalyzer" + postfix, "setting"]

            node_config = self.curr_vdom_root.find_tree_node(
                config, list_value)
            if node_config.node_type.value == 0:
                continue

            # remove field "psksecret" and "localid" and "encrypt"
            list_psksecret = ["set", "psksecret"]
            list_localid = ["set", "localid"]
            list_encrypt = ["set", "encrypt"]
            node_config.child_branch.loose_find_and_remove_node(
                set, list_psksecret)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_localid)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_encrypt)

    def convert_config_log_webtrends_filter(self):

        config = "config"
        list_value = ["config", "log", "webtrends", "filter"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_appctrl = ["set", "app-ctrl"]
        list_dlp = ["set", "dlp"]
        list_explicit = ["set", "explicit-proxy-traffic"]
        list_appctrlall = ["set", "app-ctrl-all"]
        list_dlpall = ["set", "dlp-all"]

        node_config.child_branch.loose_find_and_remove_node(set, list_appctrl)
        node_config.child_branch.loose_find_and_remove_node(set, list_dlp)
        node_config.child_branch.loose_find_and_remove_node(set, list_explicit)
        node_config.child_branch.loose_find_and_remove_node(
            set, list_appctrlall)
        node_config.child_branch.loose_find_and_remove_node(set, list_dlpall)

    def convert_config_system_accprofile(self):

        key = "config"
        list_value = ["config", "system", "accprofile"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field wanoptgrp
        list_set_wan_opt_grp = ["set", "wanoptgrp"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_set_wan_opt_grp)

    def convert_config_system_admin(self):

        # "config system admin"
        config = "config"
        list_value = ["config", "system", "admin"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_dash_board_tabs = ["config", "dashboard-tabs"]
        list_dash_board = ["config", "dashboard"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove subview "config dashboard-tabs"
            node_edit.child_branch.find_and_remove_node(
                config, list_dash_board_tabs)

            # remove subview "config dashboard"
            node_edit.child_branch.find_and_remove_node(
                config, list_dash_board)

    def convert_config_system_fortiguard(self):

        # config system fortiguard
        config = "config"
        list_value = ["config", "system", "fortiguard"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # Replace keyword "set webfilter-sdns-server-ip" to "set sdns-server-ip"
        key = "set"
        list_value = ["set", "webfilter-sdns-server-ip"]
        node_config.child_branch.find_and_rename_field(
            key, list_value, "sdns-server-ip")

    def convert_config_system_global(self):

        def insert_system_settings(node):

            list_value = ["config", "vdom"]
            list_vdom_node = self.config_root.strict_match_tree_node(
                "config", list_value)
            if len(list_vdom_node) > 0:
                # Enable VDOM mode
                list_value = ["config", "system", "settings"]
                for node_vdom in list_vdom_node:
                    for node_edit in node_vdom.child_branch.list_child:
                        if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and \
                                node_edit.get_last_leaf_index() > 0:
                            vdom_root = node_edit.child_branch
                            node_config_setting = vdom_root.find_tree_node(
                                "config", list_value)
                            if node_config_setting.node_type.value == 0:
                                node_config_setting = vdom_root.create_blank_config_node(
                                    list_value, 0)

                            node_copy = node.clone(
                                node_config_setting.child_branch)
                            node_config_setting.insert_tree_node(
                                node_copy, node_config_setting.get_last_leaf_index())

            else:
                # Disable VDOM mode
                list_value = ["config", "system", "settings"]
                node_config_setting = self.config_root.find_tree_node(
                    "config", list_value)
                # It's impossible to create this node for disable vdom case.
                if node_config_setting.node_type.value == 0:
                    node_config_setting = self.config_root.create_blank_config_node(
                        list_value, 0)

                node_config_setting.insert_tree_node(
                    node, node_config_setting.get_last_leaf_index())

        config = "config"
        key = "set"
        list_value = ["config", "system", "global"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_remove_node = []

        # Get all the child nodes from global context.

        # move field "set gui-antivirus" into "config system settings" context
        list_value = ["set", "gui-antivirus"]
        gui_antivirus = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_antivirus.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_antivirus)

        # move field "set gui-application-control" into "config system settings" context
        list_value = ["set", "gui-application-control"]
        gui_app_control = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_app_control.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_app_control)

        # move field "set gui-ap-profile" into "config system settings" context
        list_value = ["set", "gui-ap-profile"]
        gui_ap_profile = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_ap_profile.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_ap_profile)

        # move field "set gui-central-nat-table" into "config system settings" context
        list_value = ["set", "gui-central-nat-table"]
        gui_centralnat_table = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_centralnat_table.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_centralnat_table)

        # move field "set gui-traffic-shaping" into "config system settings" context
        list_value = ["set", "gui-traffic-shaping"]
        gui_traffic_shaping = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_traffic_shaping.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_traffic_shaping)

        # move field "set gui-dlp" into "config system settings" context
        list_value = ["set", "gui-dlp"]
        gui_dlp = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_dlp.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_dlp)

        # move field "set gui-dns-database" into "config system settings" context
        list_value = ["set", "gui-dns-database"]
        gui_dns_database = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_dns_database.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_dns_database)

        # move field "set gui-dynamic-profile-display" into "config system settings" context
        list_value = ["set", "gui-dynamic-profile-display"]
        gui_dynamic_profile_display = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_dynamic_profile_display.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_dynamic_profile_display)

        # move field "set gui-dynamic-routing" into "config system settings" context
        list_value = ["set", "gui-dynamic-routing"]
        gui_dynamic_routing = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_dynamic_routing.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_dynamic_routing)

        # move field "set gui-endpoint-control" into "config system settings" context
        list_value = ["set", "gui-endpoint-control"]
        gui_endpoint_control = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_endpoint_control.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_endpoint_control)

        # move field "set gui-explicit-proxy" into "config system settings" context
        list_value = ["set", "gui-explicit-proxy"]
        gui_explicit_proxy = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_explicit_proxy.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_explicit_proxy)

        # move field "set gui-icap" into "config system settings" context
        list_value = ["set", "gui-icap"]
        gui_icap = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_icap.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_icap)

        # move field "set gui-implicit-policy" into "config system settings" context
        list_value = ["set", "gui-implicit-policy"]
        gui_implicit_policy = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_implicit_policy.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_implicit_policy)

        # move field "set gui-ips" into "config system settings" context
        list_value = ["set", "gui-ips"]
        gui_ips = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_ips.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_ips)

        # move field "set gui-ipsec-manual-key" into "config system settings" context
        list_value = ["set", "gui-ipsec-manual-key"]
        gui_ipsec_manual_key = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_ipsec_manual_key.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_ipsec_manual_key)

        # move field "set gui-load-balance" into "config system settings" context
        list_value = ["set", "gui-load-balance"]
        gui_load_balance = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_load_balance.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_load_balance)

        # move field "set gui-multicast-policy" into "config system settings" context
        list_value = ["set", "gui-multicast-policy"]
        gui_multicast_policy = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_multicast_policy.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_multicast_policy)

        # move field "set gui-multiple-utm-profiles" into "config system settings" context
        list_value = ["set", "gui-multiple-utm-profiles"]
        gui_multiple_utm_profiles = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_multiple_utm_profiles.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_multiple_utm_profiles)

        # move field "set gui-nat46-64" into "config system settings" context
        list_value = ["set", "gui-nat46-64"]
        gui_nat4664 = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_nat4664.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_nat4664)

        # move field "set gui-object-tags" into "config system settings" context and rename field to "set gui-object-colors"
        list_value = ["set", "gui-object-tags"]
        gui_object_tags = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_object_tags.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_object_tags)

        # move field "set gui-policy-based-ipsec" into "config system settings" context
        list_value = ["set", "gui-policy-based-ipsec"]
        gui_policy_based_ipsec = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_policy_based_ipsec.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_policy_based_ipsec)

        # move field "set gui-replacement-message-groups" into "config system settings" context
        list_value = ["set", "gui-replacement-message-groups"]
        gui_replacement_msg_groups = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_replacement_msg_groups.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_replacement_msg_groups)

        # move field "set gui-spamfilter" into "config system settings" context
        list_value = ["set", "gui-spamfilter"]
        gui_spam_filter = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_spam_filter.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_spam_filter)

        # move field "set gui-sslvpn-personal-bookmarks" into "config system settings" context
        list_value = ["set", "gui-sslvpn-personal-bookmarks"]
        gui_sslvpn_personal = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_sslvpn_personal.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_sslvpn_personal)

        # move field "set gui-sslvpn-realms" into "config system settings" context
        list_value = ["set", "gui-sslvpn-realms"]
        gui_sslvpn_realms = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_sslvpn_realms.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_sslvpn_realms)

        # move field "set gui-threat-weight" into "config system settings" context
        list_value = ["set", "gui-threat-weight"]
        gui_threat_weight = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_threat_weight.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_threat_weight)

        # move field "set gui-voip-profile" into "config system settings" context
        list_value = ["set", "gui-voip-profile"]
        gui_voip_profile = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_voip_profile.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_voip_profile)

        # move field "set gui-vpn" into "config system settings" context
        list_value = ["set", "gui-vpn"]
        gui_vpn = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_vpn.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_vpn)

        # move field "set gui-vulnerability-scan" into "config system settings" context
        list_value = ["set", "gui-vulnerability-scan"]
        gui_vulnerability_scan = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_vulnerability_scan.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_vulnerability_scan)

        # move field "set gui-wanopt-cache" into "config system settings" context
        list_value = ["set", "gui-wanopt-cache"]
        gui_wanopt_cache = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_wanopt_cache.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_wanopt_cache)

        # move field "set gui-webfilter" into "config system settings" context
        list_value = ["set", "gui-webfilter"]
        gui_webfilter = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if gui_webfilter.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            list_remove_node.append(gui_webfilter)

        # remove field "set gui-gui-utm-monitors"
        list_value = ["set", "gui-utm-monitors"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set gui-wireless-controller"
        list_value = ["set", "gui-wireless-controller"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set internal-switch-mode interface/hub/switch"
        list_value = ["set", "internal-switch-mode"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set http-obfuscate"
        list_value = ["set", "http-obfuscate"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "access-banner"
        list_value = ["set", "access-banner"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "lcdpin"
        list_value = ["set", "lcdpin"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "lcdprotection"
        list_value = ["set", "lcdprotection"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        if len(list_remove_node) > 0:
            for remove_node in list_remove_node:
                # remove nodes from global context
                remove_node.remove_tree_node()

                if len(remove_node.list_value) > 1 and remove_node.list_value[1] in (
                        "gui-vulnerability-scan", "gui-central-nat-table"):
                    continue

                # Insert node into settings context.
                if len(remove_node.list_value) > 1 and remove_node.list_value[1] == "gui-object-tags":
                    # Replace with "gui-object-colors"
                    remove_node.list_value[1] = "gui-object-colors"

                insert_system_settings(remove_node)

    def convert_config_system_replacemsg(self):

        # "config system replacemsg im <xxx>"
        key = "config"
        list_value = ["config", "system", "replacemsg", "im"]
        list_node = self.curr_vdom_root.loose_match_tree_node(key, list_value)
        if len(list_node) == 0:
            return

        for node_config in list_node:
            if node_config.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                node_config.remove_tree_node()

    def convert_config_system_sessionSync(self):

        config = "config"
        list_value = ["config", "system", "session-sync"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            node_config.remove_tree_node()

    def convert_config_system_storage(self):

        # config system storage
        config = "config"
        list_value = ["config", "system", "storage"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # Right now, we only simple remove this settings.
        node_config.remove_tree_node()

    def convert_config_system_ha(self):

        # config system ha
        config = "config"
        list_value = ["config", "system", "ha"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ["set", "helo-holddown"]
        node_config.child_branch.find_and_rename_field(
            key, list_value, "hello-holddown")

    def convert_config_system_interface(self):

        # config system interface
        config = "config"
        list_value = ["config", "system", "interface"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_listent_forticlient_connection = [
            "set", "listen-forticlient-connection"]
        list_physical = ["set", "type", "physical"]
        list_snmp_index = ["set", "snmp", "index"]
        list_vdom = ["set", "vdom"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # For some lower-end model, they do not support VDOMs.
            node_vdom = node_edit.child_branch.loose_find_tree_node(
                key, list_vdom)
            if node_vdom.node_type.value == 0:
                node_edit.create_leaf_node(
                    key, ["set", "vdom", self.curr_vdom], 0)

            # rename set listen forticlient connection into "fortiheartbeat"
            node_edit.child_branch.find_and_rename_field(
                key, list_listent_forticlient_connection, "fortiheartbeat")

            # remove set type physical
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_physical)

            # remove set snmp index
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_snmp_index)

    def convert_config_system_dhcp_server(self):

        # config system dhcp server
        config = "config"
        list_value = ["config", "system", "dhcp", "server"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_option = ["set", ""]
        list_code = ["set", "code", ""]
        list_value = ["set", "value", ""]
        list_config_option = ["config", "options"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            for i in range(1, 7):
                list_option[1] = "option{0}".format(i)
                node_option = node_edit.child_branch.loose_find_tree_node(
                    set, list_option)
                if node_option.node_type.value > 0:
                    code = node_option.list_value[2]
                    value = node_option.list_value[3] if len(
                        node_option.list_value) > 3 else ""
                    node_config_option = node_edit.child_branch.find_or_create_config_node(config,
                                                                                           list_config_option,
                                                                                           node_edit.get_last_leaf_index())
                    node_option_edit = node_config_option.child_branch.create_blank_edit_node(str(i),
                                                                                              node_config_option.get_last_leaf_index())
                    list_code[2] = code
                    node_option_edit.create_leaf_node(
                        set, list_code, node_option_edit.get_last_leaf_index())
                    if value:
                        list_value[2] = value
                        node_option_edit.create_leaf_node(
                            set, list_value, node_option_edit.get_last_leaf_index())
                    node_option.remove_tree_node()
                else:
                    break

    def convert_config_system_virtualwanlink(self):

        # config system virtual-wan-link
        config = "config"
        list_value = ["config", "system", "virtual-wan-link"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_quality_mode = ["set", "load-balance-quality-mode"]
        node_config.child_branch.loose_find_and_remove_node(
            set, list_quality_mode)

        list_member = ["config", "members"]
        list_detect_server = ["set", "detect-server"]
        node_member = node_config.child_branch.find_tree_node(
            config, list_member)

        if node_member.node_type.value > 0:
            for node_edit in node_member.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_edit.child_branch.loose_find_and_remove_node(
                    set, list_detect_server)

    def convert_config_system_npu(self):

        # config system storage
        config = "config"
        list_value = ["config", "system", "npu"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

    def convert_config_spamfilter_profile(self):

        # config system storage
        config = "config"
        key = "set"
        list_value = ["config", "spamfilter", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["set", "extended-utm-log"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue
            node_edit.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_vpn_ssl_web_portal(self):

        # config vpn ssl web portal
        config = "config"
        list_value = ["config", "vpn", "ssl", "web", "portal"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_auto_prompt = ["set", "auto-prompt-mobile-user-download"]
        list_page_layout = ["set", "page-layout"]
        list_display_ftc_download = ["set", "display-forticlient-download"]
        list_cache_cleaner = ["set", "cache-cleaner"]
        list_theme = ["set", "theme"]

        list_bookmark_group = ["config", "bookmark-group"]
        list_bookmarks = ["config", "bookmarks"]
        list_full_screen_mode = ["set", "full-screen-mode"]
        list_screen_width = ["set", "screen-width"]
        list_screen_height = ["set", "screen-height"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # Remove "set auto-prompt-mobile-user-download"
            node_edit.child_branch.loose_find_and_remove_node(
                set, list_auto_prompt)

            # Remove "set page-layout double-column"
            node_edit.child_branch.loose_find_and_remove_node(
                set, list_page_layout)

            # Remove "set display-forticlient-download"
            node_edit.child_branch.loose_find_and_remove_node(
                set, list_display_ftc_download)

            # Remove "set cache-cleaner"
            node_edit.child_branch.loose_find_and_remove_node(
                set, list_cache_cleaner)

            # Remove "set theme"
            node_edit.child_branch.loose_find_and_remove_node(set, list_theme)

            node_bookmark_group = node_edit.child_branch.find_tree_node(
                config, list_bookmark_group)
            if node_bookmark_group.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            for node_bookmark_group_edit in node_bookmark_group.child_branch.list_child:
                if node_bookmark_group_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_bookmarks = node_bookmark_group_edit.child_branch.find_tree_node(
                    config, list_bookmarks)
                if node_bookmarks.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                for node_bookmarks_edit in node_bookmarks.child_branch.list_child:
                    if node_bookmarks_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                        continue

                    node_bookmarks_edit.child_branch.loose_find_and_remove_node(
                        set, list_full_screen_mode)
                    node_bookmarks_edit.child_branch.loose_find_and_remove_node(
                        set, list_screen_height)
                    node_bookmarks_edit.child_branch.loose_find_and_remove_node(
                        set, list_screen_width)

    def convert_config_vpn_ssl_web_userbookmark(self):

        # config vpn ssl web portal
        config = "config"
        list_value = ["config", "vpn", "ssl", "web", "user-bookmark"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_bookmarks = ["config", "bookmarks"]
        list_full_screen_mode = ["set", "full-screen-mode"]
        list_screen_height = ["set", "screen-height"]
        list_screen_width = ["set", "screen-width"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_bookmarks = node_edit.child_branch.find_tree_node(
                config, list_bookmarks)
            if node_bookmarks.node_type.value == 0:
                continue

            for node_bookmark_edit in node_bookmarks.child_branch.list_child:
                if node_bookmark_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_bookmark_edit.child_branch.loose_find_and_remove_node(
                    set, list_full_screen_mode)
                node_bookmark_edit.child_branch.loose_find_and_remove_node(
                    set, list_screen_height)
                node_bookmark_edit.child_branch.loose_find_and_remove_node(
                    set, list_screen_width)

    def convert_config_vpn_certificate(self):
        '''
        Move "config vpn certificate ca" from global scope into each vdom. 
           * 'global'.associateNode.strKey == "config"
        '''
        if self.curr_vdom_root.associate_node:
            node = self.curr_vdom_root.associate_node
            if node.key == "config":
                list_vpn_cert_node = []
                config = "config"
                list_value = ["config", "vpn", "certificate", "ca"]
                node = self.curr_vdom_root.find_tree_node(config, list_value)
                if node.node_type.value > 0:
                    node.remove_tree_node()
                    list_vpn_cert_node.append(node)

                list_value[3] = "crl"
                node = self.curr_vdom_root.find_tree_node(config, list_value)
                if node.node_type.value > 0:
                    node.remove_tree_node()
                    list_vpn_cert_node.append(node)

                list_value[3] = "local"
                node = self.curr_vdom_root.find_tree_node(config, list_value)
                if node.node_type.value > 0:
                    node.remove_tree_node()
                    list_vpn_cert_node.append(node)

                list_value[3] = "ocsp-server"
                node = self.curr_vdom_root.find_tree_node(config, list_value)
                if node.node_type.value > 0:
                    node.remove_tree_node()
                    list_vpn_cert_node.append(node)

                list_value[3] = "remote"
                node = self.curr_vdom_root.find_tree_node(config, list_value)
                if node.node_type.value > 0:
                    node.remove_tree_node()
                    list_vpn_cert_node.append(node)

                list_value[3] = "setting"
                node = self.curr_vdom_root.find_tree_node(config, list_value)
                if node.node_type.value > 0:
                    node.remove_tree_node()
                    list_vpn_cert_node.append(node)

                if len(list_vpn_cert_node) == 0:
                    return

                list_vdom = ["config", "vdom"]
                list_node_vdom = self.config_root.strict_match_tree_node(
                    config, list_vdom)
                if len(list_node_vdom) > 0:
                    for node_vdom in list_node_vdom:
                        for node_edit in node_vdom.child_branch.list_child:
                            if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and \
                                    node_edit.get_last_leaf_index() > 0:
                                for node_vpn in list_vpn_cert_node:
                                    if node_vpn.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and \
                                            node_vpn.get_last_leaf_index() > 0:
                                        node_edit.insert_tree_node(
                                            node_vpn, node_edit.get_last_leaf_index())

                else:
                    # Disable VDOM mode
                    for node_vpn in list_vpn_cert_node:
                        if node_vpn.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node_vpn.get_last_leaf_index() > 0:
                            self.config_root.associate_node.insert_tree_node(node_vpn,
                                                                             self.config_root.associate_node.get_last_leaf_index())

    def convert_config_vpn_ipsec_phase1(self):

        config = "config"
        list_value = ["config", "vpn", "ipsec", "phase1"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_peertype = ["set", "peertype"]
        list_peertype_any = ["set", "peertype", "any"]
        list_xauthexpire = ["set", "xauthexpire"]
        list_mode = ["set", "mode"]
        list_aggressive = ["set", "mode", "aggressive"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_peertype = node_edit.child_branch.loose_find_tree_node(
                set, list_peertype)
            if node_peertype.node_type.value == 0:
                node_edit.create_leaf_node(
                    set, list_peertype_any, node_edit.get_last_leaf_index())

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_xauthexpire)

            node_peertype = node_edit.child_branch.loose_find_tree_node(
                set, list_peertype)
            if node_peertype.node_type.value > 0 and node_peertype.list_value[2] == "dialup":
                node_mode = node_edit.child_branch.loose_find_tree_node(
                    set, list_mode)
                if node_mode.node_type.value == 0:
                    node_edit.create_leaf_node(set, list_aggressive, 0)

    def convert_config_vpn_ipsec_phase1_interface(self):

        config = "config"
        list_value = ["config", "vpn", "ipsec", "phase1-interface"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_peertype = ["set", "peertype"]
        list_peertype_any = ["set", "peertype", "any"]
        list_xauthexpire = ["set", "xauthexpire"]
        list_mode = ["set", "mode"]
        list_aggressive = ["set", "mode", "aggressive"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_peertype = node_edit.child_branch.loose_find_tree_node(
                set, list_peertype)
            if node_peertype.node_type.value == 0:
                node_edit.create_leaf_node(
                    set, list_peertype_any, node_edit.get_last_leaf_index())

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_xauthexpire)

            node_peertype = node_edit.child_branch.loose_find_tree_node(
                set, list_peertype)
            if node_peertype.node_type.value > 0 and node_peertype.list_value[2] == "dialup":
                node_mode = node_edit.child_branch.loose_find_tree_node(
                    set, list_mode)
                if node_mode.node_type.value == 0:
                    node_edit.create_leaf_node(set, list_aggressive, 0)

    def convert_config_voip_profile(self):

        # config voip profile
        config = "config"
        list_value = ["config", "voip", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # Remove "set extended-utm-log"
            list_extended_utm_log = ["set", "extended-utm-log"]
            node_edit.child_branch.loose_find_and_remove_node(
                "set", list_extended_utm_log)

    def convert_config_wireless_controller_global(self):

        config = "config"
        key = "set"
        list_value = ["config", "wireless-controller", "global"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove "set local-radio-vdom"
        list_local_radio_vdom = ["set", "local-radio-vdom"]
        node_config.child_branch.loose_find_and_remove_node(
            key, list_local_radio_vdom)

    def convert_config_wireless_controller_wtp_profile(self):

        # config wireless-controller wtp-profile
        config = "config"
        key = "set"
        list_value = ["config", "wireless-controller", "wtp-profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_fapc220c = ["edit", "\"FAPC220C-default\""]
        # Find out FAPC220C node
        node_fapcc220c = node_config.child_branch.find_tree_node(
            "edit", list_fapc220c)
        if node_fapcc220c.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            node_fapcc220c.remove_tree_node()

        list_fapc225c = ["edit", "\"FAPC225C-default\""]
        # Find out FAPC225C node
        node_fapcc225c = node_config.child_branch.find_tree_node(
            "edit", list_fapc225c)
        if node_fapcc225c.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            node_fapcc225c.remove_tree_node()

        list_value_radio1 = ["config", "radio-1"]
        list_value_radio2 = ["config", "radio-2"]
        list_value_vaps = ["set", "vaps"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_radio = node_edit.child_branch.find_tree_node(
                config, list_value_radio1)
            if node_radio.node_type.value != 0:
                node_radio.child_branch.loose_find_and_remove_node(
                    key, list_value_vaps)

            node_radio = node_edit.child_branch.find_tree_node(
                config, list_value_radio2)
            if node_radio.node_type.value != 0:
                node_radio.child_branch.loose_find_and_remove_node(
                    key, list_value_vaps)

    def convert_config_wireless_controller_vap(self):

        # config wireless-controller wtp-profile
        config = "config"
        list_value = ["config", "wireless-controller", "vap"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        # list_value_pass_phrase = ["set", "passphrase", "ENC"]
        list_value_local_switching = ["set", "local-switching"]
        list_vdom = ["set", "vdom"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # node_edit.child_branch.loose_find_and_remove_node(key, list_value_pass_phrase)
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_value_local_switching)

            node_vdom = node_edit.child_branch.loose_find_tree_node(
                key, list_vdom)
            if node_vdom.node_type.value == 0:
                node_edit.create_leaf_node(
                    key, ["set", "vdom", self.curr_vdom], 0)

    def convert_config_wanopt_settings(self):

        # config wanopt setting
        config = "config"
        list_value = ["config", "wanopt", "settings"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # Right now, we only simple remove this settings.
        node_config.remove_tree_node()

    def convert_config_wanopt_profile(self):

        # config wanopt profile
        config = "config"
        list_value = ["config", "wanopt", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # Right now, we only simple remove this settings.
        node_config.remove_tree_node()

    def convert_config_wanopt_storage(self):

        # config wanopt storage
        config = "config"
        list_value = ["config", "wanopt", "storage"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # Right now, we only simple remove this settings.
        node_config.remove_tree_node()

    def convert_config_webfilter_ftgd_local_rating(self):

        config = "config"
        list_value = ["config", "webfilter", "ftgd-local-rating"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        rating_group = ["set", "rating"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            '''
             In 5.2 url rating support category group 'g21'.
             In 5.4 no category group allowed.
            '''
            node_rating = node_edit.child_branch.loose_find_tree_node(
                set, rating_group)
            if node_rating.node_type.value > 0:
                category_name = node_rating.list_value[2]
                if "g" in category_name:
                    node_rating.rename_option("0")

    def convert_config_webfilter_profile(self):

        # config webfilter profile
        config = "config"
        key = "set"
        list_value = ["config", "webfilter", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_inspection = ["set", "inspection-mode"]
        list_inspection_flow = ["set", "inspection-mode", "flow"]
        list_inspection_flowbased = ["set", "inspection-mode", "flow-based"]

        if len(node_config.child_branch.list_child) > 1:
            list_value = ["config", "system", "settings"]
            node_settings = self.curr_vdom_root.find_or_create_config_node(
                config, list_value, 1)
            node_inspection = node_settings.child_branch.loose_find_tree_node(
                key, list_inspection)
            if node_inspection.node_type.value == 0:
                node_settings.create_leaf_node(
                    key, list_inspection_flow, node_settings.get_last_leaf_index())
            else:
                node_inspection.rename_option("flow")

        list_ftgd = ["config", "ftgd-wf"]
        list_filters = ["config", "filters"]
        list_category32 = ["set", "category", "32"]
        list_category = ["set", "category"]
        list_config_override = ["config", "override"]
        list_flowbased = ["set", "flow-based"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove field "set category 32" in "config ftgd-wf"
            node_ftgd = node_edit.child_branch.find_tree_node(
                config, list_ftgd)
            if node_ftgd.node_type.value > 0:
                node_ftgd.child_branch.loose_find_and_remove_node(
                    key, list_category32)
                node_filters = node_ftgd.child_branch.find_tree_node(
                    config, list_filters)
                if node_filters.node_type.value > 0:
                    list_empty_nodes = []
                    for node_edit_filter in node_filters.child_branch.list_child:
                        if node_edit_filter.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                            continue

                        node_category = node_edit_filter.child_branch.loose_find_tree_node(
                            key, list_category)
                        if node_category.node_type.value == 0:
                            list_empty_nodes.append(node_edit_filter)

                    for node_edit_filter in list_empty_nodes:
                        node_edit_filter.remove_tree_node()

            node_config_override = node_edit.child_branch.find_tree_node(
                config, list_config_override)
            if node_config_override.node_type.value > 0:
                # remove "set ovrd-user-group xxx" if xxx is null.
                list_overd_user_group = ["set", "ovrd-user-group"]
                ovrd_user_group = node_config.child_branch.loose_find_tree_node(
                    key, list_overd_user_group)
                if ovrd_user_group.node_type == FGTNodeType.FGTNODE_TYPE_LEAF and \
                        ovrd_user_group.list_value[2] == "\"\"":
                    ovrd_user_group.remove_tree_node()

                # remove "set profile xxx" if xxx in null.
                list_profile = ["set", "profile"]
                profile = node_config.child_branch.loose_find_tree_node(
                    key, list_profile)
                if profile.node_type == FGTNodeType.FGTNODE_TYPE_LEAF and \
                        profile.list_value[2] == "\"\"":
                    profile.remove_tree_node()

            node_flowbased = node_edit.child_branch.loose_find_tree_node(
                key, list_flowbased)
            if node_flowbased.node_type.value != 0:
                status = node_flowbased.list_value[2]
                node_flowbased.remove_tree_node()
                if status == "enable":
                    node_edit.create_leaf_node(
                        key, list_inspection_flowbased, node_edit.get_last_leaf_index())

    def convert_config_webfilter_fortiguard(self):

        config = "config"
        list_value = ["config", "webfilter", "fortiguard"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_value = ["set", "ovrd-auth-cert"]
        node_config.child_branch.loose_find_and_remove_node(set, list_value)

    def convert_config_netscan_assets(self):

        config = "config"
        list_value = ["config", "netscan", "assets"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove config netscan assets
        node_config.remove_tree_node()

    def convert_config_report_setting(self):

        config = "config"
        list_value = ["config", "report", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_value = ["set", "status"]
        node_config.child_branch.find_and_rename_field(
            set, list_value, "fortiview")

    def convert_config_router_policy(self):

        config = "config"
        list_value = ["config", "router", "policy"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_src = ["set", "src"]
        list_dst = ["set", "dst"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_src = node_edit.child_branch.loose_find_tree_node(
                set, list_src)
            if node_src.node_type.value > 0 and len(node_src.list_value) == 4:
                ip = node_src.list_value[2]
                netmask = node_src.list_value[3]
                if utils.is_ip_address(ip) and utils.is_ip_address(netmask):
                    netmask_num = utils.atoip(netmask)
                    mask_len = utils.masktolen(netmask_num)
                    node_src.list_value.remove(netmask)
                    node_src.list_value[2] += "/" + str(mask_len)

            node_dst = node_edit.child_branch.loose_find_tree_node(
                set, list_dst)
            if node_dst.node_type.value > 0 and len(node_dst.list_value) == 4:
                ip = node_dst.list_value[2]
                netmask = node_dst.list_value[3]
                if utils.is_ip_address(ip) and utils.is_ip_address(netmask):
                    netmask_num = utils.atoip(netmask)
                    mask_len = utils.masktolen(netmask_num)
                    node_dst.list_value.remove(netmask)
                    node_dst.list_value[2] += "/" + str(mask_len)

    def convert_config(self):

        try:
            self.convert_config_antivirus_profile()
            self.convert_config_dlp_sensor()
            self.convert_config_endpoint_control_profile()
            self.convert_config_firewall_address()
            self.convert_config_firewall_service_group()
            self.convert_config_firewall_central_nat()
            self.convert_config_firewall_policy()
            self.convert_config_firewall_localinpolicy()
            self.convert_config_firewall_ssl_ssh_profile()
            self.convert_config_application_list()
            self.convert_config_log_setting()
            self.convert_config_log_fortianalyzer_setting()
            self.convert_config_log_webtrends_filter()
            self.convert_config_system_accprofile()
            self.convert_config_system_admin()
            self.convert_config_system_fortiguard()
            self.convert_config_system_global()
            self.convert_config_system_replacemsg()
            self.convert_config_system_sessionSync()
            self.convert_config_system_storage()
            self.convert_config_system_ha()
            self.convert_config_system_interface()
            self.convert_config_system_dhcp_server()
            self.convert_config_system_virtualwanlink()
            self.convert_config_system_npu()
            self.convert_config_spamfilter_profile()
            self.convert_config_vpn_ssl_web_portal()
            self.convert_config_vpn_ssl_web_userbookmark()
            self.convert_config_vpn_certificate()
            self.convert_config_vpn_ipsec_phase1()
            self.convert_config_vpn_ipsec_phase1_interface()
            self.convert_config_voip_profile()
            self.convert_config_wireless_controller_global()
            self.convert_config_wireless_controller_wtp_profile()
            self.convert_config_wireless_controller_vap()
            self.convert_config_wanopt_settings()
            self.convert_config_wanopt_profile()
            self.convert_config_wanopt_storage()
            self.convert_config_webfilter_ftgd_local_rating()
            self.convert_config_webfilter_profile()
            self.convert_config_webfilter_fortiguard()
            self.convert_config_netscan_assets()
            self.convert_config_report_setting()
            self.convert_config_router_policy()

        except Exception as e:
            print(f"Convert5.2_5.4 Error: {e}")
            raise e

    # Convert v5.2 to v5.4
    def convert_config_52_to_54(self):

        key = "config"
        list_global = ["config", "global"]
        list_vdom = ["config", "vdom"]

        node_global = self.config_root.find_tree_node(key, list_global)
        list_node_vdom = self.config_root.strict_match_tree_node(
            key, list_vdom)
        if node_global.node_type.value > 0 and len(list_node_vdom) > 0:
            # Enable VDOM mode
            self.curr_vdom = node_global.list_value[1]
            self.curr_vdom_root = node_global.child_branch
            self.convert_config()

            for node_vdom in list_node_vdom:
                for node_edit in node_vdom.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and \
                            node_edit.get_last_leaf_index() > 0:
                        self.curr_vdom = node_edit.list_value[1]
                        self.curr_vdom_root = node_edit.child_branch
                        self.convert_config()

        elif len(list_node_vdom) == 0 and node_global.node_type.value == 0:
            # Disable VDOM mode
            self.curr_vdom = "root"
            self.curr_vdom_root = self.config_root
            self.convert_config()
