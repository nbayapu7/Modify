import celery_app.fortinet.model.utils as utils
from celery_app.fortinet.model.config_tree import FGTNodeType


class Convert50_52:

    def __init__(self, fgt):

        self.config_root = fgt.config_root
        self.output_fgt = fgt
        self.curr_vdom_root = None

    def convert_config_ativirus_profile(self):

        # in "config antivirus profile"
        config = "config"
        key = "set"
        list_value = ["config", "antivirus", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_im = ["config", "im"]
        list_botnet = ["set", "block-botnet-connections"]
        list_ext_utm_log = ["set", "extended-utm-log"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove option "config im"
            node_edit.child_branch.find_and_remove_node(config, list_im)

            # replace option "set block-botnet-connections" with "set scan-botnet-connections block"
            node_block_botnet_connect = node_edit.child_branch.loose_find_tree_node(
                key, list_botnet)
            if node_block_botnet_connect.node_type.value > 0:
                setting = node_block_botnet_connect.list_value[-1]
                node_block_botnet_connect.rename_field(
                    "scan-botnet-connections")
                if setting == "enable":
                    node_block_botnet_connect.rename_option("block")

            # remove option "set extended-utm-log"
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_ext_utm_log)

    def convert_config_antivirus_quarantine(self):

        # in "config antivirus quarantine"
        key = "config"
        list_value = ["config", "antivirus", "quarantine"]
        node_config = self.curr_vdom_root.loose_find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        list_im = ["im"]
        # remove option "set drop-heuristic im"
        key = "set"
        list_value = ["set", "drop-heuristic"]
        node_config.child_branch.find_and_remove_options(
            key, list_value, list_im)

        # remove option "set drop-infected im"
        list_value = ["set", "drop-infected"]
        node_config.child_branch.find_and_remove_options(
            key, list_value, list_im)

        # remove option "set store-heuristic im"
        list_value = ["set", "store-heuristic"]
        node_config.child_branch.find_and_remove_options(
            key, list_value, list_im)

        # remove option "set store-infected im"
        list_value = ["set", "store-infected"]
        node_config.child_branch.find_and_remove_options(
            key, list_value, list_im)

    def convert_config_antivirus_service(self):

        # in "config antivirus service"
        key = "config"
        list_value = ["config", "antivirus", "service"]
        list_node_config = self.curr_vdom_root.loose_match_tree_node(
            key, list_value)
        if len(list_node_config) == 0:
            return

        # move "config antivirus service" into "config firewall profile-protocol-options XXX"
        dic_service_setting = dict()
        for node_config in list_node_config:
            service = node_config.list_value[-1]
            list_child = node_config.child_branch.list_child
            if len(list_child) > 0:
                del list_child[-1]
            service = service.replace('\"', '')
            dic_service_setting[service] = list_child
            node_config.remove_tree_node()

        list_value = ["config", "firewall", "profile-protocol-options"]
        node_profile = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_profile.node_type.value == 0:
            return

        list_profile_protocol = ["http", "ftp",
                                 "imap", "mapi", "pop3", "smtp", "nntp"]

        for node_edit in node_profile.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            for keys, value in dic_service_setting.items():
                if keys not in list_profile_protocol:
                    continue

                list_value = ["config", keys]
                node_config_service = node_edit.child_branch.find_or_create_config_node(key, list_value,
                                                                                        node_edit.get_last_leaf_index())

                insert_idx = node_config_service.get_last_leaf_index()
                for node in value:
                    node_config_service.insert_tree_node(node, insert_idx)
                    insert_idx += 1

    def convert_config_application_list(self):

        config = "config"
        key = "set"
        list_value = ["config", "application", "list"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["config", "entries"]
        list_audio = ["set", "block-audio"]
        list_encrypt = ["set", "block-encrypt"]
        list_file = ["set", "block-file"]
        list_im = ["set", "block-im"]
        list_long_chat = ["set", "block-long-chat"]
        list_photo = ["set", "block-photo"]
        list_im_summary = ["set", "im-no-content-summary"]
        list_im_chat = ["set", "imoversizechat"]
        list_log = ["set", "log"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_config_entries = node_edit.child_branch.find_tree_node(
                config, list_value)
            if node_config_entries.node_type.value == 0:
                return

            for node_entries_edit in node_config_entries.child_branch.list_child:
                if node_entries_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                #  remove field "set block-audio"
                node_entries_edit.child_branch.loose_find_and_remove_node(
                    key, list_audio)

                #  remove field "set block-encrypt"
                node_entries_edit.child_branch.loose_find_and_remove_node(
                    key, list_encrypt)

                #  remove field "set block-file"
                node_entries_edit.child_branch.loose_find_and_remove_node(
                    key, list_file)

                #  remove field "set block-im"
                node_entries_edit.child_branch.loose_find_and_remove_node(
                    key, list_im)

                #  remove field "set block-long-chat"
                node_entries_edit.child_branch.loose_find_and_remove_node(
                    key, list_long_chat)

                #  remove field "set block-photo"
                node_entries_edit.child_branch.loose_find_and_remove_node(
                    key, list_photo)

                #  remove field "set im-no-content-summary"
                node_entries_edit.child_branch.loose_find_and_remove_node(
                    key, list_im_summary)

                #  remove field "set imoversizechat"
                node_entries_edit.child_branch.loose_find_and_remove_node(
                    key, list_im_chat)

                #  remove field "set log"
                node_entries_edit.child_branch.loose_find_and_remove_node(
                    key, list_log)

    def convert_config_client_reputation_profile(self):

        # rename to config "log threat-weight"
        key = "config"
        list_value = ["config", "client-reputation", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["config", "log", "threat-weight"]
        node_config.rename_command(list_value)

    def convert_config_dlp_sensor(self):

        config = "config"
        key = "set"
        list_value = ["config", "dlp", "sensor"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["config", "filter"]

        list_utm_log = ["set", "extended-utm-log"]
        list_to_be_removed = ["aim", "icq", "msn", "yahoo"]
        list_full_archive = ["set", "full-archive-proto"]
        list_summary = ["set", "summary-proto"]
        list_proto = ["set", "proto"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove field "set extended-utm-log"
            node_edit.child_branch.find_and_remove_node(key, list_utm_log)

            # remove options "aim", "icq", "msn", "yahoo"
            node_edit.child_branch.find_and_remove_options(
                key, list_full_archive, list_to_be_removed)

            # remove options "aim", "icq", "msn", "yahoo"
            node_edit.child_branch.find_and_remove_options(
                key, list_summary, list_to_be_removed)

            node_config_filter = node_edit.child_branch.find_tree_node(
                config, list_value)
            if node_config_filter.node_type.value > 0:
                filter_idx = 0
                for node_filter_edit in node_config_filter.child_branch.list_child:
                    if node_filter_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                        continue

                    # use id to replace filter name
                    name = node_filter_edit.list_value[-1]
                    node_filter_edit.rename_edit_name(str(filter_idx))
                    filter_idx += 1
                    list_name = ["set", "name", name]
                    node_filter_edit.create_leaf_node(key, list_name, 0)

                    # remove options "aim" "icq" "msn" "yahoo"
                    node_filter_edit.child_branch.find_and_remove_options(
                        key, list_proto, list_to_be_removed)

    def convert_config_firewall_deepinspectionoptions(self):

        # rename to "config firewall deep-inspection-options"
        key = "config"
        list_value = ["config", "firewall", "deep-inspection-options"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["config", "firewall", "ssl-ssh-profile"]
        node_config.rename_command(list_value)

        key = "set"
        list_ssl = ["set", "ssl-invalid-server-cert-log"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.rename_edit_name("deep-inspection")

            node_edit.child_branch.loose_find_and_remove_node(key, list_ssl)

    def convert_config_firewall_policy(self):

        def convert_config_firewall_policy_content(node_config):

            key = "set"
            config = "config"
            list_active_auth_method = ["set", "active-auth-method"]
            list_action = ["set", "action"]
            list_identity_based = ["set", "identity-based"]
            list_identity_from = ["set", "identity-from"]
            list_fail_through = ["set", "fall-through-unauthenticated"]
            list_log_unmatched = ["set", "log-unmatched-traffic"]
            list_device_detection = ["set", "device-detection-portal"]
            list_email_collection = ["set", "email-collection-portal"]
            list_fc_enforcement = [
                "set", "forticlient-compliance-enforcement-portal"]
            list_fc_devices = ["set", "forticlient-compliance-devices"]
            list_deep_inspection = ["set", "deep-inspection-options"]
            list_id_based_policy = ["config", "identity-based-policy"]
            list_ssl_vpn_auth = ["set", "sslvpn-auth"]
            list_ssl_vpn_ccert = ["set", "sslvpn-ccert"]
            list_ssl_vpn_cipher = ["set", "sslvpn-cipher"]
            list_sso_auth_method = ["set", "sso-auth-method"]
            list_service = ["set", "service"]

            list_node_id_based_policy = []

            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node = node_edit.child_branch.find_tree_node(
                    config, list_id_based_policy)
                if node.node_type.value > 0:
                    list_node_id_based_policy.append(node_edit)

                # remove field "set active-auth-method"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_active_auth_method)

                node_action = node_edit.child_branch.loose_find_tree_node(
                    key, list_action)
                if node_action.node_type.value > 0 and "ssl-vpn" in node_action.list_value:
                    node_action.rename_option("accept")

                # remove field "set identity-based"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_identity_based)

                # remove field "set identity-from"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_identity_from)

                # remove field "set fall-through-unauthenticated"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_fail_through)

                # remove field "set log-unmatched-traffic"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_log_unmatched)

                # remove field "set device-detection-portal"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_device_detection)

                # remove field "set email-collection-portal"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_email_collection)

                # remove field "set forticlient-compliance-enforcement-portal"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_fc_enforcement)

                # remove field "forticlient-compliance-devices"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_fc_devices)

                # rename field "deep-inspection-options" into "ssl-ssh-profile"
                node_edit.child_branch.find_and_rename_field(
                    key, list_deep_inspection, "ssl-ssh-profile")

                # reset "deep- inspection"
                list_ssl_ssh_profile = ["set", "ssl-ssh-profile"]
                list_value = ["set", "ssl-ssh-profile", "\"deep-inspection\""]
                node_edit.child_branch.find_and_rename_command(
                    key, list_ssl_ssh_profile, list_value)

                # remove field "set sslvpn-auth"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_ssl_vpn_auth)

                # remove field "set sslvpn-ccert"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_ssl_vpn_ccert)

                # remove field "set sslvpn-cipher"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_ssl_vpn_cipher)

                # remove field "set sso-auth-method"
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_sso_auth_method)

                # rename the predefined service "ANY" into "ALL"
                node_service = node_edit.child_branch.loose_find_tree_node(
                    "set", list_service)
                if node_service.node_type.value > 0:
                    if "\"ANY\"" in node_service.list_value:
                        node_service.rename_option("\"ALL\"")
                    if "\"ICMP_ANY\"" in node_service.list_value:
                        node_service.list_value.remove("\"ICMP_ANY\"")
                        node_service.list_value.append("\"ALL_ICMP\"")

            list_dstaddr = ["set", "dstaddr"]
            list_devices = ["set", "devices"]
            list_endpoint = ["set", "endpoint-compliance"]
            list_groups = ["set", "groups"]
            list_users = ["set", "users"]
            list_schedule = ["set", "schedule"]
            list_log = ["set", "logtraffic"]
            list_log_app = ["set", "logtraffic-app"]
            list_utm_status = ["set", "utm-status"]
            list_av_profile = ["set", "av-profile"]
            list_web_filter_profile = ["set", "webfilter-profile"]
            list_profile_protocol_options = ["set", "profile-protocol-options"]

            for node_id_based_policy in list_node_id_based_policy:
                index = node_config.child_branch.list_child.index(
                    node_id_based_policy)
                node = node_id_based_policy.child_branch.find_tree_node(
                    config, list_id_based_policy)
                id_based_policy_index = node_id_based_policy.child_branch.list_child.index(
                    node)
                node.remove_tree_node()

                list_node_edit = []
                for node_edit in node.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        list_node_edit.append(node_edit)

                for node_idx in range(len(list_node_edit)):
                    replace_item_index = id_based_policy_index
                    node_edit = list_node_edit[node_idx]

                    node_id_based_policy_item = node_id_based_policy.clone(
                        node_id_based_policy.parent_branch)

                    # move field "set dstaddr" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_dstaddr)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set devices" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_devices)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set endpoint-compliance" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_endpoint)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set groups" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_groups)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set users" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_users)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set service" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_service)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set schedule" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_schedule)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set logtraffic" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_log)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set logtraffic" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_log_app)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set utm-status" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_utm_status)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set av-profile" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_av_profile)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set webfilter-profile" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_web_filter_profile)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    # move field "set ProfileProtocolOptions" out of "config identity-based policy"
                    node_move = node_edit.child_branch.loose_find_tree_node(
                        key, list_profile_protocol_options)
                    if node_move.node_type.value > 0:
                        node_id_based_policy_item.insert_tree_node(
                            node_move, replace_item_index)
                        replace_item_index += 1

                    original_policy_idx = 0
                    new_policy_idx = 10000 + node_idx
                    last = len(node_id_based_policy.list_value) - 1
                    is_parse_to_int, original_policy_idx = utils.try_parse_int(node_id_based_policy.list_value[last],
                                                                               original_policy_idx)
                    if is_parse_to_int:
                        new_policy_idx += original_policy_idx * 10
                    if node_idx == 0:
                        new_policy_idx = original_policy_idx

                    node_id_based_policy_item.list_value[last] = str(
                        new_policy_idx)
                    node_config.child_branch.list_child.insert(
                        index + node_idx, node_id_based_policy_item)

                node_id_based_policy.remove_tree_node()

        key = "config"
        list_value = ["config", "firewall", "policy"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_policy_content(node_config)

        list_value = ["config", "firewall", "policy6"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_policy_content(node_config)

    def convert_config_firewall_profilegroup(self):

        key = "config"
        list_value = ["config", "firewall", "profile-group"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ["set", "deep-inspection-options"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                continue

            # rename field "set deep-inspection-options" into "set ssl-ssh-profile"
            node_edit.child_branch.find_and_rename_field(
                key, list_value, "ssl-ssh-profile")

            # reset "deep-inspection"
            list_ssl_ssh_profile = ["set", "ssl-ssh-profile"]
            list_deep_inspection = [
                "set", "ssl-ssh-profile", "\"deep-inspection\""]
            node_edit.child_branch.find_and_rename_command(
                "set", list_ssl_ssh_profile, list_deep_inspection)

    def convert_config_firewall_profileprotocoloptions(self):

        key = "config"
        list_value = ["config", "firewall", "profile-protocol-options"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove command "config im"
        list_value = ["config", "im"]
        node_config.child_branch.find_and_remove_node(key, list_value)

        # remove option "no-content-summary" in "set options"
        key = "set"
        list_value = ["set", "options"]
        list_node_options = node_config.child_branch.loose_match_tree_node(
            key, list_value)
        list_to_be_removed = ["no-content-summary"]
        for node_options in list_node_options:
            node_options.remove_options(list_to_be_removed)

        # Replace keywords "uncompnestlimit" and "uncompsizelimit".
        # rename "set uncompnestlimit" into "set uncompressed-nest-limit"
        list_value = ["set", "uncompnestlimit"]
        list_node_nest = node_config.child_branch.loose_match_tree_node(
            key, list_value)
        for node_nest in list_node_nest:
            node_nest.rename_field("uncompressed-nest-limit")

        # rename "set uncompsizelimit" into "set uncompressed-oversize-limit"
        list_value = ["set", "uncompsizelimit"]
        list_node_orversize = node_config.child_branch.loose_match_tree_node(
            key, list_value)
        for node_oversize in list_node_orversize:
            node_oversize.rename_field("uncompressed-oversize-limit")

        list_value = ["set", "extended-utm-log"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_firewall_sslsshprofile(self):

        key = "config"
        list_value = ["config", "firewall", "ssl-ssh-profile"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ["set", "extended-utm-log"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_firewall_sniffinterfacepolicy(self):

        list_sniffer = ["config", "firewall", "sniffer"]

        # rename command "config firewall sniff-interface-policy" to "config firewall sniffer"
        key = "config"
        list_value = ["config", "firewall", "sniff-interface-policy"]
        self.curr_vdom_root.find_and_rename_command(
            key, list_value, list_sniffer)

        list_value = ["config", "firewall", "sniff-interface-policy6"]
        self.curr_vdom_root.find_and_rename_command(
            key, list_value, list_sniffer)

    def convert_config_imp2p(self):

        key = "config"
        list_value = ["config", "imp2p"]
        list_node_config = self.curr_vdom_root.loose_match_tree_node(
            key, list_value)
        if len(list_node_config) == 0:
            return

        # remove command "config imp2p"
        for node_config in list_node_config:
            node_config.remove_tree_node()

    def convert_config_ips_sensor(self):

        key = "config"
        list_value = ["config", "ips", "sensor"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ["set", "log"]

        # remove field "set log"
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_log_disk_setting(self):

        key = "config"
        list_value = ["config", "log", "disk", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set report" and convert into command "config report setting"
        key = "set"
        list_value = ["set", "report"]
        node_set_report = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_set_report.node_type.value == 0:
            return

        key = "config"
        list_value = ["config", "report", "setting"]
        idx = node_config.get_location_index() + 1
        node_report_setting = node_config.parent_branch.find_or_create_config_node(
            key, list_value, idx)

        node_set_report.rename_field("status")
        node_report_setting.move_tree_node(node_set_report, 0)

    def convert_config_log_eventfilter(self):

        key = "config"
        list_value = ["config", "log", "eventfilter"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set admin"
        key = "set"
        list_value = ["set", "admin"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set dna"
        list_value = ["set", "dns"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set utm"
        list_value = ["set", "utm"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_log_memoryfilter(self):
        '''
         config log memory filter
           set email-log-smtp disable
           set web-filter-activex disable
           set web-filter-applet disable
           set web-filter-cookie disable
         end 
        '''
        key = "config"
        list_value = ["config", "log", "memory", "filter"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set email-log-smtp"
        key = "set"
        list_value = ["set", "email-log-smtp"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set web-filter-activex"
        key = "set"
        list_value = ["set", "web-filter-activex"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set web-filter-applet"
        key = "set"
        list_value = ["set", "web-filter-applet"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set web-filter-cookie"
        key = "set"
        list_value = ["set", "web-filter-cookie"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_log_syslogd_filter(self):

        config = "config"
        set = "set"
        list_appctrl = ["set", "app-ctrl"]
        list_appctrlall = ["set", "app-ctrl-all"]
        list_dlp = ["set", "dlp"]
        list_dlpall = ["set", "dlp-all"]
        list_failed_connection = ["set", "failed-connection"]
        list_netscan = ["set", "netscan"]
        list_blocked = ["set", "blocked"]
        list_discovery = ["set", "discovery"]

        list_email_log_google = ["set", "email-log-google"]
        list_email_log_imap = ["set", "email-log-imap"]
        list_email_log_msn = ["set", "email-log-msn"]
        list_email_log_pop3 = ["set", "email-log-pop3"]
        list_email_log_smtp = ["set", "email-log-smtp"]
        list_email_log_yahoo = ["set", "email-log-yahoo"]
        list_ftgd_wf_block = ["set", "ftgd-wf-block"]
        list_ftgd_wf_errors = ["set", "ftgd-wf-errors"]
        list_infected = ["set", "infected"]
        list_oversized = ["set", "oversized"]
        list_scanerror = ["set", "scanerror"]
        list_signature = ["set", "signature"]
        list_url_filter = ["set", "url-filter"]
        list_vulnerability = ["set", "vulnerability"]

        list_web_content = ["set", "web-content"]
        list_web_filter_activex = ["set", "web-filter-activex"]
        list_web_filter_applet = ["set", "web-filter-applet"]
        list_web_filter_cookie = ["set", "web-filter-cookie"]
        list_web_filter_ftgd_quota = ["set", "web-filter-ftgd-quota"]
        list_web_filter_ftgd_quota_counting = [
            "set", "web-filter-ftgd-quota-counting"]
        list_web_filter_ftgd_quota_expired = [
            "set", "web-filter-ftgd-quota-expired"]
        list_web_filter_script_other = ["set", "web-filter-script-other"]

        list_postfix = ["", "2", "3", "4"]

        for postfix in list_postfix:

            list_value = ["config", "log", "syslogd" + postfix, "filter"]
            node_config = self.curr_vdom_root.find_tree_node(
                config, list_value)
            if node_config.node_type.value == 0:
                continue

            node_config.child_branch.loose_find_and_remove_node(
                set, list_appctrl)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_appctrlall)
            node_config.child_branch.loose_find_and_remove_node(set, list_dlp)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_dlpall)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_failed_connection)
            node_netscan = node_config.child_branch.loose_find_tree_node(
                set, list_netscan)
            if node_netscan.node_type.value > 0:
                node_config.child_branch.find_and_rename_field(
                    set, list_discovery, "netscan-discovery")
                node_config.child_branch.find_and_rename_field(
                    set, list_vulnerability, "netscan-vulnerability")
                node_netscan.remove_tree_node()

            node_config.child_branch.loose_find_and_remove_node(
                set, list_blocked)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_email_log_google)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_email_log_imap)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_email_log_msn)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_email_log_pop3)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_email_log_smtp)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_email_log_yahoo)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_ftgd_wf_block)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_ftgd_wf_errors)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_infected)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_oversized)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_scanerror)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_signature)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_url_filter)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_web_content)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_web_filter_activex)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_web_filter_applet)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_web_filter_cookie)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_web_filter_ftgd_quota)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_web_filter_ftgd_quota_counting)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_web_filter_ftgd_quota_expired)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_web_filter_script_other)

    def convert_config_log_setting(self):

        key = "config"
        list_value = ["config", "log", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set uuid" and convert into "set log-uuid" in command "config system global"
        key = "set"
        list_value = ["set", "uuid"]
        node_uuid = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_uuid.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            node_uuid.rename_field("log-uuid")

            obj_parent = node_config.parent_branch
            key = "config"
            list_value = ["config", "system", "global"]
            count = len(obj_parent.list_child) - 1
            node_config_global = obj_parent.find_or_create_config_node(
                key, list_value, count)
            node_config_global.move_tree_node(node_uuid, 0)

        # Rename field "set local-in-deny disable" and convert into "set local-in-deny-unicast disable" and "set local-in-deny-broadcast disable"
        key = "set"
        list_value = ["set", "local-in-deny"]
        node_local_in_deny = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_local_in_deny.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            node_local_in_deny.rename_field("local-in-deny-unicast")

            node_append_node = node_local_in_deny.clone(
                node_local_in_deny.parent_branch)
            node_append_node.leading_space = node_local_in_deny.leading_space
            node_append_node.rename_field("local-in-deny-broadcast")
            append_index = node_config.child_branch.list_child.index(
                node_local_in_deny)
            node_config.insert_tree_node(node_append_node, append_index)

    def convert_config_log_threat_weight(self):

        key = "config"
        list_value = ["config", "log", "threat-weight"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["config", "web"]
        node_config_web = node_config.child_branch.find_tree_node(
            key, list_value)
        if node_config_web.node_type.value == 0:
            return

        # rename field "set group" into "set category"
        key = "set"
        list_value = ["set", "group"]
        list_node_group = node_config.child_branch.loose_match_tree_node(
            key, list_value)
        for node_group in list_node_group:
            node_group.rename_field("category")

    def convert_config_router_gwdetect(self):

        key = "config"
        list_value = ["config", "router", "gwdetect"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        '''
        # rename command "config router gwdetect" into "config system link-monitor"
        list_value = ["config", "system", "link-monitor"]
        node_config.rename_command(list_value)
        '''
        # may not convert into config system link-monitor directly, delete temporily
        node_config.remove_tree_node()

    def convert_config_system_bugreport(self):

        # remove command "config system bug-report"
        key = "config"
        list_value = ["config", "system", "bug-report"]
        self.curr_vdom_root.find_and_remove_node(key, list_value)

    def convert_config_system_centralmanagement(self):

        key = "config"
        list_value = ["config", "system", "central-management"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set fortimanager-fds-override"
        key = "set"
        list_value = ["set", "fortimanager-fds-override"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_system_global(self):

        key = "config"
        list_value = ["config", "system", "global"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set auth-policy-exact-match"
        key = "set"
        list_value = ["set", "auth-policy-exact-match"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set gui-client-reputation"
        list_value = ["set", "gui-client-reputation"]
        node_config.child_branch.find_and_rename_field(
            key, list_value, "gui-threat-weight")

        # rename field "set tos-based-priority" into "traffic-priority-level"
        # with "set traffic-priority tos"
        list_value = ["set", "tos-based-priority"]
        node_tos = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_tos.node_type.value > 0:
            list_value = ["set", "traffic-priority", "tos"]
            node_config.create_leaf_node(
                key, list_value, node_tos.get_location_index())
            node_tos.rename_field("traffic-priority-level")

        # move field "set use-usb-wan" into "config system lte-modem"
        list_value = ["set", "use-usb-wan"]
        node_status = node_config.child_branch.loose_find_tree_node(
            key, list_value)

        # move field "set usb-wan-auth-type" into "config system lte-modem"
        list_value = ["set", "usb-wan-auth-type"]
        node_auth_type = node_config.child_branch.loose_find_tree_node(
            key, list_value)

        # move field "set usb-wan-extra-init" into "config system lte-modem"
        list_value = ["set", "usb-wan-extra-init"]
        node_extra_init = node_config.child_branch.loose_find_tree_node(
            key, list_value)

        # move field "set usb-wan-passwd" into "config system lte-modem"
        list_value = ["set", "usb-wan-passwd"]
        node_passwd = node_config.child_branch.loose_find_tree_node(
            key, list_value)

        # move field "set usb-wan-username" into "config system lte-modem"
        list_value = ["set", "usb-wan-username"]
        node_user = node_config.child_branch.loose_find_tree_node(
            key, list_value)

        if node_status.node_type.value > 0 or node_auth_type.node_type.value > 0 or node_extra_init.node_type.value > 0 or \
                node_passwd.node_type.value > 0 or node_user.node_type.value > 0:
            key = "config"
            list_value = ["config", "system", "lte-modem"]
            insert_index = node_config.get_location_index()
            node_lte_modem = node_config.parent_branch.create_blank_config_node(
                list_value, insert_index)
            if node_status.node_type.value > 0:
                node_status.rename_field("status")
                node_lte_modem.move_tree_node(
                    node_status, node_lte_modem.get_last_leaf_index())

            if node_status.node_type.value > 0:
                node_auth_type.rename_field("authtype")
                node_lte_modem.move_tree_node(
                    node_auth_type, node_lte_modem.get_last_leaf_index())

            if node_passwd.node_type.value > 0:
                node_passwd.rename_field("password")
                node_lte_modem.move_tree_node(
                    node_passwd, node_lte_modem.get_last_leaf_index())

            if node_extra_init.node_type.value > 0:
                node_extra_init.rename_field("extra-init")
                node_lte_modem.move_tree_node(
                    node_extra_init, node_lte_modem.get_last_leaf_index())

            if node_user.node_type.value > 0:
                node_user.rename_field("username")
                node_lte_modem.move_tree_node(
                    node_user, node_lte_modem.get_last_leaf_index())

        list_gui = ["set", "gui-multiple-utm-profiles"]
        node_gui = node_config.child_branch.loose_find_tree_node(
            "set", list_gui)
        if node_gui.node_type.value == 0:
            list_gui.append("enable")
            node_config.create_leaf_node("set", list_gui, 0)

        list_gui = ["set", "gui-dynamic-routing"]
        node_gui = node_config.child_branch.loose_find_tree_node(
            "set", list_gui)
        if node_gui.node_type.value == 0:
            list_gui.append("enable")
            node_config.create_leaf_node("set", list_gui, 0)

        list_gui = ["set", "gui-replacement-message-groups"]
        node_gui = node_config.child_branch.loose_find_tree_node(
            "set", list_gui)
        if node_gui.node_type.value == 0:
            list_gui.append("enable")
            node_config.create_leaf_node("set", list_gui, 0)

        list_gui = ["set", "gui-wireless-controller"]
        node_gui = node_config.child_branch.loose_find_tree_node(
            "set", list_gui)
        if node_gui.node_type.value == 0:
            list_gui.append("enable")
            node_config.create_leaf_node("set", list_gui, 0)

        list_gui = ["set", "gui-wireless-opensecurity"]
        node_gui = node_config.child_branch.loose_find_tree_node(
            "set", list_gui)
        if node_gui.node_type.value == 0:
            list_gui.append("enable")
            node_config.create_leaf_node("set", list_gui, 0)

        list_admin = ["set", "admin-server-cert"]
        node_admin = node_config.child_branch.loose_find_tree_node(
            "set", list_admin)
        if node_admin.node_type.value == 0:
            list_admin.append("enable")
            node_config.create_leaf_node("set", list_admin, 0)

        list_admin = ["set", "admin-maintainer"]
        node_admin = node_config.child_branch.loose_find_tree_node(
            "set", list_admin)
        if node_admin.node_type.value == 0:
            list_admin.append("enable")
            node_config.create_leaf_node("set", list_admin, 0)

    def convert_config_system_interface(self):

        key = "config"
        list_value = ["config", "system", "interface"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set log"
        key = "set"
        list_value = ["set", "log"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_system_replacemsg(self):

        key = "config"
        list_value = ["config", "system", "replacemsg", "captive-portal-dflt"]
        list_node = self.curr_vdom_root.loose_match_tree_node(key, list_value)
        if len(list_node) == 0:
            return

        for node_config in list_node:
            if node_config.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                node_config.remove_tree_node()

    def convert_config_system_serverprobe(self):

        # remove command "config system server-probe"
        key = "config"
        list_value = ["config", "system", "server-probe"]
        self.curr_vdom_root.find_and_remove_node(key, list_value)

        # May not convert into "config system link-moniter" directly. Skip temporarily.

    def convert_config_system_settings(self):

        key = "config"
        list_value = ["config", "system", "settings"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set per-ip-bandwidth"
        key = "set"
        list_value = ["set", "per-ip-bandwidth"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_system_storage(self):

        config = "config"
        list_value = ["config", "system", "storage"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # Right now, we only simple remove this settings.
        node_config.remove_tree_node()

    def convert_config_vpn_ipsec_phase1(self):

        key = "config"
        list_value = ["config", "vpn", "ipsec", "phase1"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value > 0:
            self.convert_config_vpn_ipsec_phase1_content(node_config)

        list_value = ["config", "vpn", "ipsec", "phase1-interface"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value > 0:
            self.convert_config_vpn_ipsec_phase1_content(node_config)

    def convert_config_vpn_ipsec_phase1_content(self, node_config):

        key = "set"
        list_authmethod = ["set", "authmethod", "rsa-signature"]
        list_certificate = ["set", "rsa-certificate"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # rename option "rsa-signature" in field "set authmethod" into "signature"
            node_set = node_edit.child_branch.find_tree_node(
                key, list_authmethod)
            if node_set.node_type.value > 0:
                node_set.rename_option("signature")

            # rename field "set rsa-certificate" into "set certificate"
            node_edit.child_branch.find_and_rename_field(
                key, list_certificate, "certificate")

    def convert_config_vpn_ssl_settings(self):

        key = "config"
        list_value = ["config", "vpn", "ssl", "settings"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # rename "set allow-ssl-big-buffer" into "set ssl-big-buffer"
        key = "set"
        list_value = ["set", "allow-ssl-big-buffer"]
        node_config.child_branch.find_and_rename_field(
            key, list_value, "ssl-big-buffer")

        # rename "set allow-ssl-client-renegotiation" into "set ssl-client-renegotiation"
        list_value = ["set", "allow-ssl-client-renegotiation"]
        node_config.child_branch.find_and_rename_field(
            key, list_value, "ssl-client-renegotiation")

        # rename "set allow-ssl-insert-empty-fragment" into "set ssl-insert-empty-fragment"
        list_value = ["set", "allow-ssl-insert-empty-fragment"]
        node_config.child_branch.find_and_rename_field(
            key, list_value, "ssl-insert-empty-fragment")

        # rename "set allow-unsafe-legacy-renegotiation" into "set unsafe-legacy-renegotiation"
        list_value = ["set", "allow-unsafe-legacy-renegotiation"]
        node_config.child_branch.find_and_rename_field(
            key, list_value, "unsafe-legacy-renegotiation")

        # remove "set auto-tunnel-policy"
        list_value = ["set", "auto-tunnel-policy"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_vpn_ssl_web_portal(self):

        # "config vpn ssl web portal"
        config = "config"
        list_value = ["config", "vpn", "ssl", "web", "portal"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove "set allow-access"
            list_allow_access = ["set", "allow-access"]
            node_edit.child_branch.loose_find_and_remove_node(
                "set", list_allow_access)

            # remove "config widget"
            list_config_widget = ["config", "widget"]
            node_config_widget = node_edit.child_branch.find_tree_node(
                config, list_config_widget)
            if node_config_widget.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                node_config_widget.remove_tree_node()

    def convert_config_vpn_ssl_web_user(self):

        config = "config"
        key = "set"
        list_value = ["config", "vpn", "ssl", "web", "user"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.list_value = [
            "config", "vpn", "ssl", "web", "user-bookmark"]

        list_widget = ["config", "widget"]
        list_bookmarks = ["config", "bookmarks"]
        list_form_data = ["config", "form-data"]
        list_set_name = ["set", "name"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # move command "config bookmarks" under "config vpn ssl web user"
            node_bookmarks = None
            node_widget = node_edit.child_branch.find_tree_node(
                config, list_widget)
            if node_widget.node_type.value > 0:
                for node_edit_id in node_widget.child_branch.list_child:
                    if node_edit_id.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                        continue

                    node_bookmarks = node_edit_id.child_branch.find_tree_node(
                        config, list_bookmarks)
                    if node_bookmarks.node_type.value != 0:
                        break

                node_widget.remove_tree_node()

            if node_bookmarks.node_type.value == 0:
                continue

            node_edit.move_tree_node(node_bookmarks, 0)

            node_form_data = node_bookmarks.child_branch.find_tree_node(
                config, list_form_data)
            if node_form_data.node_type.value == 0:
                continue

            # put the value "name" after "edit" in "config from-data"
            for node_edit_id in node_form_data.child_branch.list_child:
                if node_edit_id.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_name = node_edit_id.child_branch.loose_find_tree_node(
                    key, list_set_name)
                if node_name.node_type.value > 0:
                    name = node_name.list_value[-1]
                    node_name.remove_tree_node()
                    node_edit_id.list_value[len(
                        node_edit_id.list_value) - 1] = name

    def convert_config_Wanopt_storage(self):

        config = "config"
        list_value = ["config", "wanopt", "storage"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

    def convert_config_webfilter_profile(self):

        config = "config"
        key = "set"
        list_value = ["config", "webfilter", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_safe_search = ["set", "safe-search"]
        list_ext_utm_log = ["set", "extended-utm-log"]
        list_ftgd = ["config", "ftgd-wf"]
        list_exe_ssl = ["set", "exempt-ssl"]
        list_unset_exe_ssl = ["unset", "exempt-ssl"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_safe_search = node_edit.child_branch.loose_find_tree_node(
                key, list_safe_search)
            if node_safe_search.node_type.value > 0:
                if node_safe_search.list_value[2] not in ("url", "header"):
                    node_safe_search.list_value = [
                        "set", "safe-search", "header"]

            # remove field "set extended-utm-log"
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_ext_utm_log)

            # remove field "set exempt-ssl" in "config ftgd-wf"
            node_ftgd = node_edit.child_branch.find_tree_node(
                config, list_ftgd)
            if node_ftgd.node_type.value > 0:
                node_ftgd.child_branch.loose_find_and_remove_node(
                    key, list_exe_ssl)
                node_ftgd.child_branch.find_and_remove_node(
                    "unset", list_unset_exe_ssl)

    def convert_config_webfilter_urlfilter(self):

        config = "config"
        key = "set"
        list_value = ["config", "webfilter", "urlfilter"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_entries = ["config", "entries"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            entry_idx = 1
            node_entries = node_edit.child_branch.find_tree_node(
                config, list_entries)
            if node_entries.node_type.value == 0:
                continue

            for node_edit_entry in node_entries.child_branch.list_child:
                if node_edit_entry.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                url = node_edit_entry.list_value[-1]
                list_url = ["set", "url", url]
                node_edit_entry.rename_edit_name(str(entry_idx))
                node_edit_entry.create_leaf_node(key, list_url, 0)
                entry_idx += 1

    def convert_config_webproxy_global(self):

        config = "config"
        key = "set"
        list_value = ["config", "web-proxy", "global"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # get the options of field "set add-header-client-ip"
        add_client = ""
        add_via = ""
        add_x = ""
        add_front = ""
        list_value = ["set", "add-header-client-ip"]
        node_add_client = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_add_client.node_type.value > 0:
            add_client = node_add_client.list_value[-1]
            node_add_client.remove_tree_node()

        # get the options of field "set add-header-via"
        list_value = ["set", "add-header-via"]
        node_add_via = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_add_via.node_type.value > 0:
            add_via = node_add_via.list_value[-1]
            node_add_via.remove_tree_node()

        # get the options of field "set add-header-x-forwarded-for"
        list_value = ["set", "add-header-x-forwarded-for"]
        node_add_x = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_add_x.node_type.value > 0:
            add_x = node_add_x.list_value[-1]
            node_add_x.remove_tree_node()

        # get the options of field "set add-header-front-end-https"
        list_value = ["set", "add-header-front-end-https"]
        node_add_front = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_add_front.node_type.value > 0:
            add_front = node_add_front.list_value[-1]
            node_add_front.remove_tree_node()

        if add_client != "enable" and add_via != "enable" and add_x != "enable" and add_front != "enable":
            return

        obj_parent = node_config.parent_branch
        insert_index = obj_parent.list_child.index(node_config)

        list_value = ["config", "web-proxy", "profile"]
        node_config = obj_parent.find_or_create_config_node(
            config, list_value, insert_index)

        if len(node_config.child_branch.list_child) == 1:
            node_config.create_blank_edit_node("global", 0)

        list_client = ["set", "header-client-ip", "add"]
        list_via_request = ["set", "header-via-request", "add"]
        list_via_response = ["set", "header-via-response", "add"]
        list_x = ["set", "header-x-forwarded-for", "add"]
        list_front = ["set", "header-front-end-https", "add"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # convert field "set add-header-client-ip enable"
            # into "set header-client-ip add" in "config web-proxy profile"
            if add_client == "enable":
                node_edit.create_leaf_node(key, list_client, 0)

            # convert field "set add-header-via enable"
            # into "set header-via-request add" and "set header-via-response add" in "config web-proxy profile"
            if add_via == "enable":
                node_edit.create_leaf_node(key, list_via_request, 0)
                node_edit.create_leaf_node(key, list_via_response, 0)

            # convert field "set add-header-x-forwarded-for enable"
            # into "set header-front-end-https add" in "config web-proxy profile"
            if add_x == "enable":
                node_edit.create_leaf_node(key, list_x, 0)

            # convert field "set add-header-front-end-https enable"
            # into "set header-front-end-https add" in "config web-proxy profile"
            if add_front == "enable":
                node_edit.create_leaf_node(key, list_front, 0)

    def convert_config_wireless_controller(self):

        config = "config"
        key = "set"
        list_value = ["config", "wireless-controller", "wtp-profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_radio1 = ["config", "radio-1"]
        list_radio2 = ["config", "radio-2"]
        list_moniter = ["set", "mode", "moniter"]
        list_locate = ["set", "station-locate"]
        list_channel = ["set", "channel-bonding"]
        list_lbs = ["config", "lbs"]

        dic_ap_scan = dict()

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            is_lbs_created = False
            node_name = node_edit.list_value[-1]

            node_radio = node_edit.child_branch.find_tree_node(
                config, list_radio1)
            if node_radio.node_type.value > 0:
                node_mode = node_radio.child_branch.loose_find_tree_node(
                    key, list_moniter)
                if node_mode.node_type.value > 0:
                    mode = node_mode.list_value[-1]
                    if mode == "moniter":
                        node_mode.rename_option("sniffer")

                node_locate = node_radio.child_branch.loose_find_tree_node(
                    key, list_locate)
                if node_locate.node_type.value > 0:
                    insert_index = node_edit.get_last_leaf_index()
                    node_lbs = node_edit.child_branch.create_blank_config_node(
                        list_lbs, insert_index)
                    node_lbs.move_tree_node(node_locate, 0)
                    is_lbs_created = True

                node_channel = node_radio.child_branch.loose_find_tree_node(
                    key, list_channel)
                if node_channel.node_type.value > 0:
                    status = node_channel.list_value[-1]
                    if status == "enable":
                        node_channel.rename_option("20MHz")
                    else:
                        node_channel.remove_tree_node()

                list_ap_scan = self.convert_config_wireless_controller_ap_content(
                    node_radio)
                if len(list_ap_scan) > 0:
                    dic_ap_scan[node_name] = list_ap_scan

            node_radio = node_edit.child_branch.find_tree_node(
                config, list_radio2)
            if node_radio.node_type.value > 0:
                # rename option "moniter" of "set mode" into "sniffer"
                node_mode = node_radio.child_branch.loose_find_tree_node(
                    key, list_moniter)
                if node_mode.node_type.value > 0:
                    node_mode.rename_option("sniffer")

                # move field "set station-locate" into subcommand "config lbs"
                node_locate = node_radio.child_branch.loose_find_tree_node(
                    key, list_locate)
                if node_locate.node_type.value > 0 and not is_lbs_created:
                    node_lbs = node_edit.child_branch.create_blank_config_node(list_lbs,
                                                                               node_edit.get_last_leaf_index())
                    node_lbs.move_tree_node(node_locate, 0)

                node_channel = node_radio.child_branch.loose_find_tree_node(
                    key, list_channel)
                if node_channel.node_type.value > 0:
                    status = node_channel.list_value[-1]
                    if status == "enable":
                        node_channel.rename_option("20MHz")
                    else:
                        node_channel.remove_tree_node()

                # collect fields to be moved into command "config wireless-controller wids-profile"
                list_ap_scan = self.convert_config_wireless_controller_ap_content(
                    node_radio)
                if len(list_ap_scan) > 0 and node_name not in dic_ap_scan.keys():
                    dic_ap_scan[node_name] = list_ap_scan

        if len(dic_ap_scan) > 0:
            # move fields into command "config wireless-controller wids-profile"
            insert_index = node_config.get_location_index()
            list_value = ["config", "wireless-controller", "wids-profile"]
            node_config = node_config.parent_branch.find_or_create_config_node(
                config, list_value, insert_index)

            edit = "edit"

            for key, value in dic_ap_scan.items():
                list_value = [edit, key]
                node_edit = node_config.child_branch.find_tree_node(
                    edit, list_value)
                if node_edit.node_type.value == 0:
                    node_edit = node_config.create_blank_edit_node(key, 0)

                for index in range(len(value)):
                    node_edit.move_tree_node(value[index], index)

    def convert_config_wireless_controller_ap_content(self, node_radio):

        key = "set"
        list_disable_day = ["set", "ap-bgscan-disable-day"]
        list_disable_end = ["set", "ap-bgscan-disable-end"]
        list_disable_start = ["set", "ap-bgscan-disable-start"]
        list_duration = ["set", "ap-bgscan-duration"]
        list_intv = ["set", "ap-bgscan-intv"]
        list_period = ["set", "ap-bgscan-period"]
        list_bg_report_intv = ["set", "ap-bgscan-report-intv"]
        list_fg_report_intv = ["set", "ap-fgscan-report-intv"]
        list_scan = ["set", "ap-scan"]

        list_ap_scan = []

        # collect fields to be moved into command "config wireless-controller wids-profile"
        node_ap = node_radio.child_branch.loose_find_tree_node(
            key, list_disable_day)
        if node_ap.node_type.value > 0:
            list_ap_scan.append(node_ap)

        node_ap = node_radio.child_branch.loose_find_tree_node(
            key, list_disable_end)
        if node_ap.node_type.value > 0:
            list_ap_scan.append(node_ap)

        node_ap = node_radio.child_branch.loose_find_tree_node(
            key, list_disable_start)
        if node_ap.node_type.value > 0:
            list_ap_scan.append(node_ap)

        node_ap = node_radio.child_branch.loose_find_tree_node(
            key, list_duration)
        if node_ap.node_type.value > 0:
            list_ap_scan.append(node_ap)

        node_ap = node_radio.child_branch.loose_find_tree_node(key, list_intv)
        if node_ap.node_type.value > 0:
            list_ap_scan.append(node_ap)

        node_ap = node_radio.child_branch.loose_find_tree_node(
            key, list_period)
        if node_ap.node_type.value > 0:
            list_ap_scan.append(node_ap)

        node_ap = node_radio.child_branch.loose_find_tree_node(
            key, list_bg_report_intv)
        if node_ap.node_type.value > 0:
            list_ap_scan.append(node_ap)

        node_ap = node_radio.child_branch.loose_find_tree_node(
            key, list_fg_report_intv)
        if node_ap.node_type.value > 0:
            list_ap_scan.append(node_ap)

        node_ap = node_radio.child_branch.loose_find_tree_node(key, list_scan)
        if node_ap.node_type.value > 0:
            list_ap_scan.append(node_ap)

        return list_ap_scan

    def convert_config_spamfilter_profile(self):

        key = "config"
        list_value = ["config", "spamfilter", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        list_options = ["set", "options"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue
            '''
             In 4.x series we use 'spamemailbwl' to filter email using a black/white list.
             In 5.x series we use 'spambwl'. 
            '''
            node_edit.child_branch.find_and_rename_options(
                "set", list_options, "spamemailbwl", "spambwl")

    def convert_config(self):

        try:
            self.convert_config_ativirus_profile()
            self.convert_config_antivirus_quarantine()
            self.convert_config_antivirus_service()
            self.convert_config_application_list()
            self.convert_config_client_reputation_profile()
            self.convert_config_dlp_sensor()
            self.convert_config_firewall_deepinspectionoptions()
            self.convert_config_firewall_policy()
            self.convert_config_firewall_profilegroup()
            self.convert_config_firewall_profileprotocoloptions()
            self.convert_config_firewall_sslsshprofile()
            self.convert_config_firewall_sniffinterfacepolicy()
            self.convert_config_imp2p()
            self.convert_config_ips_sensor()
            self.convert_config_log_disk_setting()
            self.convert_config_log_eventfilter()
            self.convert_config_log_memoryfilter()
            self.convert_config_log_syslogd_filter()
            self.convert_config_log_setting()
            self.convert_config_log_threat_weight()
            self.convert_config_router_gwdetect()
            self.convert_config_system_bugreport()
            self.convert_config_system_centralmanagement()
            self.convert_config_system_global()
            self.convert_config_system_interface()
            self.convert_config_system_replacemsg()
            self.convert_config_system_serverprobe()
            self.convert_config_system_settings()
            self.convert_config_system_storage()
            self.convert_config_vpn_ipsec_phase1()
            self.convert_config_vpn_ssl_settings()
            self.convert_config_vpn_ssl_web_portal()
            self.convert_config_vpn_ssl_web_user()
            self.convert_config_Wanopt_storage()
            self.convert_config_webfilter_profile()
            self.convert_config_webfilter_urlfilter()
            self.convert_config_webproxy_global()
            self.convert_config_wireless_controller()
            self.convert_config_spamfilter_profile()

        except Exception as e:
            print("Convert5.0_5.2 Error")
            raise e

    def convert_config_50_to_52(self):

        key = "config"
        list_global = ["config", "global"]
        list_vdom = ["config", "vdom"]

        node_global = self.config_root.find_tree_node(key, list_global)
        list_node_vdom = self.config_root.strict_match_tree_node(
            key, list_vdom)

        if node_global.node_type.value > 0 and len(list_node_vdom) > 0:
            # Enable VDOM mode
            self.curr_vdom_root = node_global.child_branch
            self.convert_config()

            for node_vdom in list_node_vdom:
                for node_edit in node_vdom.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node_edit.get_last_leaf_index() > 0:
                        self.curr_vdom_root = node_edit.child_branch
                        self.convert_config()

        elif len(list_node_vdom) == 0 and node_global.node_type.value == 0:
            # Disable VDOM mode
            self.curr_vdom_root = self.config_root
            self.convert_config()
