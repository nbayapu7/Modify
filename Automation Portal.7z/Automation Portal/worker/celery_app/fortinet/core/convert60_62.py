from celery_app.fortinet.model import utils
from celery_app.fortinet.model.config_tree import FGTNodeType


class Convert60_62:
    def __init__(self, fgt):
        self.config_root = fgt.config_root
        self.output_fgt = fgt
        self.curr_vdom = ""
        self.curr_vdom_root = None

        self.moved_vdom_config = {}

    # Default wildcard-fqdn and fqdn in FortiOS
    list_dafault_wildcard_fqdn60 = ("apple", "dropbox.com", "Gotomeeting", "icloud", "itunes", "android", "skype",
                                    "appstore", "eease", "google-drive", "google-play2", "google-play3", "microsoft",
                                    "adobe", "Adobe Login", "fortinet", "googleapis.com", "citrix", "verisign",
                                    "Windows update 2", "live.com", "firefox update server", "auth.gfx.ms",
                                    "softwareupdate.vmware.com",
                                    # default fqdn type
                                    "autoupdate.opera.com", "google-play", "swscan.apple.com", "update.microsoft.com",
                                    )

    def convert_config_system_global(self):
        config = "config"
        list_value = ("config", "system", "global")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ("set", "vdom-admin")
        node_vdom_admin = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_vdom_admin.node_type.value > 0:
            if node_vdom_admin.list_value[2] == "enable":
                node_config.create_leaf_node(key, ["set", "vdom-mode", "multi-vdom"],
                                             node_vdom_admin.get_location_index() + 1)
            elif node_vdom_admin.list_value[2] == "disable":
                node_config.create_leaf_node(key, ["set", "vdom-mode", "no-vdom"],
                                             node_vdom_admin.get_location_index() + 1)
            node_vdom_admin.remove_tree_node()

    def convert_config_wireless_controller_vap(self):
        config = "config"
        list_value = ["config", "wireless-controller", "vap"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_vdom = ["set", "vdom"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            if node_edit.child_branch.check_leaf_in_node(set, list_vdom):
                vdom = node_edit.child_branch.find_and_get_field_name(
                    set, list_vdom)
                node_edit.child_branch.loose_find_and_remove_node(
                    set, list_vdom)

                if vdom not in self.moved_vdom_config:
                    self.moved_vdom_config[vdom] = {
                        ("config", "wireless-controller", "vap"): []}
                self.moved_vdom_config[vdom][(
                    "config", "wireless-controller", "vap")].append(node_edit)

        node_config.remove_tree_node()

    def convert_config_system_interface(self):
        config = "config"
        list_value = ("config", "system", "interface")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_device_list = ("set", "device-access-list")
        list_device_identification_active_scan = (
            "set", "device-identification-active-scan")
        list_scan_botnet_connections = ("set", "scan-botnet-connections")
        list_allowaccess = ("set", "allowaccess")
        list_fortiheartbeat = ("set", "fortiheartbeat")
        list_vdom = ("set", "vdom")
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # For some lower-end model, they do not support VDOMs.
            node_vdom = node_edit.child_branch.loose_find_tree_node(
                key, list_vdom)
            if node_vdom.node_type.value == 0:
                node_edit.create_leaf_node(
                    key, ["set", "vdom", self.curr_vdom], 0)

            node_edit.child_branch.loose_find_and_remove_node(
                key, list_device_list)
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_device_identification_active_scan)
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_scan_botnet_connections)

            # Remove from 6.2.3
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_fortiheartbeat)

            node_allowaccess = node_edit.child_branch.find_tree_node(
                key, list_allowaccess)
            if "capwap" in node_allowaccess.list_value:
                node_allowaccess.list_value.remove("capwap")

    def convert_config_user_device(self):
        config = "config"
        list_value = ("config", "user", "device")
        node_config_user_device = self.curr_vdom_root.find_tree_node(
            config, list_value)
        if node_config_user_device.node_type.value == 0:
            return

        list_value = ("config", "firewall", "address")
        node_address_config = self.curr_vdom_root.find_tree_node(
            config, list_value)

        list_value = ("config", "firewall", "policy")
        node_policy_config = self.curr_vdom_root.find_tree_node(
            config, list_value)

        def convert_device_to_mac_address(device_node):
            # translate node under "config user device" to "config firewall address" category with type "mac"
            key = "set"
            list_set_mac = ("set", "mac")
            mac_leaf = device_node.child_branch.loose_find_tree_node(
                key, list_set_mac)
            if len(mac_leaf.list_value) > 2:
                node_mac_address = node_address_config.create_blank_edit_node(device_node.list_value[1],
                                                                              node_address_config.get_last_leaf_index())
                node_mac_address.create_leaf_node(
                    key, ["set", "end-mac", mac_leaf.list_value[-1]], 0)
                node_mac_address.create_leaf_node(
                    key, ["set", "start-mac", mac_leaf.list_value[-1]], 0)
                node_mac_address.create_leaf_node(
                    key, ["set", "type", "mac"], 0)

        def convert_policy_device_to_source_address():
            # lookup policies, find the "set device" setting and put to the source address.
            key = "set"
            list_set_device = ("set", "devices")
            for node_edit in node_policy_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_set_device = node_edit.child_branch.loose_find_tree_node(
                    key, list_set_device)
                if len(node_set_device.list_value) > 2:
                    list_set_srcaddr = ("set", "srcaddr")
                    node_set_srcaddr = node_set_device.parent_branch.loose_find_tree_node(
                        key, list_set_srcaddr)
                    # Paste devices to the last of srcaddr
                    node_set_srcaddr.list_value += node_set_device.list_value[2:]

                    # Remove set devices
                    node_set_device.remove_tree_node()

        for node_edit in node_config_user_device.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            convert_device_to_mac_address(node_edit)

        node_config_user_device.remove_tree_node()

        convert_policy_device_to_source_address()

    def convert_config_user_device_category(self):
        config = "config"
        list_value = ["config", "user", "device-category"]
        node_cofig = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_cofig.node_type.value == 0:
            return

        node_cofig.remove_tree_node()

    def convert_config_user_device_group(self):
        config = "config"
        list_value = ["config", "user", "device-group"]
        node_cofig = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_cofig.node_type.value == 0:
            return

        node_cofig.remove_tree_node()

    def convert_config_user_device_access_list(self):
        config = "config"
        list_value = ["config", "user", "device-access-list"]
        node_cofig = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_cofig.node_type.value == 0:
            return

        node_cofig.remove_tree_node()

    def convert_config_user_security_exempt_list(self):
        config = "config"
        list_value = ("config", "user", "security-exempt-list")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            rule_node = node_edit.child_branch.find_tree_node(
                config, ("config", "rule"))
            if rule_node.node_type.value == 0:
                continue

            key = "set"
            list_value = ("set", "devices")
            for sub_rule_node in rule_node.child_branch.list_child:
                if sub_rule_node.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                device_node = sub_rule_node.child_branch.loose_find_tree_node(
                    key, list_value)
                if device_node.node_type.value == 0:
                    continue

                device = device_node.list_value[-1]
                device_node.remove_tree_node()

                sub_rule_node.create_leaf_node(
                    key, ["set", "srcaddr", device], sub_rule_node.get_last_leaf_index())
                sub_rule_node.create_leaf_node(
                    key, ["set", "dstaddr", device], sub_rule_node.get_last_leaf_index())

    def convert_config_spamfilter_bwl(self):
        config = "config"
        list_value = ["config", "spamfilter", "bwl"]
        list_emailfilter = ["config", "emailfilter", "bwl"]
        self.curr_vdom_root.find_and_rename_command(
            config, list_value, list_emailfilter)

    def convert_config_spamfilter_profile(self):
        config = "config"
        list_value = ["config", "spamfilter", "profile"]
        list_emailfilter = ["config", "emailfilter", "profile"]
        self.curr_vdom_root.find_and_rename_command(
            config, list_value, list_emailfilter)

    def convert_config_dlp_fpsensitivity(self):
        config = "config"
        list_value = ["config", "dlp", "fp-sensitivity"]
        list_dlp_sensitivity = ["config", "dlp", "sensitivity"]
        self.curr_vdom_root.find_and_rename_command(
            config, list_value, list_dlp_sensitivity)

    def convert_config_endpoint_control_profile(self):
        config = "config"
        list_value = ["config", "endpoint-control", "profile"]
        node_cofig = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_cofig.node_type.value == 0:
            return

        node_cofig.remove_tree_node()

    def convert_config_firewall_policy(self):
        key = "config"
        list_value = ["config", "firewall", "policy"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_spamfilter_profile = ["set", "spamfilter-profile"]
        list_utm_inspection_mode = ["set", "utm-inspection-mode"]
        list_device = ["set", "device"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.find_and_rename_field(
                key, list_spamfilter_profile, "emailfilter-profile")
            node_edit.child_branch.find_and_rename_field(
                key, list_utm_inspection_mode, "inspection-mode")

            node_edit.child_branch.loose_find_and_remove_node(key, list_device)

    def convert_config_system_virtualwanlink(self):
        config = "config"
        list_value = ["config", "system", "virtual-wan-link"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_service = ["config", "service"]
        node_services = node_config.child_branch.find_tree_node(
            config, list_service)
        if node_services.node_type.value == 0:
            return

        key = "set"
        list_internet_service_ctrl_value = ["set", "internet-service-ctrl"]
        list_internet_service_ctrl_group_value = [
            "set", "internet-service-ctrl-group"]

        for node_edit in node_services.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.find_and_rename_field(key, list_internet_service_ctrl_value,
                                                         "internet-service-app-ctrl")

            node_edit.child_branch.find_and_rename_field(key, list_internet_service_ctrl_group_value,
                                                         "internet-service-app-ctrl-group")

    def move_address_to_wildcard(self, node_config_address, address_name):

        edit = "edit"
        list_value = ["edit", address_name]

        key = "set"
        list_type = ["set", "type"]
        list_uuid = ["set", "uuid"]
        list_wildcard_fqdn = ("set", "wildcard-fqdn")

        node_edit = node_config_address.child_branch.find_tree_node(
            edit, list_value)
        if node_edit.node_type.value == 0:
            return

        # For fqdn type conversion, *. is needed in the wildcard-fqdn prefix
        node_type = node_edit.child_branch.loose_find_tree_node(key, list_type)
        if node_type.list_value[2] == "fqdn":
            node_wildcard = node_edit.child_branch.loose_find_tree_node(
                key, list_wildcard_fqdn)
            if "*" not in node_wildcard.list_value[2]:
                node_wildcard.rename_option(
                    "*." + utils.remove_quota(node_wildcard.list_value[2]))

        node_edit.child_branch.loose_find_and_remove_node(key, list_type)
        node_edit.child_branch.loose_find_and_remove_node(key, list_uuid)

        config = "config"
        list_custom = ["config", "firewall", "wildcard-fqdn", "custom"]
        node_custom = self.curr_vdom_root.find_or_create_config_node(config, list_custom,
                                                                     node_config_address.get_location_index() + 1)
        node_custom.move_tree_node(
            node_edit, node_custom.get_last_leaf_index())

    def convert_config_firewall_address(self):

        config = "config"
        list_value = ["config", "firewall", "address"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_remove_node = []
        list_wildcard = ("set", "wildcard-fqdn")
        list_type = ("set", "type")
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            if utils.remove_quota(node_edit.list_value[1]) in self.list_dafault_wildcard_fqdn60:
                list_remove_node.append(node_edit)
                continue

            # In 6.2.2 and above, users can custom wildcard FQDN address and put in firewall policies
            '''
            config firewall address
                edit "test-wildcardfqdn-1"
                    set uuid 7288ba26-ce92-51e9-04c0-39c707eb4519
                    set type fqdn
                    set fqdn "*.fortinet.com"
                next
            end
            '''
            node_wildcard = node_edit.child_branch.loose_find_tree_node(
                key, list_wildcard)
            if node_wildcard.node_type.value == 0:
                continue

            node_type = node_edit.child_branch.loose_find_tree_node(
                key, list_type)
            if node_type.node_type.value == 0:
                continue

            node_wildcard.rename_field("fqdn")
            node_type.rename_option("fqdn")

        # Remove default node which match item in list_dafault_wildcard_fqdn60
        for node in list_remove_node:
            node.remove_tree_node()

    def convert_config_firewall_ssl_ssh_profile(self):

        def insert_policy_check_settings(profile, node):
            config = "config"
            list_value = ["config", "firewall", "policy"]
            node_config = self.curr_vdom_root.find_tree_node(
                config, list_value)
            if node_config.node_type.value == 0:
                return

            key = "set"
            list_ssl_ssh_profile = ["set", "ssl-ssh-profile", profile]
            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_ssl_ssh_profile = node_edit.child_branch.find_tree_node(
                    key, list_ssl_ssh_profile)
                if node_ssl_ssh_profile.node_type.value > 0:
                    list_ssh_policy_redirect_value = [
                        "set", "ssh-policy-redirect", node.list_value[2]]
                    node_edit.create_leaf_node(key, list_ssh_policy_redirect_value,
                                               node_ssl_ssh_profile.get_location_index() + 1)

        config = "config"
        list_value = ["config", "firewall", "ssl-ssh-profile"]

        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_ssh = ["config", "ssh"]
        list_ssh_policy_check = ["set", "ssh-policy-check"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_ssh = node_edit.child_branch.find_tree_node(config, list_ssh)
            if node_ssh.node_type.value > 0:
                node_policy_check = node_ssh.child_branch.loose_find_tree_node(
                    key, list_ssh_policy_check)
                if node_policy_check.node_type.value > 0:
                    profile_name = node_edit.list_value[1]
                    insert_policy_check_settings(
                        profile_name, node_policy_check)

                    node_policy_check.remove_tree_node()

    def convert_config_firewall_profile_protocol_option(self):
        def insert_http_policy_settings(profile, node):
            config = "config"
            list_value = ["config", "firewall", "policy"]
            node_config = self.curr_vdom_root.find_tree_node(
                config, list_value)
            if node_config.node_type.value == 0:
                return

            key = "set"
            list_profile_protocol_option = [
                "set", "profile-protocol-options", profile]
            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_profile_protocol_option = node_edit.child_branch.find_tree_node(
                    key, list_profile_protocol_option)
                if node_profile_protocol_option.node_type.value > 0:
                    list_ssh_policy_redirect_value = [
                        "set", "http-policy-redirect", node.list_value[2]]
                    node_edit.create_leaf_node(key, list_ssh_policy_redirect_value,
                                               node_profile_protocol_option.get_location_index() + 1)

        config = "config"
        list_value = ["config", "firewall", "profile-protocol-option"]

        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_http = ["config", "http"]
        list_http_policy_check = ["set", "http-policy"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_http = node_edit.child_branch.find_tree_node(
                config, list_http)
            if node_http.node_type.value > 0:
                node_policy_check = node_http.child_branch.loose_find_tree_node(
                    key, list_http_policy_check)
                if node_policy_check.node_type.value > 0:
                    profile_name = node_edit.list_value[1]
                    insert_http_policy_settings(
                        profile_name, node_policy_check)

                    node_policy_check.remove_tree_node()

    def convert_config_log_threatweight(self):
        config = "config"
        list_value = ["config", "log", "threat-weight"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_malware = ["config", "malware"]
        node_malware = node_config.child_branch.loose_find_tree_node(
            config, list_malware)
        if node_malware.node_type.value > 0:
            key = "set"
            list_botnet_connection = ["set", "botnet-connection"]
            options = node_malware.child_branch.loose_find_tree_node(
                key, list_botnet_connection)
            if options.node_type.value > 0:
                options.list_value[1] = "botnet-connection-detected"
                node_config.create_leaf_node(
                    key, options.list_value, node_config.get_last_leaf_index())
                options.remove_tree_node()

    def convert_config_wireless_controller_wtp_profile(self):
        config = "config"
        list_value = ["config", "wireless-controller", "wtp-profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            list_allowaccess_http = ["set", "allowaccess", "http"]
            list_allowaccess_telnet = ["set", "allowaccess", "telnet"]
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_allowaccess_http)
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_allowaccess_telnet)

    def convert_config_wireless_controller_wtp(self):
        config = "config"
        list_value = ["config", "wireless-controller", "wtp"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            list_allowaccess_http = ["set", "allowaccess", "http"]
            list_allowaccess_telnet = ["set", "allowaccess", "telnet"]
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_allowaccess_http)
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_allowaccess_telnet)

    def convert_config_wireless_controller_timers(self):
        config = "config"
        list_value = ["config", "wireless-controller", "timers"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            list_darrp_day = ["set", "darrp-day"]
            list_darrp_time = ["set", "darrp-time"]
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_darrp_day)
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_darrp_time)

    def convert_config_wireless_controller_wids_profile(self):
        config = "config"
        list_value = ["config", "wireless-controller", "wids-profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            list_ap_bgscan_disable_day = ["set", "ap-bgscan-disable-day"]
            list_ap_bgscan_disable_start = ["set", "ap-bgscan-disable-start"]
            list_ap_bgscan_disable_end = ["set", "ap-bgscan-disable-end"]
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_ap_bgscan_disable_day)
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_ap_bgscan_disable_start)
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_ap_bgscan_disable_end)

    def convert_config_webfilter_profile(self):
        config = "config"
        list_value = ("config", "webfilter", "profile")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            list_inspection_mode = ("set", "inspection-mode")
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_inspection_mode)

    def convert_config_antivirus_profile(self):
        config = "config"
        list_value = ("config", "antivirus", "profile")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            list_inspection_mode = ("set", "inspection-mode")
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_inspection_mode)

    def insert_moved_vdom_node(self):
        if self.curr_vdom not in self.moved_vdom_config:
            return

        config_node = self.moved_vdom_config[self.curr_vdom]
        for config in config_node.keys():
            list_config = list(config)
            node = self.curr_vdom_root.find_or_create_config_node(
                "config", list_config, 0)
            for edit_node in config_node[config]:
                node.move_tree_node(edit_node, node.get_location_index())

    def convert_config(self):
        try:
            self.convert_config_system_global()
            self.convert_config_system_interface()
            self.convert_config_system_virtualwanlink()
            self.convert_config_user_device()
            self.convert_config_user_device_category()
            self.convert_config_user_device_group()
            self.convert_config_user_device_access_list()
            self.convert_config_user_security_exempt_list()
            self.convert_config_spamfilter_bwl()
            self.convert_config_spamfilter_profile()
            self.convert_config_dlp_fpsensitivity()
            self.convert_config_endpoint_control_profile()
            self.convert_config_firewall_policy()
            self.convert_config_firewall_ssl_ssh_profile()
            self.convert_config_firewall_profile_protocol_option()
            self.convert_config_log_threatweight()
            self.convert_config_wireless_controller_vap()
            self.convert_config_wireless_controller_wtp_profile()
            self.convert_config_wireless_controller_wtp()
            self.convert_config_webfilter_profile()
            self.convert_config_antivirus_profile()

            ''' 6.2.1 CLI changes '''
            self.convert_config_wireless_controller_timers()
            self.convert_config_wireless_controller_wids_profile()

            ''' 6.2.2 CLI changes '''
            self.convert_config_firewall_address()

            ''' 6.2.3 CLI changes '''

            self.insert_moved_vdom_node()

        except Exception as ex:
            print("Convert6.0_6.2 Error")
            raise ex

    def convert_config_60_to_62(self):
        key = "config"
        list_global = ["config", "global"]
        list_vdom = ["config", "vdom"]

        node_global = self.config_root.find_tree_node(key, list_global)
        list_node_vdom = self.config_root.strict_match_tree_node(
            key, list_vdom)

        if node_global.node_type.value > 0 and len(list_node_vdom) > 0:
            # Enable VDOM mode
            self.curr_vdom_root = node_global.child_branch
            self.convert_config()

            for node_vdom in list_node_vdom:
                for node_edit in node_vdom.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node_edit.get_last_leaf_index() > 0:
                        self.curr_vdom = node_edit.list_value[1]
                        self.curr_vdom_root = node_edit.child_branch
                        self.convert_config()

        elif len(list_node_vdom) == 0 and node_global.node_type.value == 0:
            # Disable VDOM mode
            self.curr_vdom = "root"
            self.curr_vdom_root = self.config_root
            self.convert_config()
