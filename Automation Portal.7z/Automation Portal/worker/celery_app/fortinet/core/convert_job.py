import re

from celery_app.fortinet.model.fortigate import ConfigTrimmer

from .convert43_50 import Convert43_50
from .convert50_52 import Convert50_52
from .convert52_54 import Convert52_54
from .convert54_56 import Convert54_56
from .convert56_60 import Convert56_60
from .convert60_62 import Convert60_62
from .convert62_64 import Convert62_64
from .convert64_70 import Convert64_70


class ConvertJob:
    def __init__(self, source_dev, target_dev) -> None:
        self.list_vdom = []
        self.source_dev = source_dev
        self.target_dev = target_dev
        self.vdom_enable = self.source_dev.is_vdom_enabled()

        self.input_model = ""
        self.input_version = "0.0"
        self.input_major = 0
        self.input_minor = 0
        self.input_patch = 0
        self.input_build = ""

        self.output_model = ""
        self.output_version = "0.0"
        self.output_major = 0
        self.output_minor = 0
        self.output_patch = 0
        self.output_build = ""

    @property
    def input_verion_int(self):
        return self.input_major * 10 + self.input_minor

    @property
    def output_version_int(self):
        return self.output_major * 10 + self.output_minor

    @property
    def do43_to_50_conversion(self):
        return self.input_verion_int < 50 and self.output_version_int >= 50

    @property
    def do50_to_52_conversion(self):
        return self.input_verion_int < 52 and self.output_version_int >= 52

    @property
    def do52_to_54_conversion(self):
        return self.input_verion_int < 54 and self.output_version_int >= 54

    @property
    def do54_to_56_conversion(self):
        return self.input_verion_int < 56 and self.output_version_int >= 56

    @property
    def do56_to_60_conversion(self):
        return self.input_verion_int < 60 and self.output_version_int >= 60

    @property
    def do60_to_62_conversion(self):
        return self.input_verion_int < 62 and self.output_version_int >= 62

    @property
    def do62_to_64_conversion(self):
        return self.input_verion_int < 64 and self.output_version_int >= 64

    @property
    def do64_to_70_conversion(self):
        return self.input_verion_int < 70 and self.output_version_int >= 70

    def resolve_device_name(self, name_in_config):

        try:
            name_split = name_in_config.split("-")

            if name_split[1].find("H1") >= 0:
                name_split[1] = name_split[1].replace("H1", "01")
            elif name_split[1].find("H") >= 0:
                name_split[1] = name_split[1].replace("H", "00")

            if name_split[1].find("P") >= 0:
                name_split[1] = name_split[1].replace("P", "-POE")
            elif name_split[1].find("EP") >= 0:
                name_split[1] = name_split[1].replace("EP", "-POE")
            elif name_split[1].find("DP") >= 0:
                name_split[1] = name_split[1].replace("DP", "-POE")

            index_k = name_split[1].find("K")
            if index_k >= 0:
                pattern = "(\d)K(\d*)([A-Z])"
                result = re.match(pattern, name_split[1])
                if result:
                    if len(result.group(2)) > 2:
                        name_split[1] = result.group(
                            1) + result.group(2) + result.group(3)
                    elif len(result.group(2)) == 2:
                        name_split[1] = result.group(1) + result.group(2)[0] + "0" + result.group(2)[1] + result.group(
                            3)
                    elif len(result.group(2)) == 1:
                        name_split[1] = result.group(
                            1) + result.group(2) + "00" + result.group(3)
                    else:
                        name_split[1] = result.group(
                            1) + "000" + result.group(3)
                else:
                    name_split[1] = name_split[1].replace("K", "000")

            if name_split[0] in ("FG", "FGT", "F"):
                return "FortiGate " + name_split[1]
            elif name_split[0] == "FOS":
                return "FortiOS " + name_split[1]
            else:
                return "FortiWiFi " + name_split[1]
        except Exception:
            return "Unknown"

    def get_input_and_output_model_version(self):

        self.input_version = self.source_dev.extract_version_info()
        self.output_version = self.target_dev.extract_version_info()

        self.input_model = self.resolve_device_name(self.source_dev.model)
        self.output_model = self.resolve_device_name(self.target_dev.model)

        input_version = self.input_version.split('.')
        if len(input_version) >= 2:
            self.input_major = int(input_version[0])
            self.input_minor = int(input_version[1])
            self.input_patch = int(input_version[2]) if len(
                input_version) == 3 else 0

        output_version = self.output_version.split('.')
        if len(output_version) >= 2:
            self.output_major = int(output_version[0])
            self.output_minor = int(output_version[1])
            self.output_patch = int(output_version[2]) if len(
                output_version) == 3 else 0

        self.input_build = int(self.source_dev.build)
        self.output_build = int(self.target_dev.build)

        return self.input_version, self.output_version

    def do_version_upgrade_path(self):
        self.get_input_and_output_model_version()

        if self.do43_to_50_conversion:
            print("Convert 43 to 50")
            task43_50 = Convert43_50(self.source_dev)
            task43_50.convert_config_43_to_50()

        if self.do50_to_52_conversion:
            print("Convert 50 to 52")
            task_50_52 = Convert50_52(self.source_dev)
            task_50_52.convert_config_50_to_52()

        if self.do52_to_54_conversion:
            print("Convert 52 to 54")
            task52_54 = Convert52_54(self.source_dev)
            task52_54.convert_config_52_to_54()

        if self.do54_to_56_conversion:
            print("Convert 54 to 56")
            task54_56 = Convert54_56(self.source_dev)
            task54_56.convert_config_54_to_56()

        if self.do56_to_60_conversion:
            print("Convert 56 to 60")
            task56_60 = Convert56_60(self.source_dev)
            task56_60.convert_config_56_to_60()

        if self.do60_to_62_conversion:
            print("Convert 60 to 62")
            task60_62 = Convert60_62(self.source_dev)
            task60_62.convert_config_60_to_62()

        if self.do62_to_64_conversion:
            print("Convert 62 to 64")
            task60_62 = Convert62_64(self.source_dev)
            task60_62.convert_config_62_to_64()

        if self.do64_to_70_conversion:
            print("Convert 64 to 70")
            task60_62 = Convert64_70(self.source_dev)
            task60_62.convert_config_64_to_70()

    def adapt_config_from_import(self):
        self.source_dev = ConfigTrimmer.trim_source(
            self.source_dev, self.target_dev)
        # self.target_dev = ConfigTrimmer.trim_target(self.source_dev, self.target_dev)

    def do_conversion(self):
        self.list_vdom = self.source_dev.collect_vdom_list()

        self.do_version_upgrade_path()

        self.adapt_config_from_import()

        return self.source_dev
