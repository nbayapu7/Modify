from celery_app.fortinet.model.config_tree import FGTNodeType


class Convert64_70:
    def __init__(self, fgt):
        self.config_root = fgt.config_root
        self.output_fgt = fgt
        self.curr_vdom = ""
        self.curr_vdom_root = None

    def convert_config_system_dns(self):
        config = "config"
        list_value = ("config", "system", "dns")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ("set", "dns-over-tls")
        node_dts = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_dts.node_type.value != 0:
            if node_dts.list_value[-1] == "disable":
                node_config.create_leaf_node(
                    key, ["set", "protocol", "cleartext"], -1)
            elif node_dts.list_value[-1] in ("enable", "enforce"):
                node_config.create_leaf_node(
                    key, ["set", "protocol", "DoT"], -1)

            node_dts.remove_tree_node()

    def convert_config_ips_global(self):
        config = "config"
        list_value = ("config", "ips", "global")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ("set", "intelligent-mode")
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config(self):
        self.convert_config_system_dns()
        self.convert_config_ips_global()

    def convert_config_64_to_70(self):
        key = "config"
        list_global = ["config", "global"]
        list_vdom = ["config", "vdom"]

        node_global = self.config_root.find_tree_node(key, list_global)
        list_node_vdom = self.config_root.strict_match_tree_node(
            key, list_vdom)

        if node_global.node_type.value > 0 and len(list_node_vdom) > 0:
            # Enable VDOM mode
            self.curr_vdom_root = node_global.child_branch
            self.convert_config()

            for node_vdom in list_node_vdom:
                for node_edit in node_vdom.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node_edit.get_last_leaf_index() > 0:
                        self.curr_vdom = node_edit.list_value[1]
                        self.curr_vdom_root = node_edit.child_branch
                        self.convert_config()

        elif len(list_node_vdom) == 0 and node_global.node_type.value == 0:
            # Disable VDOM mode
            self.curr_vdom = "root"
            self.curr_vdom_root = self.config_root
            self.convert_config()
