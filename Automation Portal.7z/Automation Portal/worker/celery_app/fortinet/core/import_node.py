from enum import Enum

from celery_app.fortinet.model.utils import remove_quota


class ImportStatus(Enum):
    IMPORT_STATUS_PREVIEW = "Not installed"
    IMPORT_STATUS_IMPORTING = "IMPORTING"
    IMPORT_STATUS_SUCCESS = "SUCCESS"
    IMPORT_STATUS_WARNING = "WARNING"
    IMPORT_STATUS_ERROR = "ERROR"
    IMPORT_STATUS_IGNORE = "IGNORED"


class ImportFGTNode:
    def __init__(self, vdom, cmdb, node_name, type, status, FGTNode, path, name, parent_node=None, reviewed=False):
        self.vdom = vdom
        self.cmdb = cmdb
        self.node_name = remove_quota(node_name)
        self.node_type = type
        self.import_status = status

        self.FGTNode = FGTNode  # Import FGTNode Object
        self.path = path  # RESTAPI Path
        self.name = name  # RESTAPI Name

        self.nodes = []
        self.reason = []
        self.parent_node = parent_node

    @property
    def is_edit_node(self):
        return True if self.node_type == 'edit_node' else False

    @property
    def is_config_node(self):
        return True if self.node_type == 'config_node' else False

    @property
    def import_twice(self):
        # TOFIX, workaround for now, see ticket 0570079 and 0570083
        return self.cmdb in ("config webfilter profile", "config firewall profile-protocol-options")

    @property
    def category(self):
        return self.cmdb + "\n"

    @property
    def cli(self):
        return self.FGTNode.generate_cli_from_FGTNode()

    @property
    def end(self):
        return "end"
