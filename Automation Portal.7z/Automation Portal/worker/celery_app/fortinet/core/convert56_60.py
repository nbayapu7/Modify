from celery_app.fortinet.model import utils
from celery_app.fortinet.model.config_tree import FGTNodeType


class Convert56_60:

    def __init__(self, fgt):

        self.config_root = fgt.config_root
        self.output_fgt = fgt
        self.curr_vdom = ""
        self.curr_vdom_root = None

    # static variables
    # Default wildcard-fqdn and fqdn in FortiOS
    list_dafault_wildcard_fqdn60 = ("apple", "dropbox.com", "Gotomeeting", "icloud", "itunes", "android", "skype",
                                    "appstore", "eease", "google-drive", "google-play2", "google-play3", "microsoft",
                                    "adobe", "Adobe Login", "fortinet", "googleapis.com", "citrix", "verisign",
                                    "Windows update 2", "live.com", "firefox update server", "auth.gfx.ms",
                                    "softwareupdate.vmware.com",
                                    # default fqdn type
                                    "autoupdate.opera.com", "google-play", "swscan.apple.com", "update.microsoft.com",
                                    )

    def convert_config_system_global(self):

        config = "config"
        list_value = ["config", "system", "global"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_ldapconntimeout = ["set", "ldapconntimeout"]
        node_ldapconntimeout = node_config.child_branch.loose_find_tree_node(
            set, list_ldapconntimeout)
        if node_ldapconntimeout.node_type.value > 0:
            try:
                timeout = int(node_ldapconntimeout.list_value[2])
                if timeout > 300000:
                    node_ldapconntimeout.rename_option("300000")
            except:
                return

        list_fortigard = ["set", "fortiguard-audit-result-submission"]
        node_config.child_branch.find_and_rename_field(
            set, list_fortigard, "security-rating-result-submission")

        list_count = ["set", "virtual-server-count"]
        list_acceleration = ["set", "virtual-server-hardware-acceleration"]
        node_config.child_branch.loose_find_and_remove_node(set, list_count)
        node_config.child_branch.loose_find_and_remove_node(
            set, list_acceleration)

    def convert_config_system_interface(self):
        config = "config"
        list_value = ["config", "system", "interface"]
        node_config = self.curr_vdom_root.loose_find_tree_node(
            config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_vdom = ["set", "vdom"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # For some lower-end model, they do not support VDOMs.
            node_vdom = node_edit.child_branch.loose_find_tree_node(
                key, list_vdom)
            if node_vdom.node_type.value == 0:
                node_edit.create_leaf_node(
                    key, ["set", "vdom", self.curr_vdom], 0)

    def convert_config_system_accprofile(self):

        config = "config"
        list_value = ["config", "system", "accprofile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_mntgrp = ["set", "mntgrp"]
        list_admingrp = ["set", "admingrp"]
        list_updategrp = ["set", "updategrp"]
        list_routegrp = ["set", "routegrp"]
        list_endpointcontrolgrp = ["set", "endpoint-control-grp"]

        list_netgrp = ["set", "netgrp"]
        list_netgrp_custom = ["set", "netgrp", "custom"]
        list_sysgrp = ["set", "sysgrp"]
        list_sysgrp_custom = ["set", "sysgrp", "custom"]
        list_utmgrp = ["set", "utmgrp"]
        list_utmgrp_custom = ["set", "utmgrp", "custom"]

        list_sysgrp_permission = ["config", "sysgrp-permission"]
        list_mnt = ["set", "mnt", ""]
        list_upd = ["set", "upd", ""]
        list_admin = ["set", "admin", ""]
        list_cfg = ["set", "cfg", ""]

        list_netgrp_permission = ["config", "netgrp-permission"]
        list_routecfg = ["set", "route-cfg", ""]

        list_utmgrp_permission = ["config", "utmgrp-permission"]
        list_endpointcontrol = ["set", "endpoint-control", ""]

        list_fwgrp = ["set", "fwgrp"]
        list_fwgrp_permission = ["config", "fwgrp-permission"]
        list_packetcapture = ["set", "packet-capture"]
        list_packetcapture_node = ["set", "packet-capture", ""]
        list_others = ["set", "others"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_mntgrp = node_edit.child_branch.loose_find_tree_node(
                set, list_mntgrp)
            node_admingrp = node_edit.child_branch.loose_find_tree_node(
                set, list_admingrp)
            node_updategrp = node_edit.child_branch.loose_find_tree_node(
                set, list_updategrp)
            node_routegrp = node_edit.child_branch.loose_find_tree_node(
                set, list_routegrp)
            node_endpointcontrolgrp = node_edit.child_branch.loose_find_tree_node(
                set, list_endpointcontrolgrp)

            node_netgrp = node_edit.child_branch.loose_find_tree_node(
                set, list_netgrp)
            node_sysgrp = node_edit.child_branch.loose_find_tree_node(
                set, list_sysgrp)
            node_utmgrp = node_edit.child_branch.loose_find_tree_node(
                set, list_utmgrp)

            perm_mnt = node_mntgrp.list_value[2] if node_mntgrp.node_type.value > 0 else "none"
            perm_admin = node_admingrp.list_value[2] if node_admingrp.node_type.value > 0 else "none"
            perm_update = node_updategrp.list_value[2] if node_updategrp.node_type.value > 0 else "none"
            perm_route = node_routegrp.list_value[2] if node_routegrp.node_type.value > 0 else "none"
            perm_endpointcontrol = node_endpointcontrolgrp.list_value[
                2] if node_endpointcontrolgrp.node_type.value > 0 else "none"

            perm_sys = node_sysgrp.list_value[2] if node_sysgrp.node_type.value > 0 else "none"
            perm_net = node_netgrp.list_value[2] if node_netgrp.node_type.value > 0 else "none"
            perm_utm = node_utmgrp.list_value[2] if node_utmgrp.node_type.value > 0 else "none"

            if not (perm_mnt == perm_admin == perm_update == perm_sys):
                if node_sysgrp.node_type.value == 0:
                    node_sysgrp = node_edit.create_leaf_node(
                        set, list_sysgrp_custom, 0)
                else:
                    node_sysgrp.rename_option("custom")
                node_config_sysgrp = node_edit.child_branch.find_or_create_config_node(config,
                                                                                       list_sysgrp_permission,
                                                                                       node_sysgrp.get_location_index() + 1)
                list_mnt[2] = perm_mnt
                list_upd[2] = perm_update
                list_admin[2] = perm_admin
                list_cfg[2] = perm_sys
                node_config_sysgrp.create_leaf_node(set, list_mnt, 0)
                node_config_sysgrp.create_leaf_node(set, list_upd, 0)
                node_config_sysgrp.create_leaf_node(set, list_admin, 0)
                node_config_sysgrp.create_leaf_node(set, list_cfg, 0)

            node_mntgrp.remove_tree_node()
            node_admingrp.remove_tree_node()
            node_updategrp.remove_tree_node()

            if perm_endpointcontrol != perm_utm:
                if node_utmgrp.node_type.value == 0:
                    node_utmgrp = node_edit.create_leaf_node(
                        set, list_utmgrp_custom, 0)
                else:
                    node_utmgrp.rename_option("custom")

                node_config_utmgrp = node_edit.child_branch.find_or_create_config_node(config,
                                                                                       list_utmgrp_permission,
                                                                                       node_utmgrp.get_location_index() + 1)
                list_endpointcontrol[2] = perm_endpointcontrol
                node_config_utmgrp.create_leaf_node(
                    set, list_endpointcontrol, 0)

            node_endpointcontrolgrp.remove_tree_node()

            perm_packetcapture = "none"
            node_config_fwgrp = node_edit.child_branch.find_tree_node(
                config, list_fwgrp_permission)
            if node_config_fwgrp.node_type.value > 0:
                node_packetcapture = node_config_fwgrp.child_branch.loose_find_tree_node(
                    set, list_packetcapture)
                if node_packetcapture.node_type.value > 0:
                    perm_packetcapture = node_packetcapture.list_value[2]
                    node_packetcapture.remove_tree_node()

                node_config_fwgrp.child_branch.loose_find_and_remove_node(
                    set, list_others)

            else:
                node_fwgrp = node_edit.child_branch.loose_find_tree_node(
                    set, list_fwgrp)
                perm_packetcapture = node_fwgrp.list_value[2] if node_fwgrp.node_type.value > 0 else "none"

            if not (perm_route == perm_packetcapture == perm_net):
                if node_netgrp.node_type.value == 0:
                    node_netgrp = node_edit.create_leaf_node(
                        set, list_netgrp_custom, 0)
                else:
                    node_netgrp.rename_option("custom")

                node_config_netgrp = node_edit.child_branch.find_or_create_config_node(config,
                                                                                       list_netgrp_permission,
                                                                                       node_netgrp.get_location_index() + 1)

                list_routecfg[2] = perm_route
                list_cfg[2] = perm_net
                list_packetcapture_node[2] = perm_packetcapture

                node_config_netgrp.create_leaf_node(set, list_routecfg, 0)
                node_config_netgrp.create_leaf_node(set, list_cfg, 0)
                node_config_netgrp.create_leaf_node(
                    set, list_packetcapture_node, 0)

            node_routegrp.remove_tree_node()

    def convert_config_system_objecttag(self):

        config = "config"
        list_value = ["config", "system", "object-tag"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_tags = ["set", "tags"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue
            list_tags.append(node_edit.list_value[1])

        list_value = ["config", "system", "object-tagging"]
        node_config_tagging = self.curr_vdom_root.create_blank_config_node(
            list_value, node_config.get_location_index())
        node_edit_tagging = node_config_tagging.child_branch.create_blank_edit_node(
            "default", 0)
        node_edit_tagging.create_leaf_node(set, list_tags, 0)

        node_config.remove_tree_node()

    def convert_config_system_virtualwanlink(self):

        config = "config"
        list_value = ["config", "system", "virtual-wan-link"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_timeout = ["set", "timeout"]
        list_health_check = ["config", "health-check"]

        node_health_check = node_config.child_branch.find_tree_node(
            config, list_health_check)
        if node_health_check.node_type.value == 0:
            return

        for node_edit in node_health_check.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_timeout)

    def convert_config_system_linkmonitor(self):

        config = "config"
        list_value = ["config", "system", "link-monitor"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_timeout = ["set", "timeout"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_timeout)

    def convert_config_system_csf(self):

        config = "config"
        list_value = ["config", "system", "csf"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_logging_mode = ["set", "logging-mode"]
        node_config.child_branch.find_and_rename_field(
            set, list_logging_mode, "configuration-sync")

    def convert_config_system_np6(self):

        config = "config"
        list_value = ["config", "system", "np6"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_fastpath = ["set", "fastpath"]
        node_config.child_branch.loose_find_and_remove_node(set, list_fastpath)

    def convert_config_webfilter_profile(self):

        config = "config"
        list_value = ["config", "webfilter", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_category_override = ("set", "category-override")
        list_options = ("set", "options")
        list_ftgd = ("config", "ftgd-wf")
        list_inspection_mode = ("set", "inspection-mode")

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_category_override)
            node_edit.child_branch.loose_find_and_remove_node(
                set, list_inspection_mode)

            node_ftgd = node_edit.child_branch.find_tree_node(
                config, list_ftgd)
            if node_ftgd.node_type.value > 0:
                node_options = node_ftgd.child_branch.loose_find_tree_node(
                    set, list_options)
                if node_options.node_type.value > 0:
                    if "http-err-detail" in node_options.list_value:
                        node_options.list_value.remove("http-err-detail")
                    if len(node_options.list_value) == 2:
                        node_options.list_value[0] = "unset"
                        node_options.key = "unset"

    def convert_wireless_controller_vap(self):
        config = "config"
        list_value = ("config", "wireless-controller", "vap")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_vdom = ("set", "vdom")
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_vdom = node_edit.child_branch.loose_find_tree_node(
                key, list_vdom)
            if node_vdom.node_type.value == 0:
                node_edit.create_leaf_node(
                    key, ["set", "vdom", self.curr_vdom], 0)

    def convert_config_firewall_address(self):

        config = "config"
        list_value = ["config", "firewall", "address"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_tags = ["set", "tags"]
        list_config_tagging = ["config", "tagging"]
        list_category_default = ["set", "category", "default"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_tags = node_edit.child_branch.loose_find_tree_node(
                set, list_tags)
            if node_tags.node_type.value == 0:
                continue

            node_config_tagging = node_edit.child_branch.create_blank_config_node(list_config_tagging,
                                                                                  node_tags.get_location_index())
            node_edit_tagging = node_config_tagging.child_branch.create_blank_edit_node(
                "1", 0)
            node_edit_tagging.create_leaf_node(set, list_category_default, 0)
            node_edit_tagging.move_tree_node(node_tags, 1)

        list_remove_node = []
        # list_move_to_wildcard_node = []
        # list_wildcard = ("set", "wildcard-fqdn")
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            if utils.remove_quota(node_edit.list_value[1]) in self.list_dafault_wildcard_fqdn60:
                list_remove_node.append(node_edit)
                continue

            '''
            # Move wildcard-fqdn address to wildcard-fqdn address custom category
            node_wildcard = node_edit.child_branch.loose_find_tree_node(set, list_wildcard)
            if node_wildcard.node_type.value == 0:
                continue
            list_move_to_wildcard_node.append(node_edit.list_value[1])
            '''

        # Remove default node
        for node in list_remove_node:
            node.remove_tree_node()

        '''
        # Move custom node
        for node_name in list_move_to_wildcard_node:
            self.move_address_to_wildcard(node_config, node_name)
        '''

    def convert_config_firewall_policy(self):

        def convert_config_firewall_policy_content(node_config):

            list_tags = ["set", "tags"]
            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_edit.child_branch.loose_find_and_remove_node(
                    set, list_tags)

        config = "config"
        set = "set"
        list_value = ["config", "firewall", "policy"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_policy_content(node_config)

        list_value = ["config", "firewall", "policy6"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_policy_content(node_config)

    def is_wildcard_address_name(self, node_config_address, address_name):

        config = "config"
        list_custom = ["config", "firewall", "wildcard-fqdn", "custom"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_custom)
        if node_config.node_type.value > 0:
            node_wildcard = node_config.child_branch.find_branch_node_edit(
                address_name)
            if node_wildcard.node_type.value > 0:
                return True

        node_edit = node_config_address.child_branch.find_branch_node_edit(
            address_name)
        if node_edit.node_type.value == 0:
            return False

        set = "set"
        list_type = ["set", "type"]
        node_type = node_edit.child_branch.loose_find_tree_node(set, list_type)
        return node_type.node_type.value > 0 and node_type.list_value[2] == "wildcard-fqdn"

    def move_address_to_wildcard(self, node_config_address, address_name):

        edit = "edit"
        list_value = ["edit", address_name]

        set = "set"
        list_type = ["set", "type"]
        list_uuid = ["set", "uuid"]
        list_wildcard_fqdn = ("set", "wildcard-fqdn")

        node_edit = node_config_address.child_branch.find_tree_node(
            edit, list_value)
        if node_edit.node_type.value == 0:
            return

        # For fqdn type conversion, *. is needed in the wildcard-fqdn prefix
        node_type = node_edit.child_branch.loose_find_tree_node(set, list_type)
        if node_type.list_value[2] == "fqdn":
            node_wildcard = node_edit.child_branch.loose_find_tree_node(
                set, list_wildcard_fqdn)
            if "*" not in node_wildcard.list_value[2]:
                node_wildcard.rename_option(
                    "*." + utils.remove_quota(node_wildcard.list_value[2]))

        node_edit.child_branch.loose_find_and_remove_node(set, list_type)
        node_edit.child_branch.loose_find_and_remove_node(set, list_uuid)

        config = "config"
        list_custom = ["config", "firewall", "wildcard-fqdn", "custom"]
        node_custom = self.curr_vdom_root.find_or_create_config_node(config, list_custom,
                                                                     node_config_address.get_location_index() + 1)
        node_custom.move_tree_node(
            node_edit, node_custom.get_last_leaf_index())

    def move_addrgrp_to_wildcard(self, node_config_addrgrp, address_name):

        edit = "edit"
        list_value = ["edit", address_name]

        set = "set"
        list_uuid = ["set", "uuid"]

        node_edit = node_config_addrgrp.child_branch.find_tree_node(
            edit, list_value)
        if node_edit.node_type.value == 0:
            return

        node_edit.child_branch.loose_find_and_remove_node(set, list_uuid)

        config = "config"
        list_group = ["config", "firewall", "wildcard-fqdn", "group"]
        node_group = self.curr_vdom_root.find_or_create_config_node(config, list_group,
                                                                    node_config_addrgrp.get_location_index() + 1)
        node_group.move_tree_node(node_edit, node_group.get_last_leaf_index())

    def is_pure_wildcard_address_group(self, node_config_address, node_config_addrgrp, address_name):

        config = "config"
        list_group = ["config", "firewall", "wildcard-fqdn", "group"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_group)
        if node_config.node_type.value > 0:
            node_wildcard = node_config.child_branch.find_branch_node_edit(
                address_name)
            if node_wildcard.node_type.value > 0:
                return True

        if node_config_addrgrp.node_type.value == 0:
            return False
        node_edit = node_config_addrgrp.child_branch.find_branch_node_edit(
            address_name)
        if node_edit.node_type.value == 0:
            return False

        list_member = ["set", "member"]
        list_address_memeber = node_edit.child_branch.get_list_word(
            list_member)

        for address_member in list_address_memeber:
            if self.is_wildcard_address_name(node_config_address, address_member):
                self.move_address_to_wildcard(
                    node_config_address, address_member)

            elif self.is_pure_wildcard_address_group(node_config_address, node_config_addrgrp, address_member):
                self.move_addrgrp_to_wildcard(
                    node_config_addrgrp, address_member)

            else:
                return False

        return True

    def is_part_wildcard_address_group(self, node_config_address, node_config_addrgrp, address_name,
                                       list_member_wildcard):

        if node_config_addrgrp.node_type.value == 0:
            return False

        edit = "edit"
        list_value = ["edit", address_name]
        node_edit = node_config_addrgrp.child_branch.find_tree_node(
            edit, list_value)
        if node_edit.node_type.value == 0:
            return False

        set = "set"
        list_member = ["set", "member"]
        node_memeber = node_edit.child_branch.loose_find_tree_node(
            set, list_member)

        has_wildcard = False
        has_normal = False
        list_member_address = node_memeber.list_value[2:]

        for address_member in list_member_address:
            if self.is_wildcard_address_name(node_config_address, address_member):
                self.move_address_to_wildcard(
                    node_config_address, address_member)
                node_memeber.list_value.remove(address_member)
                list_member_wildcard.append(address_member)
                has_wildcard = True

            elif self.is_pure_wildcard_address_group(node_config_address, node_config_addrgrp, address_member):
                self.move_addrgrp_to_wildcard(
                    node_config_addrgrp, address_member)
                node_memeber.list_value.remove(address_member)
                list_member_wildcard.append(address_member)
                has_wildcard = True

            else:
                has_normal = True

        return has_wildcard and has_normal

    def create_wildcard_addrgrp(self, wildcard_group_name, list_member_wildcard, insert_index):

        config = "config"
        list_group = ["config", "firewall", "wildcard-fqdn", "group"]
        node_group = self.curr_vdom_root.find_or_create_config_node(
            config, list_group, insert_index)

        node_edit = node_group.child_branch.find_branch_node_edit(
            wildcard_group_name)
        if node_edit.node_type.value > 0:
            return

        node_edit = node_group.child_branch.create_blank_edit_node(wildcard_group_name,
                                                                   node_group.get_last_leaf_index())

        set = "set"
        list_member = ["set", "member"]
        list_member.extend(list_member_wildcard)
        node_edit.create_leaf_node(set, list_member, 0)

    def check_wildcard_fqdn_address(self, node_sslexempt_edit, node_config_address, node_config_addrgrp, address_name):

        config = "config"
        list_custom = ["config", "firewall", "wildcard-fqdn", "custom"]

        set = "set"
        list_type = ["set", "type"]
        list_address = ["set", "address"]
        list_member_wildcard = []

        if self.is_wildcard_address_name(node_config_address, address_name):

            self.move_address_to_wildcard(node_config_address, address_name)

            node_type = node_sslexempt_edit.child_branch.loose_find_tree_node(
                set, list_type)
            node_type.rename_option("wildcard-fqdn")
            node_address = node_sslexempt_edit.child_branch.loose_find_tree_node(
                set, list_address)
            node_address.rename_field("wildcard-fqdn")

        elif self.is_pure_wildcard_address_group(node_config_address, node_config_addrgrp, address_name):

            self.move_addrgrp_to_wildcard(node_config_addrgrp, address_name)

            node_type = node_sslexempt_edit.child_branch.loose_find_tree_node(
                set, list_type)
            node_type.rename_option("wildcard-fqdn")
            node_address = node_sslexempt_edit.child_branch.loose_find_tree_node(
                set, list_address)
            node_address.rename_field("wildcard-fqdn")

        elif self.is_part_wildcard_address_group(node_config_address, node_config_addrgrp, address_name,
                                                 list_member_wildcard):

            wildcard_group_name = address_name[:-1] + "-wildcard\""
            node_custom = self.curr_vdom_root.find_tree_node(
                config, list_custom)
            self.create_wildcard_addrgrp(wildcard_group_name, list_member_wildcard,
                                         node_custom.get_location_index() + 1)

            edit_name = "10" + node_sslexempt_edit.list_value[1]
            node_edit = node_sslexempt_edit.parent_branch.create_blank_edit_node(edit_name,
                                                                                 node_sslexempt_edit.get_location_index() + 1)
            node_edit.create_leaf_node(
                set, ["set", "type", "wildcard-fqdn"], 0)
            node_edit.create_leaf_node(
                set, ["set", "wildcard-fqdn", wildcard_group_name], 1)

    def convert_config_dnsfilter_domainfilter(self):

        config = "config"
        list_value = ["config", "dnsfilter", "domain-filter"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_entries = ["config", "entries"]
        list_domain = ["set", "domain"]
        list_type = ["set", "type"]
        list_type_wildcard = ["set", "type", "wildcard"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_entries = node_edit.child_branch.find_tree_node(
                config, list_entries)
            if node_entries.node_type.value == 0:
                continue

            for node_entry_edit in node_entries.child_branch.list_child:
                if node_entry_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_domain = node_entry_edit.child_branch.loose_find_tree_node(
                    set, list_domain)
                if node_domain.node_type.value == 0:
                    continue

                domain = node_domain.list_value[2]
                if "/" in domain:
                    node_type = node_entry_edit.child_branch.loose_find_tree_node(
                        set, list_type)
                    if node_type.node_type.value == 0:
                        node_entry_edit.create_leaf_node(
                            set, list_type_wildcard, 1)
                    elif node_type.list_value[2] == "simple":
                        node_type.rename_option("wildcard")

    def convert_config_firewall_sslsshprofile(self):

        config = "config"
        list_value = ["config", "firewall", "ssl-ssh-profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["config", "firewall", "address"]
        node_config_address = self.curr_vdom_root.find_tree_node(
            config, list_value)
        list_value = ["config", "firewall", "addrgrp"]
        node_config_addrgrp = self.curr_vdom_root.find_tree_node(
            config, list_value)

        set = "set"
        list_type = ["set", "type"]
        list_address = ["set", "address"]
        list_sslexempt = ["config", "ssl-exempt"]

        list_address_to_be_changed = []
        list_custom = ["config", "firewall", "wildcard-fqdn", "custom"]
        node_custom = self.curr_vdom_root.find_tree_node(config, list_custom)
        if node_custom.node_type.value > 0:
            for node_edit_custom in node_custom.child_branch.list_child:
                if node_edit_custom.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                list_address_to_be_changed.append(
                    node_edit_custom.list_value[2])

        list_ssh = ["config", "ssh"]
        list_log = ["set", "log"]
        list_block = ["set", "block"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_sslexempt = node_edit.child_branch.find_tree_node(
                config, list_sslexempt)
            if node_sslexempt.node_type.value > 0:

                for node_sslexempt_edit in node_sslexempt.child_branch.list_child:
                    if node_sslexempt_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                        continue

                    node_type = node_sslexempt_edit.child_branch.loose_find_tree_node(
                        set, list_type)
                    if node_type.node_type.value == 0 or node_type.list_value[2] != "address":
                        continue

                    node_address = node_sslexempt_edit.child_branch.loose_find_tree_node(
                        set, list_address)
                    address_name = node_address.list_value[2]
                    if address_name == "\"*.live.com\"" and "\"live.com\"" in list_address_to_be_changed:
                        address_name = "\"live.com\""
                        node_address.rename_option("\"live.com\"")
                    elif address_name == "\"citrixonline\"" and "\"citrix\"" in list_address_to_be_changed:
                        address_name = "\"citrix\""
                        node_address.rename_option("\"citrix\"")
                    elif address_name == "\"appstore.com\"" and "\"appstore\"" in list_address_to_be_changed:
                        address_name = "\"appstore\""
                        node_address.rename_option("\"appstore\"")

                    if address_name in list_address_to_be_changed or address_name in self.list_dafault_wildcard_fqdn60:
                        node_type.rename_option("wildcard-fqdn")
                        node_address.rename_field("wildcard-fqdn")
                    else:
                        self.check_wildcard_fqdn_address(node_sslexempt_edit, node_config_address, node_config_addrgrp,
                                                         address_name)

            node_ssh = node_edit.child_branch.find_tree_node(config, list_ssh)
            if node_ssh.node_type.value > 0:
                node_ssh.child_branch.loose_find_and_remove_node(set, list_log)
                node_ssh.child_branch.loose_find_and_remove_node(
                    set, list_block)

    def convert_config_firewall_sslserver(self):

        config = "config"
        list_value = ["config", "firewall", "ssl-server"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_ssl_min_version = ["set", "ssl-min-version"]
        list_ssl_max_version = ["set", "ssl-max-version"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_min = node_edit.child_branch.loose_find_tree_node(
                set, list_ssl_min_version)
            if node_min.node_type.value > 0 and node_min.list_value[2] == "ssl-3.0":
                node_min.rename_option("tls-1.0")

            node_max = node_edit.child_branch.loose_find_tree_node(
                set, list_ssl_max_version)
            if node_max.node_type.value > 0 and node_max.list_value[2] == "ssl-3.0":
                node_max.rename_option("tls-1.0")

    def convert_config_log_guidisplay(self):

        config = "config"
        list_value = ["config", "log", "gui-display"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_location = ["set", "location"]
        node_config.child_branch.loose_find_and_remove_node(set, list_location)

    def convert_config_log_fortianalyzer_setting(self):

        list_postfix = ["", "2", "3"]

        config = "config"
        set = "set"

        for postfix in list_postfix:
            list_value = ["config", "log",
                          "fortianalyzer" + postfix, "setting"]
            node_config = self.curr_vdom_root.find_tree_node(
                config, list_value)
            if node_config.node_type.value == 0:
                continue

            list_enc_algorithm = ["set", "enc-algorithm"]
            node_encalgorithm = node_config.child_branch.loose_find_tree_node(
                set, list_enc_algorithm)
            if node_encalgorithm.node_type.value == 0:
                continue

            type = node_encalgorithm.list_value[2]
            if type == "default":
                node_encalgorithm.rename_option("high-medium")
            elif type == "disable":
                node_encalgorithm.remove_tree_node()

    def convert_config_log_threatweight(self):

        config = "config"
        list_value = ["config", "log", "threat-weight"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_malware_detected = ["set", "malware-detected"]
        list_botnet_connection_detected = ["set", "botnet-connection-detected"]
        list_botnet_connection = ["set", "botnet-connection", ""]
        list_malware = ["config", "malware"]

        node_config.child_branch.loose_find_and_remove_node(
            set, list_malware_detected)
        node_botnet = node_config.child_branch.loose_find_tree_node(
            set, list_botnet_connection_detected)
        if node_botnet.node_type.value == 0:
            return

        node_malware = node_config.child_branch.create_blank_config_node(
            list_malware, node_botnet.get_location_index())
        list_botnet_connection[2] = node_botnet.list_value[2]
        node_malware.create_leaf_node(set, list_botnet_connection, 0)
        node_botnet.remove_tree_node()

    def convert_config_user_ldap(self):

        config = "config"
        list_value = ["config", "user", "ldap"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_key_name = ["set", "account-key-name"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.find_and_rename_field(
                set, list_key_name, "account-key-filter")

    def convert_config_dlp_filepattern(self):

        config = "config"
        list_value = ["config", "dlp", "filepattern"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_filetype = ["set", "file-type"]
        list_entries = ["config", "entries"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_entries = node_edit.child_branch.find_tree_node(
                config, list_entries)
            if node_entries.node_type.value == 0:
                continue

            list_node_to_be_removed = []
            for node_entry_edit in node_entries.child_branch.list_child:
                if node_entry_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                entry_name = node_entry_edit.list_value[1]
                if "prc" in entry_name:
                    list_node_to_be_removed.append(node_entry_edit)
                else:
                    node_filetype = node_entry_edit.child_branch.loose_find_tree_node(
                        set, list_filetype)
                    if node_filetype.node_type.value > 0:
                        if node_filetype.list_value[2] == "prc":
                            list_node_to_be_removed.append(node_entry_edit)

            for node_entry_edit in list_node_to_be_removed:
                node_entry_edit.remove_tree_node()

    def convert_config_vpn_ssl_settings(self):

        config = "config"
        list_value = ["config", "vpn", "ssl", "settings"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        set = "set"
        list_sslv3 = ["set", "sslv3"]
        list_route = ["set", "route-source-interface"]
        list_buffer = ["set", "ssl-big-buffer"]
        node_config.child_branch.loose_find_and_remove_node(set, list_sslv3)
        node_config.child_branch.loose_find_and_remove_node(set, list_route)
        node_config.child_branch.loose_find_and_remove_node(set, list_buffer)

    def convert_config_antivirus_profile(self):
        config = "config"
        list_value = ("config", "antivirus", "profile")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            list_inspection_mode = ("set", "inspection-mode")
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_inspection_mode)

    def convert_config(self):

        try:
            self.convert_config_system_global()
            self.convert_config_system_interface()
            self.convert_config_system_accprofile()
            self.convert_config_system_objecttag()
            self.convert_config_system_virtualwanlink()
            self.convert_config_system_linkmonitor()
            self.convert_config_system_csf()
            self.convert_config_system_np6()
            self.convert_config_webfilter_profile()
            self.convert_wireless_controller_vap()
            self.convert_config_antivirus_profile()
            self.convert_config_dnsfilter_domainfilter()
            self.convert_config_firewall_sslsshprofile()
            self.convert_config_firewall_sslserver()
            self.convert_config_firewall_address()
            self.convert_config_firewall_policy()
            self.convert_config_log_guidisplay()
            self.convert_config_log_fortianalyzer_setting()
            self.convert_config_log_threatweight()
            self.convert_config_user_ldap()
            self.convert_config_dlp_filepattern()
            self.convert_config_vpn_ssl_settings()

        except Exception as e:
            print("Convert5.6_6.0 Error")
            raise e

    # Convert v5.6 to v6.0
    def convert_config_56_to_60(self):

        key = "config"
        list_global = ["config", "global"]
        list_vdom = ["config", "vdom"]

        node_global = self.config_root.find_tree_node(key, list_global)
        list_node_vdom = self.config_root.strict_match_tree_node(
            key, list_vdom)

        if node_global.node_type.value > 0 and len(list_node_vdom) > 0:
            # Enable VDOM mode
            self.curr_vdom = node_global.list_value[1]
            self.curr_vdom_root = node_global.child_branch
            self.convert_config()

            for node_vdom in list_node_vdom:
                for node_edit in node_vdom.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node_edit.get_last_leaf_index() > 0:
                        self.curr_vdom = node_edit.list_value[1]
                        self.curr_vdom_root = node_edit.child_branch
                        self.convert_config()

        elif len(list_node_vdom) == 0 and node_global.node_type.value == 0:
            # Disable VDOM mode
            self.curr_vdom = "root"
            self.curr_vdom_root = self.config_root
            self.convert_config()
