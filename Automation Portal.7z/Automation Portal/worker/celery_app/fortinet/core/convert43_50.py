import logging
import tempfile

from celery_app.fortinet.model.config_tree import (FGTNode, FGTNodeType,
                                                   FGTObject)
from celery_app.fortinet.model.utils import remove_quota


class Convert43_50:

    def __init__(self, fgt):

        self.config_root = fgt.config_root
        self.output_fgt = fgt
        self.curr_vdom_root = None

    def convert_config_antivirus_profile50(self):

        config = "config"
        key = "set"
        list_value = ["config", "antivirus", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set avdb"
        list_value = ["set", "avdb"]
        list_proto_to_be_removed = ["https", "ftps", "imaps", "smtps", "pop3s"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # remove "config XXX"
            for proto in list_proto_to_be_removed:
                list_proto = ["config", proto]
                node_edit.child_branch.find_and_remove_node(config, list_proto)

            for node in node_edit.child_branch.list_child:
                if node.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_antivirus_quarantine50(self):

        key = "config"
        list_value = ["config", "antivirus", "quarantine"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set enable-auto-submit"
        key = "set"
        list_value = ["set", "enable-auto-submit"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set sel-status"
        list_value = ["set", "sel-status"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "use-fpat"
        list_value = ["set", "use-fpat"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        # remove field "set use-status"
        list_value = ["set", "use-status"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_antivirus_quarfilepattern(self):

        # remove command "config antivirus quarfilepattern"
        key = "config"
        list_value = ["config", "antivirus", "quarfilepattern"]
        self.curr_vdom_root.find_and_remove_node(key, list_value)

    def convert_config_antivirus_settings(self):

        config = "config"
        key = "set"
        list_value = ["config", "antivirus", "settings"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove option "flow-based" in "set default-db"
        list_value = ["set", "default-db"]
        node_db = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        if node_db.node_type.value == 0 or node_db.list_value[-1] != "flow-based":
            return

        node_db.remove_tree_node()

        # convert the field into "set inspection-mode flow-based" in command "config antivirus profile"
        list_value = ["config", "antivirus", "profile"]
        node_profile = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_profile.node_type.value == 0:
            return

        list_value = ["set", "inspection-mode", "flow-based"]

        for node_edit in node_profile.child_branch.list_child:
            if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                node_edit.create_leaf_node(key, list_value, 0)

    def convert_config_application_list50(self):

        config = "config"
        list_value = ["config", "application", "list"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set log"
        set = "set"
        list_log = ["set", "log"]
        list_inspect_anyport = ["set", "inspect-anyport"]
        list_entries = ["config", "entries"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(set, list_log)
            node_entries = node_edit.child_branch.find_tree_node(
                config, list_entries)
            if node_entries.node_type.value == 0:
                continue

            for node_entry_edit in node_entries.child_branch.list_child:
                if node_entry_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_entry_edit.child_branch.loose_find_and_remove_node(
                    set, list_inspect_anyport)

    def convert_config_dlp_compound(self):

        # remove command "config dlp compound"
        key = "config"
        list_value = ["config", "dlp", "compound"]
        self.curr_vdom_root.find_and_remove_node(key, list_value)

    def convert_config_dlp_filepattern(self):

        config = "config"
        key = "set"
        list_value = ["config", "dlp", "filepattern"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)

        if node_config.node_type.value == 0:
            return

        # remove field "set action" and "set active"
        list_entries = ["config", "entries"]
        list_action = ["set", "action"]
        list_active = ["set", "active"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_entries = node_edit.child_branch.find_tree_node(
                config, list_entries)
            if node_entries.node_type.value == 0:
                continue

            for node_edit_entries in node_entries.child_branch.list_child:
                if node_edit_entries.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_edit_entries.child_branch.loose_find_and_remove_node(
                    key, list_action)
                node_edit_entries.child_branch.loose_find_and_remove_node(
                    key, list_active)

    def convert_config_dlp_rule(self):

        # remove command "config dlp rule"
        config = "config"
        key = "set"
        next = "next"
        list_value = ["config", "dlp", "rule"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

        list_value = ["config", "dlp", "sensor"]
        node_sersor = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_sersor.node_type.value == 0:
            return

        # Purge sensor content
        for node_edit in node_sersor.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            list_to_be_removed_node = []
            for node in node_edit.child_branch.list_child:
                if node.key == key:
                    if len(node.list_value) > 2 and node.list_value[1] == "comment":
                        continue
                    else:
                        list_to_be_removed_node.append(node)
                elif node.key == config:
                    list_to_be_removed_node.append(node)
                elif node.key == next:
                    continue

            # Remove nodes
            if len(list_to_be_removed_node) > 0:
                for node in list_to_be_removed_node:
                    node.remove_tree_node()

    def convert_config_endpoint_control_appDetect_rulelist(self):

        # remove command "config endpoint-control app-detect rule-list"
        key = "config"
        list_value = ["config", "endpoint-control", "app-detect", "rule-list"]

        self.curr_vdom_root.find_and_remove_node(key, list_value)

    def convert_config_endpoint_control_profile(self):

        key = "config"
        list_value = ["config", "endpoint-control", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_group = ["set", "replacemsg-override-group"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_group = node_edit.child_branch.loose_find_tree_node(
                key, list_group)
            remove_count = node_edit.get_last_leaf_index()
            del node_edit.child_branch.list_child[:remove_count]
            if node_group.node_type.value > 0:
                node_edit.insert_tree_node(node_group, 0)

        node_config.remove_tree_node()

    def convert_config_endpoint_control_settings(self):

        key = "config"
        list_value = ["config", "endpoint-control", "settings"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_enforce = ["set", "enforce-minimum-version"]
        list_version = ["set", "version"]
        node_config.child_branch.loose_find_and_remove_node(key, list_enforce)
        node_config.child_branch.loose_find_and_remove_node(key, list_version)

    def convert_config_firewall_interface_policy(self):

        def convert_config_firewall_interface_policy_content(node_config):

            key = "set"
            list_service = ["set", "service"]
            list_ips_dos = ["set", "ips-DoS-status"]
            list_node_dos = []

            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_ips_dos = node_edit.child_branch.loose_find_tree_node(
                    key, list_ips_dos)
                if node_ips_dos.node_type.value > 0:
                    node_ips_dos.rename_field("status")
                    list_node_dos.append(node_edit)

                node_service = node_edit.child_branch.loose_find_tree_node(
                    key, list_service)
                if node_service.node_type.value > 0:
                    if "\"ANY\"" in node_service.list_value:
                        node_service.rename_option("\"ALL\"")
                    elif "\"ICMP_ANY\"" in node_service.list_value:
                        node_service.list_value.remove("\"ICMP_ANY\"")
                        node_service.list_value.append("\"ALL_ICMP\"")

            # use "config firewall DoS-policy" to config DoS policy
            if len(list_node_dos) > 0:
                key = "config"
                list_dos_policy = ["config", "firewall", "DoS-policy"]
                node_dos_policy = node_config.parent_branch.find_or_create_config_node(key, list_dos_policy,
                                                                                       node_config.get_location_index())
                for node_policy in list_node_dos:
                    self.convert_ips_dos(node_dos_policy, node_policy)

        key = "config"
        list_value = ["config", "firewall", "interface-policy"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_interface_policy_content(node_config)

        list_value = ["config", "firewall", "interface-policy6"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_interface_policy_content(node_config)

    def convert_ips_dos(self, node_dos_policy, node_policy):

        key = "config"
        list_ips_dos = ["config", "ips", "DoS"]
        node_ips_dos = self.curr_vdom_root.find_tree_node(key, list_ips_dos)
        if node_ips_dos.node_type.value == 0:
            return

        key = "set"
        list_dos = ["set", "ips-DoS"]
        node = node_policy.child_branch.loose_find_tree_node(key, list_dos)
        if node.node_type.value == 0:
            return

        node.remove_tree_node()
        ips_dos_name = node.list_value[-1]
        node_dos = node_ips_dos.child_branch.find_branch_node_edit(
            ips_dos_name)
        if node_dos.node_type.value == 0:
            return

        name = node_policy.list_value[-1]
        if node_dos_policy.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            node_edit = node_dos_policy.create_blank_edit_node(
                name, node_dos_policy.get_last_leaf_index())
            node_clone = node_policy.clone(None)

            list_status = ["set", "status"]
            list_inf = ["set", "interface"]
            list_src_addr = ["set", "srcaddr"]
            list_dst_addr = ["set", "dstaddr"]
            list_service = ["set", "service"]
            list_comment = ["set", "comment"]
            list_anomaly = ["config", "anomaly"]
            list_quarantine_log = ["set", "quarantine-log"]

            # move needed fields from policy into DoS policy
            insert_idx = 0
            node = node_clone.child_branch.loose_find_tree_node(
                key, list_status)
            if node.node_type.value > 0:
                node_edit.move_tree_node(node, insert_idx)
                insert_idx += 1

            node = node_clone.child_branch.loose_find_tree_node(key, list_inf)
            if node.node_type.value > 0:
                node_edit.move_tree_node(node, insert_idx)
                insert_idx += 1

            node = node_clone.child_branch.loose_find_tree_node(
                key, list_src_addr)
            if node.node_type.value > 0:
                node_edit.move_tree_node(node, insert_idx)
                insert_idx += 1

            node = node_clone.child_branch.loose_find_tree_node(
                key, list_dst_addr)
            if node.node_type.value > 0:
                node_edit.move_tree_node(node, insert_idx)
                insert_idx += 1

            node = node_clone.child_branch.loose_find_tree_node(
                key, list_service)
            if node.node_type.value > 0:
                node_edit.move_tree_node(node, insert_idx)
                insert_idx += 1

            node = node_dos.child_branch.loose_find_tree_node(
                key, list_comment)
            if node.node_type.value > 0:
                node_comment = node.clone(None)
                node_edit.insert_tree_node(node_comment, insert_idx)
                insert_idx += 1

            key = "config"
            node = node_dos.child_branch.find_tree_node(key, list_anomaly)
            if node.node_type.value > 0:
                key = "set"
                list_quar_log = node.child_branch.loose_match_tree_node(
                    key, list_quarantine_log)
                for node_quar_log in list_quar_log:
                    node_quar_log.remove_tree_node()

                node_anomaly = node.clone(None)
                node_edit.insert_tree_node(node_anomaly, insert_idx)
                insert_idx += 1

        node_policy.remove_tree_node()

    def convert_config_firewall_mms_profile(self):

        key = "config"
        list_value = ["config", "firewall", "mms-profile"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove option "strict-file" in "set mm1" and "set mm7"
        key = "set"
        list_mm1 = ["set", "mm1"]
        list_mm7 = ["set", "mm7"]
        list_to_be_removed = ["strict-file"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                return
            node_edit.child_branch.find_and_remove_options(
                key, list_mm1, list_to_be_removed)
            node_edit.child_branch.find_and_remove_options(
                key, list_mm7, list_to_be_removed)

    def convert_config_firewall_multicast_policy(self):

        key = "config"
        list_value = ["config", "firewall", "multicast-policy"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # rename field "set nat" into "set snat"
        key = "set"
        list_value = ["set", "nat"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.find_and_rename_field(
                key, list_value, "snat")

    def convert_config_firewall_policy50(self):

        def convert_config_firewall_policy50_content(node_config):

            key = "set"
            list_auth_method = ["set", "auth-method"]
            list_dp = ["set", "dynamic-profile"]
            list_dp_group = ["set", "dynamic-profile-group"]
            list_dp_access = ["set", "dynamic-profile-access"]
            list_dos = ["set", "ips-DoS-status"]
            list_log = ["set", "logtraffic", "enable"]
            list_tcp_reset = ["set", "tcp-reset"]
            list_service = ["set", "service"]
            config = "config"
            list_id_based_policy = ["config", "identity-based-policy"]

            list_node_dos = []

            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                # use "sso-auth-method" or "active-auth-method" to replace field "set", "auth-method"
                node_auth_method = node_edit.child_branch.loose_find_tree_node(
                    key, list_auth_method)
                if node_auth_method.node_type.value > 0:
                    method = node_auth_method.list_value[-1]
                    if method == "fsso":
                        node_auth_method.rename_field("sso-auth-method")
                    else:
                        node_auth_method.rename_field("active-auth-method")

                # remove field "set dynamic-profile", "set dynamic-profile-group" and "set dynamic-profile-access"
                node_edit.child_branch.loose_find_and_remove_node(key, list_dp)
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_dp_group)
                node_edit.child_branch.loose_find_and_remove_node(
                    key, list_dp_access)

                # remove field "set ips-DoS-status"
                node_dos = node_edit.child_branch.loose_find_tree_node(
                    key, list_dos)
                if node_dos.node_type.value > 0:
                    node_dos.remove_tree_node()
                    list_node_dos.append(node_edit)

                # convert option "enable" into "all" in field "set logtraffic"
                node_log = node_edit.child_branch.find_tree_node(key, list_log)
                if node_log.node_type.value > 0:
                    node_log.rename_option("all")

                # rename field "tcp-reset" into "send-deny-packet"
                node_edit.child_branch.find_and_rename_field(
                    key, list_tcp_reset, "send-deny-packet")

                # rename the predefined service "ANY" into "ALL"
                node_service = node_edit.child_branch.loose_find_tree_node(
                    key, list_service)
                if node_service.node_type.value > 0:
                    if "\"ANY\"" in node_service.list_value:
                        node_service.rename_option("\"ALL\"")
                    else:
                        if "\"ICMP_ANY\"" in node_service.list_value:
                            node_service.list_value.remove("\"ICMP_ANY\"")
                            node_service.list_value.append("\"ALL_ICMP\"")
                        if "\"TCP\"" in node_service.list_value:
                            node_service.list_value.remove("\"TCP\"")
                            node_service.list_value.append("\"ALL_TCP\"")
                        if "\"UDP\"" in node_service.list_value:
                            node_service.list_value.remove("\"UDP\"")
                            node_service.list_value.append("\"ALL_UDP\"")

                node_id_based_policy = node_edit.child_branch.find_tree_node(
                    config, list_id_based_policy)
                if node_id_based_policy.node_type.value > 0:
                    for node_edit_id_based_policy in node_id_based_policy.child_branch.list_child:
                        if node_edit_id_based_policy.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                            continue

                        node_log = node_edit_id_based_policy.child_branch.find_tree_node(
                            key, list_log)
                        if node_log.node_type.value > 0:
                            node_log.rename_option("all")

                        # rename the predefined service "ANY" into "ALL"
                        node_service = node_edit_id_based_policy.child_branch.loose_find_tree_node(
                            key, list_service)
                        if node_service.node_type.value > 0:
                            if "\"ANY\"" in node_service.list_value:
                                node_service.rename_option("\"ALL\"")
                            else:
                                if "\"ICMP_ANY\"" in node_service.list_value:
                                    node_service.list_value.remove(
                                        "\"ICMP_ANY\"")
                                    node_service.list_value.append(
                                        "\"ALL_ICMP\"")
                                if "\"TCP\"" in node_service.list_value:
                                    node_service.list_value.remove("\"TCP\"")
                                    node_service.list_value.append(
                                        "\"ALL_TCP\"")
                                if "\"UDP\"" in node_service.list_value:
                                    node_service.list_value.remove("\"UDP\"")
                                    node_service.list_value.append(
                                        "\"ALL_UDP\"")

            # use "config firewall DoS-policy" to config DoS policy
            if len(list_node_dos) > 0:
                key = "config"
                list_dos_policy = ["config", "firewall", "DoS-policy"]
                node_dos_policy = node_config.parent_branch.find_or_create_config_node(key, list_dos_policy,
                                                                                       node_config.get_location_index())
                for node_policy in list_node_dos:
                    self.convert_ips_dos(node_dos_policy, node_policy)

        key = "config"
        list_value = ["config", "firewall", "policy"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_policy50_content(node_config)

        list_value = ["config", "firewall", "policy6"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value != 0:
            convert_config_firewall_policy50_content(node_config)

    def convert_config_firewall_profile_protocol_options50(self):

        def insert_deep_inspection_options_to_policy(node_config):

            key = "set"
            list_profile = ["set", "profile-protocol-options"]

            # create "set deep-inspection-options" in policy
            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_profile = node_edit.child_branch.loose_find_tree_node(
                    key, list_profile)
                if node_profile.node_type.value > 0:
                    list_deep_inspect = [
                        "set", "deep-inspection-options", "\"deep-inspection\""]
                    node_edit.create_leaf_node(
                        key, list_deep_inspect, node_edit.get_last_leaf_index())

        def convert_config_firewall_deep_inspection_options50(node_opts):

            node_clone = node_opts.clone(node_opts.parent_branch)
            del node_opts.child_branch.list_child[0:node_opts.get_last_leaf_index(
            )]

            key = "set"
            list_port = ["set", "port"]
            list_options = ["set", "options"]
            list_client = ["set", "client-cert-request"]
            list_unsupported = ["set", "unsupported-ssl"]

            insert_index = 0

            # rename "set port" into "set ports"
            node_port = node_clone.child_branch.loose_find_tree_node(
                key, list_port)
            if node_port.node_type.value > 0:
                node_port.rename_field("ports")
                node_opts.insert_tree_node(node_port, insert_index)
                insert_index += 1

            node_options = node_clone.child_branch.loose_find_tree_node(
                key, list_options)
            if node_options.node_type.value > 0:
                options = node_options.list_value[-1]
                if options == "allow-invalid-server-cert":
                    # convert "set options allow-invalid-server-cert" into "set allow-invalid-server-cert enable"
                    list_allow = ["set", "allow-invalid-server-cert", "enable"]
                    node_opts.create_leaf_node(key, list_allow, insert_index)
                    insert_index += 1
                elif options == "ssl-ca-list":
                    # convert "set options ssl-ca-list" into "set ssl-ca-list enable"
                    list_ssl = ["set", "ssl-ca-list", "enable"]
                    node_opts.create_leaf_node(key, list_ssl, insert_index)
                    insert_index += 1

            # create field "set client-cert-request"
            node_client = node_clone.child_branch.loose_find_tree_node(
                key, list_client)
            if node_client.node_type.value > 0:
                node_opts.insert_tree_node(node_client, insert_index)
                insert_index += 1

            # create field "set unsupported-ssl"
            node_unsupported = node_clone.child_branch.loose_find_tree_node(
                key, list_unsupported)
            if node_unsupported.node_type.value > 0:
                node_opts.insert_tree_node(node_unsupported, insert_index)
                insert_index += 1

        key = "config"
        list_value = ["config", "firewall", "profile-protocol-options"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # move config "ftps", "https", "imaps", "pop3s" and "smtps" to "config deep-inspection-options"
        list_ssl = ["set", "ssl-invalid-server-cert-log"]
        list_ftps = ["config", "ftps"]
        list_https = ["config", "https"]
        list_imaps = ["config", "imaps"]
        list_pop3s = ["config", "pop3s"]
        list_smtps = ["config", "smtps"]

        dic_deep_inspect = dict()
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            list_deep_inspect = []

            key = "set"
            node = node_edit.child_branch.loose_find_tree_node(key, list_ssl)
            if node.node_type.value > 0:
                node.remove_tree_node()

            key = "config"
            node = node_edit.child_branch.find_tree_node(key, list_ftps)
            if node.node_type.value > 0:
                node.remove_tree_node()
                list_deep_inspect.append(node)

            node = node_edit.child_branch.find_tree_node(key, list_https)
            if node.node_type.value > 0:
                node.remove_tree_node()
                list_deep_inspect.append(node)

            node = node_edit.child_branch.find_tree_node(key, list_imaps)
            if node.node_type.value > 0:
                node.remove_tree_node()
                list_deep_inspect.append(node)

            node = node_edit.child_branch.find_tree_node(key, list_pop3s)
            if node.node_type.value > 0:
                node.remove_tree_node()
                list_deep_inspect.append(node)

            node = node_edit.child_branch.find_tree_node(key, list_smtps)
            if node.node_type.value > 0:
                node.remove_tree_node()
                list_deep_inspect.append(node)

            if len(list_deep_inspect) > 0:
                opt_name = node_edit.list_value[-1]
                dic_deep_inspect[opt_name] = list_deep_inspect

        if len(dic_deep_inspect) > 0:
            list_value = ["config", "firewall", "deep-inspection-options"]
            insert_index = node_config.get_location_index() + 1
            node_deep_inspect = node_config.parent_branch.create_blank_config_node(
                list_value, insert_index)
            insert_index = 0
            for keys, values in dic_deep_inspect.items():
                node_edit = node_deep_inspect.create_blank_edit_node(
                    keys, insert_index)
                opts_insert_index = 0
                for node_opts in values:
                    convert_config_firewall_deep_inspection_options50(
                        node_opts)
                    node_edit.insert_tree_node(node_opts, opts_insert_index)
                    opts_insert_index += 1
                insert_index += 1

            # if a policy refers this "profile-protocol-option", create a reference of "deep-inspection" in it
            list_value = ["config", "firewall", "policy"]
            node_config = self.curr_vdom_root.find_tree_node(key, list_value)
            if node_config.node_type.value != 0:
                insert_deep_inspection_options_to_policy(node_config)

            list_value = ["config", "firewall", "policy6"]
            node_config = self.curr_vdom_root.find_tree_node(key, list_value)
            if node_config.node_type.value != 0:
                insert_deep_inspection_options_to_policy(node_config)

    def convert_config_firewall_Service_explicit_web(self):

        key = "config"
        list_value = ["config", "firewall", "service", "explicit-web"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # convert services in "config firewall service explicit-web"
        # into services in "config firewall service custom" with "set explicit-proxy enable"
        list_value = ["config", "firewall", "service", "custom"]
        node_service = node_config.parent_branch.find_or_create_config_node(key, list_value,
                                                                            node_config.get_location_index())

        key = "set"
        list_exp_porxy = ["set", "explicit-proxy", "enable"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.create_leaf_node(key, list_exp_porxy, 0)

            '''
            For webproxy node.
            edit "webproxy"
                set explicit-proxy enable
                set category "Web Proxy"
                set protocol ALL
                set tcp-portrange 0-65535:0-65535
            next 
            '''
            if "\"webproxy\"" in node_edit.list_value:
                list_category = ["set", "category", "\"Web Proxy\""]
                node_edit.create_leaf_node(key, list_category, 1)

                list_protocol = ["set", "protocol", "ALL"]
                node_edit.create_leaf_node(key, list_protocol, 2)

                list_tcp_port = ["set", "tcp-portrange", "0-65535"]
                node_edit.create_leaf_node(key, list_tcp_port, 3)

            else:
                # convert all the protocols in "explicit-web" service into "TCP/UDP/SCTP"
                list_protocol = ["set", "protocol"]
                node_protocol = node_edit.child_branch.loose_find_tree_node(
                    key, list_protocol)
                if node_protocol.node_type.value != 0:
                    node_protocol.rename_option("TCP/UDP/SCTP")

            node_service.insert_tree_node(
                node_edit, node_service.get_last_leaf_index())

        node_config.remove_tree_node()

    def convert_config_firewall_service_group_explicit_web(self):

        key = "config"
        list_value = ["config", "firewall", "service", "group-explicit-web"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # convert services in "config firewall service explicit-web"
        # into services in "config firewall service custom" with "set explicit-proxy enable"
        list_value = ["config", "firewall", "service", "group"]
        node_service = node_config.parent_branch.find_or_create_config_node(key, list_value,
                                                                            node_config.get_location_index())

        key = "set"
        list_exp_proxy = ["set", "explicit-proxy", "enable"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.create_leaf_node(key, list_exp_proxy, 0)
            node_service.insert_tree_node(
                node_edit, node_service.get_last_leaf_index())

        node_config.remove_tree_node()

    def convert_config_firewall_service_category(self):

        # don't need to add default service category in global scope
        if self.curr_vdom_root.associate_node:
            node = self.curr_vdom_root.associate_node
            if node.key == "config":
                last = node.list_value[-1]
                if last == "global":
                    return

        '''Add default service category.'''
        array_str = ["config firewall service category",
                     "    edit \"General\"",
                     "        set comment \"General services.\"",
                     "    next",
                     "    edit \"Web Access\"",
                     "        set comment \"Web access.\"",
                     "    next",
                     "    edit \"File Access\"",
                     "        set comment \"File access.\"",
                     "    next",
                     "    edit \"Email\"",
                     "        set comment \"Email services.\"",
                     "    next",
                     "    edit \"Network Services\"",
                     "        set comment \"Network services.\"",
                     "    next",
                     "    edit \"Authentication\"",
                     "        set comment \"Authentication service.\"",
                     "    next",
                     "    edit \"Remote Access\"",
                     "        set comment \"Remote access.\"",
                     "    next",
                     "    edit \"Tunneling\"",
                     "        set comment \"Tunneling service.\"",
                     "    next",
                     "    edit \"VoIP, Messaging & Other Applications\"",
                     "        set comment \"VoIP, messaging, and other applications.\"",
                     "    next",
                     "    edit \"Web Proxy\"",
                     "        set comment \"Explicit web proxy.\"",
                     "    next",
                     "end"]

        key = "config"
        list_value = ["config", "firewall", "policy"]
        node_policy = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_policy.node_type.value > 0:
            insert_idx = node_policy.get_location_index()
        else:
            insert_idx = len(self.curr_vdom_root.list_child) - 1

        list_value = ["config", "firewall", "service", "category"]
        node_service_category = self.curr_vdom_root.find_or_create_config_node(
            key, list_value, insert_idx)

        current_obj = FGTObject()
        current_obj.height = 0
        current_obj.list_child = []

        content = "\n".join(array_str)
        ''' Format string list to stream '''
        temp_content = tempfile.TemporaryFile(mode="wb+")
        temp_content.write(content.encode("utf-8"))
        temp_content.seek(0)

        current_obj.read_config_file(temp_content)
        node_default_category = current_obj.find_tree_node(key, list_value)
        if node_default_category.node_type.value == 0:
            return

        key = "edit"

        for node_edit in node_default_category.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue
            node_category = node_service_category.child_branch.find_tree_node(
                key, node_edit.list_value)
            if node_category.node_type.value == 0:
                node_service_category.insert_tree_node(
                    node_edit, node_service_category.get_last_leaf_index())

    def convert_config_firewall_service_predefined(self):

        # don't need to add default service in global scope
        if self.curr_vdom_root.associate_node:
            node = self.curr_vdom_root.associate_node
            if node.key == "config":
                last = node.list_value[-1]
                if last == "global":
                    return

        ''' Add default service '''
        array_str = ["config firewall service custom",
                     "    edit \"ALL\"",
                     "        set category \"General\"",
                     "        set protocol IP",
                     "    next",
                     "    edit \"ALL_TCP\"",
                     "        set category \"General\"",
                     "        set tcp-portrange 1-65535",
                     "    next",
                     "    edit \"ALL_UDP\"",
                     "        set category \"General\"",
                     "        set udp-portrange 1-65535",
                     "    next",
                     "    edit \"ALL_ICMP\"",
                     "        set category \"General\"",
                     "        set protocol ICMP",
                     "        unset icmptype",
                     "    next",
                     "    edit \"ALL_ICMP6\"",
                     "        set category \"General\"",
                     "        set protocol ICMP6",
                     "        unset icmptype",
                     "    next",
                     "    edit \"GRE\"",
                     "        set category \"Tunneling\"",
                     "        set protocol IP",
                     "        set protocol-number 47",
                     "    next",
                     "    edit \"AH\"",
                     "        set category \"Tunneling\"",
                     "        set protocol IP",
                     "        set protocol-number 51",
                     "    next",
                     "    edit \"ESP\"",
                     "        set category \"Tunneling\"",
                     "        set protocol IP",
                     "        set protocol-number 50",
                     "    next",
                     "    edit \"AOL\"",
                     "        set visibility disable",
                     "        set tcp-portrange 5190-5194",
                     "    next",
                     "    edit \"BGP\"",
                     "        set category \"Network Services\"",
                     "        set tcp-portrange 179",
                     "    next",
                     "    edit \"DHCP\"",
                     "        set category \"Network Services\"",
                     "        set udp-portrange 67-68",
                     "    next",
                     "    edit \"DNS\"",
                     "        set category \"Network Services\"",
                     "        set tcp-portrange 53",
                     "        set udp-portrange 53",
                     "    next",
                     "    edit \"FINGER\"",
                     "        set visibility disable",
                     "        set tcp-portrange 79",
                     "    next",
                     "    edit \"FTP\"",
                     "        set category \"File Access\"",
                     "        set tcp-portrange 21",
                     "    next",
                     "    edit \"FTP_GET\"",
                     "        set category \"File Access\"",
                     "        set tcp-portrange 21",
                     "    next",
                     "    edit \"FTP_PUT\"",
                     "        set category \"File Access\"",
                     "        set tcp-portrange 21",
                     "    next",
                     "    edit \"GOPHER\"",
                     "        set visibility disable",
                     "        set tcp-portrange 70",
                     "    next",
                     "    edit \"H323\"",
                     "        set category \"VoIP, Messaging & Other Applications\"",
                     "        set tcp-portrange 1720 1503",
                     "        set udp-portrange 1719",
                     "    next",
                     "    edit \"HTTP\"",
                     "        set category \"Web Access\"",
                     "        set tcp-portrange 80",
                     "    next",
                     "    edit \"HTTPS\"",
                     "        set category \"Web Access\"",
                     "        set tcp-portrange 443",
                     "    next",
                     "    edit \"IKE\"",
                     "        set category \"Tunneling\"",
                     "        set udp-portrange 500 4500",
                     "    next",
                     "    edit \"IMAP\"",
                     "        set category \"Email\"",
                     "        set tcp-portrange 143",
                     "    next",
                     "    edit \"IMAPS\"",
                     "        set category \"Email\"",
                     "        set tcp-portrange 993",
                     "    next",
                     "    edit \"Internet-Locator-Service\"",
                     "        set visibility disable",
                     "        set tcp-portrange 389",
                     "    next",
                     "    edit \"IRC\"",
                     "        set category \"VoIP, Messaging & Other Applications\"",
                     "        set tcp-portrange 6660-6669",
                     "    next",
                     "    edit \"L2TP\"",
                     "        set category \"Tunneling\"",
                     "        set tcp-portrange 1701",
                     "        set udp-portrange 1701",
                     "    next",
                     "    edit \"LDAP\"",
                     "        set category \"Authentication\"",
                     "        set tcp-portrange 389",
                     "    next",
                     "    edit \"NetMeeting\"",
                     "        set visibility disable",
                     "        set tcp-portrange 1720",
                     "    next",
                     "    edit \"NFS\"",
                     "        set category \"File Access\"",
                     "        set tcp-portrange 111 2049",
                     "        set udp-portrange 111 2049",
                     "    next",
                     "    edit \"NNTP\"",
                     "        set visibility disable",
                     "        set tcp-portrange 119",
                     "    next",
                     "    edit \"NTP\"",
                     "        set category \"Network Services\"",
                     "        set tcp-portrange 123",
                     "        set udp-portrange 123",
                     "    next",
                     "    edit \"OSPF\"",
                     "        set category \"Network Services\"",
                     "        set protocol IP",
                     "        set protocol-number 89",
                     "    next",
                     "    edit \"PC-Anywhere\"",
                     "        set category \"Remote Access\"",
                     "        set tcp-portrange 5631",
                     "        set udp-portrange 5632",
                     "    next",
                     "    edit \"PING\"",
                     "        set category \"Network Services\"",
                     "        set protocol ICMP",
                     "        set icmptype 8",
                     "        unset icmpcode",
                     "    next",
                     "    edit \"TIMESTAMP\"",
                     "        set protocol ICMP",
                     "        set visibility disable",
                     "        set icmptype 13",
                     "        unset icmpcode",
                     "    next",
                     "    edit \"INFO_REQUEST\"",
                     "        set protocol ICMP",
                     "        set visibility disable",
                     "        set icmptype 15",
                     "        unset icmpcode",
                     "    next",
                     "    edit \"INFO_ADDRESS\"",
                     "        set protocol ICMP",
                     "        set visibility disable",
                     "        set icmptype 17",
                     "        unset icmpcode",
                     "    next",
                     "    edit \"ONC-RPC\"",
                     "        set category \"Remote Access\"",
                     "        set tcp-portrange 111",
                     "        set udp-portrange 111",
                     "    next",
                     "    edit \"DCE-RPC\"",
                     "        set category \"Remote Access\"",
                     "        set tcp-portrange 135",
                     "        set udp-portrange 135",
                     "    next",
                     "    edit \"POP3\"",
                     "        set category \"Email\"",
                     "        set tcp-portrange 110",
                     "    next",
                     "    edit \"POP3S\"",
                     "        set category \"Email\"",
                     "        set tcp-portrange 995",
                     "    next",
                     "    edit \"PPTP\"",
                     "        set category \"Tunneling\"",
                     "        set tcp-portrange 1723",
                     "    next",
                     "    edit \"QUAKE\"",
                     "        set visibility disable",
                     "        set udp-portrange 26000 27000 27910 27960",
                     "    next",
                     "    edit \"RAUDIO\"",
                     "        set visibility disable",
                     "        set udp-portrange 7070",
                     "    next",
                     "    edit \"REXEC\"",
                     "        set visibility disable",
                     "        set tcp-portrange 512",
                     "    next",
                     "    edit \"RIP\"",
                     "        set category \"Network Services\"",
                     "        set udp-portrange 520",
                     "    next",
                     "    edit \"RLOGIN\"",
                     "        set visibility disable",
                     "        set tcp-portrange 513:512-1023",
                     "    next",
                     "    edit \"RSH\"",
                     "        set visibility disable",
                     "        set tcp-portrange 514:512-1023",
                     "    next",
                     "    edit \"SCCP\"",
                     "        set category \"VoIP, Messaging & Other Applications\"",
                     "        set tcp-portrange 2000",
                     "    next",
                     "    edit \"SIP\"",
                     "        set category \"VoIP, Messaging & Other Applications\"",
                     "        set tcp-portrange 5060",
                     "        set udp-portrange 5060",
                     "    next",
                     "    edit \"SIP-MSNmessenger\"",
                     "        set category \"VoIP, Messaging & Other Applications\"",
                     "        set tcp-portrange 1863",
                     "    next",
                     "    edit \"SAMBA\"",
                     "        set category \"File Access\"",
                     "        set tcp-portrange 139",
                     "    next",
                     "    edit \"SMTP\"",
                     "        set category \"Email\"",
                     "        set tcp-portrange 25",
                     "    next",
                     "    edit \"SMTPS\"",
                     "        set category \"Email\"",
                     "        set tcp-portrange 465",
                     "    next",
                     "    edit \"SNMP\"",
                     "        set category \"Network Services\"",
                     "        set tcp-portrange 161-162",
                     "        set udp-portrange 161-162",
                     "    next",
                     "    edit \"SSH\"",
                     "        set category \"Remote Access\"",
                     "        set tcp-portrange 22",
                     "    next",
                     "    edit \"SYSLOG\"",
                     "        set category \"Network Services\"",
                     "        set udp-portrange 514",
                     "    next",
                     "    edit \"TALK\"",
                     "        set visibility disable",
                     "        set udp-portrange 517-518",
                     "    next",
                     "    edit \"TELNET\"",
                     "        set category \"Remote Access\"",
                     "        set tcp-portrange 23",
                     "    next",
                     "    edit \"TFTP\"",
                     "        set category \"File Access\"",
                     "        set udp-portrange 69",
                     "    next",
                     "    edit \"MGCP\"",
                     "        set visibility disable",
                     "        set udp-portrange 2427 2727",
                     "    next",
                     "    edit \"UUCP\"",
                     "        set visibility disable",
                     "        set tcp-portrange 540",
                     "    next",
                     "    edit \"VDOLIVE\"",
                     "        set visibility disable",
                     "        set tcp-portrange 7000-7010",
                     "    next",
                     "    edit \"WAIS\"",
                     "        set visibility disable",
                     "        set tcp-portrange 210",
                     "    next",
                     "    edit \"WINFRAME\"",
                     "        set visibility disable",
                     "        set tcp-portrange 1494 2598",
                     "    next",
                     "    edit \"X-WINDOWS\"",
                     "        set category \"Remote Access\"",
                     "        set tcp-portrange 6000-6063",
                     "    next",
                     "    edit \"PING6\"",
                     "        set protocol ICMP6",
                     "        set visibility disable",
                     "        set icmptype 128",
                     "        unset icmpcode",
                     "    next",
                     "    edit \"MS-SQL\"",
                     "        set category \"VoIP, Messaging & Other Applications\"",
                     "        set tcp-portrange 1433 1434",
                     "    next",
                     "    edit \"MYSQL\"",
                     "        set category \"VoIP, Messaging & Other Applications\"",
                     "        set tcp-portrange 3306",
                     "    next",
                     "    edit \"RDP\"",
                     "        set category \"Remote Access\"",
                     "        set tcp-portrange 3389",
                     "    next",
                     "    edit \"VNC\"",
                     "        set category \"Remote Access\"",
                     "        set tcp-portrange 5900",
                     "    next",
                     "    edit \"DHCP6\"",
                     "        set category \"Network Services\"",
                     "        set udp-portrange 546 547",
                     "    next",
                     "    edit \"SQUID\"",
                     "        set category \"Tunneling\"",
                     "        set tcp-portrange 3128",
                     "    next",
                     "    edit \"SOCKS\"",
                     "        set category \"Tunneling\"",
                     "        set tcp-portrange 1080",
                     "        set udp-portrange 1080",
                     "    next",
                     "    edit \"WINS\"",
                     "        set category \"Remote Access\"",
                     "        set tcp-portrange 1512",
                     "        set udp-portrange 1512",
                     "    next",
                     "    edit \"RADIUS\"",
                     "        set category \"Authentication\"",
                     "        set udp-portrange 1812 1813",
                     "    next",
                     "    edit \"RADIUS-OLD\"",
                     "        set visibility disable",
                     "        set udp-portrange 1645 1646",
                     "    next",
                     "    edit \"CVSPSERVER\"",
                     "        set visibility disable",
                     "        set tcp-portrange 2401",
                     "        set udp-portrange 2401",
                     "    next",
                     "    edit \"AFS3\"",
                     "        set category \"File Access\"",
                     "        set tcp-portrange 7000-7009",
                     "        set udp-portrange 7000-7009",
                     "    next",
                     "    edit \"TRACEROUTE\"",
                     "        set category \"Network Services\"",
                     "        set udp-portrange 33434-33535",
                     "    next",
                     "    edit \"RTSP\"",
                     "        set category \"VoIP, Messaging & Other Applications\"",
                     "        set tcp-portrange 554 7070 8554",
                     "        set udp-portrange 554",
                     "    next",
                     "    edit \"MMS\"",
                     "        set visibility disable",
                     "        set tcp-portrange 1755",
                     "        set udp-portrange 1024-5000",
                     "    next",
                     "    edit \"KERBEROS\"",
                     "        set category \"Authentication\"",
                     "        set tcp-portrange 88",
                     "        set udp-portrange 88",
                     "    next",
                     "    edit \"LDAP_UDP\"",
                     "        set category \"Authentication\"",
                     "        set udp-portrange 389",
                     "    next",
                     "    edit \"SMB\"",
                     "        set category \"File Access\"",
                     "        set tcp-portrange 445",
                     "    next",
                     "    edit \"webproxy\"",
                     "        set explicit-proxy enable",
                     "        set category \"Web Proxy\"",
                     "        set protocol ALL",
                     "        set tcp-portrange 0-65535:0-65535",
                     "    next",
                     "end"]

        key = "config"
        list_value = ["config", "firewall", "service", "category"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)

        if node_config.node_type.value > 0:
            insert_idx = node_config.get_location_index() + 1
        else:
            insert_idx = len(self.curr_vdom_root.list_child) - 1
        list_value = ["config", "firewall", "service", "custom"]
        node_config = self.curr_vdom_root.find_or_create_config_node(
            key, list_value, insert_idx)
        if node_config.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            current_obj = FGTObject()
            current_obj.height = 0
            current_obj.list_child = []
            content = "\n".join(array_str)
            ''' Format string list to stream '''
            temp_content = tempfile.TemporaryFile(mode="wb+")
            temp_content.write(content.encode("utf-8"))
            temp_content.seek(0)

            current_obj.read_config_file(temp_content)

            node_default_service = current_obj.find_tree_node(key, list_value)
            if node_default_service.node_type.value == 0:
                return

            key = "edit"
            for node_edit in node_default_service.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_service = node_config.child_branch.find_tree_node(
                    key, node_edit.list_value)
                if node_service.node_type.value == 0:
                    node_config.insert_tree_node(
                        node_edit, node_config.get_last_leaf_index())

    def convert_config_firewall_sniffInterface_policy50(self):

        config = "config"
        key = "set"
        list_value = ["config", "firewall", "sniff-interface-policy"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_dos = ["set", "ips-DoS-status"]
        list_log = ["set", "logtraffic", "enable"]
        list_dos_policy = []

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_dos = node_edit.child_branch.loose_find_tree_node(
                key, list_dos)
            if node_dos.node_type.value > 0:
                node_dos.remove_tree_node()
                list_dos_policy.append(node_edit)

            # rename option "enable" in "set logtraffic" into "all"
            node_log = node_edit.child_branch.loose_find_tree_node(
                key, list_log)
            if node_log.node_type.value > 0:
                node_log.rename_option("all")

        # convert policies with "ips-DoS-status enabled" into DoS policy
        if len(list_dos_policy) > 0:
            list_value = ["config", "firewall", "DoS-policy"]
            node_dos_policy = node_config.parent_branch.find_or_create_config_node(config, list_value,
                                                                                   node_config.get_location_index())
            for node_policy in list_dos_policy:
                self.convert_ips_dos(node_dos_policy, node_policy)

    def convert_config_firewall_sniffInterface_policy6(self):

        config = "config"
        key = "set"
        list_value = ["config", "firewall", "sniff-interface-policy6"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_log = ["set", "logtraffic", "enable"]
        list_dos_policy = []

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # rename option "enable" in "set logtraffic" into "all"
            node_log = node_edit.child_branch.find_tree_node(key, list_log)
            if node_log.node_type.value > 0:
                node_log.rename_option("all")

    def convert_config_firewall_ssl_setting(self):

        config = "config"
        key = "set"
        list_value = ["config", "firewall", "ssl", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_caname = ["set", "caname"]
        list_ssl_max = ["set", "ssl-max-version"]
        list_ssl_min = ["set", "ssl-min-version"]

        # remove field "ssl-max-version" and "ssl-min-version"
        node_config.child_branch.loose_find_and_remove_node(key, list_ssl_max)
        node_config.child_branch.loose_find_and_remove_node(key, list_ssl_min)

        node_caname = self.curr_vdom_root.loose_find_tree_node(
            key, list_caname)
        if node_caname.node_type.value == 0:
            return

        node_caname.remove_tree_node()

        # move "set caname" into "config firewall deep-inspection-options"
        list_value = ["config", "firewall", "deep-inspection-options"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_clone = node_caname.clone(None)
            node_edit.insert_tree_node(node_clone, 0)

    def convert_config_ips_global(self):

        config = "config"
        set = "set"
        list_value = ["config", "ips", "global"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_ignore_session_bytes = ["set", "ignore-session-bytes"]
        list_ips_opt = ["set", "ips-opt"]
        node_config.child_branch.loose_find_and_remove_node(
            set, list_ignore_session_bytes)
        node_config.child_branch.loose_find_and_remove_node(set, list_ips_opt)

    def convert_config_ips_dos(self):

        # remove command "config ips Dos"
        key = "config"
        list_ips_dos = ["config", "ips", "DoS"]
        self.curr_vdom_root.find_and_remove_node(key, list_ips_dos)

    def convert_config_log_filter(self):

        key = "config"
        list_value = ["config", "log"]
        list_node = self.curr_vdom_root.loose_match_tree_node(key, list_value)
        list_node_log = []
        for node_log in list_node:
            if node_log.list_value[-1] == "filter":
                list_node_log.append(node_log)

        if len(list_node_log) == 0:
            return

        key = "set"
        list_extended_log = ["set", "extended-traffic-log"]
        list_upload_format = ["set", "upload-format"]

        is_extended_log = False

        for node_config in list_node_log:
            # remove field "set upload-format"
            node_config.child_branch.loose_find_and_remove_node(
                key, list_upload_format)

            # remove field "set extended-traffic-log"
            node_extended_log = node_config.child_branch.loose_find_tree_node(
                key, list_extended_log)
            if node_extended_log.node_type.value > 0:
                node_extended_log.remove_tree_node()
                option = node_extended_log.list_value[-1]
                if option == "enable":
                    is_extended_log = True

        # use field "set log-invalid-packet" in "config log setting" to replace "set extended-traffic-log"
        if is_extended_log:
            key = "config"
            list_value = ["config", "log", "setting"]
            obj_parent = list_node_log[0].parent_branch
            insert_idx = list_node_log[0].get_location_index()
            node_log_settings = obj_parent.find_or_create_config_node(
                key, list_value, insert_idx)

            key = "set"
            list_value = ["set", "log-invalid-packet", "enable"]
            node_log_settings.create_leaf_node(key, list_value, 0)

    def convert_config_log_disk_setting50(self):

        key = "config"
        list_value = ["config", "log", "disk", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_ms = ["set", "ms-per-transaction"]
        list_rows = ["set", "rows-per-transaction"]
        list_sql_max_size = ["set", "sql-max-size"]
        list_sql_max_size_action = ["set", "sql-max-size-action"]
        list_sql_oldest_entry = ["set", "sql-oldest-entry"]

        # remove fields "set ms-per-transaction", "set rows-per-transaction",
        # "set sql-max-size", "set sql-max-size-action", "set sql-oldest-entry"

        node_config.child_branch.loose_find_and_remove_node(key, list_ms)
        node_config.child_branch.loose_find_and_remove_node(key, list_rows)
        node_config.child_branch.loose_find_and_remove_node(
            key, list_sql_max_size)
        node_config.child_branch.loose_find_and_remove_node(
            key, list_sql_max_size_action)
        node_config.child_branch.loose_find_and_remove_node(
            key, list_sql_oldest_entry)

    def convert_config_log_remote_setting(self):

        key = "config"
        list_value = ["config", "log", "remote", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

    def convert_config_log_eventfilter50(self):

        key = "config"
        list_value = ["config", "log", "eventfilter"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"

        list_amc = ["set", "amc-intf-bypass"]
        list_chasis = ["set", "chassis-loadbalance-ha"]
        list_cpu = ["set", "cpu-memory-usage"]
        list_ha = ["set", "ha"]
        list_ldb = ["set", "ldb-monitor"]

        list_auth = ["set", "auth"]
        list_radius = ["set", "radius"]

        list_config = ["set", "config"]
        list_admin = ["set", "admin"]

        list_ipsec = ["set", "ipsec"]
        list_vpn_auth = ["set", "sslvpn-log-auth"]
        list_vpn_adm = ["set", "sslvpn-log-adm"]
        list_vpn_session = ["set", "sslvpn-log-session"]

        list_dhcp = ["set", "dhcp"]
        list_ppp = ["set", "ppp"]
        list_vip = ["set", "vip-ssl"]
        list_gtp = ["set", "gtp"]
        list_notification = ["set", "notification"]

        list_pattern = ["set", "pattern"]
        list_forti = ["set", "forticlient"]
        list_mms = ["set", "mms-stats"]

        list_nac = ["set", "nac-quarantine"]
        list_voip = ["set", "voip"]

        disable_count = 0
        node = node_config.child_branch.loose_find_tree_node(key, list_amc)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_chasis)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_cpu)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_ha)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_ldb)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        # convert "set amc-intf-bypass", "set chassis-loadbalance-ha",
        # "set cpu-memory-usage", "set ha", "set ldb-monitor" into "set system"
        if disable_count == 5:
            # disable the new field only when all the old fields are desabled
            list_system = ["set", "system", "disable"]
            node_config.create_leaf_node(key, list_system, 0)

        disable_count = 0

        node = node_config.child_branch.loose_find_tree_node(key, list_auth)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_radius)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        # convert "set auth", "set radius" into "set user"
        if disable_count == 2:
            # disable the new field only when all the old fields are desabled
            list_system = ["set", "user", "disable"]
            node_config.create_leaf_node(key, list_system, 0)

        # remove field "set config" and "set admin"
        node_config.child_branch.loose_find_and_remove_node(key, list_config)
        node_config.child_branch.loose_find_and_remove_node(key, list_admin)

        disable_count = 0

        node = node_config.child_branch.loose_find_tree_node(key, list_ipsec)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(
            key, list_vpn_auth)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_vpn_adm)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(
            key, list_vpn_session)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        # convert "set ipsec", "set sslvpn-log-auth", "set sslvpn-log-adm",
        # "set sslvpn-log-session" into "set vpn"
        if disable_count == 4:
            # disable the new field only when all the old fields are desabled
            list_system = ["set", "vpn", "disable"]
            node_config.create_leaf_node(key, list_system, 0)

        disable_count = 0
        node = node_config.child_branch.loose_find_tree_node(key, list_dhcp)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_ppp)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_vip)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_gtp)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(
            key, list_notification)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        # convert fields "set dhcp", "set ppp", "set vip-ssl", "set gtp", "set notification" into "set network"
        if disable_count == 5:
            # disable the new field only when all the old fields are desabled
            list_system = ["set", "network", "disable"]
            node_config.create_leaf_node(key, list_system, 0)

        disable_count = 0
        node = node_config.child_branch.loose_find_tree_node(key, list_pattern)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_forti)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        node = node_config.child_branch.loose_find_tree_node(key, list_mms)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                disable_count += 1

        # convert fields "set pattern", "set forticlient", "set mms-status" into "set utm"
        if disable_count == 3:
            # disable the new field only when all the old fields are desabled
            list_system = ["set", "utm", "disable"]
            node_config.create_leaf_node(key, list_system, 0)

        node_config.child_branch.loose_find_and_remove_node(key, list_nac)

        is_voip = False
        node = node_config.child_branch.loose_find_tree_node(key, list_voip)
        if node.node_type.value > 0:
            node.remove_tree_node()
            if node.list_value[-1] == "disable":
                is_voip = True

        # convert fields "set voip" into "set voip"
        # in "config log XXX filter"
        if is_voip:
            key = "config"
            list_value = ["config", "log"]
            list_node = self.curr_vdom_root.loose_match_tree_node(
                key, list_value)
            list_node_log = []
            for node_log in list_node:
                if node_log.list_value[-1] == "filter":
                    list_node_log.append(node_log)

            if len(list_node_log) == 0:
                return

            list_voip.append("disable")

            key = "set"

            for node_filter in list_node_log:
                if node_filter.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                    if is_voip:
                        insert_idx = node_filter.get_last_leaf_index()
                        node_filter.create_leaf_node(
                            key, list_voip, insert_idx)

    def convert_config_log_forti_analyzer(self):

        key = "config"
        list_value = ["config", "log", "fortianalyzer", "filter"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type == 0:
            return

        node_config.remove_tree_node()

    def convert_config_log_settings(self):

        key = "config"
        list_value = ["config", "log"]
        list_node = self.curr_vdom_root.loose_match_tree_node(key, list_value)
        list_node_log = []
        for node_log in list_node:
            if node_log.list_value[-1] == "setting" and len(node_log.list_value) == 4:
                list_node_log.append(node_log)

        if len(list_node_log) == 0:
            return

        key = "set"
        list_buffer = ["set", "buffer-max-send"]
        list_max_buffer = ["set", "max-buffer-size"]
        list_address = ["set", "address-mode"]
        list_fdp_device = ["set", "fdp-device"]
        list_fdp_interface = ["set", "fdp-interface"]

        # remove fields "set buffer-max-send", "set max-buffer-size", "set address-mode", "set fdp-device", "set fdp-interface"
        for node_config in list_node_log:
            node_config.child_branch.loose_find_and_remove_node(
                key, list_buffer)
            node_config.child_branch.loose_find_and_remove_node(
                key, list_max_buffer)
            node_config.child_branch.loose_find_and_remove_node(
                key, list_address)
            node_config.child_branch.loose_find_and_remove_node(
                key, list_fdp_device)
            node_config.child_branch.loose_find_and_remove_node(
                key, list_fdp_interface)

    def convert_config_log_syslogd_filter(self):
        '''
        Remove these commands : 
        config log syslogd filter
        set attack disable
        set email disable

        set traffic disable
        set virus disable
        set web disable
        end 
        '''
        config = "config"
        set = "set"
        list_attack = ["set", "attack"]
        list_email = ["set", "email"]
        list_traffic = ["set", "traffic"]
        list_virus = ["set", "virus"]
        list_web = ["set", "web"]
        list_explicit_proxy_traffic = ["set", "explicit-proxy-traffic"]
        list_wanopt_traffic = ["set", "wanopt-traffic"]
        list_webcache_traffic = ["set", "webcache-traffic"]
        list_allowed = ["set", "allowed"]
        list_violation = ["set", "violation"]

        list_postfix = ["", "2", "3", "4"]

        for postfix in list_postfix:

            list_value = ["config", "log", "syslogd" + postfix, "filter"]
            node_config = self.curr_vdom_root.find_tree_node(
                config, list_value)
            if node_config.node_type.value == 0:
                continue

            node_config.child_branch.loose_find_and_remove_node(
                set, list_attack)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_email)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_traffic)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_virus)
            node_config.child_branch.loose_find_and_remove_node(set, list_web)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_explicit_proxy_traffic)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_wanopt_traffic)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_webcache_traffic)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_allowed)
            node_config.child_branch.loose_find_and_remove_node(
                set, list_violation)

    def convert_config_log_webtrends_filter(self):
        '''
        Remove these commands : 
            config log webtrends filter
                set attack disable
                set email disable

                set traffic disable
                set virus disable
                set web disable
            end
        '''
        key = "config"
        list_value = ["config", "log", "webtrends", "filter"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            key = "set"
            list_attack = ["set", "attack"]
            node_config.child_branch.loose_find_and_remove_node(
                key, list_attack)

            list_email = ["set", "email"]
            node_config.child_branch.loose_find_and_remove_node(
                key, list_email)

            list_traffic = ["set", "traffic"]
            node_config.child_branch.loose_find_and_remove_node(
                key, list_traffic)

            list_virus = ["set", "virus"]
            node_config.child_branch.loose_find_and_remove_node(
                key, list_virus)

            list_web = ["set", "web"]
            node_config.child_branch.loose_find_and_remove_node(key, list_web)

    def convert_config_log_gui(self):

        key = "config"
        list_value = ["config", "log", "gui"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

    def convert_config_log_memory_setting(self):

        key = "config"
        list_value = ["config", "log", "memory", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set ips-archive"
        key = "set"
        list_value = ["set", "ips-archive"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_log_setting50(self):

        key = "config"
        list_value = ["config", "log", "setting"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # move fields "set resolve-apps" and "set resolve-hosts" to command "config log gui-display"
        key = "set"
        list_apps = ["set", "resolve-apps"]
        list_hosts = ["set", "resolve-hosts"]

        node_apps = node_config.child_branch.loose_find_tree_node(
            key, list_apps)
        node_hosts = node_config.child_branch.loose_find_tree_node(
            key, list_hosts)

        if node_apps.node_type.value == 0 and node_hosts.node_type.value == 0:
            return

        key = "config"
        list_value = ["config", "log", "gui-display"]
        node_config = node_config.parent_branch.find_or_create_config_node(key, list_value,
                                                                           node_config.get_location_index())
        if node_config.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            insert_idx = node_config.get_last_leaf_index()
            if node_apps.node_type.value > 0:
                node_config.move_tree_node(node_apps, insert_idx)
                insert_idx += 1

            if node_hosts.node_type.value > 0:
                node_config.move_tree_node(node_hosts, insert_idx)
                insert_idx += 1

    def convert_config_netscan_settings(self):

        key = "config"
        list_value = ["config", "netscan", "settings"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_os = ["set", "os-detection", "default"]
        list_service = ["set", "service-detection", "default"]
        list_tcp = ["set", "tcp-scan", "default"]
        list_udp = ["set", "udp-scan", "default"]

        # rename option "default" into "auto" in fields "set os-detection",
        # "set service-detection", "set tcp-scan", "set udp-scan"
        node = node_config.child_branch.find_tree_node(key, list_os)
        if node.node_type.value > 0:
            node.rename_option("auto")

        node = node_config.child_branch.find_tree_node(key, list_service)
        if node.node_type.value > 0:
            node.rename_option("auto")

        node = node_config.child_branch.find_tree_node(key, list_tcp)

        if node.node_type.value > 0:
            node.rename_option("auto")

        node = node_config.child_branch.find_tree_node(key, list_udp)

        if node.node_type.value > 0:
            node.rename_option("auto")

    def convert_config_report_chart(self):

        # remove command "config report chart"
        key = "config"
        list_value = ["config", "report", "chart"]
        self.curr_vdom_root.find_and_remove_node(key, list_value)

    def convert_config_report_layout(self):

        key = "config"
        list_value = ["config", "report", "layout"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ["set", "schedule-type", "once"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # rename option "once" into "demand" in field "set schedule-type"
            node_set = node_config.child_branch.find_tree_node(key, list_value)
            if node_set.node_type.value > 0:
                node_set.rename_option("demand")

    def convert_config_report_summary(self):

        # remove command "config report summary"
        key = "config"
        list_value = ["config", "report", "summary"]
        self.curr_vdom_root.find_and_remove_node(key, list_value)

    def convert_config_router_gwdetect50(self):

        key = "config"
        list_value = ["config", "router", "gwdetect"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        id = 0

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # move "edit <interface name>" into the field "set interface"
            intf_name = node_edit.list_value[-1]
            node_edit.rename_edit_name(str(id))
            list_value = ["set", "interface", intf_name]
            node_edit.create_leaf_node(key, list_value, 0)
            id += 1

    def convert_config_spamfilter_profile(self):

        key = "config"
        list_value = ["config", "spamfilter", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        list_imaps = ["config", "imaps"]
        list_pop3s = ["config", "pop3s"]
        list_smtps = ["config", "smtps"]
        list_options = ["set", "options"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.find_and_remove_node(key, list_imaps)
            node_edit.child_branch.find_and_remove_node(key, list_pop3s)
            node_edit.child_branch.find_and_remove_node(key, list_smtps)

            '''
            In 4.x series we use 'spamemailbwl' to filter email using a black/white list.
            In 5.x series we use 'spambwl'.
            '''
            node_edit.child_branch.find_and_rename_options(
                "set", list_options, "spamemailbwl", "spambwl")

    def convert_config_spamfilter_bwl(self):

        def find_created_bwl_id(dic_pair, email_table_id, ip_table_id):

            for keys, values in dic_pair.items():
                for k, v in values.items():
                    if k == email_table_id and v == ip_table_id:
                        return keys

            return -1

        def merge_bwl_nodes(node_email, node_ip, id):

            config = "config"
            key = "set"
            insert_idx = 0

            node_merged = FGTNode()
            node_merged.key = "edit"
            node_merged.list_value = ["edit", str(id)]
            node_merged.node_type = FGTNodeType.FGTNODE_TYPE_BRANCH
            node_merged.child_branch = FGTObject()
            node_merged.child_branch.associate_node = node_merged
            node_merged.child_branch.list_child = []

            node_clone = None
            if not node_email:
                node_clone = node_ip.clone(None)
            elif not node_ip:
                node_clone = node_email.clone(None)

            if node_clone:
                for node in node_clone.child_branch.list_child:
                    node_merged.insert_tree_node(node, insert_idx)
                    insert_idx += 1

                return node_merged

            next = "next"
            list_value = ["next"]
            node_merged.create_leaf_node(next, list_value, 0)

            list_name = ["set", "name"]
            list_comment = ["set", "comment"]
            node_email_name = node_email.child_branch.loose_find_tree_node(
                key, list_name)
            node_ip_name = node_ip.child_branch.loose_find_tree_node(
                key, list_name)

            email_name = None
            ip_name = None
            if node_email_name.node_type.value > 0:
                email_name = remove_quota(node_email_name.list_value[-1])
            if node_ip_name.node_type.value > 0:
                ip_name = remove_quota(node_ip_name.list_value[-1])

            name = ""
            if not email_name:
                name = "IP_" + ip_name
            elif not ip_name:
                name = "Email_" + email_name
            else:
                name = "Email_" + email_name + "_IP_" + ip_name

            if name != "":
                list_value = ["set", "name", name]
                node_merged.create_leaf_node(key, list_value, insert_idx)
                insert_idx += 1

            node_email_comment = node_email.child_branch.loose_find_tree_node(
                key, list_comment)
            node_ip_comment = node_ip.child_branch.loose_find_tree_node(
                key, list_comment)

            email_comment = None
            ip_comment = None
            if node_email_comment.node_type.value > 0:
                email_comment = remove_quota(
                    node_email_comment, list_value[-1])
            if node_ip_comment.node_type.value > 0:
                ip_comment = remove_quota(node_ip_comment.list_value[-1])

            comment = ""
            if ip_comment and email_comment:
                comment = "Email - " + email_comment + " - IP - " + ip_comment
            elif email_comment:
                comment = email_comment
            elif ip_comment:
                comment = ip_comment

            if comment != "":
                list_value = ["set", "comment", comment]
                node_merged.create_leaf_node(list_value, insert_idx)
                insert_idx += 1

            list_entries = ["config", "entries"]
            node_merged.child_branch.create_blank_config_node(
                list_entries, node_merged.get_last_leaf_index())
            node_merged_entries = node_merged.child_branch.find_tree_node(
                config, list_entries)
            entries_idx = 0

            node_entries = node_email.child_branch.find_tree_node(
                config, list_entries)
            if node_entries.node_type.value > 0:
                node_entries_clone = node_entries.clone(None)
                for node_edit in node_entries_clone.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        node_merged_entries.insert_tree_node(
                            node_edit, entries_idx)
                        entries_idx += 1

            node_entries = node_ip.child_branch.find_tree_node(
                config, list_entries)
            if node_entries.node_type.value > 0:
                node_entries_clone = node_entries.clone(None)
                for node_edit in node_entries_clone.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        node_merged_entries.insert_tree_node(
                            node_edit, entries_idx)
                        entries_idx += 1

            entry_id = 0
            while entry_id < entries_idx:
                node_entry = node_merged_entries.child_branch.list_child[entry_id]
                node_entry.rename_edit_name(str(entry_id + 1))
                entry_id += 1

            return node_merged

        config = "config"
        key = "set"
        list_value = ["config", "spamfilter", "emailbwl"]
        node_email = self.curr_vdom_root.find_tree_node(config, list_value)

        list_value = ["config", "spamfilter", "ipbwl"]
        node_ip = self.curr_vdom_root.find_tree_node(config, list_value)

        if node_email.node_type.value == 0 and node_ip.node_type.value == 0:
            return

        obj_parent = node_email.parent_branch
        bwl_location = node_email.get_location_index()
        dic_email = dict()
        dic_ip = dict()

        list_entries = ["config", "entries"]

        # add "set type email" for entries in emailbwl
        if node_email.node_type.value > 0:
            for node_edit in node_email.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_entries = node_edit.child_branch.find_tree_node(
                    config, list_entries)
                if node_entries.node_type.value > 0:
                    list_type = ["set", "type", "email"]
                    for node_entry in node_entries.child_branch.list_child:
                        if node_entry.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                            node_entry.create_leaf_node(key, list_type, 0)

                id = node_edit.list_value[-1]
                dic_email[id] = node_edit
            node_email.remove_tree_node()

        # add "set type ip" for entries in ipbwl
        if node_ip.node_type.value > 0:
            for node_edit in node_ip.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_entries = node_edit.child_branch.find_tree_node(
                    config, list_entries)
                if node_entries.node_type.value > 0:
                    list_type = ["set", "type", "ip"]
                    for node_entry in node_entries.child_branch.list_child:
                        if node_entry.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                            node_entry.create_leaf_node(key, list_type, 0)

                id = node_edit.list_value[-1]
                dic_ip[id] = node_edit

            node_ip.remove_tree_node()

        # reorder bwl table and recreate needed bwl tables
        list_value = ["config", "spamfilter", "profile"]
        node_profile = self.curr_vdom_root.find_tree_node(config, list_value)

        if node_profile.node_type.value == 0:
            return

        list_email = ["set", "spam-emaddr-table"]
        list_ip = ["set", "spam-ipbwl-table"]

        dic_pair = dict()
        dic_bwl = dict()

        for node_edit in node_profile.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            email_table_id = ""
            ip_table_id = ""
            node_email_table = node_edit.child_branch.loose_find_tree_node(
                key, list_email)
            node_ip_table = node_edit.child_branch.loose_find_tree_node(
                key, list_ip)
            node_email = None
            node_ip = None
            if node_email_table.node_type.value == 0 and node_ip_table.node_type.value == 0:
                continue

            # remove field "set spam-emailbwl-table" and "set spam-ipbwl-table"
            if node_email_table.node_type.value > 0:
                email_table_id = node_email_table.list_value[-1]
                if email_table_id in dic_email:
                    node_email = dic_email[email_table_id]
                node_email_table.remove_tree_node()

            if node_ip_table.node_type.value > 0:
                ip_table_id = node_ip_table.list_value[-1]
                if ip_table_id in dic_ip:
                    node_ip = dic_ip[ip_table_id]
                node_ip_table.remove_tree_node()

            # find of create new bwl table
            create_id = find_created_bwl_id(
                dic_pair, email_table_id, ip_table_id)

            if create_id >= 0:
                list_bwl = ["set", "spam-bwl-table", str(create_id)]
                node_edit.create_leaf_node(
                    key, list_bwl, node_edit.get_last_leaf_index())
            else:
                # merge the ipbwl table and emailbwl table together to create a new bwl table
                id = len(dic_bwl) + 1
                node_merged = merge_bwl_nodes(node_email, node_ip, id)
                list_bwl = ["set", "spam-bwl-table", str(id)]
                node_edit.create_leaf_node(
                    key, list_bwl, node_edit.get_last_leaf_index())
                dic_bwl[id] = node_merged
                dic_pair[id] = {email_table_id: ip_table_id}

        # combine emailbwl and ipbwl into command "config spamfilter bwl"
        list_value = ["config", "spamfilter", "bwl"]
        node_bwl = obj_parent.create_blank_config_node(
            list_value, bwl_location)
        for bwl in range(1, len(dic_bwl) + 1):
            node_bwl.insert_tree_node(dic_bwl[bwl], bwl - 1)

    def convert_config_system_accprofile(self):

        key = "config"
        list_value = ["config", "system", "accprofile"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "menu-file"
        list_set_menu_file = ["set", "menu-file"]
        list_unset_menu_file = ["unset", "menu-file"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_set_menu_file)
            key = "unset"
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_unset_menu_file)

    def convert_config_system_admin(self):

        config = "config"
        key = "set"
        list_value = ["config", "system", "admin"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        obj_parent = node_config.parent_branch
        list_gui_location = ["set", "gui-log-location"]
        list_gui_detail_location = ["set", "gui-detail-panel-location"]
        list_log_setting = ["config", "log", "setting"]

        # move field "set gui-log-location" to "config log setting"
        node_gui = node_config.child_branch.loose_find_tree_node(
            key, list_gui_location)
        if node_gui.node_type.value > 0:
            node_log = obj_parent.find_or_create_config_node(
                config, list_log_setting, node_config.get_location_index())
            if node_log.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                node_gui.rename_field("gui-location")
                node_log.move_tree_node(
                    node_gui, node_log.get_last_leaf_index())

        # remove field "set gui-detail-panel-location"
        node_config.child_branch.loose_find_and_remove_node(
            key, list_gui_detail_location)

        list_dash_board = ["config", "dashboard"]
        node_dash_board = node_config.child_branch.find_tree_node(
            config, list_dash_board)
        if node_dash_board.node_type.value > 0:
            # remove "destination-location" and "destination-port" in field "set report-by"
            list_report_by = ["set", "report-by"]
            list_to_be_removed = ["destination-location", "destination-port"]
            list_widget_type = ["set", "widget-type", "per-ip-usage"]

            for node_edit in node_dash_board.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_edit.child_branch.find_and_remove_node(
                    key, list_widget_type)
                node_edit.child_branch.find_and_remove_options(
                    key, list_report_by, list_to_be_removed)

    def convert_config_system_alertemail(self):

        key = "config"
        list_value = ["config", "system", "alertemail"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # rename command "config system alertemail" into "config system email-server"
        list_email = ["config", "system", "email-server"]
        node_config.rename_command(list_email)

    def convert_config_system_dhcp_server(self):

        key = "config"
        list_value = ["config", "system", "dhcp", "server"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # rename field "set enable" into "set status"
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            list_enable = ["set", "enable"]
            node_config.child_branch.find_and_rename_field(
                key, list_enable, "status")

    def convert_config_system_dhcp_reservedaddress(self):

        key = "config"
        list_value = ["config", "system", "dhcp", "reserved-address"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

    def convert_config_system_autoupdate(self):

        config = "config"
        key = "set"
        list_value = ["config", "system", "autoupdate", "clientoverride"]
        node_client = self.curr_vdom_root.find_tree_node(config, list_value)
        list_value = ["config", "system", "autoupdate", "override"]
        node_override = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_client.node_type.value == 0 and node_override.node_type.value == 0:
            return

        # remove command "config system autoupdate clientoverride" and "config system autoupdate override"
        is_override_enable = False
        list_status = ["set", "status"]
        if node_client.node_type.value > 0:
            node_status = node_client.child_branch.loose_find_tree_node(
                key, list_status)
            if node_status.node_type.value > 0:
                option = node_status.list_value[-1]
                if option == "enable":
                    is_override_enable = True

        if node_override.node_type.value > 0 and not is_override_enable:
            node_status = node_override.child_branch.loose_find_tree_node(
                key, list_status)
            if node_status.node_type.value > 0:
                option = node_status.list_value[-1]
                if option == "enable":
                    is_override_enable = True

        # convert into "set fortimanager-fds-override enable" in "config system central-management"
        if is_override_enable:
            node = node_client if node_client.node_type.value > 0 else node_override
            obj_parent = node.parent_branch
            if not obj_parent:
                obj_parent = node_override.parent_branch
            list_value = ["config", "system", "central-management"]
            node_config = obj_parent.find_or_create_config_node(
                config, list_value, node.get_location_index())
            if node_config.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                list_override = ["set", "fortimanager-fds-override", "enable"]
                node_config.create_leaf_node(
                    key, list_override, node_config.get_last_leaf_index())

        node_client.remove_tree_node()
        node_override.remove_tree_node()

    def convert_config_system_fortiguard(self):

        key = "config"
        list_value = ["config", "system", "fortiguard"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

    def convert_config_system_fortiguardlog(self):

        config = "config"
        key = "set"
        list_value = ["config", "system", "fortiguard-log"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove command "config system fortiguard-log" and convert the content into "config log fortiguard setting"
        list_status = ["set", "status", "enable"]
        list_source_ip = ["set", "source-ip"]
        node_source_ip = node_config.child_branch.loose_find_tree_node(
            key, list_source_ip)
        if node_source_ip.node_type.value > 0:
            list_log = ["config", "log", "fortiguard", "setting"]
            node_log = node_config.parent_branch.find_or_create_config_node(config, list_log,
                                                                            node_config.get_location_index())
            node_log.move_tree_node(node_source_ip, 0)
            node_log.create_leaf_node(key, list_status, 0)

        node_config.remove_tree_node()

    def convert_config_system_global50(self):

        config = "config"
        key = "set"
        list_value = ["config", "system", "global"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # rename field "access banner"
        list_access = ["set", "access-banner"]
        node_config.child_branch.find_and_rename_field(
            key, list_access, "pre-login-banner")

        # move field "auth-lockout-duration" and "auth-lockout-threshold" to "config user setting"
        list_duration = ["set", "auth-lockout-duration"]
        list_threshold = ["set", "auth-lockout-threshold"]
        list_node_auth_lockout = []
        node_duration = node_config.child_branch.loose_find_tree_node(
            key, list_duration)
        if node_duration.node_type.value > 0:
            list_node_auth_lockout.append(node_duration)

        node_threshold = node_config.child_branch.loose_find_tree_node(
            key, list_threshold)
        if node_threshold.node_type.value > 0:
            list_node_auth_lockout.append(node_threshold)

        if len(list_node_auth_lockout) > 0:
            list_user = ["config", "user", "setting"]
            obj_parent = node_config.parent_branch
            node_user = obj_parent.find_or_create_config_node(
                config, list_user, node_config.get_location_index() + 1)
            if node_user.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                for node in list_node_auth_lockout:
                    node_user.move_tree_node(
                        node, node_user.get_last_leaf_index())

        # remove field "set detection-summary"
        list_detection = ["set", "detection-summary"]
        node_config.child_branch.loose_find_and_remove_node(
            key, list_detection)

        # remove field "set gui-implicit-id-based-policy" and replace by "set gui-implicit-policy"
        list_implicit_id_based = ["set", "gui-implicit-id-based-policy"]
        list_implicit = ["set", "gui-implicit-policy"]
        node_id_based = node_config.child_branch.loose_find_tree_node(
            key, list_implicit_id_based)
        if node_id_based.node_type.value > 0:
            is_id_base_enable = node_id_based.list_value[-1] == "enable"
            if is_id_base_enable:
                node_implicit = node_config.child_branch.loose_find_tree_node(
                    key, list_implicit)
                if node_implicit.node_type.value > 0:
                    node_implicit.rename_option("enable")
                else:
                    list_implicit.append("enable")
                    node_config.create_leaf_node(
                        list_implicit, node_id_based.get_location_index())

            node_id_based.remove_tree_node()

        # remove field "set gui-policy-interface-pairs-view"
        list_intf_pairs_view = ["set", "gui-policy-interface-pairs-view"]
        node_config.child_branch.loose_find_and_remove_node(
            key, list_intf_pairs_view)

        # remove field "set usb-lte"
        list_usb_lte = ["set", "usb-lte"]
        node_config.child_branch.loose_find_and_remove_node(key, list_usb_lte)

        # remove field "set max-sql-log-size"
        list_max_sql = ["set", "max-sql-log-size"]
        node_config.child_branch.loose_find_and_remove_node(key, list_max_sql)

        # remove option "wtp" in field "set wireless-mode"
        list_wireless = ["set", "wireless-mode"]
        list_to_be_removed = ["wtp"]
        node_config.child_branch.find_and_remove_options(
            key, list_wireless, list_to_be_removed)

        # move field "set fwpolicy-implicit-log", "set fwpolicy6-implicit-log" and "set log-user-in-upper" into
        # "config log setting" and  remove field "set loglocaldeny"
        list_fw_policy = ["set", "fwpolicy-implicit-log"]
        list_fw_policy6 = ["set", "fwpolicy6-implicit-log"]
        list_user_upper = ["set", "log-user-in-upper"]
        list_local_deny = ["set", "loglocaldeny"]
        list_log_setting = ["config", "log", "setting"]

        node_log = self.curr_vdom_root.find_or_create_config_node(config, list_log_setting,
                                                                  node_config.get_location_index() + 1)
        if node_log.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            node_fw_policy = node_config.child_branch.loose_find_tree_node(
                key, list_fw_policy)
            if node_fw_policy.node_type.value > 0:
                node_log.move_tree_node(
                    node_fw_policy, node_log.get_last_leaf_index())

            node_fw_policy6 = node_config.child_branch.loose_find_tree_node(
                key, list_fw_policy6)
            if node_fw_policy6.node_type.value > 0:
                node_log.move_tree_node(
                    node_fw_policy6, node_log.get_last_leaf_index())

            node_user_upper = node_config.child_branch.loose_find_tree_node(
                key, list_user_upper)
            if node_user_upper.node_type.value > 0:
                node_log.move_tree_node(
                    node_user_upper, node_log.get_last_leaf_index())

        node_local_deny = node_config.child_branch.loose_find_tree_node(
            key, list_local_deny)
        if node_local_deny.node_type.value > 0:
            node_local_deny.remove_tree_node()

        list_policy_auth = ["set", "policy-auth-concurrent"]
        node_policy_auth = node_config.child_branch.loose_find_tree_node(
            key, list_policy_auth)
        if node_policy_auth.node_type.value > 0:
            option = node_policy_auth.list_value[-1]
            if option == "enable":
                node_policy_auth.rename_option("1")
            elif option == "disable":
                node_policy_auth.rename_option("0")

        list_sslvpn_sport = ["set", "sslvpn-sport"]
        node_sslvpn_sport = node_config.child_branch.loose_find_tree_node(
            key, list_sslvpn_sport)
        if node_sslvpn_sport.node_type.value > 0:
            port = node_sslvpn_sport.list_value[2]
            node_sslvpn_sport.remove_tree_node()
            list_sslvpn_setting = ["config", "vpn", "ssl", "settings"]
            list_sslvpn = ["config", "vpn", "ssl"]
            node_sslvpn = self.curr_vdom_root.loose_find_tree_node(
                config, list_sslvpn)
            if node_sslvpn.node_type.value > 0:
                insert_index = node_sslvpn.get_location_index()
                node_sslvpn_setting = self.curr_vdom_root.find_or_create_config_node(config, list_sslvpn_setting,
                                                                                     insert_index)
                list_port = ["set", "port", port]
                node_sslvpn_setting.create_leaf_node(
                    key, list_port, insert_index)

    def convert_config_system_ha(self):

        key = "config"
        list_value = ["config", "system", "ha"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_upgrade = ["set", "uninterruptable-upgrade"]
        node_config.child_branch.find_and_rename_field(
            key, list_upgrade, "uninterruptible-upgrade")

        list_subsecond = ["set", "subsecond"]
        node_config.child_branch.loose_find_and_remove_node(
            key, list_subsecond)

    def convert_config_system_interface50(self):

        key = "config"
        list_value = ["config", "system", "interface"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_allow_access = ["set", "allowaccess"]
        list_log = ["set", "log"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # replace option "dynamin-profile-radius-server" by "radius-acct"
            node_allow_access = node_edit.child_branch.loose_find_tree_node(
                key, list_allow_access)
            if node_allow_access.node_type.value > 0:
                to_be_renamed = "dynamin-profile-radius-server"
                new_name = "radius-acct"
                if to_be_renamed in node_allow_access.list_value:
                    node_allow_access.list_value.remove(to_be_renamed)
                    node_allow_access.list_value.append(new_name)

            node_edit.child_branch.loose_find_and_remove_node(key, list_log)

    def convert_config_system_npu(self):

        key = "config"
        list_value = ["config", "system", "npu"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove field "set elbc-mode"
        key = "set"
        list_elbc = ["set", "elbc-mode"]
        node_config.child_branch.loose_find_and_remove_node(key, list_elbc)

    def convert_config_system_replacemsg50(self):

        # modify those commande of "config system replacemsg"
        key = "config"
        list_value = ["config", "system",
                      "replacemsg", "ftp", "\"ftp-dl-dlp\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"dlp-text\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system",
                      "replacemsg", "ftp", "\"ftp-dl-infected\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"dlp-text\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system",
                      "replacemsg", "http", "http-clientvirus"]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"dlp-text\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system", "replacemsg", "http", "\"http-dlp\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"dlp-html\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system",
                      "replacemsg", "http", "\"http-virus\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"virus-html\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system", "replacemsg",
                      "http", "\"http-client-virus\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"virus-html\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system", "replacemsg",
                      "mail", "\"email-dlp-ban-sender\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"dlp-text\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system",
                      "replacemsg", "mail", "\"email-dlp\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"dlp-text\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system",
                      "replacemsg", "mail", "\"email-virus\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"virus-text\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system",
                      "replacemsg", "mail", "\"smtp-virus\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"virus-text\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system", "replacemsg",
                      "nntp", "\"nntp-dl-infected\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "utm", "\"virus-text\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system", "replacemsg", "nntp", "\"nntp-dlp\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system",
                           "replacemsg", "nntp", "\"nntp-dl-blocked\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        list_value = ["config", "system", "replacemsg",
                      "admin", "\"admin-disclaimer-text\""]
        node = self.curr_vdom_root.find_tree_node(key, list_value)
        list_new_config = ["config", "system", "replacemsg",
                           "admin", "\"pre_admin-disclaimer-text\""]
        if node.node_type.value > 0:
            node.list_value = list_new_config

        # remove all except "config system replacemsg ec endpt-download-portal"
        list_value = ["config", "system", "replacemsg", "ec"]
        list_node = self.curr_vdom_root.loose_match_tree_node(key, list_value)
        if node.node_type.value > 0:
            for node_replace_msg in list_node:
                if node_replace_msg.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                field = node_replace_msg.list_value[-1]
                if field != "\"endpt-download-portal\"":
                    node_replace_msg.remove_tree_node()

    def convert_config_system_session_sync(self):

        config = "config"
        key = "set"
        list_value = ["config", "system", "session-sync"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_service_custom = ["config", "firewall", "service", "custom"]
        node_service_custom = node_config.parent_branch.find_tree_node(
            config, list_service_custom)

        list_filter = ["config", "filter"]
        list_service = ["set", "service"]
        list_port_range = ["set", "tcp-portrange"]
        list_custom_service = ["config", "custom-service"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_filter = node_edit.child_branch.find_tree_node(
                config, list_filter)
            if node_filter.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_service = node_filter.child_branch.loose_find_tree_node(
                key, list_service)
            if node_service.node_type.value == 0:
                continue

            node_service.remove_tree_node()

            if node_service_custom.node_type.value == 0:
                continue

            # find referred service and convert it into the content of "config custom-service"
            service = node_service.list_value[-1]
            node_target_service = node_service_custom.child_branch.find_branch_node_edit(
                service)
            if node_target_service.node_type.value == 0:
                continue

            node_port_range = node_target_service.child_branch.loose_find_tree_node(
                key, list_port_range)
            if node_port_range.node_type.value == 0:
                continue

            port_range = node_port_range.list_value[-1]
            src_port_range = None
            dst_port_range = None
            if ":" in port_range:
                port_range_split = port_range.split(":")
                dst_port_range = port_range_split[0]
                src_port_range = port_range_split[1]
            else:
                dst_port_range = port_range

            node_custom_service = node_filter.child_branch.create_blank_config_node(list_custom_service,
                                                                                    node_filter.get_last_leaf_index())
            node_edit_service = node_custom_service.create_blank_edit_node(
                service, 0)
            list_dst_port_range = ["set", "dst-port-range", dst_port_range]
            node_edit_service.create_leaf_node(key, list_dst_port_range, 0)
            if src_port_range:
                list_src_port_range = ["set", "src-port-range", src_port_range]
                node_edit_service.create_leaf_node(key, list_src_port_range, 0)

    def convert_config_system_storage(self):

        config = "config"
        list_value = ["config", "system", "storage"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # Right now, we only simple remove this settings.
        node_config.remove_tree_node()

    def convert_config_user_group(self):

        key = "config"
        list_value = ["config", "user", "group"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_group_type = ["set", "group-type", "directory-service"]
        list_ssl_vpn = ["set", "sslvpn-portal"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # rename option "directory-service" into "fsso-service" in "set group-type"
            node_group_type = node_edit.child_branch.find_tree_node(
                key, list_group_type)
            if node_group_type.node_type.value > 0:
                node_group_type.rename_option("fsso-service")

            # remove field "set sslvpn-portal"
            node_edit.child_branch.loose_find_and_remove_node(
                key, list_ssl_vpn)

    def convert_config_user_radius(self):

        key = "config"
        list_value = ["config", "user", "radius"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # rename "dp-XXX" into "rsso-XXX"
        key = "set"
        list_dp = ["set", "dynamic-profile"]
        list_context = ["set", "dp-context-timeout"]
        list_carrier = ["set", "dp-carrier-endpoint-attribute"]
        list_flush = ["set", "dp-flush-ip-session"]
        list_flags = ["set", "dp-log-dyn-flags"]
        list_period = ["set", "dp-log-period"]
        list_attr = ["set", "dp-profile-attribute"]
        list_attr_key = ["set", "dp-profile-attribute-key"]
        list_response = ["set", "dp-radius-response"]
        list_server = ["set", "dp-radius-server-port"]
        list_secret = ["set", "dp-secret"]
        list_validate = ["set", "dp-validate-request-secret"]

        list_mem = ["set", "dp-mem-percent"]
        list_hold = ["set", "dp-hold-time"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(key, list_mem)
            node_edit.child_branch.loose_find_and_remove_node(key, list_hold)

            node_edit.child_branch.find_and_rename_field(key, list_dp, "rsso")
            node_edit.child_branch.find_and_rename_field(
                key, list_context, "rsso-context-timeout")
            node_edit.child_branch.find_and_rename_field(
                key, list_carrier, "rsso-carrier-endpoint-attribute")
            node_edit.child_branch.find_and_rename_field(
                key, list_flush, "rsso-flush-ip-session")
            node_edit.child_branch.find_and_rename_field(
                key, list_flags, "rsso-log-flags")
            node_edit.child_branch.find_and_rename_field(
                key, list_period, "rsso-log-period")
            node_edit.child_branch.find_and_rename_field(
                key, list_attr, "sso-attribute")
            node_edit.child_branch.find_and_rename_field(
                key, list_attr_key, "sso-attribute-key")
            node_edit.child_branch.find_and_rename_field(
                key, list_response, "rsso-radius-response")
            node_edit.child_branch.find_and_rename_field(
                key, list_server, "rsso-radius-server-port")
            node_edit.child_branch.find_and_rename_field(
                key, list_secret, "rsso-secret")
            node_edit.child_branch.find_and_rename_field(
                key, list_validate, "rsso-validate-request-secret")

    def convert_config_vpn_certificate_ocsp(self):

        key = "config"
        list_value = ["config", "vpn", "certificate", "ocsp"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # rename command "config vpn certificate ocsp" into "config vpn certificate ocsp-server"
        list_value = ["config", "vpn", "certificate", "ocsp-server"]
        node_config.rename_command(list_value)

        key = "set"
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # get the title of "edit" and convert into field "set cert"
            cert = node_edit.list_value[-1]
            node_edit.list_value = ["edit", "ocsp_", cert]
            list_cert = ["set", "cert", cert]
            node_edit.create_leaf_node(key, list_cert, 0)

    def convert_config_vpn_ipsec_phase1interface(self):

        key = "config"
        list_value = ["config", "vpn", "ipsec", "phase1-interface"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # rename field "set monitor" into "set", "monitor"
        key = "set"
        list_monitor = ["set", "monitor-phase1"]
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.find_and_rename_field(
                key, list_monitor, "monitor")

    def convert_config_vpn_ssl_web_portal(self):

        key = "config"
        list_value = ["config", "vpn", "ssl", "web", "portal"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        list_widget = ["config", "widget"]
        list_tunnel = ["set", "tunnel-status"]
        list_bookmarks = ["config", "bookmarks"]
        list_sso = ["set", "sso", "static"]
        list_sso_credential = ["set", "sso-credential", "alternative"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_widget = node_edit.child_branch.find_tree_node(
                key, list_widget)
            if node_widget.node_type.value == 0:
                continue

            node_widget.remove_tree_node()

    def convert_config_wanopt_rule(self):

        config = "config"
        key = "set"
        list_value = ["config", "wanopt", "rule"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # rename command "config wanopt rule" into "config wanopt profile"
        list_value = ["config", "wanopt", "profile"]
        node_config.rename_command(list_value)

        list_auth_group = ["set", "auth-group"]
        list_transparant = ["set", "transparent"]

        list_proto = ["set", "proto"]

        list_byte = ["set", "byte-caching"]
        list_port = ["set", "port"]
        list_secure = ["set", "secure-tunnel"]
        list_ssl = ["set", "ssl"]
        list_status = ["set", "status"]
        list_non_http = ["set", "tunnel-non-http"]
        list_sharing = ["set", "tunnel-sharing"]
        list_unknown = ["set", "unknown-http-version"]

        # keep valid fields
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_profile = node_edit.clone(None)
            del node_edit.child_branch.list_child[0:node_edit.get_last_leaf_index(
            )]

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_auth_group)
            if node.node_type.value > 0:
                node_edit.move_tree_node(node, node_edit.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_transparant)
            if node.node_type.value > 0:
                node_edit.move_tree_node(node, node_edit.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_proto)
            if node.node_type.value == 0:
                continue

            proto = node.list_value[-1]
            list_config_proto = ["config", proto]
            node_config_proto = node_edit.child_branch.create_blank_config_node(list_config_proto,
                                                                                node_edit.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_byte)
            if node.node_type.value > 0:
                node_config_proto.move_tree_node(
                    node, node_config_proto.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_port)
            if node.node_type.value > 0:
                node_config_proto.move_tree_node(
                    node, node_config_proto.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_secure)
            if node.node_type.value > 0:
                node_config_proto.move_tree_node(
                    node, node_config_proto.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_ssl)
            if node.node_type.value > 0:
                node_config_proto.move_tree_node(
                    node, node_config_proto.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_status)
            if node.node_type.value > 0:
                node_config_proto.move_tree_node(
                    node, node_config_proto.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_non_http)
            if node.node_type.value > 0:
                node_config_proto.move_tree_node(
                    node, node_config_proto.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_sharing)
            if node.node_type.value > 0:
                node_config_proto.move_tree_node(
                    node, node_config_proto.get_last_leaf_index())

            node = node_profile.child_branch.loose_find_tree_node(
                key, list_unknown)
            if node.node_type.value > 0:
                node_config_proto.move_tree_node(
                    node, node_config_proto.get_last_leaf_index())

    def convert_config_wanopt_storage(self):

        config = "config"
        list_value = ["config", "wanopt", "storage"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

    def convert_config_wanopt_webcache(self):

        config = "config"
        key = "set"
        list_value = ["config", "wanopt", "webcache"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_exemption = ["set", "cache-exemption"]
        list_exemption_list = ["config", "cache-exemption-list"]

        # move field "set cache-exemption" and "config cache-exemption-list"
        # into "config web-proxy url-match"
        node_exemption = node_config.child_branch.loose_find_tree_node(
            key, list_exemption)
        if node_exemption.node_type.value > 0:
            node_exemption.remove_tree_node()

        node_exemption_list = node_config.child_branch.find_tree_node(
            config, list_exemption_list)
        if node_exemption_list.node_type.value == 0:
            return

        node_exemption_list.remove_tree_node()
        list_url_match = ["config", "web-proxy", "url-match"]
        node_url_match = node_config.parent_branch.create_blank_config_node(list_url_match,
                                                                            node_config.get_location_index() + 1)
        if node_url_match.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            for node_edit in node_exemption_list.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                if node_exemption.node_type.value > 0:
                    node_clone = node_exemption.clone(None)
                    node_edit.insert_tree_node(node_clone, 0)

                node_url_match.insert_tree_node(
                    node_edit, node_url_match.get_last_leaf_index())

    def convert_config_webfilter_profile50(self):

        config = "config"
        key = "set"
        list_value = ["config", "webfilter", "profile"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_activex = ["set", "web-filter-activex"]
        list_ftgd = ["config", "ftgd-wf"]
        list_enable = ["set", "enable"]
        list_disable = ["set", "disable"]
        list_options = ["set", "options"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            # rename field "set web-filter-activex" into "set web-filter-activex-log"
            node_edit.child_branch.find_and_rename_field(
                key, list_activex, "web-filter-activex-log")

            # remove field "set disable" and rename field "set enable" into "set category-override"
            node_ftgd = node_edit.child_branch.find_tree_node(
                config, list_ftgd)
            if node_ftgd.node_type.value > 0:
                node_ftgd.child_branch.find_and_rename_field(
                    key, list_enable, "category-override")
                node_ftgd.child_branch.loose_find_and_remove_node(
                    key, list_disable)
                node_options = node_ftgd.child_branch.loose_find_tree_node(
                    key, list_options)
                if node_options.node_type.value > 0:
                    if "strict-blocking" in node_options.list_value:
                        node_options.list_value.remove("strict-blocking")

                    if "log-all-url" in node_options.list_value:
                        node_options.list_value.remove("log-all-url")

                    if len(node_options.list_value) == 2:
                        node_options.list_value[0] = "unset"
                        node_options.key = "unset"

            node_options = node_edit.child_branch.loose_find_tree_node(
                key, list_options)
            if node_options.node_type.value > 0:
                if "https-scan" in node_options.list_value:
                    node_options.list_value.remove("https-scan")
                    node_options.list_value.append("https-url-scan")

    def convert_config_wireless_controller_global(self):

        key = "config"
        list_value = ["config", "wireless-controller", "global"]
        node_config = self.curr_vdom_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        # remove fields "set max-discoveries", "set ac-discovery-type", "set ac-list",
        # "set ac-port", "set discovery-mc-ttl", "set image-update" and "set max-failed-dtls"
        key = "set"
        list_max_discovery = ["set", "max-discoveries"]
        list_ac_discovery = ["set", "ac-discovery-type"]
        list_ac_list = ["set", "ac-list"]
        list_ac_port = ["set", "ac-port"]
        list_discovery_mc_ttl = ["set", "discovery-mc-ttl"]
        list_image_update = ["set", "image-update"]
        list_max_failed = ["set", "max-failed-dtls"]

        node_config.child_branch.loose_find_and_remove_node(
            key, list_max_discovery)
        node_config.child_branch.loose_find_and_remove_node(
            key, list_ac_discovery)
        node_config.child_branch.loose_find_and_remove_node(key, list_ac_list)
        node_config.child_branch.loose_find_and_remove_node(key, list_ac_port)
        node_config.child_branch.loose_find_and_remove_node(
            key, list_discovery_mc_ttl)
        node_config.child_branch.loose_find_and_remove_node(
            key, list_image_update)
        node_config.child_branch.loose_find_and_remove_node(
            key, list_max_failed)

    def convert_config_wireless_controller_vap(self):

        config = "config"
        key = "set"
        list_value = ["config", "wireless-controller", "vap"]
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        # remove fields "set mac", "set mac-filter", "set mac-filter-policy",
        # "set mac-filter-policy-other", "set passphrase" and command "config mac-filter-list"

        list_mac = ["set", "mac"]
        list_filter = ["set", "mac-filter"]
        list_policy = ["set", "mac-filter-policy"]
        list_other = ["set", "mac-filter-policy-other"]
        # list_pass_phrase = ["set", "passphrase"]
        list_filter_list = ["config", "mac-filter-list"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(key, list_mac)
            node_edit.child_branch.loose_find_and_remove_node(key, list_filter)
            node_edit.child_branch.loose_find_and_remove_node(key, list_policy)
            node_edit.child_branch.loose_find_and_remove_node(key, list_other)
            # node_edit.child_branch.loose_find_and_remove_node(key, list_pass_phrase)
            node_edit.child_branch.find_and_remove_node(
                config, list_filter_list)

    def convert_config_wireless_controller_vapgroup(self):

        # remove command "config wireless-controller vap-group"
        key = "config"
        list_value = ["config", "wireless-controller", "vap-group"]
        self.curr_vdom_root.find_and_remove_node(key, list_value)

    def convert_config(self):

        try:
            self.convert_config_antivirus_profile50()
            self.convert_config_antivirus_quarantine50()
            self.convert_config_antivirus_quarfilepattern()
            self.convert_config_antivirus_settings()
            self.convert_config_application_list50()
            self.convert_config_dlp_compound()
            self.convert_config_dlp_filepattern()
            self.convert_config_dlp_rule()
            self.convert_config_endpoint_control_appDetect_rulelist()
            self.convert_config_endpoint_control_profile()
            self.convert_config_endpoint_control_settings()
            self.convert_config_firewall_interface_policy()
            self.convert_config_firewall_mms_profile()
            self.convert_config_firewall_multicast_policy()
            self.convert_config_firewall_policy50()
            self.convert_config_firewall_profile_protocol_options50()
            self.convert_config_firewall_Service_explicit_web()
            self.convert_config_firewall_service_group_explicit_web()
            self.convert_config_firewall_service_category()
            self.convert_config_firewall_service_predefined()
            self.convert_config_firewall_sniffInterface_policy50()
            self.convert_config_firewall_sniffInterface_policy6()
            self.convert_config_firewall_ssl_setting()
            self.convert_config_ips_global()
            self.convert_config_ips_dos()
            self.convert_config_log_filter()
            self.convert_config_log_disk_setting50()
            self.convert_config_log_remote_setting()
            self.convert_config_log_eventfilter50()
            self.convert_config_log_forti_analyzer()
            self.convert_config_log_settings()
            self.convert_config_log_syslogd_filter()
            self.convert_config_log_webtrends_filter()
            self.convert_config_log_gui()
            self.convert_config_log_memory_setting()
            self.convert_config_log_setting50()
            self.convert_config_netscan_settings()
            self.convert_config_report_chart()
            self.convert_config_report_layout()
            self.convert_config_report_summary()
            self.convert_config_router_gwdetect50()
            self.convert_config_spamfilter_profile()
            self.convert_config_spamfilter_bwl()
            self.convert_config_system_accprofile()
            self.convert_config_system_admin()
            self.convert_config_system_alertemail()
            self.convert_config_system_autoupdate()
            self.convert_config_system_dhcp_server()
            self.convert_config_system_dhcp_reservedaddress()
            self.convert_config_system_fortiguard()
            self.convert_config_system_fortiguardlog()
            self.convert_config_system_global50()
            self.convert_config_system_ha()
            self.convert_config_system_interface50()
            self.convert_config_system_npu()
            self.convert_config_system_replacemsg50()
            self.convert_config_system_session_sync()
            self.convert_config_system_storage()
            self.convert_config_user_group()
            self.convert_config_user_radius()
            self.convert_config_vpn_certificate_ocsp()
            self.convert_config_vpn_ipsec_phase1interface()
            self.convert_config_vpn_ssl_web_portal()
            self.convert_config_wanopt_rule()
            self.convert_config_wanopt_storage()
            self.convert_config_wanopt_webcache()
            self.convert_config_webfilter_profile50()
            self.convert_config_wireless_controller_global()
            self.convert_config_wireless_controller_vap()
            self.convert_config_wireless_controller_vapgroup()

        except Exception as e:
            logging.exception("Convert4.3_5.0 Error")
            raise e

    def convert_config_43_to_50(self):

        key = "config"
        list_global = ["config", "global"]
        list_vdom = ["config", "vdom"]

        node_global = self.config_root.find_tree_node(key, list_global)
        list_node_vdom = self.config_root.strict_match_tree_node(
            key, list_vdom)
        if node_global.node_type.value > 0 and len(list_node_vdom) > 0:
            # Enable VDOM mode.
            self.curr_vdom_root = node_global.child_branch
            self.convert_config()

            for node_vdom in list_node_vdom:
                for node_edit in node_vdom.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node_edit.get_last_leaf_index() > 0:
                        self.curr_vdom_root = node_edit.child_branch
                        self.convert_config()

        elif len(list_node_vdom) == 0 and node_global.node_type.value == 0:
            # Disable VDOM mode.
            self.curr_vdom_root = self.config_root
            self.convert_config()
