from celery_app.fortinet.model.config_tree import FGTNodeType


class Convert62_64:
    def __init__(self, fgt):
        self.config_root = fgt.config_root
        self.output_fgt = fgt
        self.curr_vdom = ""
        self.curr_vdom_root = None

        self.moved_vdom_config = {}

    def convert_system_virtual_wan_link(self):
        config = "config"
        list_value = ("config", "system", "virtual-wan-link")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_new_command = ["config", "system", "sdwan"]
        node_config.rename_command(list_new_command)

        list_zone = ["config", "zone"]
        node_config_zone = node_config.child_branch.create_blank_config_node(
            list_zone, 2)
        node_config_zone.child_branch.create_blank_edit_node(
            "virtual-wan-link", 0)

        list_value = ("config", "service")
        node_services = node_config.child_branch.find_tree_node(
            config, list_value)
        if node_services.node_type.value == 0:
            return

        key = "set"
        list_value = ("set", "sla-compare-method")
        node_services.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_router_static(self):
        config = "config"
        list_value = ("config", "router", "static")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            key = "set"
            list_virtual_wan_link = ("set", "virtual-wan-link")
            node_edit.child_branch.find_and_rename_field(
                key, list_virtual_wan_link, "sdwan")

    def convert_config_antivirus_profile(self):
        config = "config"
        list_value = ("config", "antivirus", "profile")
        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ("set", "scan-mode")
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config_antivirus_settings(self):
        config = "config"
        list_value = ("config", "antivirus", "settings")

        node_config = self.curr_vdom_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ("set", "default-db")
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

    def convert_config(self):
        try:
            self.convert_system_virtual_wan_link()
            self.convert_config_router_static()
            self.convert_config_antivirus_profile()
            self.convert_config_antivirus_settings()

        except Exception as ex:
            print("Convert6.2_6.4 Error")
            raise ex

    def convert_config_62_to_64(self):
        key = "config"
        list_global = ["config", "global"]
        list_vdom = ["config", "vdom"]

        node_global = self.config_root.find_tree_node(key, list_global)
        list_node_vdom = self.config_root.strict_match_tree_node(
            key, list_vdom)

        if node_global.node_type.value > 0 and len(list_node_vdom) > 0:
            # Enable VDOM mode
            self.curr_vdom_root = node_global.child_branch
            self.convert_config()

            for node_vdom in list_node_vdom:
                for node_edit in node_vdom.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node_edit.get_last_leaf_index() > 0:
                        self.curr_vdom = node_edit.list_value[1]
                        self.curr_vdom_root = node_edit.child_branch
                        self.convert_config()

        elif len(list_node_vdom) == 0 and node_global.node_type.value == 0:
            # Disable VDOM mode
            self.curr_vdom = "root"
            self.curr_vdom_root = self.config_root
            self.convert_config()
