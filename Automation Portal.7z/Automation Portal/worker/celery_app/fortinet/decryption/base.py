import csv
import subprocess
from collections import defaultdict
from enum import Enum
from subprocess import PIPE


class CMDBType(Enum):
    CMDB_PROPERTY_PASSWD = 0
    CMDB_PROPERTY_PASSWD2 = 1
    CMDB_PROPERTY_PASSWD3 = 2
    CMDB_PROPERTY_VARLEN_PASSWD = 3
    CMDB_PROPERTY_PASSWD_AES256 = 4


class Decode:
    def __init__(self, type, algorithm, key, err):
        self.type = CMDBType[type],
        self.algorithm = algorithm
        self.key = key
        self.err = err


class CMDBCategoryKeyword:
    def __init__(self, category, key, type, subcategory1="", subcategory2="", subcategory3=""):
        self.category = category.split(' ')
        self.type = CMDBType[type]
        self.key_list = key.split(';')
        self.has_subcategory = len(subcategory1) > 0
        self.subcategory = [category.split(' ') for category in (subcategory1, subcategory2, subcategory3) if
                            category != ""]

    @property
    def cmdb(self):
        return ' '.join(self.category)


class ZeroWorker:
    DECODER = "celery_app/fortinet/decryption/bin/decoder.exe"
    HEX = "-h"

    def __init__(self):
        self.file_path = None
        self.output_dir = None

        self.device = None
        self.curr_vdom_root = None

        self.category_keyword = defaultdict(list)
        self.extract_csv()

        self.csv_file = None
        self.csv_writer = None

    @property
    def hex_csv_path(self):
        file_name = f'{self.file_path.stem}_hex.csv'
        return self.output_dir / file_name

    @property
    def algo_flag(self):
        if not self.device.fos_version or self.device.fos_version == "0.0":
            return "-a"

        if float(self.device.fos_version) > 5.4 or (
                self.device.fos_version == "5.4" and int(self.device.build) >= 1064):
            return "-a"
        else:
            return "-d"

    def extract_csv(self):
        with open('celery_app/fortinet/decryption/category.csv', newline='') as csvfile:
            rows = csv.DictReader(csvfile)

            for row in rows:
                cmdb_category = row['Category']
                if not cmdb_category:
                    continue

                self.category_keyword[cmdb_category].append(CMDBCategoryKeyword(cmdb_category,
                                                                                row['Keyword'],
                                                                                row['Type'],
                                                                                row['Subcategory1'],
                                                                                row['Subcategory2'],
                                                                                row['Subcategory3']))

    def is_multivdom(self, node_global, list_node_vdom):
        return node_global.node_type.value > 0 and len(list_node_vdom) > 0

    def is_singlevdom(self, node_global, list_node_vdom):
        return node_global.node_type.value == 0 and len(list_node_vdom) == 0

    def is_edit_node(self, node_config):
        return set(node.key for node in node_config.child_branch.list_child) & {"edit"}

    def format_output(self, process):
        # stdout format:
        # Type:%s, Algorithm:%s, Result:%s\n
        return_code, stdout, err = process.returncode, \
                                   process.stdout.decode('utf-8').strip(), \
                                   process.stderr
        if return_code != -1:
            decode = Decode(stdout.split(',')[0].split(':')[1],
                            stdout.split(',')[1].split(':')[1],
                            stdout.split(',')[2].split(':')[1],
                            err.decode('utf-8'))
            return decode
        else:
            raise Exception(f"return code: {return_code}, message: {err.decode('utf-8')}")

    def open_csv_file(self):
        self.csv_file = open(self.hex_csv_path, 'w', newline='')
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(["CMDB_Type", "Name", "Field", "hex code"])

    def decode(self, category, enc_list_value, edit_name=""):
        if category.type == CMDBType.CMDB_PROPERTY_PASSWD2:
            # SHA algorithm, no decoding
            print(f"{category.cmdb} -> set {enc_list_value[1]} -> SHA hashed value kept.")
            return enc_list_value

        process = subprocess.run([self.DECODER, str(category.type.value), enc_list_value[-1], self.algo_flag],
                                 stdout=PIPE, stderr=PIPE)
        decode = self.format_output(process)
        if decode.algorithm:
            if decode.key:

                if "?" in decode.key:
                    if self.csv_file is None:
                        self.open_csv_file()

                    print(f"{category.cmdb} -> set {enc_list_value[1]} -> {decode.key} (Decoded by {decode.algorithm})")
                    print(
                        "\tThe decoded string contains '?' so it cannot be imported by CLI. The encrypted string is kept and the decrypted string is listed in the CSV file.");
                    self.csv_writer.writerow([category.cmdb, edit_name, ' '.join(enc_list_value[:2]), decode.key])
                    return enc_list_value
                else:
                    print(f"{category.cmdb} -> set {enc_list_value[1]} -> {decode.key} (Decoded by {decode.algorithm})")
                    return enc_list_value[:2] + [decode.key]
            else:
                print(f"{category.cmdb} -> set {enc_list_value[1]} -> Empty string (Decoded by {decode.algorithm})")
                new_list = enc_list_value[:2]
                new_list[0] = "unset"
                return new_list
        else:
            if self.csv_file is None:
                self.open_csv_file()

            process = subprocess.run(
                [self.DECODER, str(category.type.value), enc_list_value[-1], self.HEX, self.algo_flag],
                stdout=PIPE, stderr=PIPE)
            decode = self.format_output(process)
            if decode.key:
                print(f"{category.cmdb} -> set {enc_list_value[1]} -> Decoding failed and HEX value generated.)")
                self.csv_writer.writerow([category.cmdb, edit_name, ' '.join(enc_list_value[:2]), decode.key])
            else:
                print(
                    f"{category.cmdb} -> set {enc_list_value[1]} -> Decoding failed and HEX value generation failed.)")

            return enc_list_value
