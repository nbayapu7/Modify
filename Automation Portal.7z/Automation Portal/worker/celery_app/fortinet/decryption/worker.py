from celery_app.fortinet.model.config_tree import FGTNodeType
from .base import ZeroWorker


class DecryptionWorker(ZeroWorker):
    def __init__(self, converted_dev):
        super().__init__()

        self.device = converted_dev

    def select_dfs(self, node, subcategory):
        if node.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH or not subcategory:
            return node

        sub_node = node.child_branch.loose_find_tree_node("config", subcategory[0])

        return self.select_dfs(sub_node, subcategory[1:])

    def rewrite_key(self, node, target, key, node_edit=None):
        node_pwd = node.child_branch.loose_find_tree_node("set", ("set", key))
        if node_pwd.list_value:
            node_pwd.list_value = self.decode(target, node_pwd.list_value,
                                              node_edit.list_value[-1] if node_edit else "")

    def select_edit_cmdb(self, node_config, target_list):
        for target in target_list:
            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                if target.has_subcategory:
                    find_node = self.select_dfs(node_edit, target.subcategory)
                    if find_node.node_type == FGTNodeType.FGTNODE_TYPE_NONE:
                        continue

                    for key in target.key_list:
                        if self.is_edit_node(find_node):
                            for sub_node in find_node.child_branch.list_child:
                                if sub_node.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                                    continue
                                self.rewrite_key(sub_node, target, key, node_edit)
                        else:
                            self.rewrite_key(find_node, target, key, node_edit)
                else:
                    for key in target.key_list:
                        self.rewrite_key(node_edit, target, key, node_edit)

    def select_config_cmdb(self, node_config, target_list):
        for target in target_list:
            if target.has_subcategory:
                find_node = self.select_dfs(node_config, target.subcategory)
                if find_node.node_type == FGTNodeType.FGTNODE_TYPE_NONE:
                    continue

                for key in target.key_list:
                    if self.is_edit_node(find_node):
                        for node_edit in node_config.child_branch.list_child:
                            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                                continue
                            self.rewrite_key(node_edit, target, key, node_edit)
                    else:
                        self.rewrite_key(find_node, target, key)
            else:
                for key in target.key_list:
                    self.rewrite_key(node_config, target, key)

    def select_cmdb(self):
        config = "config"

        for cmdb, target_list in self.category_keyword.items():
            list_cmdb_value = cmdb.split(' ')
            node_config = self.curr_vdom_root.find_tree_node(config, list_cmdb_value)
            if node_config.node_type.value == 0:
                continue
            if self.is_edit_node(node_config):
                self.select_edit_cmdb(node_config, target_list)
            else:
                self.select_config_cmdb(node_config, target_list)

    def run(self):
        config_root = self.device.config_root

        key = "config"
        list_global = ("config", "global")
        list_vdom = ("config", "vdom")

        node_global = config_root.find_tree_node(key, list_global)
        list_node_vdom = config_root.strict_match_tree_node(key, list_vdom)

        if self.is_multivdom(node_global, list_node_vdom):
            # VDOM mode enabled
            self.curr_vdom_root = node_global.child_branch
            self.select_cmdb()

            for node_vdom in list_node_vdom:
                for node_edit in node_vdom.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node_edit.get_last_leaf_index() > 0:
                        self.curr_vdom_root = node_edit.child_branch
                        self.select_cmdb()

        elif self.is_singlevdom(node_global, list_node_vdom):
            # VDOM mode disabled
            self.curr_vdom_root = config_root
            self.select_cmdb()

        if self.csv_file is not None:
            self.csv_file.close()

        return self.device

    def output_file(self, file_name):
        self.device.generate_config_file(file_name)