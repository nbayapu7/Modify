def is_ip_address(ip_str):
    for char in ip_str:
        if char != '.' and (ord(char) < ord('0') or ord(char) > ord('9')):
            return False

    ip = ip_str.split('.')
    if len(ip) == 4:
        val_0 = int(ip[0])
        val_1 = int(ip[1])
        val_2 = int(ip[2])
        val_3 = int(ip[3])
        if ((0 <= val_0 <= 255) and (0 <= val_1 <= 255) and
                (0 <= val_2 <= 255) and (0 <= val_3 <= 255)):
            return True

    return False


def remove_quota(str):
    return str.replace('"', '')


def list_to_subtract(list_one, list_two):
    list_substract = []
    for temp in list_one:
        if temp not in list_two:
            list_substract.append(temp)

    return list_substract


def list_equal(list_one, list_two):
    if not list_one and not list_two:
        return True
    if not list_one or not list_two:
        return False

    if not len(list_one) == len(list_two):
        return False

    try:
        return set(list_one) == set(list_two)
    except Exception as E:
        print(E)
        raise E


def try_parse_int(string, idx):
    '''
    Try parse string into integer if convert work return true else False
    Like C# Int32.TryParse()
    '''
    try:
        idx = int(string)
    except:
        return False, None
    else:
        return True, idx


def atoip(ip_str):
    ip_num = 0
    ip_split = ip_str.split(".")

    for ip_part in ip_split:
        ip_num = (ip_num << 8) + int(ip_part)

    return ip_num


def iptoa(ip_num):
    a = int((ip_num & 0xFF000000) >> 24)
    b = int((ip_num & 0x00FF0000) >> 16)
    c = int((ip_num & 0x0000FF00) >> 8)
    d = int((ip_num & 0x000000FF))
    return "{0}.{1}.{2}.{3}".format(a, b, c, d)


def masktolen(netmask):
    len = 0
    i = 31
    while i >= 0:

        if (netmask & (1 << i)) > 0:
            len += 1
        else:
            break
        i -= 1

    return len


def list_exactly_equals_object(_list, _addr):
    return len(_list) == 1 and _list[0] == _addr


def filter_condition(policy, erase_index):
    return policy.name not in erase_index
