import re
from enum import Enum
from itertools import zip_longest

from celery_app.fortinet.model import utils


class FGTNodeType(Enum):
    FGTNODE_TYPE_NONE = 0
    FGTNODE_TYPE_LEAF = 1
    FGTNODE_TYPE_BRANCH = 2


class FGTNodeModify(Enum):
    FGTNODE_MODBY_NONE = 0
    FGTNODE_MODBY_MAPPING = 1
    FGTNODE_MODBY_RULE = 2


class FGTNode:
    def __init__(self):
        self.key = ""
        self.list_value = []

        self.node_type = FGTNodeType.FGTNODE_TYPE_NONE
        self.leading_space = 0
        self.appending_space = 0
        self.mod_by = FGTNodeModify.FGTNODE_MODBY_NONE

        self.child_branch = None
        self.parent_branch = None
        self.associated_object = None

    def clone(self, parent):

        clone_node = FGTNode()
        # Clone current node.
        clone_node.key = self.key
        clone_node.list_value = []
        for str in self.list_value:
            clone_node.list_value.append(str)

        clone_node.node_type = self.node_type
        clone_node.leading_space = self.leading_space
        clone_node.appending_space = self.appending_space
        clone_node.mod_by = self.mod_by
        clone_node.parent_branch = parent
        # if self.associated_object is not None:
        #     clone_node.associated_object = model.Policy.objects.get(conversion_id=self.associated_object.conversion_id,
        #                                                             vdom=self.associated_object.vdom,
        #                                                             pk=self.associated_object.pk)
        #     clone_node.associated_object.pk = None
        #     clone_node.associated_object.id = None
        #     clone_node.associated_object.save()

        if self.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            clone_node.child_branch = self.child_branch  # child_branch should be null

        elif self.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            clone_node.child_branch = FGTObject()
            clone_node.child_branch.list_child = []
            clone_node.child_branch.associate_node = clone_node
            clone_node.child_branch.height = self.child_branch.height
            if len(self.child_branch.list_child) > 0:
                for child_node in self.child_branch.list_child:
                    clone_child_node = child_node.clone(
                        clone_node.child_branch)
                    clone_node.child_branch.list_child.append(clone_child_node)

        return clone_node

    # nValidLeafCount
    def get_valid_leaf_count(self):

        count = 0
        if self.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            if (self.key == "end" or self.key == "next") and len(self.list_value) == 1:
                return 0
            elif not self.key or len(self.key) == 0 or self.key == "#":
                return 0
            else:
                return 1

        elif self.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            # Collect value from child.
            for node in self.child_branch.list_child:
                count += node.get_valid_leaf_count()

        return count

    # DespString
    def get_desp_string(self):

        str = ""
        if self.list_value and len(self.list_value) > 0:
            for s in self.list_value:
                str += s + " "
            str = str[:-1]

        return str

    # get_location_index()
    def get_location_index(self):
        return self.parent_branch.list_child.index(self)

    # get_last_leaf_index()
    def get_last_leaf_index(self):
        return 0 if len(self.child_branch.list_child) == 0 else len(self.child_branch.list_child) - 1

    '''
    def compare_list_value(self, list):
        
        if len(list) > len(self.list_value):
            return False
                
        for i in range(len(list)):
            if list[i] != self.list_value[i]:
                return i == len(list)
        
        return True'''

    def strict_compare_node_value(self, key, list_value):

        if self.key == key:
            if len(self.list_value) == len(list_value):
                return self.compare_string_list(list_value, self.list_value)

        return False

    def loose_compare_node_value(self, key, list_value):

        if self.key == key:
            return self.compare_string_list(list_value, self.list_value)

        return False

    def rename_option(self, new_name):

        if len(self.list_value) > 2:
            self.list_value[2] = new_name

    def move_tree_node(self, node, insert_index):

        node.remove_tree_node()
        self.insert_tree_node(node, insert_index)

    def remove_tree_node(self):
        '''
        if self.node_type.value == 0:
            return

        # Loop back multi-child node.
        parent = self.parent_branch
        while len(parent.list_child) == 1:
            self = parent.associate_node
            if self != None:
                parent = self.parent_branch

        parent.list_child.remove(self)
        '''
        if self.node_type.value == 0:
            return

        remove_node = self
        # Loop back multi-child node.
        parent = remove_node.parent_branch
        while len(parent.list_child) == 1:
            remove_node = parent.associate_node
            if remove_node:
                parent = remove_node.parent_branch

        parent.list_child.remove(remove_node)

    def create_blank_edit_node(self, name, insert_index):

        node_next = FGTNode()
        node_next.node_type = FGTNodeType.FGTNODE_TYPE_LEAF
        node_next.list_value = ["next"]
        node_next.key = "next"
        node_next.leading_space = self.leading_space + 4

        node_edit = FGTNode()
        node_edit.node_type = FGTNodeType.FGTNODE_TYPE_BRANCH
        node_edit.list_value = ["edit", name]
        node_edit.key = "edit"
        node_edit.child_branch = FGTObject()
        node_edit.child_branch.list_child = []
        node_edit.child_branch.list_child.append(node_next)
        node_edit.child_branch.associate_node = node_edit
        node_edit.leading_space = self.leading_space + 4

        node_next.parent_branch = node_edit.child_branch
        self.child_branch.list_child.insert(insert_index, node_edit)

        return node_edit

    def rename_field(self, new_name):

        if len(self.list_value) > 1:
            self.list_value[1] = new_name

    def set_leading_space(self, leading_space_shift):

        self.leading_space += leading_space_shift
        if self.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            for node_child in self.child_branch.list_child:
                node_child.set_leading_space(leading_space_shift)

    def insert_tree_node(self, node_child, insert_index):

        if self.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            space_shift = 0
            node_child.parent_branch = self.child_branch
            if self.leading_space + 4 >= node_child.leading_space:
                space_shift = self.leading_space + 4 - node_child.leading_space

            node_child.set_leading_space(space_shift)
            self.child_branch.list_child.insert(insert_index, node_child)

    def create_leaf_node(self, key, list_value, insert_index):

        node_leaf = FGTNode()
        node_leaf.key = key
        node_leaf.list_value = []
        node_leaf.list_value.extend(list_value)
        node_leaf.node_type = FGTNodeType.FGTNODE_TYPE_LEAF
        node_leaf.leading_space = self.leading_space + 4
        node_leaf.parent_branch = self.child_branch
        self.child_branch.list_child.insert(insert_index, node_leaf)
        return node_leaf

    def compare_string_list(self, list_one, list_two):

        if len(list_one) > len(list_two):
            return False

        for i in range(len(list_one)):
            if utils.remove_quota(list_one[i]) != utils.remove_quota(list_two[i]):
                return i == len(list_one)

        return True

    # def get_node_list_word(self, list_value):
    #
    #     list_word = []
    #     if len(self.list_value) <= len(list_value):
    #         return list_word
    #
    #     match = self.compare_list_value(list_value, self.list_value)
    #     if match:
    #
    #         # Get the left word list.
    #         for i in range(len(list_value), len(self.list_value)):
    #             list_word.append(self.list_value[i])
    #
    #     return list_word

    def rename_edit_name(self, new_name):

        self.rename_field(new_name)

    def rename_command(self, list_new_name):

        self.list_value = list_new_name

    def remove_options(self, list_to_be_removed):

        if self.list_value:
            self.list_value = utils.list_to_subtract(
                self.list_value, list_to_be_removed)
            if len(self.list_value) == 2 and self.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                self.remove_tree_node()

    def generate_cli_from_FGTNode(self):

        # By default C# use unicode encoding. FGT only accept ASCII encoding.
        # System.Text.ASCIIEncoding asciiencoding = new System.Text.ASCIIEncoding();
        # System.Text.UTF8Encoding utf8encoding = new System.Text.UTF8Encoding();

        node = self
        cliString = ''

        if node.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
            count = len(node.list_value)
            if count > 0:
                if node.leading_space > 0:
                    cliString += ' ' * node.leading_space

                loop = 0
                # Detect the content and convert unicode to utf8.
                for value in node.list_value:

                    cliString += value

                    # Add space between words.
                    if loop < count - 1:
                        cliString += " "
                        loop += 1

                if node.appending_space > 0:
                    cliString += " " * node.appending_space

                cliString += "\n"

            elif len(node.list_value) == 0 and len(node.key) == 0:

                if node.leading_space > 0:
                    cliString += ' ' * node.leading_space

                if node.appending_space > 0:
                    cliString += " " * node.appending_space

                cliString += "\n"

        elif node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:

            count = len(node.list_value)
            if count > 0:

                if node.leading_space > 0:
                    cliString += ' ' * node.leading_space

                loop = 0
                # Detect the content and convert unicode to utf8.
                for value in node.list_value:

                    cliString += value

                    # Add space between words.
                    if loop < count - 1:
                        cliString += " "
                        loop += 1

                if node.appending_space > 0:
                    cliString += " " * node.appending_space

                cliString += "\n"

            child_cli_string = node.child_branch.generate_cli_from_FGTNode()
            cliString += child_cli_string
        return cliString

    def revert_encrypted_node(self, source_config):
        contain_encrypted = False
        remove_node = []
        try:
            for target_node, encrypted_node in zip_longest(self.child_branch.list_child,
                                                           source_config.child_branch.list_child):
                if not (target_node and encrypted_node):
                    continue

                # Config node
                if target_node.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                    if len(encrypted_node.list_value) > 3 and encrypted_node.list_value[2] == "ENC":
                        # Replace by origin encrypted value
                        target_node.list_value = encrypted_node.list_value
                        contain_encrypted = True
                # Edit node, recursively handled.
                elif target_node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                    # Check if the name is the same
                    if len(target_node.list_value) == 2 and \
                            target_node.list_value[1] != encrypted_node.list_value[1]:
                        continue

                    if target_node.revert_encrypted_node(encrypted_node):
                        contain_encrypted = True
                    else:
                        # node does not contain ENC encrypted information
                        remove_node.append(target_node)

            for node in remove_node:
                node.remove_tree_node()

        except Exception as ex:
            # Exception occurs, do not revert ENC string
            contain_encrypted = False
        finally:
            return contain_encrypted


class FGTObject:
    def __init__(self):
        self.height = 0
        self.associate_node = None
        self.list_child = []

    def clone(self):

        clone_obj = FGTObject()
        # Travesal each node and clone.
        if self.list_child:
            for node in self.list_child:
                clone_node = node.clone(clone_obj)
                clone_obj.list_child.append(clone_node)

        return clone_obj

    multiline_buffer = ""

    def read_config_file(self, file):

        end_of_section = False

        # Read each line.
        leading_space = 0
        appending_space = 0
        is_multiline_set = False
        key = ""
        list_value = []
        pattern1 = re.compile("^([\s]*#).+")
        pattern2 = re.compile("^[\s]*config\s(.+)")
        pattern3 = re.compile("^[\s]*edit\s(.+)")
        pattern4 = re.compile("^[\s]*set\s(.+)")
        pattern5 = re.compile("^[\s]*unset\s(.+)")
        pattern6 = re.compile("^[\s]*next$")
        pattern7 = re.compile("^[\s]*end$")

        while not end_of_section:

            byte_line = file.readline()

            line = ""
            try:
                line = byte_line.decode("utf-8")
            except UnicodeDecodeError:
                line = byte_line.decode("cp1252", "ignore")

            if len(line) == 0:
                break

            key = ""
            list_value = []

            # Parse each line.
            line = line.replace("\r", "")
            line = line.replace("\n", "")

            leading_space = self.get_leading_space_count(line)
            appending_space = self.get_appending_space_count(line)

            match_type = 0
            matched = True

            # Match regex rule 1.
            # Example: #config-version=FG140T-5.00-FW-build271-140409:opmode=0:vdom=0:user=admin
            if pattern1.match(line):
                match_type = 1
                key = "#"
                list_value = self.read_line_word(line)

            # Match regex rule 2.
            # Example: config system global
            elif not is_multiline_set and pattern2.match(line):
                match_type = 2
                key = "config"
                list_value = self.read_line_word(line)

            # Match regex rule 3.
            # Example: edit "xxx" or edit 1
            elif not is_multiline_set and pattern3.match(line):
                match_type = 3
                key = "edit"
                list_value = self.read_line_word(line)

            # Match regex rule 4.
            # Example: set xxx xxx or set xxx xxx “xxx”
            elif not is_multiline_set and pattern4.match(line):
                # Check the double quote number.
                if self.double_quote_match(line):
                    match_type = 4
                    key = "set"
                    list_value = self.read_line_word(line)
                    is_multiline_set = False
                else:
                    matched = False

            # Match regex rule 5.
            # Example: unset xxx xxx
            elif not is_multiline_set and pattern5.match(line):
                match_type = 5
                key = "unset"
                list_value = self.read_line_word(line)

            # Match regex rule 6.
            # Example: next
            elif not is_multiline_set and pattern6.match(line):
                # Function exit point.
                end_of_section = True
                match_type = 6
                key = "next"
                list_value = self.read_line_word(line)
                is_multiline_set = False

            # Match regex rule 7.
            # Example: end
            elif not is_multiline_set and pattern7.match(line):

                # Function exit point.
                end_of_section = True
                match_type = 7
                key = "end"
                list_value = self.read_line_word(line)
                is_multiline_set = False

            else:
                matched = False

            if not matched:
                # Match blank line.
                if not is_multiline_set and not line:
                    match_type = 8
                    key = ""

                elif self.is_multiple_line_set(self.multiline_buffer):

                    self.multiline_buffer += f'{line}\n'
                    if self.double_quote_match(self.multiline_buffer):
                        match_type = 4
                        key = "set"
                        list_value = self.read_line_word(
                            self.multiline_buffer, True)
                        is_multiline_set = False
                        self.multiline_buffer = ""

                # Match incomplete line.
                # set xxx "xxx
                # xxx
                # " */
                else:
                    match_type = 9
                    key = ""
                    list_value.append(line.strip())

                    if self.is_multiple_line_set(line):
                        is_multiline_set = True

                    if is_multiline_set:
                        self.multiline_buffer += f'{line}\n'
                        continue

                    '''if not is_multiline_set:					
                        ConversionLog lg = new ConversionLog(4, DateTime.Now.ToShortTimeString(), "Line Incomplete", "\"" + line + "\" may be an incomplete line.", "");
                        ConverterManager.Instance.ConversionLogs.appendLog(ConverterManager.Instance.GetCurrentDomain(), "Warning", lg);'''

                ''' Format: 
                    #config-version=FG140T-5.00-FW-build271-140409:opmode=0:vdom=0:user=admin
                    set xxx xxx 
                    unset xxx xxx
                    next 
                    end
                    blank line '''

            if match_type == 1 or match_type == 4 or match_type == 5 or match_type == 6 or match_type == 7 or match_type == 8 or match_type == 9:

                leaf_node = FGTNode()
                leaf_node.node_type = FGTNodeType.FGTNODE_TYPE_LEAF
                leaf_node.leading_space = leading_space
                leaf_node.appending_space = appending_space
                leaf_node.mod_by = FGTNodeModify.FGTNODE_MODBY_NONE
                leaf_node.key = key
                leaf_node.list_value = list_value
                leaf_node.parent_branch = self
                leaf_node.child_branch = None
                self.list_child.append(leaf_node)

                ''' Format:
                    config system global
                    edit "xxx" '''

            elif match_type == 2 or match_type == 3:

                child = FGTObject()
                child.list_child = []
                child.height = self.height + 1
                child.read_config_file(file)

                branch_node = FGTNode()
                branch_node.node_type = FGTNodeType.FGTNODE_TYPE_BRANCH
                branch_node.leading_space = leading_space
                branch_node.appending_space = appending_space
                branch_node.mod_by = FGTNodeModify.FGTNODE_MODBY_NONE
                branch_node.key = key
                branch_node.list_value = list_value
                branch_node.parent_branch = self
                branch_node.child_branch = child
                child.associate_node = branch_node
                self.list_child.append(branch_node)

            # edit "xxx"
            # config system global

    @property
    def is_empty_vdom(self):
        if len(self.list_child) < 2 and self.list_child[0].list_value == ["next"]:
            return True
        return False

    def read_line_word(self, line, is_multiline=False):

        list_word = []

        try:
            if is_multiline:
                leading_space = self.get_leading_space_count(line)
                pattern = "^[\s]*set (buffer|private-key|crl|ca|description|menu-file|content|script|certificate|pac-file-data)\s+(\"(.|\s)*\")"
                match = re.match(pattern, line)
                if match:
                    list_word = [f'{leading_space * " "}set',
                                 match.group(1), match.group(2)]
            elif re.match("(.+)\s\"([\S ]+)\"", line):

                # edit "xxx"
                # set member "DCE-RPC" "DNS" "HTTPS"
                line_split = line.strip().split()
                is_in_quote = False
                list_word_collect = []

                for _str in line_split:

                    if is_in_quote:
                        list_word_collect.append(_str)
                        if len(_str) > 0 and _str[-1] == '"':
                            _join = " ".join(list_word_collect)
                            list_word.append(_join)
                            list_word_collect = []
                            is_in_quote = False

                    else:
                        if len(_str) > 0 and _str[0] == '"':
                            if _str[-1] == '"':
                                list_word.append(_str)
                            else:
                                list_word_collect.append(_str)
                                is_in_quote = True

                        else:
                            list_word.append(_str)
            else:
                # config system global
                pattern = "([\s]*[^\s]+)"
                result = re.findall(pattern, line)
                if len(result):
                    list_word = [word.strip() for word in result]

        except Exception as ex:
            print(f'Parse Failed: {ex}')
            pass

        finally:
            return list_word

    def get_leading_space_count(self, line):
        return len(line) - len(line.lstrip(' '))

    def get_appending_space_count(self, line):
        return len(line) - len(line.rstrip(' '))

    def double_quote_match(self, line):
        # Replace the intepret char.
        str_without_quotes = line.replace('\\"', "")
        count = len(str_without_quotes.split('"')) - 1
        return count % 2 == 0

    def is_multiple_line_set(self, line):
        return re.match(
            "^[\s]*set (buffer|private-key|crl|ca|description|menu-file|content|script|certificate|pac-file-data)\s(.+)",
            line)

    def remove_blank_line(self, list_node):

        previous = False
        current = False
        list_ignore_blank = []
        list_result = []

        for node in list_node:
            if node.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                current = len(node.list_value) == 0 and len(node.key) == 0
                if previous and current:
                    # Both previous and current lines are blank.
                    list_ignore_blank.append(node)

                else:
                    if len(list_ignore_blank) <= 3:
                        list_result.extend(list_ignore_blank)
                        list_ignore_blank = []

                    previous = current
                    list_result.append(node)

            elif node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                previous = False
                current = False
                if len(list_ignore_blank) <= 3:
                    list_result.extend(list_ignore_blank)
                    list_ignore_blank = []

                list_result.append(node)

        return list_result

    def contains_unicode_character(self, input):

        max_ansi_code = 255
        for char in input:
            if ord(char) > max_ansi_code:
                return True

        return False

    def generate_cli_from_FGTNode(self):

        # By default C# use unicode encoding. FGT only accept ASCII encoding.
        # System.Text.ASCIIEncoding asciiencoding = new System.Text.ASCIIEncoding();
        # System.Text.UTF8Encoding utf8encoding = new System.Text.UTF8Encoding();

        cliString = ''

        if self.list_child:
            list_child = self.remove_blank_line(self.list_child)
            for node in list_child:
                if node.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                    count = len(node.list_value)
                    if count > 0:
                        if node.leading_space > 0:
                            cliString += ' ' * node.leading_space

                        loop = 0
                        # Detect the content and convert unicode to utf8.
                        for value in node.list_value:

                            cliString += value

                            # Add space between words.
                            if loop < count - 1:
                                cliString += " "
                                loop += 1

                        if node.appending_space > 0:
                            cliString += " " * node.appending_space

                        cliString += "\n"

                elif len(node.list_value) == 0 and len(node.key) == 0:

                    if node.leading_space > 0:
                        cliString += ' ' * node.leading_space

                    if node.appending_space > 0:
                        cliString += " " * node.appending_space

                    cliString += "\n"

                elif node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:

                    count = len(node.list_value)
                    if count > 0:

                        if node.leading_space > 0:
                            cliString += ' ' * node.leading_space

                        loop = 0
                        # Detect the content and convert unicode to utf8.
                        for value in node.list_value:
                            cliString += value

                            # Add space between words.
                            if loop < count - 1:
                                cliString += " "
                                loop += 1

                        if node.appending_space > 0:
                            cliString += " " * node.appending_space

                        cliString += "\n"

                    child_cli_string = node.child_branch.generate_cli_from_FGTNode()
                    cliString += child_cli_string
        return cliString

    def write_config_file(self, output_file):

        # By default C# use unicode encoding. FGT only accept ASCII encoding.
        # System.Text.ASCIIEncoding asciiencoding = new System.Text.ASCIIEncoding();
        # System.Text.UTF8Encoding utf8encoding = new System.Text.UTF8Encoding();

        if self.list_child:
            list_child = self.remove_blank_line(self.list_child)
            for node in list_child:
                if node.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                    count = len(node.list_value)
                    if count > 0:
                        if node.leading_space > 0:
                            output_file.write(b' ' * node.leading_space)

                        loop = 0
                        # Detect the content and convert unicode to utf8.
                        for value in node.list_value:

                            '''has_unicode = self.contains_unicode_character(value);
                            if (hasUnicode)
                            {
                                /* Convert unicode string to utf8. */
                                Byte[] bytes = utf8encoding.GetBytes(value);
                                fileStream.Write(bytes, 0, bytes.Length);
                            }
                            else
                            {
                                /* Convert unicode string to ASCII. */
                                Byte[] bytes = asciiencoding.GetBytes(value);
                                fileStream.Write(bytes, 0, bytes.Length);
                            }'''
                            try:
                                output_file.write(value.encode("utf-8"))
                            except UnicodeEncodeError:
                                output_file.write(
                                    value.encode("cp1252", "ignore"))

                            # Add space between words.
                            if loop < count - 1:
                                '''string strOneSpace = " ";
                                Byte[] bytes = asciiencoding.GetBytes(strOneSpace);
                                fileStream.Write(bytes, 0, bytes.Length);'''
                                output_file.write(b" ")
                                loop += 1

                        if node.appending_space > 0:
                            output_file.write(b" " * node.appending_space)

                        output_file.write(b"\n")

                    elif len(node.list_value) == 0 and len(node.key) == 0:

                        if node.leading_space > 0:
                            output_file.write(b' ' * node.leading_space)

                        if node.appending_space > 0:
                            output_file.write(b" " * node.appending_space)

                        output_file.write(b"\n")

                elif node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:

                    count = len(node.list_value)
                    if count > 0:

                        if node.leading_space > 0:
                            output_file.write(b' ' * node.leading_space)

                        loop = 0
                        # Detect the content and convert unicode to utf8.
                        for value in node.list_value:

                            '''bool hasUnicode = self.contains_unicode_character(value);
                            if (hasUnicode)
                            {
                                /* Convert unicode string to utf8. */
                                Byte[] bytes = utf8encoding.GetBytes(value);
                                fileStream.Write(bytes, 0, bytes.Length);
                            }
                            else
                            {
                                /* Convert unicode string to ASCII. */
                                Byte[] bytes = asciiencoding.GetBytes(value);
                                fileStream.Write(bytes, 0, bytes.Length);
                            }'''
                            try:
                                output_file.write(value.encode("utf-8"))
                            except UnicodeEncodeError:
                                output_file.write(
                                    value.encode("cp1252", "ignore"))

                            # Add space between words.
                            if loop < count - 1:
                                '''string strOneSpace = " ";
                                Byte[] bytes = asciiencoding.GetBytes(strOneSpace);
                                fileStream.Write(bytes, 0, bytes.Length);'''
                                output_file.write(b" ")
                                loop += 1

                        if node.appending_space > 0:
                            output_file.write(b" " * node.appending_space)

                        output_file.write(b"\n")

                    node.child_branch.write_config_file(output_file)

    def get_list_word(self, list_keyword):

        list_word = []
        if len(self.list_child) > 0:
            for node in self.list_child:

                if node.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                    if len(node.list_value) <= len(list_keyword):
                        continue

                    # Compare two lists.
                    match = self.associate_node.compare_string_list(
                        list_keyword, node.list_value)
                    if match:
                        # Get the left word list.
                        for i in range(len(list_keyword), len(node.list_value)):
                            list_word.append(node.list_value[i])
        return list_word

    def get_list_word_no_quota(self, list_keyword):

        list_word = []
        if len(self.list_child) > 0:
            for node in self.list_child:

                if node.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                    if len(node.list_value) <= len(list_keyword):
                        continue

                    # Compare two lists.
                    match = self.associate_node.compare_string_list(
                        list_keyword, node.list_value)
                    if match:
                        # Get the left word list.
                        for i in range(len(list_keyword), len(node.list_value)):
                            value = utils.remove_quota(node.list_value[i])
                            list_word.append(value)
        return list_word

    # Find the first matched tree node based on multi-vdom tree structure.
    def find_vdom_tree_node(self, vdom, key, list_value):

        result = FGTNode()
        global_scope = ["config", "global"]
        vdom_scope = ["config", "vdom"]
        for node in self.list_child:
            if node.list_value not in [global_scope, vdom_scope]:
                continue

            if node.list_value == global_scope:
                result = node.child_branch.find_tree_node(key, list_value)
            else:
                edit = "edit"
                list_vdom_value = [edit, vdom]
                vdom_tree = node.child_branch.find_tree_node(
                    edit, list_vdom_value)
                if vdom_tree.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                    result = vdom_tree.child_branch.find_tree_node(
                        key, list_value)

            if result.node_type.value > 0:
                break

        return result

    def find_vdom_cmdb_tree_list_node(self, vdom, key, cmdb, list_nodes):
        results = []
        # Find config node
        cmdb_node = self.find_vdom_tree_node(vdom, key, cmdb)
        edit = "edit"
        for sub_node in cmdb_node.child_branch.list_child:
            if sub_node.key == edit and len(sub_node.list_value) == 2:
                if utils.remove_quota(sub_node.list_value[1]) in list_nodes:
                    results.append(sub_node)

        return results

    # Find the first matched tree node.
    def find_tree_node(self, key, list_value):

        result = FGTNode()
        for node in self.list_child:
            if node.node_type.value > 0 and node.strict_compare_node_value(key, list_value):
                return node

            if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                # Go into next sub-branch node.
                result = node.child_branch.find_tree_node(key, list_value)
                if result.node_type.value > 0:
                    break

        return result

    # Find all the tree nodes in cmdb tree.
    def find_cmdb_tree_list_node(self, key, cmdb, list_nodes):
        results = []
        edit = "edit"
        # Find config node
        cmdb_node = self.find_tree_node(key, cmdb)
        for sub_node in cmdb_node.child_branch.list_child:
            if sub_node.key == edit and len(sub_node.list_value) == 2:
                if utils.remove_quota(sub_node.list_value[1]) in list_nodes:
                    results.append(sub_node)

        return results

    # Find the first matched tree node.
    def loose_find_tree_node(self, key, list_value):

        result = FGTNode()
        for node in self.list_child:
            if node.node_type.value > 0 and node.loose_compare_node_value(key, list_value):
                result = node
                break

            if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                # Go into next sub-branch node.
                result = node.child_branch.loose_find_tree_node(
                    key, list_value)
                if result.node_type.value > 0:
                    break

        return result

    # Find all the matched tree node.
    def strict_match_tree_node(self, key, list_value):

        list_match = []
        for node in self.list_child:

            if node.node_type.value > 0 and node.strict_compare_node_value(key, list_value):
                list_match.append(node)

            if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                # Go into next sub-branch node.
                list_submatch = node.child_branch.strict_match_tree_node(
                    key, list_value)
                if len(list_submatch) > 0:
                    list_match.extend(list_submatch)

        return list_match

    '''
    def create_leaf_node(self, key, list_value, insert_index):
        
        node_leaf = FGTNode()
        node_leaf.key = key
        node_leaf.list_value = []
        node_leaf.list_value.extend(list_value)
        node_leaf.node_type = FGTNodeType.FGTNODE_TYPE_LEAF
        node_leaf.leading_space = self.associate_node.leading_space + 4
        node_leaf.parent_branch = self
        self.list_child.insert(insert_index, node_leaf)
    '''

    def find_and_remove_node(self, key, list_value):

        node = self.find_tree_node(key, list_value)
        if node.node_type.value > 0:
            node.remove_tree_node()

    def loose_find_and_remove_node(self, key, list_value):

        node = self.loose_find_tree_node(key, list_value)
        if node.node_type.value > 0:
            node.remove_tree_node()

    def find_branch_node_edit(self, name):

        key = "edit"
        list_value = ["edit", name]
        return self.find_tree_node(key, list_value)

    def find_or_create_config_node(self, key, list_value, insert_index):

        node = self.find_tree_node(key, list_value)
        if node.node_type.value == 0:
            node = self.create_blank_config_node(list_value, insert_index)

        return node

    def create_blank_config_node(self, list_value, insert_index):

        space = 0 if not self.associate_node else self.associate_node.leading_space + 4

        node_end = FGTNode()
        node_end.node_type = FGTNodeType.FGTNODE_TYPE_LEAF
        node_end.list_value = ["end"]
        node_end.key = "end"
        node_end.leading_space = space

        node_config = FGTNode()
        node_config.node_type = FGTNodeType.FGTNODE_TYPE_BRANCH
        node_config.list_value = list_value
        node_config.key = "config"
        node_config.child_branch = FGTObject()
        node_config.child_branch.list_child = []
        node_config.child_branch.list_child.append(node_end)
        node_config.child_branch.associate_node = node_config
        node_config.leading_space = space
        node_config.parent_branch = self

        node_end.parent_branch = node_config.child_branch
        self.list_child.insert(insert_index, node_config)

        return node_config

    def find_and_remove_options(self, key, list_value, list_to_be_removed):

        node = self.loose_find_tree_node(key, list_value)
        if node.node_type.value > 0:
            node.remove_options(list_to_be_removed)

    def remove_options(self, list_to_be_removed):

        if self.list_value:
            self.list_value = utils.list_to_subtract(
                self.list_value, list_to_be_removed)
            if len(self.list_value) == 2 and self.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                self.remove_tree_node()

    def find_and_rename_field(self, key, list_value, new_name):
        node = self.loose_find_tree_node(key, list_value)
        if node.node_type.value > 0:
            node.rename_field(new_name)

    def find_and_get_field_name(self, key, list_value):
        node = self.loose_find_tree_node(key, list_value)
        if node.node_type.value > 0:
            return utils.remove_quota(node.list_value[-1])
        return ""

    def create_blank_edit_node(self, name, insert_index):

        node_next = FGTNode()
        node_next.node_type = FGTNodeType.FGTNODE_TYPE_LEAF
        node_next.list_value = ["next"]
        node_next.key = "next"
        node_next.leading_space = self.associate_node.leading_space + 4

        node_edit = FGTNode()
        node_edit.node_type = FGTNodeType.FGTNODE_TYPE_BRANCH
        node_edit.list_value = ["edit", name]
        node_edit.key = "edit"
        node_edit.child_branch = FGTObject()
        node_edit.child_branch.list_child = [node_next]
        node_edit.child_branch.associate_node = node_edit
        node_edit.leading_space = self.associate_node.leading_space + 4

        node_next.parent_branch = node_edit.child_branch
        self.list_child.insert(insert_index, node_edit)

        return node_edit

    def find_and_rename_options(self, key, list_value, old_name, new_name):

        node = self.loose_find_tree_node(key, list_value)
        if node.node_type.value > 0:
            if old_name in node.list_value:
                node.list_value.remove(old_name)
                node.list_value.append(new_name)

    def loose_match_tree_node(self, key, list_value):

        list_match = []
        for node in self.list_child:
            if node.node_type.value > 0 and node.loose_compare_node_value(key, list_value):
                list_match.append(node)

            if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                # Go into next sub-branch node
                list_sub_match = node.child_branch.loose_match_tree_node(
                    key, list_value)
                if len(list_sub_match) > 0:
                    list_match.extend(list_sub_match)

        return list_match

    '''
    def loose_compare_node_value(self, key, list_value):
        
        if self.key == key:
            return self.compare_string_list(list_value, self.list_value)
        
        return False

    def compare_list_value(self, list):
        
        if len(list) > len(self.list_value):
            return False
                
        for i in range(len(list)):
            if list[i] != self.list_value[i]:
                return False	
        
        return True
    '''

    def rename_field(self, new_name):

        if len(self.list_value) > 1:
            self.list_value[1] = new_name

    def find_and_rename_command(self, key, list_value, list_new_name):

        node = self.loose_find_tree_node(key, list_value)
        if node.node_type.value > 0:
            node.rename_command(list_new_name)

    def check_leaf_in_node(self, key, list_value):
        if not self.list_child:
            return False

        for node_leaf in self.list_child:
            if node_leaf.key != key:
                continue

            # To check [set, vdom, root] and [set vdom] leaf node
            # Careful! This is unordered check and comparison.
            if all(item in node_leaf.list_value for item in list_value):
                return True

        return False

    def get_options_leaf_in_node(self, key, list_value, list_options):
        option_node = self.loose_find_tree_node(key, list_value)
        if option_node.list_value and option_node.list_value[-1] in list_options:
            return option_node
        return None

    def merge_branch(self, branch):

        key = "set"

        for node_edit in branch.list_child:

            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH or node_edit.key != "edit":
                continue

            obj_name = node_edit.list_value[1]
            node_edit_self = self.find_branch_node_edit(obj_name)

            if node_edit_self.node_type.value == 0:
                insert_index = self.associate_node.get_last_leaf_index()
                self.associate_node.insert_tree_node(node_edit, insert_index)

            else:
                for node_set in node_edit.child_branch.list_child:

                    if len(node_set.list_value) < 2:
                        continue

                    key = node_set.list_value[0]
                    field_name = node_set.list_value[1]
                    list_value = [key, field_name]
                    node_set_self = node_edit_self.child_branch.loose_find_tree_node(
                        key, list_value)

                    if node_set_self.node_type.value == 0:
                        insert_index = node_edit_self.get_last_leaf_index()
                        node_edit_self.insert_tree_node(node_set, insert_index)

                    else:
                        node_set_self.list_value = node_set.list_value

    def merge_branch_name_only(self, branch):

        key = "set"

        for node_edit in branch.list_child:

            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH or node_edit.key != "edit":
                continue

            obj_name = node_edit.list_value[1]
            node_edit_self = self.find_branch_node_edit(obj_name)

            if node_edit_self.node_type.value == 0:
                insert_index = self.associate_node.get_last_leaf_index()
                new_node_edit = node_edit.clone(node_edit_self.child_branch)
                list_child = []
                for node in new_node_edit.child_branch.list_child:
                    if node.key == "next":
                        list_child.append(node)
                new_node_edit.child_branch.list_child = list_child
                self.associate_node.insert_tree_node(
                    new_node_edit, insert_index)
