import os
import re
import tempfile
import pickle
from enum import Enum

from celery_app.fortinet.model.config_tree import FGTNodeType, FGTObject
from .utils import remove_quota


class FGTVdomStatus(Enum):
    FGTVDOM_STATUS_CONFIG = 1
    FGTVDOM_STATUS_EDIT = 2


class FortiGate:
    def __init__(self, file_path, device="source"):
        self.node_config_version = None
        self.node_file_version = None
        self.node_build_no = None
        self.node_vdom_no = None

        self.file_path = file_path
        self.config_root = FGTObject()

        self.fos_version = ""
        self.model = ""
        self.version = ""
        self.build = ""
        self.device = device

        try:
            list_modified_content = self.remedy_vdom_format(file_path)
            modified_file = tempfile.TemporaryFile(mode="wb+")
            for line in list_modified_content:
                try:
                    modified_file.write(line.encode("utf-8"))
                except UnicodeEncodeError:
                    modified_file.write(line.encode("cp1252", "ignore"))
            modified_file.seek(0)
            self.config_root.read_config_file(modified_file)
            modified_file.close()
            if self.config_root.list_child:
                print(f'Parse {device} configuration.')
                # self.extract_header_version_info()
                for node in self.config_root.list_child:
                    self.collect_config_info(node)
        except Exception as e:
            print(e)

    def clone(self):

        clone_gate = FortiGate("")
        clone_gate.config_root = self.config_root.clone()

        if clone_gate.config_root.list_child:
            for node in clone_gate.config_root.list_child:
                clone_gate.collect_config_info(node)

        return clone_gate

    def extract_header_version_info(self):
        if self.version:
            return self.version

        version_node = self.config_root.list_child[0]
        if version_node.key != "#":
            return

        version = version_node.list_value[0]
        if "config-version=" not in version:
            return

        pattern = "#config-version=([FG|FW].+)-(\d+\.\d+.\d+)-FW-build([0-9]+)-"
        capture = re.match(pattern, version) or re.match(pattern, version)
        if not capture:
            return

        self.model = capture.group(1)
        self.version = capture.group(2)
        self.build = capture.group(3)

        return self.version

    def remedy_vdom_format(self, file_path):
        list_original = []
        if os.path.isfile(file_path) and os.path.getsize(file_path) > 0:
            input = open(file_path, "rb")

            for line in input:
                try:
                    list_original.append(line.decode("utf-8"))
                except UnicodeDecodeError:
                    list_original.append(line.decode("cp1252", "ignore"))

            input.close()
        else:
            return []

        # Remedy vdom block format.
        depth = 0
        index = 0
        status = 0
        list_index = []

        pattern_vdom = re.compile("^[\s]*edit\s(.+)")
        pattern_config_edit = re.compile("^[\s]*(config|edit)\s(.+)")

        for line in list_original:

            temp = line.strip()
            if temp == "config vdom":
                depth += 1
                status = FGTVdomStatus.FGTVDOM_STATUS_CONFIG

            elif status == FGTVdomStatus.FGTVDOM_STATUS_CONFIG:
                if pattern_vdom.match(temp):
                    depth += 1
                    status = FGTVdomStatus.FGTVDOM_STATUS_EDIT

            elif status == FGTVdomStatus.FGTVDOM_STATUS_EDIT:
                if pattern_config_edit.match(temp):
                    depth += 1

                elif temp == "next":
                    depth -= 1

                elif temp == "end":
                    depth -= 1
                    if depth == 1:
                        status = 0
                        depth = 0
                        list_index.append(index)

                    elif depth == 0:
                        status = 0
            index += 1

        add_line = 0
        list_modify_index = []
        list_modify = []
        for i in range(len(list_original)):

            if i in list_index:
                list_modify.append("next")
                add_line += 1
                list_modify_index.append(i + add_line)

            list_original[i] = list_original[i].replace("\r", "")
            list_modify.append(list_original[i].replace("\n", ""))

        # Remove the following two lines, "end" and "config vdom" in the middle.
        for index in list_modify_index:

            erase_end = False
            erase_config = False
            end = 0
            config_vdom = 0

            for j in range(index, len(list_modify)):

                if list_modify[j] == "end" and not erase_end:
                    erase_end = True
                    end = j

                elif list_modify[j] == "config vdom" and not erase_config:
                    erase_config = True
                    config_vdom = j

                elif list_modify[j] == "config global":
                    # Cease from global configuration.
                    break

                if erase_end and erase_config:
                    list_modify[end] = ""
                    list_modify[config_vdom] = ""

                    break

        for i in range(len(list_modify)):
            list_modify[i] = list_modify[i] + "\n"

        return list_modify

    def collect_config_info(self, node_comment):

        line = node_comment.get_desp_string()

        pattern = "^([\s]*#config-version=).+"
        if not self.node_config_version and re.match(pattern, line):
            self.node_config_version = node_comment
            return

        pattern = "^([\\s]*#conf_file_ver=)[\\d]+"
        if not self.node_file_version and re.match(pattern, line):
            self.node_file_version = node_comment
            return

        pattern = "^([\\s]*#version=)[\\d]+"
        if not self.node_file_version and re.match(pattern, line):
            self.node_file_version = node_comment
            return

        pattern = "^([\\s]*#buildno=)[\\d]+"
        if not self.node_build_no and re.match(pattern, line):
            self.node_build_no = node_comment
            return

        pattern = "^([\\s]*#build=)[\\d]+"
        if not self.node_build_no and re.match(pattern, line):
            self.node_build_no = node_comment
            return

        pattern = "^([\\s]*#global_vdom=)[\\d]+"
        if not self.node_vdom_no and re.match(pattern, line):
            self.node_vdom_no = node_comment

    def collect_host_name(self):

        host_name = ""
        key = "config"
        list_value = ["config", "system", "global"]
        node = self.config_root.find_tree_node(key, list_value)
        if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            if len(node.child_branch.list_child) > 0:
                # Get "set hostname" attribute.
                list_keyword = ["set", "hostname"]
                list_host_name = node.child_branch.get_list_word(list_keyword)
                if len(list_host_name) == 1:
                    host_name = remove_quota(list_host_name[0])

        return host_name

    def collect_alias_name(self):
        alias_name = ""
        key = "config"
        list_value = ["config", "system", "global"]
        node = self.config_root.find_tree_node(key, list_value)
        if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            if len(node.child_branch.list_child) > 0:
                # Get "set hostname" attribute.
                list_keyword = ["set", "alias"]
                list_alias_name = node.child_branch.get_list_word(list_keyword)
                if len(list_alias_name) == 1:
                    alias_name = remove_quota(list_alias_name[0])

        return alias_name

    def remove_host_alias_name(self, host_name):

        key = "config"
        list_value = ["config", "system", "global"]
        node_config = self.config_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_value = ["set", "hostname"]
        node_config.child_branch.loose_find_and_remove_node(key, list_value)

        list_value = ["set", "alias"]
        node_alias = node_config.child_branch.loose_find_tree_node(
            key, list_value)
        # If hostname equal to alias, replace them together.
        if node_alias.node_type.value > 0 and \
                node_alias.list_value[-1] == f'"{host_name}"':
            node_alias.remove_tree_node()

    def is_vdom_enabled(self):
        key = "config"
        list_value = ["config", "vdom"]
        node_vdom = self.config_root.find_tree_node(key, list_value)
        return node_vdom.node_type.value != 0

    def extract_version_info(self):
        def parse_version_info(pre_parse_ver, build):
            '''
            Two types of versionInfo
            1. legacy FortiOS version
            "#config-version=FG110C-5.00-FW-build252-131031:opmode=0:vdom=0:user=admin#conf_file_ver=41353354528"
            2. 5.6 or higher version
            "#config-version=FG5H1E-6.2.1-FW-build0932-190716:opmode=0:vdom=0:user=admin#conf_file_ver=16584586"

            :param pre_parse_ver: pre-parse version
            :param build: build number
            :return: version info after calculate
            '''
            try:
                version_list = pre_parse_ver.split('.')
                if len(version_list) == 2:
                    if version_list[0] == "4":
                        minor = "0" if build < 185 else "1" if build < 272 else "2" if build < 458 else "3"
                    elif version_list[0] == "5":
                        minor = "0" if build < 617 else "2" if build < 1093 else "4"
                    elif version_list[0] == "6":
                        minor = "0" if build < 866 else "2" if build < 1579 else "4"

                    return f'{version_list[0]}.{minor}'

                elif len(version_list) == 3:
                    return pre_parse_ver
            except Exception as ex:
                return "0.0"

        if self.fos_version:
            return self.fos_version

        version_node = self.config_root.list_child[0]
        if version_node.key != "#":
            return

        version = version_node.list_value[0]
        if "config-version=" not in version:
            return

        pattern = "#config-version=(FGT|FG|FWF|FW|FOS|FGVM|F)(\d.+)-((\d+\.\d+\.\d+)|(\d+\.\d+))-FW-build([0-9]+)-"
        result = re.match(pattern, version)

        if not result:
            self.fos_version = "0.0"
            self.build = "0000"
            self.model = "Unknown"
            return self.fos_version

        keyword = result.group(1)
        series = result.group(2)
        self.model = keyword + "-" + series
        self.build = result.group(6)
        # Further check and parse input version if it's under v5.6
        self.fos_version = parse_version_info(result.group(3), int(self.build))

        return self.fos_version

    def append_output_file(self, output_file):

        if output_file.node_config_version:
            output_file.node_config_version.remove_tree_node()

        if output_file.node_file_version:
            output_file.node_file_version.remove_tree_node()

        if output_file.node_build_no:
            output_file.node_build_no.remove_tree_node()

        if output_file.node_vdom_no:
            output_file.node_vdom_no.remove_tree_node()

        interim_lines = ["", "#migrated config starts", "", ""]

        content = "\n".join(interim_lines)
        interim = tempfile.TemporaryFile(mode="wb+")
        interim.write(content.encode("utf-8"))
        interim.seek(0)
        current_obj = FGTObject()
        current_obj.read_config_file(interim)

        for node in current_obj.list_child:
            self.config_root.list_child.append(node)
            node.parent_branch = self.config_root

        for node in output_file.config_root.list_child:
            self.config_root.list_child.append(node)
            node.parent_branch = self.config_root

    def replace_vdom_name_config_vdom(self, original_vdom, mapped_name):

        key = "config"
        list_value = ["config", "vdom"]
        list_node = self.config_root.strict_match_tree_node(key, list_value)
        if not list_node:
            return

        key = "edit"
        list_edit = ["edit", original_vdom]

        for node in list_node:
            if node.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_vdom = node.child_branch.find_tree_node(key, list_edit)
            if node_vdom.node_type.value > 0:
                node_vdom.list_value = ["edit", mapped_name]

    def replace_vdom_name_config_sys_intf(self, original_vdom, mapped_name):

        key = "config"
        list_value = ["config", "system", "interface"]
        list_node = self.config_root.strict_match_tree_node(key, list_value)
        if not list_node:
            return

        key = "set"
        list_set_vdom = ["set", "vdom", '"' + original_vdom + '"']
        old_postfix = "." + original_vdom + '"'
        new_postfix = '.' + mapped_name + '"'

        dic_replace_mapping = {}

        for node in list_node:
            if node.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            for node_intf in node.child_branch.list_child:
                if node_intf.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                intf_name = node_intf.list_value[-1]
                node_vdom = node_intf.child_branch.find_tree_node(
                    key, list_set_vdom)
                if node_vdom.node_type.value > 0:
                    node_vdom.list_value = [
                        "set", "vdom", '"' + mapped_name + '"']

                idx = intf_name.find(old_postfix)
                if idx > 0:
                    new_name = intf_name[:idx] + new_postfix
                    node_intf.rename_edit_name(new_name)
                    dic_replace_mapping[intf_name] = new_name

        dic_replace_count = {}
        for intf_name in dic_replace_mapping.keys():
            dic_replace_count[intf_name] = 0

        self.replace_interface_name(
            self.config_root, dic_replace_mapping, dic_replace_count)

    def replace_interface_name(self, root, dic_mapping, dic_count):

        if not root.list_child:
            return

        for node in root.list_child:

            mapped_name = ""
            if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH and node.key == "edit":
                if len(node.list_value) > 1:
                    mapped_name = self.get_intf_name_if_matched(
                        dic_mapping, dic_count, node.list_value[1])

                    if len(mapped_name) > 0:
                        node.list_value[1] = mapped_name

            elif node.node_type == FGTNodeType.FGTNODE_TYPE_LEAF and node.key == "set" and len(node.list_value) > 2:
                for idx in range(2, len(node.list_value)):
                    mapped_name = self.get_intf_name_if_matched(
                        dic_mapping, dic_count, node.list_value[idx])

                    if mapped_name:
                        node.list_value[idx] = mapped_name

            if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                self.replace_interface_name(
                    node.child_branch, dic_mapping, dic_count)

    def get_intf_name_if_matched(self, dic_mapping, dic_count, orig_str):

        if orig_str in ("dmz", "lan", "wan"):
            return ""

        if orig_str in dic_mapping:
            dic_count[orig_str] += 1
            return dic_mapping[orig_str]

        orig_str_no_quote = remove_quota(orig_str)
        if orig_str_no_quote in dic_mapping:
            dic_count[orig_str_no_quote] += 1
            return '"' + dic_mapping[orig_str_no_quote] + '"'

        return ""

    def replace_vdom_name_config_sys_admin(self, original_vdom, mapped_name):

        config = "config"
        list_value = ("config", "system", "admin")
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_gui_dashboard = ("config", "gui-dashboard")
        list_vdom = ["set", "vdom", f'\"{original_vdom}\"']

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_gui_dashboard = node_edit.child_branch.find_tree_node(
                config, list_gui_dashboard)
            if node_gui_dashboard.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            for grand_node_edit in node_gui_dashboard.child_branch.list_child:
                if grand_node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_vdom = grand_node_edit.child_branch.loose_find_tree_node(
                    key, list_vdom)
                if node_vdom.node_type.value > 0:
                    node_vdom.rename_option('"' + mapped_name + '"')

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_vdom = node_edit.child_branch.loose_find_tree_node(
                key, list_vdom)
            if node_vdom.node_type.value > 0:
                node_vdom.rename_option('"' + mapped_name + '"')

    def replace_vdom_name_config_sys_vdomproperty(self, original_vdom, mapped_name):

        key = "config"
        list_value = ["config", "system", "vdom-property"]
        node_config = self.config_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            if node_edit.list_value[1] == original_vdom or node_edit.list_value[1] == '"' + original_vdom + '"':
                node_edit.rename_edit_name('"' + mapped_name + '"')

    def replace_vdom_name_config_sys_ha(self, original_vdom, mapped_name):

        key = "config"
        list_value = ["config", "system", "ha"]
        node_config = self.config_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        list_value = ["config", "secondary-vcluster"]
        node_secondary = node_config.child_branch.find_tree_node(
            key, list_value)
        if node_secondary.node_type.value == 0:
            return

        key = "set"
        list_value = ["set", "vdom"]
        node_vdom = node_secondary.child_branch.loose_find_tree_node(
            key, list_value)
        for i in range(len(node_vdom.list_value)):
            if remove_quota(node_vdom.list_value[i]) == original_vdom:
                node_vdom.list_value[i] = '"' + mapped_name + '"'

    def replace_vdom_name_config_wireless_controller_vap(self, original_vdom, mapped_name):
        key = "config"
        list_value = ["config", "wireless-controller", "vap"]
        node_config = self.config_root.find_tree_node(key, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_vdom = ["set", "vdom", f'\"{original_vdom}\"']

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_vdom = node_edit.child_branch.loose_find_tree_node(
                key, list_vdom)
            if node_vdom.node_type.value > 0:
                node_vdom.rename_option('"' + mapped_name + '"')

    def replace_vdom_name(self, original_vdom, mapped_name):
        self.replace_vdom_name_config_vdom(original_vdom, mapped_name)
        self.replace_vdom_name_config_sys_intf(original_vdom, mapped_name)
        self.replace_vdom_name_config_sys_admin(original_vdom, mapped_name)
        self.replace_vdom_name_config_sys_vdomproperty(
            original_vdom, mapped_name)
        self.replace_vdom_name_config_sys_ha(original_vdom, mapped_name)
        self.replace_vdom_name_config_wireless_controller_vap(
            original_vdom, mapped_name)

    def generate_config_file(self, output_file_path):
        try:
            with open(output_file_path, "wb") as output_file:
                self.config_root.write_config_file(output_file)

        except Exception as e:
            # log.syslog.exception(f'GenerateConfigFile exception. {e}')
            pass

    def collect_vdom_list(self):

        list_vdom = []
        if self.config_root:

            key = "config"
            list_value = ["config", "vdom"]
            node = self.config_root.find_tree_node(key, list_value)

            if node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                # Find the first node, there will be several nodes can be matched.
                if len(node.child_branch.list_child) > 0:
                    # Get "edit" child.
                    for child in node.child_branch.list_child:
                        if child.key == "edit":
                            if len(child.list_value) == 2:
                                vdom = child.list_value[1]
                                if vdom not in list_vdom:
                                    list_vdom.append(vdom)
            else:
                # User not enable admin-vdom.
                if "root" not in list_vdom:
                    list_vdom.append("root")

        return list_vdom

    def apply_interface_mapping(self, mapping):

        dic_replace_mapping = {
            intf["source_interface"]: intf for intf in mapping}

        # Update logical interface name accordingly.
        str_config = "config"
        list_value = ("config", "system", "interface")
        key = "set"
        list_allowaccess = ("set", "allowaccess")
        list_ip = ("set", "ip")
        node_config = self.config_root.find_tree_node(str_config, list_value)
        if node_config.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
            list_remove_node = []

            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                # Get the interface name, can be physical or logical.
                intf_name = remove_quota(node_edit.list_value[-1])

                # Check if the name can be found in interface mapping list.
                if intf_name in dic_replace_mapping:
                    # Mapping IP and allowaccess
                    node_ip = node_edit.child_branch.loose_find_tree_node(
                        key, list_ip)
                    if node_ip.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                        if not dic_replace_mapping[intf_name]["IP"]:
                            list_remove_node.append(node_ip)
                        else:
                            node_ip.list_value = [
                                "set", "ip"] + dic_replace_mapping[intf_name]["IP"].split(" ")
                    node_access = node_edit.child_branch.loose_find_tree_node(
                        key, list_allowaccess)
                    if node_access.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                        if not dic_replace_mapping[intf_name]["Access"]:
                            list_remove_node.append(node_access)
                        else:
                            node_access.list_value = [
                                "set", "allowaccess"] + dic_replace_mapping[intf_name]["Access"].split(" ")

                else:
                    list_value = ["set", "type", "physical"]
                    node_physical_intf = node_edit.child_branch.find_tree_node(
                        "set", list_value)
                    # Only remove physical interfaces.
                    if node_physical_intf.node_type == FGTNodeType.FGTNODE_TYPE_LEAF:
                        list_remove_node.append(node_edit)

                    # For logical interface name such as "port1.20", should be renamed to "mapped port.20".
                    elif intf_name.find('.') > 0:
                        orig_name = intf_name
                        name_split = orig_name.split('.')
                        if name_split[0] in dic_replace_mapping:
                            mapped_name = dic_replace_mapping[name_split[0]]
                            dic_replace_mapping[intf_name] = intf_name.replace(
                                name_split[0], mapped_name)

            if len(list_remove_node) > 0:
                for remove_node in list_remove_node:
                    remove_node.remove_tree_node()

        dic_replace_count = {}
        for intf_name in dic_replace_mapping.keys():
            dic_replace_count[intf_name] = 0

        name_mapping = {intf["source_interface"]: intf["FortiGate_interface"]
                        if intf["FortiGate_interface"] else intf["source_interface"] for intf in mapping}
        self.replace_interface_name(
            self.config_root, name_mapping, dic_replace_count)

    def swap_interface_to_prevent_disconnected(self, connect_info, target_dev):
        config = "config"
        list_value = ("config", "system", "interface")

        target_node_config = target_dev.config_root.find_tree_node(
            config, list_value)
        target_interface = target_node_config.child_branch.find_branch_node_edit(
            connect_info["interface"])

        keep_interface = self.swap_node(
            list_value=list_value, node_name=connect_info["interface"], target_node=target_interface)
        return keep_interface

    def swap_node(self, list_value, node_name, target_node):
        node_config = self.config_root.find_tree_node("config", list_value)
        for index, node_edit in enumerate(node_config.child_branch.list_child):
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            if remove_quota(node_edit.list_value[-1]) == node_name:
                keep_interface = node_edit.clone(node_edit.parent_branch)
                node_config.child_branch.list_child[index] = target_node

                return keep_interface

    def recovery_interface_ip_allowaccess(self, node_edit, target_interface):
        key = "set"
        list_ip = ("set", "ip")
        list_allowaccess = ("set", "allowaccess")
        list_status = ("set", "status")

        connect_intf_name = node_edit.list_value[-1]
        for node_leaf in node_edit.child_branch.list_child:
            if node_leaf.node_type != FGTNodeType.FGTNODE_TYPE_LEAF:
                continue

            if node_leaf.loose_compare_node_value(key, list_ip):
                t_ip = target_interface.child_branch.loose_find_tree_node(
                    key, list_ip)
                if t_ip.node_type.value != 0:
                    print(
                        f'Recovery {connect_intf_name} IP: {node_leaf.list_value} -> {t_ip.list_value}')
                    node_leaf.list_value = t_ip.list_value

            elif node_leaf.loose_compare_node_value(key, list_allowaccess):
                t_allowaccess = target_interface.child_branch.loose_find_tree_node(
                    key, list_allowaccess)
                if t_allowaccess.node_type.value != 0:
                    print(
                        f'Recovery {connect_intf_name} IP: {node_leaf.list_value} -> {t_allowaccess.list_value}')
                    node_leaf.list_value = t_allowaccess.list_value

            elif node_leaf.loose_compare_node_value(key, list_status):
                # interface should always up, remove the node, then default value is up
                print(f'Remove status in node {connect_intf_name}')
                node_leaf.remove_tree_node()

    def remove_default_route(self):
        # This method is hardcode for removing "9999" static route.
        # 9999 is used by FortiConverter service team routing the traffic in lab.
        node_config = self.config_root.find_tree_node(
            "config", ("config", "router", "static"))
        find_route = node_config.child_branch.find_branch_node_edit("9999")
        if find_route.node_type.value != 0:
            find_route.remove_tree_node()

    def get_session_helpers(self):

        class SessionHelper:
            def __init__(self, idx, name, protocol, port):
                self.idx = int(idx)
                self.name = name
                self.protocol = protocol
                self.port = port

            def equal_content(self, name, protocol, port):
                return self.name == name and self.protocol == protocol and self.port == port

        config = "config"
        list_value = ["config", "system", "session-helper"]
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return []

        list_name = ["set", "name"]
        list_protocol = ["set", "protocol"]
        list_port = ["set", "port"]

        session_helper_list = []
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH or len(node_edit.list_value) < 2:
                continue

            idx = node_edit.list_value[1]
            name = node_edit.child_branch.get_list_word(list_name)
            protocol = node_edit.child_branch.get_list_word(list_protocol)
            port = node_edit.child_branch.get_list_word(list_port)
            if name and protocol and port:
                session_helper_list.append(SessionHelper(
                    idx, name[0], protocol[0], port[0]))
        return session_helper_list

    def get_default_dlp_sensors_with_filter(self):

        config = "config"
        list_value = ["config", "dlp", "sensor"]
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return []

        list_filter = ["config", "filter"]

        dlp_sensor_with_filter_list = []
        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH or len(node_edit.list_value) < 2:
                continue

            sensor_name = node_edit.list_value[1]
            node_filter = node_edit.child_branch.find_tree_node(
                config, list_filter)
            if node_filter.node_type.value > 0 and len(node_filter.list_value) > 1:
                dlp_sensor_with_filter_list.append(sensor_name)

        return dlp_sensor_with_filter_list


class ConfigTrimmer:
    def __init__(self, device):
        self.device = device
        self.device_model = device.model
        self.config_root = device.config_root
        self.intf_mapped_name_list = []

        # self.convert_job = device.forti_convert_job
        # self.conversion_id = device.forti_convert_job.conversion_id
        # self.output_major = device.forti_convert_job.output_major
        # self.output_minor = device.forti_convert_job.output_minor
        # self.output_patch = device.forti_convert_job.output_patch

    @classmethod
    def trim_source(cls, source_dev, target_dev):
        source = cls(source_dev)

        source.remove_uuid_setting()
        source.reset_admin_password()
        source.remove_admin_user_settings()
        source.convert_host_name()
        source.remove_fortitoken_string()
        source.remove_default_search_engine()
        source.remove_config_system_storage()
        source.remove_snmpindex_in_interface()
        source.remove_config_wanopt_storage()
        source.remove_config_system_switch()
        source.remove_duplicate_default_session_helper(target_dev)
        source.remove_virtual_wire_pair()
        source.remove_conflict_default_dlp_sensor_filter(target_dev)
        source.move_mode_aggressive_in_ipsec_phase1()
        source.remove_default_vpn_certificate()

        return source.device

    @classmethod
    def trim_target(cls, source_dev, target_dev):
        target = cls(target_dev)

        # target.intf_mapped_name_list = target.get_interface_mapped_name()
        target.remove_physcal_intf_type_setting()
        target.remove_webfilter_profile_filters(source_dev)
        target.remove_log_threatweight_web_items()
        target.remove_config_system_settings()
        target.remove_config_system_email_server()
        target.remove_config_system_session_helper(source_dev)
        target.remove_config_vpn_ssl_settings()
        target.remove_config_vpn_ssl_web_portal()
        # target.remove_config_firewall_sniffer()
        target.remove_config_system_virtual_wire_pair()
        target.remove_fortilink_member()
        target.remove_sslvpn_default_address()

        return target.device

    # def get_interface_mapped_name(self):
    #     intf_set = DisplayIF.objects.filter(
    #         conversion_id=self.conversion_id).exclude(device="target")
    #     return (intf.mapped_name for intf in intf_set)

    # Remove command "set uuid xxxx" under firewall address, address6, vip ippool and policy view.
    def remove_uuid_setting(self):
        str_config = "config"
        str_set = "set"
        list_uuid = ["set", "uuid"]

        list_value = ["config", "firewall", "address"]
        list_node = self.config_root.strict_match_tree_node(
            str_config, list_value)

        if list_node:
            for node_config in list_node:
                for node_edit in node_config.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        node_edit.child_branch.loose_find_and_remove_node(
                            str_set, list_uuid)

        list_value = ["config", "firewall", "address6"]
        list_node = self.config_root.strict_match_tree_node(
            str_config, list_value)

        if list_node:
            for node_config in list_node:
                for node_edit in node_config.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        node_edit.child_branch.loose_find_and_remove_node(
                            str_set, list_uuid)

        list_value = ["config", "firewall", "vip"]
        list_node = self.config_root.strict_match_tree_node(
            str_config, list_value)

        if list_node:
            for node_config in list_node:
                for node_edit in node_config.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        node_edit.child_branch.loose_find_and_remove_node(
                            str_set, list_uuid)

        list_value = ["config", "firewall", "ippool"]
        list_node = self.config_root.strict_match_tree_node(
            str_config, list_value)

        if list_node:
            for node_config in list_node:
                for node_edit in node_config.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        node_edit.child_branch.loose_find_and_remove_node(
                            str_set, list_uuid)

        list_value = ["config", "firewall", "policy"]
        list_node = self.config_root.strict_match_tree_node(
            str_config, list_value)

        if list_node:
            for node_config in list_node:
                for node_edit in node_config.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        node_edit.child_branch.loose_find_and_remove_node(
                            str_set, list_uuid)

    # Reset password to empty for admin account.
    def reset_admin_password(self):

        str_config = "config"
        str_set = "set"
        list_value = ["config", "system", "admin"]
        list_node = self.config_root.strict_match_tree_node(
            str_config, list_value)

        if list_node:
            for node_config in list_node:
                # Remove "set password" node.
                list_value = ("set", "password")
                for edit_node in node_config.child_branch.list_child:
                    if edit_node.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        edit_node.child_branch.loose_find_and_remove_node(
                            str_set, list_value)

    def remove_admin_user_settings(self):
        config = "config"
        list_value = ("config", "system", "admin")
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_gui_dashboard = ("config", "gui-dashboard")
        list_login_time = ("config", "login-time")

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(
                config, list_gui_dashboard)
            node_edit.child_branch.loose_find_and_remove_node(
                config, list_login_time)

    def remove_physcal_intf_type_setting(self):
        # Remove type setting of interface to avoid overwrite the type change of new device.
        key = "config"
        list_value = ["config", "system", "interface"]
        list_node = self.config_root.strict_match_tree_node(key, list_value)
        if not list_node:
            return

        key = "set"
        list_physical = ["set", "type", "physical"]
        list_unspecified = ["set", "type", "unspecified"]
        list_mtu = ["set", "mtu"]
        list_mtu_override = ["set", "mtu-override"]
        list_alias = ["set", "alias"]
        list_auth_type = ["set", "auth-type"]
        list_macaddr = ["set", "macaddr"]

        for node_config in list_node:
            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                node_edit.child_branch.find_and_remove_node(key, list_physical)
                node_unspecified = node_edit.child_branch.find_tree_node(
                    key, list_unspecified)

                if node_unspecified.node_type.value > 0:
                    node_unspecified.remove_tree_node()
                    node_edit.child_branch.loose_find_and_remove_node(
                        key, list_mtu)
                    node_edit.child_branch.loose_find_and_remove_node(
                        key, list_mtu_override)
                    node_edit.child_branch.loose_find_and_remove_node(
                        key, list_alias)
                    node_edit.child_branch.loose_find_and_remove_node(
                        key, list_auth_type)
                    node_edit.child_branch.loose_find_and_remove_node(
                        key, list_macaddr)

    # Remove hostname in converted source_dev if migrate hostname option is disabled.
    def convert_host_name(self):
        host_name = self.device.collect_host_name()
        sn_pattern = '^(FGT|FG|FGVM|FWF|FW|FOS|)[0-9]+[A-Z0-9]+$'

        if not re.match(sn_pattern, host_name):
            return

        if host_name:
            self.device.remove_host_alias_name(host_name)

    # Remove set fortitoken and set two-factor fortitoken under config user local
    def remove_fortitoken_string(self):
        str_config = "config"
        str_set = "set"
        list_two_factor = ["set", "two-factor", "fortitoken"]
        list_fortitoken = ["set", "fortitoken"]

        list_value = ["config", "user", "local"]
        list_node = self.config_root.strict_match_tree_node(
            str_config, list_value)

        if list_node:
            for node_config in list_node:
                for node_edit in node_config.child_branch.list_child:
                    if node_edit.node_type == FGTNodeType.FGTNODE_TYPE_BRANCH:
                        node_edit.child_branch.find_and_remove_node(
                            str_set, list_two_factor)
                        node_edit.child_branch.loose_find_and_remove_node(
                            str_set, list_fortitoken)

    # Remove default search-engine in webfilter
    def remove_default_search_engine(self):
        # Remove deafult search-engine in FortiGate
        config = "config"
        list_value = ("config", "webfilter", "search-engine")

        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_default_node = []
        list_default_value = ("google", "yahoo", "bing", "yandex", "youtube",
                              "baidu", "baidu2", "baidu3")

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            if remove_quota(node_edit.list_value[1]) in list_default_value:
                list_default_node.append(node_edit)

        for node in list_default_node:
            node.remove_tree_node()

        if len(node_config.child_branch.list_child) == 1 and node_config.child_branch.list_child[0].key == "end":
            node_config.remove_tree_node()

    # Remove "config filter" in "config webfilter profile" to avoid category conflict in source and target configs.
    def remove_webfilter_profile_filters(self, source_dev):
        source_profile_name_list = source_dev.get_webfilter_profile_names()

        config = "config"
        list_value = ["config", "webfilter", "profile"]
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return []

        list_ftgdwf = ["config", "ftgd-wf"]
        list_filter = ["config", "filters"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH or len(node_edit.list_value) < 2:
                continue

            name = node_edit.list_value[1]
            if name not in source_profile_name_list:
                continue

            node_ftgdwf = node_edit.child_branch.find_tree_node(
                config, list_ftgdwf)
            if node_ftgdwf.node_type.value == 0:
                continue

            node_ftgdwf.child_branch.find_and_remove_node(config, list_filter)

    # Remove "config system storage" in source device because it is a read-only hardware property.
    def remove_config_system_storage(self):

        config = "config"
        list_value = ["config", "system", "storage"]
        self.config_root.find_and_remove_node(config, list_value)

    # Remove "snmp-index" in each interface setting because it would be given by the system.
    def remove_snmpindex_in_interface(self):

        config = "config"
        list_value = ["config", "system", "interface"]
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return []

        set = "set"
        list_snmpindex = ["set", "snmp-index"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_edit.child_branch.loose_find_and_remove_node(
                set, list_snmpindex)

    # Remove "config wanopt storage" in source device because it is a read-only hardware property.
    def remove_config_wanopt_storage(self):

        config = "config"
        list_value = ["config", "wanopt", "storage"]
        self.config_root.find_and_remove_node(config, list_value)

    # Remove "config system physical-switch" and "config system virtual-switch" because they are device dependant
    def remove_config_system_switch(self):

        config = "config"
        list_value = ["config", "system", "physical-switch"]
        self.config_root.find_and_remove_node(config, list_value)

        list_value = ["config", "system", "virtual-switch"]
        self.config_root.find_and_remove_node(config, list_value)

    def remove_duplicate_default_session_helper(self, target_dev):
        target_session_helper_list = target_dev.get_session_helpers()

        config = "config"
        list_value = ["config", "system", "session-helper"]
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return []

        list_name = ["set", "name"]
        list_protocol = ["set", "protocol"]
        list_port = ["set", "port"]
        list_edit_remove = []

        list_idx = []
        max_idx = 0
        for session_helper in target_session_helper_list:
            list_idx.append(session_helper.idx)
            max_idx = max_idx if max_idx >= session_helper.idx else session_helper.idx

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH or len(node_edit.list_value) < 2:
                continue

            idx = int(node_edit.list_value[1])
            name = node_edit.child_branch.get_list_word(list_name)
            protocol = node_edit.child_branch.get_list_word(list_protocol)
            port = node_edit.child_branch.get_list_word(list_port)
            for session_helper in target_session_helper_list:
                if session_helper.equal_content(name[0], protocol[0], port[0]):
                    list_edit_remove.append(node_edit)
                    break
            else:
                if idx in list_idx:
                    idx = max_idx + 1
                    node_edit.list_value[1] = str(idx)
                max_idx = max_idx if max_idx >= idx else idx
                list_idx.append(idx)

        for node_edit in list_edit_remove:
            node_edit.remove_tree_node()

    def remove_log_threatweight_web_items(self):

        config = "config"
        list_value = ["config", "log", "threat-weight"]
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return []

        list_web = ["config", "web"]
        node_config.child_branch.find_and_remove_node(config, list_web)

    def remove_virtual_wire_pair(self):

        config = "config"
        list_value = ["config", "system", "virtual-wire-pair"]
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        node_config.remove_tree_node()

    def remove_conflict_default_dlp_sensor_filter(self, target_dev):
        dlp_sensor_with_filter_list = target_dev.get_default_dlp_sensors_with_filter()

        config = "config"
        list_value = ["config", "dlp", "sensor"]
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        list_filter = ["config", "filter"]

        for node_edit in node_config.child_branch.list_child:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH or len(node_edit.list_value) < 2:
                continue

            sensor_name = node_edit.list_value[1]
            if sensor_name not in dlp_sensor_with_filter_list:
                continue

            node_filter = node_edit.child_branch.find_tree_node(
                config, list_filter)
            if node_filter.node_type.value > 0 and len(node_filter.list_value) > 1:
                node_filter.remove_tree_node()

    # Move "set mode aggressive" to the front of "set peertype dialup" in "config vpn ipsec phase1"
    def move_mode_aggressive_in_ipsec_phase1(self):

        config = "config"
        list_value = ["config", "vpn", "ipsec", "phase1"]
        list_phase1_node = []
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value > 0:
            list_phase1_node.extend(node_config.child_branch.list_child)

        list_value = ["config", "vpn", "ipsec", "phase1-interface"]
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value > 0:
            list_phase1_node.extend(node_config.child_branch.list_child)

        if len(list_phase1_node) == 0:
            return

        set = "set"
        list_mode_aggressive = ["set", "mode", "aggressive"]
        list_peertype_dialup = ["set", "peertype", "dialup"]

        for node_edit in list_phase1_node:
            if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                continue

            node_mode_aggressive = node_edit.child_branch.find_tree_node(
                set, list_mode_aggressive)
            node_peertype_dialup = node_edit.child_branch.find_tree_node(
                set, list_peertype_dialup)
            if node_mode_aggressive.node_type.value == 0 or node_peertype_dialup.node_type.value == 0:
                continue

            peertype_idx = node_peertype_dialup.get_location_index()
            mode_idx = node_mode_aggressive.get_location_index()
            if peertype_idx < mode_idx:
                node_edit.move_tree_node(node_mode_aggressive, peertype_idx)

    def remove_default_vpn_certificate(self):
        config = "config"
        list_value = ("config", "vpn", "certificate", "local")
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value > 0:
            list_remove = []
            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                if remove_quota(node_edit.list_value[1]).startswith('Fortinet_SSL') or \
                        remove_quota(node_edit.list_value[1]).startswith('Fortinet_CA'):
                    list_remove.append(node_edit)

            for node in list_remove:
                node.remove_tree_node()

    def remove_config_system_settings(self):
        if self.output_major > 6 and self.output_minor > 0:
            return

        config = "config"
        list_value = ("config", "system", "settings")
        list_node = self.config_root.strict_match_tree_node(config, list_value)
        if len(list_node) == 0:
            return

        key = "set"
        list_inspection = ("set", "inspection-mode", "flow")
        for node in list_node:
            node.child_branch.find_and_remove_node(key, list_inspection)

    def remove_config_system_email_server(self):
        config = "config"
        list_value = ("config", "system", "email-server")
        node_config = self.config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            return

        key = "set"
        list_port = ("set", "port", "465")
        node_config.child_branch.find_and_remove_node(key, list_port)

    # If the source file does not contain an entry that has 'set name sip',
    # then remove the 'edit 13' block that contains 'set name sip' in the default target configuration.
    def remove_config_system_session_helper(self, source_dev):
        config = "config"
        list_value = ("config", "system", "session-helper")

        def remove_target_system_session_helper_sip():
            node_target_config = self.config_root.find_tree_node(
                config, list_value)
            if node_target_config.node_type.value == 0:
                return

            node_target_config.child_branch.find_and_remove_node(
                "edit", ("edit", "13"))

        source_config_root = source_dev.config_root
        node_config = source_config_root.find_tree_node(config, list_value)
        if node_config.node_type.value == 0:
            remove_target_system_session_helper_sip()
        else:
            node_edit = node_config.child_branch.find_tree_node("edit", "13")
            if node_edit.node_type.value == 0:
                remove_target_system_session_helper_sip()

    def remove_config_vpn_ssl_settings(self):
        config = "config"
        list_value = ("config", "vpn", "ssl", "settings")
        list_node = self.config_root.strict_match_tree_node(config, list_value)
        if len(list_node) == 0:
            return

        key = "set"
        list_port = ("set", "port", "443")
        for node in list_node:
            node.child_branch.find_and_remove_node(key, list_port)

    def remove_config_vpn_ssl_web_portal(self):
        config = "config"
        list_value = ("config", "vpn", "ssl", "web", "portal")
        list_node = self.config_root.strict_match_tree_node(config, list_value)
        if len(list_node) == 0:
            return

        for node in list_node:
            node.remove_tree_node()

    # def remove_config_firewall_sniffer(self):
    #     if self.device_model not in ("FG-5H0E", "FG-5H1E", "FG-6H0E", "FG-6H1E"):
    #         return

    #     if not ({'s1', 's2'} & set(self.intf_mapped_name_list)):
    #         return

    #     config = "config"
    #     list_value = ("config", "firewall", "sniffer")
    #     list_node = self.config_root.strict_match_tree_node(config, list_value)
    #     if len(list_node) == 0:
    #         return

    #     for node in list_node:
    #         node.remove_tree_node()

    #     list_value = ("config", "system", "interface")
    #     list_node = self.config_root.strict_match_tree_node(config, list_value)
    #     if len(list_node) == 0:
    #         return

    #     key = "set"
    #     list_ips_sniffer_mode = ("set", "ips-sniffer-mode", "enable")

    #     for node_config in list_node:
    #         for node_edit in node_config.child_branch.list_child:
    #             if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
    #                 continue

    #             node_edit.child_branch.find_and_remove_node(
    #                 key, list_ips_sniffer_mode)

    def remove_config_system_virtual_wire_pair(self):
        if self.device_model not in ("FG-5H0E", "FG-5H1E", "FG-6H0E", "FG-6H1E"):
            return

        if not ({'vw1', 'vw2'} & set(self.intf_mapped_name_list)):
            return

        config = "config"
        list_value = ("config", "system", "virtual-wire-pair")
        list_node = self.config_root.strict_match_tree_node(config, list_value)
        if len(list_node) == 0:
            return

        for node in list_node:
            node.remove_tree_node()

    def remove_fortilink_member(self):
        intersection = {'x1', 'x2', 'x3', 'x4', 'a',
                        'b'} & set(self.intf_mapped_name_list)
        if not intersection:
            return

        config = "config"
        list_value = ("config", "system", "interface")
        list_node = self.config_root.strict_match_tree_node(config, list_value)
        if len(list_node) == 0:
            return

        key = "set"
        list_memeber = ("set", "member")
        for node_config in list_node:
            for node_edit in node_config.child_branch.list_child:
                if node_edit.node_type != FGTNodeType.FGTNODE_TYPE_BRANCH:
                    continue

                member_node = node_edit.child_branch.loose_find_tree_node(
                    key, list_memeber)
                if member_node.node_type.value == 0:
                    continue

                for intf in (x for x in intersection if f"\"{x}\"" in member_node.list_value):
                    member_node.list_value.remove(f"\"{intf}\"")

                if len(member_node.list_value) < 3:
                    member_node.key = "unset"
                    member_node.list_value = ["unset", "member"]

    def remove_sslvpn_default_address(self):
        config = "config"
        list_address = ("config", "firewall", "address")
        list_node = self.config_root.strict_match_tree_node(
            config, list_address)
        if len(list_node) == 0:
            return

        key = "edit"
        list_sslvpn_addr = ("edit", "SSLVPN_TUNNEL_ADDR1")
        for node_config in list_node:
            node_config.child_branch.find_and_remove_node(
                key, list_sslvpn_addr)

        list_address6 = ("config", "firewall", "address6")
        list_node = self.config_root.strict_match_tree_node(
            config, list_address6)
        if len(list_node) == 0:
            return
        list_sslvpn_addr6 = ("edit", "SSLVPN_TUNNEL_IPv6_ADDR1")
        for node_config in list_node:
            node_config.child_branch.find_and_remove_node(
                key, list_sslvpn_addr6)
