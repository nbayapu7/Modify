from smb.SMBConnection import SMBConnection


class FileServer:
    def __init__(self, file_path) -> None:
        self.conn = SMBConnection("", "", "worker_service",
                                  'FILESERVER', use_ntlm_v2=True)

        # file_path: "/swap/users/FortiConverter/auto-demo/1234/"
        split_path = file_path.strip("/").split('/')
        self.service_name = split_path[0]
        self.file_dir = f'/{"/".join(split_path[1:])}/'

    def new_connection(self, host, port=445):
        assert self.conn.connect(host, port)

    def retrive_file(self, remote_file, tempfile):
        self.conn.retrieveFile(self.service_name,
                               self.file_dir + remote_file, tempfile)

    def store_file(self, file_name, file_io):
        self.conn.storeFile(self.service_name,
                            self.file_dir + file_name, file_io)
