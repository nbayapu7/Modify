import json
import time

import requests
import urllib3
from requests.exceptions import ConnectionError

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def login_required(func):
    def decorator(*args, **kwargs):
        job = args[0]
        if job.connector.use_token:
            return func(*args, **kwargs)

        job.connector.login()
        res = func(*args, **kwargs)
        job.connector.logout()
        return res

    return decorator


class FortiGateConnector:
    def __init__(self) -> None:
        self._session = requests.session()
        self._session.verify = False  # Use to pass https verification
        self.timeout = 15
        self.host = ""
        self._username = "admin"
        self._password = ""
        self._api_token = ""
        self._https = 443
        self.use_token = False

        if self.use_token:
            self._session.headers.update(
                {'Authorization': 'Bearer ' + self.api_token})

    @classmethod
    def connect(cls, host, username, password, https_port=443):
        conn = cls()
        conn._host, conn._username, conn._password, conn.https_port, = host, username, password, https_port
        conn.url_prefix = f'https://{host}'
        conn.connection_test()
        return conn

    def update_cookie(self):
        for cookie in self._session.cookies:
            if cookie.name == 'ccsrftoken':
                csrftoken = cookie.value[1:-1]
                self._session.headers.update({'X-CSRFTOKEN': csrftoken})

    def login(self):
        try:
            login_url = self.url_prefix + '/logincheck?username={0}&secretkey={1}&ajax=1'.format(self._username,
                                                                                                 self._password)
            res = self._session.post(login_url, timeout=self.timeout)
            if res.content.decode('ascii')[0] == '1':
                self.update_cookie()
                print("Successful login")
                return res
            else:
                raise Exception

        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise Exception("Log in failed: " + str(ex))

    def connection_test(self):
        try:
            if self.use_token:
                result = self.get("monitor", "system", "status", "", "", {})
                data = json.loads(result)
                if data["status"] != "success":
                    raise ConnectionError
            else:
                self.login()
                self.logout()
            return "online"
        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise ConnectionError(ex)

    def test_device_reboot(self):
        time.sleep(60)

        # set a 3 minutes timeout for the server connection test
        timeout = time.time() + 3 * 60
        while True:
            if self.connection_test() == "online":
                break

            if time.time() > timeout:
                raise TimeoutError("Device reboot timeout!")

    def get(self, api, path, name, action, mkey, parameters):
        try:
            url = self.get_api_url(api, path, name, action, mkey, parameters)
            res = self._session.get(url, timeout=self.timeout)
            return res.content.decode("utf-8", "ignore")
        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise Exception("Request GET failed: " + str(ex))

    def post(self, api, path, name, action, mkey, parameters, data):
        try:
            url = self.get_api_url(api, path, name, action, mkey, parameters)
            data_json = json.dumps(data).encode("utf-8")
            res = self._session.post(url, data=data_json, timeout=self.timeout)
            return res
        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise Exception("Request POST failed: " + str(ex))

    def put(self, api, path, name, action, mkey, parameters, data):

        try:
            url = self.get_api_url(api, path, name, action, mkey, parameters)
            data_json = json.dumps(data).encode('utf-8')
            res = self._session.put(url, data=data_json, timeout=self.timeout)

            return res
        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise Exception("Request PUT failed: " + str(ex))

    def download(self, api, path, name, action, mkey, parameters):
        res = self.get(api, path, name, action, mkey, parameters)
        return res

    def upload(self, api, path, name, action, mkey, parameters, data, files_dict=None):
        try:
            files = [(name, (name, open(path, "r", encoding="utf-8"), "text/plain"))
                     for name, path in files_dict.items()]
            url = self.get_api_url(api, path, name, action, mkey, parameters)
            res = self._session.post(
                url, params=parameters, data=data, files=files, timeout=5)
            return res
        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise Exception("Request POST failed in Upload: " + str(ex))

    def logout(self):
        try:
            logout_url = self.url_prefix + "/logout/"
            self._session.post(logout_url, timeout=self.timeout)
            self._session.close()
            self._session.cookies.clear()

        except ConnectionError as ce:
            raise ConnectionError(ce)
        except Exception as ex:
            raise Exception("Log out failed: " + str(ex))

    def get_api_url(self, api, path, name, action, mkey, parameters):
        url_builder = []
        url_builder.append(
            "{0}/api/v2/{1}/{2}/{3}".format(self.url_prefix, api, path, name))
        if action:
            url_builder.append("/" + action)
            if mkey:
                url_builder.append("/" + mkey)

        if self.use_token:
            parameters["access_token"] = self.api_token

        if parameters:
            param_list = ["{0}={1}".format(key, value)
                          for key, value in parameters.items()]
            url_builder.append("?" + "&".join(param_list))

        return "".join(url_builder)
