# Debug
# task_always_eager = True

# Broker settings.
broker_url = 'redis://localhost:6379/0'
result_backend = 'redis://localhost:6379/0'

# List of modules to import when the Celery worker starts.
imports = ('celery_app.fortinet.tasks')

task_serializer = 'pickle'
result_serializer = 'pickle'
accept_content = ['json', 'pickle']
# timezone = 'Europe/Oslo'
enable_utc = True
result_expires = '28800'
