from pydantic import BaseModel


class Inputs(BaseModel):
    server: str
    base_dir: str
    source: str
    target: str
    interface_mapping: str


class Device(BaseModel):
    host: str
    username: str
    password: str
    https: int
    interface: str


class Task(BaseModel):
    task_uuid: str
    device_uuid: str
    ticket_id: int
    inputs: Inputs
    connect_info: Device
