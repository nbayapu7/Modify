from pathlib import Path

from celery.result import AsyncResult
from celery.utils import uuid
from celery_app.fortinet.tasks import workflow
from fastapi import APIRouter
from fastapi.responses import JSONResponse

from api.schemas import *

worker_router = APIRouter()


@worker_router.post('/new')
async def new(task: Task):

    working_space = Path("/var/lib/converter/celery")
    task_dict = task.dict()

    workflow(task=task_dict, local_dir=working_space).apply_async()
    # print(workflow.parent.parent.parent.parent.parent.id)

    return JSONResponse({"message": "OK"})


@worker_router.get('/getstate/<task_id>')
def get_state(task_id):
    res = AsyncResult(task_id)
    print(res.state)
    return res.state
