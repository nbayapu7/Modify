const { merge } = require('webpack-merge');
const path = require('path');
const common = require('./webpack.common.js');
const { proxyPort, proxyContext } = require('../package.json');

module.exports = merge(common, {
  mode: 'development',
  devtool: 'eval-cheap-module-source-map',
  cache: {
    type: 'memory', 
  },
  devServer: {
    historyApiFallback: true,
    contentBase: path.join(process.cwd(), './dist'),
    watchContentBase: true,
    open: true,
    hot: true,
    quiet: true,
    port: 3000,
    proxy: [
      {
        context: proxyContext,
        target: `http://localhost:${proxyPort}`,
        secure: false,
        logLevel: 'silent',
        changeOrigin: true,
      },
    ],
  },
});
