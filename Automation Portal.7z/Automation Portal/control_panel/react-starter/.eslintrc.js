// /* eslint-disable import/no-extraneous-dependencies */
// const a11yOff = Object.keys(require('eslint-plugin-jsx-a11y').rules).reduce((acc, rule) => {
//   acc[`jsx-a11y/${rule}`] = 'off';
//   return acc;
// }, {});

// const rules = {
//   ...a11yOff, // disable all a11y rules
//   'for-direction': 'error',
//   'no-console': ['warn', { allow: ['error', 'warn', 'info'] }],
//   'default-case': 'off',
//   'dot-notation': 'off',
//   'consistent-return': 'off',
//   'implicit-arrow-linebreak': 'off',
//   'function-paren-newline': 'off',
//   camelcase: [
//     'error',
//     {
//       properties: 'never',
//       ignoreDestructuring: true,
//     },
//   ],
//   'no-param-reassign': [
//     'error',
//     {
//       props: false,
//     },
//   ],
//   'no-return-assign': ['error', 'except-parens'],
//   eqeqeq: [
//     'error',
//     'always',
//     {
//       null: 'ignore',
//     },
//   ],
//   'guard-for-in': 'error',
//   'no-await-in-loop': 'off',
//   'class-methods-use-this': 'off',
//   'no-underscore-dangle': [
//     'warn',
//     {
//       allowFunctionParams: true,
//       allowAfterThis: true,
//     },
//   ],
//   'no-unused-expressions': [
//     'error',
//     {
//       allowShortCircuit: true,
//     },
//   ],
//   'no-unused-vars': ['warn', { caughtErrors: 'none', ignoreRestSiblings: true }],
//   'object-curly-newline': 'off',

//   // react
//   'react/jsx-curly-newline': 'off',
//   'react/display-name': 'off',
//   'react/prop-types': 'off',
//   'react/forbid-prop-types': 'off',
//   'react/destructuring-assignment': 'off',
//   'react/no-array-index-key': 'off',
//   'react/no-access-state-in-setstate': 'off',
//   'react/jsx-wrap-multilines': 'off',
//   'react/jsx-one-expression-per-line': 'off',
//   'react/require-default-props': 'off',
//   'react/jsx-props-no-spreading': 'off',
//   'react/jsx-filename-extension': [
//     'error',
//     {
//       extensions: ['.js', '.jsx', '.ts', '.tsx'],
//     },
//   ],
//   'react/jsx-no-target-blank': [
//     'error',
//     {
//       enforceDynamicLinks: 'never',
//     },
//   ],

//   // import
//   'import/prefer-default-export': 'off',
//   'import/no-extraneous-dependencies': [
//     'error',
//     {
//       devDependencies: ['./*.*', './config/*.*'],
//     },
//   ],
//   'import/extensions': [
//     'error',
//     {
//       js: 'never',
//       ts: 'never',
//       jsx: 'never',
//       tsx: 'never',
//       ttf: 'never',
//     },
//   ],
// };

// const settings = {
//   react: {
//     version: 'detect',
//   },
//   'import/resolver': {
//     node: {},
//     webpack: {
//       config: './config/webpack.common.js',
//     },
//   },
// };
// module.exports = {
//   root: true,
//   parser: 'babel-eslint',
//   extends: [
//     'eslint:recommended',
//     'airbnb-base',
//     'airbnb/rules/react',
//     'prettier',
//     'plugin:react/recommended',
//     'plugin:prettier/recommended',
//   ],
//   plugins: ['react-hooks', 'react', 'prettier'],
//   parserOptions: {
//     ecmaVersion: 2021,
//     sourceType: 'module',
//     ecmaFeatures: {
//       jsx: true,
//       modules: true,
//     },
//   },
//   ignorePatterns: ['node_modules', 'mock'],
//   env: {
//     es6: true,
//     node: true,
//     browser: true,
//   },
//   globals: {
//     module: true,
//     angular: true,
//   },
//   rules,
//   settings,
//   overrides: [
//     {
//       files: ['*.ts', '*.tsx'],
//       extends: ['plugin:@typescript-eslint/recommended', 'airbnb-typescript', 'prettier'],
//       parser: '@typescript-eslint/parser',
//       plugins: ['react', '@typescript-eslint/eslint-plugin'],
//       parserOptions: {
//         project: './tsconfig.json',
//       },
//       rules: {
//         ...rules,
//         camelcase: 'off',
//         'react/state-in-constructor': 'off',
//         '@typescript-eslint/no-explicit-any': 'off',
//         '@typescript-eslint/no-unused-vars': ['warn'],
//         '@typescript-eslint/explicit-module-boundary-types': [
//           'warn',
//           {
//             allowHigherOrderFunctions: true,
//             allowTypedFunctionExpressions: true,
//           },
//         ],
//       },
//       settings,
//     },
//   ],
// };
