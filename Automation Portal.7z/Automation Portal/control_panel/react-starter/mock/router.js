const login = require('./login');
const dashboard = require('./dashboard');

module.exports = {
  ...login,
  ...dashboard,
};
