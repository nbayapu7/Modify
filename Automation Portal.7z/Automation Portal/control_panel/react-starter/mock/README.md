# About Mock Server

## **Tools**
   * Express
   * [Mockjs](http://mockjs.com/)

## Mock Server Runing Port: 
http://localhost:3333 (Default)
 > You can change it in package.json (mockServerPort)

## How to mock a HTTP response 

#### 1. Start application in *Mock* mode

```sh
npm run start:mock

or

yarn start:mock
```

you will see something like below while starting
```sh
[nodemon] to restart at any time, enter `rs`
[nodemon] watching path(s): mock/**/* proxy.js
[nodemon] watching extensions: js,mjs,json
[nodemon] starting `node proxy.js`
🚀 Mock Server is running
```

#### 2. Add API url in your page router, e.g. `mock/dashboard/index.js`

make sure you have it in `mock/router` which contains all the mocked api

```js
// Key: '[METHOD] [URL]' URl should start with /
// Value: Object/Array/Number/Null or function (req, res) => res.json(xxxx)
'GET /your/api/url': {
  yourKey: yourData
},
```


#### 3. Save the file and mock server will automatically restart

---

### Notes
- Mock server is running indepently. Changes under `mock` folder will trigger a mock server restart, not gulp
- Only defined API will be mocked, others will keep in normal proxy target:





