const MockJS = require('mockjs');
const router = require('./router');
const { mock } = MockJS;

const isFunc = (value) => Object.prototype.toString.call(value) === '[object Function]';

module.exports = (app) => {
  Object.keys(router).forEach((key) => {
    const api = key.split(' ');
    const type = api[0].toLowerCase();
    const url = api[1];
    const response = isFunc(router[key]) ? router[key] : (req, res) => res.json(mock(router[key]));
    app[type](url, response);
  });
};
