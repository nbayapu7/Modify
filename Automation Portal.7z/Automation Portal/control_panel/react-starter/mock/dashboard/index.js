const MockJs = require('mockjs');

module.exports = {
  'DELETE /v1/app/delete': { delete_status: 'DELETE_PENDING', schedule_time: 1617158390788 },
  'GET api/v1/application/status/summary/AzureCasb': {
    service: 'AWSS3',
    applicationId: '66666',
    applicationStatus: 'RUNNING',
    statusInfoList: [
      {
        name: 'DUPLICATED_ACCOUNT',
        message: 'AWS account not previously added.',
        severity: 0,
        failList: [],
      },
      {
        name: 'ROLE',
        message: 'FortiCASB Role generated successfully.',
        severity: 0,
        failList: [],
      },
    ],
    detail: {
      cloudAccount: '77777777777',
      roleArn: 'arn:aws:iam::385279133563:role/daiweiaddawsincasb',
      sessionName: 'FortiCASB',
      externalId:
        'Jgl7DhLCGgPI7drLRPVzykcLezCAqAPckLE9OVmEYbaFpWN_bKXt7jI4BMlSin-KzSHhVTk1akdaxjWGH-PcLQ==',
      cloudTrailName: 'ThreatStackIntegration-ThreatStackTrail-RF0W3X8I5MFG',
      cloudTrailS3: 'threat-stackintegration-38',
    },
  },
  // sync message api
  'GET /api/v1/discovery/status': {
    data: {
      staging: 'onboarding',
      status: 'running',
      step: 'document',
      syncedUsrCnt: 145,
      syncedDocCnt: 1630,
      completedTimestamp: 0,
      syncingResourceList: [
        {
          type: 'resource',
          name: 'alfredau@binxufortinet.onmicrosoft.com',
          id: 'cd72c636-d667-4867-a0b6-18d1342f6484',
          retry: 19,
        },
      ],
      syncFailedResourceList: [],
    },
    code: 0,
    msg: 'success',
    httpCode: 200,
  },
};
