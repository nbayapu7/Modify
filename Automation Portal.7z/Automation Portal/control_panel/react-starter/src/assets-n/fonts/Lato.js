import LatoLight from '@/assets/fonts/Lato-Light.ttf';
import LatoRegular from '@/assets/fonts/Lato-Regular.ttf';
import LatoBold from '@/assets/fonts/Lato-Bold.ttf';

const LatoFontLight = {
  fontFamily: 'Lato',
  fontWeight: 300,
  src: `local('Lato-Light'), 
    url(${LatoLight}) format('truetype')`,
};

const LatoFontRegular = {
  fontFamily: 'Lato',
  fontWeight: 400,
  src: `local('Lato-Regular'), 
  url(${LatoRegular}) format('truetype')`,
};

const LatoFontBold = {
  fontFamily: 'Lato',
  fontWeight: 700,
  src: `local('Lato-Bold'), 
    url(${LatoBold}) format('truetype')`,
};

export default [LatoFontLight, LatoFontRegular, LatoFontBold];
