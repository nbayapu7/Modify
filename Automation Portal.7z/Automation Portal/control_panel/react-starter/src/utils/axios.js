import axios from 'axios';
import dayjs from 'dayjs';

axios.interceptors.request.use(
  (config) => {
    config.headers.timeZone = dayjs().format('ZZ');
    return config;
  },
  (err) => {
    return Promise.reject(err.response.data);
  },
);

axios.interceptors.response.use(({ data, headers, config }) => {
  if (config.ignoreResponseInterceptors) return headers;

  return data;
});
