const put = (key, value, expire) => {
  const expireString = expire ? ` expires=${new Date(expire).toUTCString()};` : '';
  document.cookie = `${encodeURIComponent(key)}=${encodeURIComponent(
    value,
  )};${expireString}path=/;`;
};

const remove = (key) => {
  document.cookie = `${encodeURIComponent(key)}=}; max-age=-99;path=/;`;
};

const getCookieMap = () => {
  const cookieStorage = new Map();
  const { cookie } = document;
  cookie.split(/\s*;\s*/).forEach(function setCookie(pair) {
    const pairList = pair.split(/\s*=\s*/);
    cookieStorage.set(pairList[0], pairList.splice(1).join('='));
  });
  return cookieStorage;
};

const get = (key) => {
  const allCookie = getCookieMap();
  try {
    const encodeKey = encodeURIComponent(key);
    const encodeValue = allCookie.get(encodeKey);
    return (encodeValue ?? null) && decodeURIComponent(encodeValue);
  } catch (e) {
    console.error(`cookies get(${key})`, e);
    return e;
  }
};

const cookies = {
  put,
  remove,
  getCookieMap,
  get,
};

export default cookies;
