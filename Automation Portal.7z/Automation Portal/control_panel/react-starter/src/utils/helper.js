import { v4 as uuidv4 } from 'uuid';
import { CLOUDAPP_NAME_MAP } from '@/constants';

export const getAppName = (appKey) => CLOUDAPP_NAME_MAP[appKey]?.name ?? '';

export const isObject = (obj) => Object.prototype.toString.call(obj) === '[object Object]';

export const withId = (array, key = 'id') => {
  if (!Array.isArray(array) || array.length === 0) return [];
  return array.map((item) => {
    if (!isObject(item)) return item;

    if (item.children) {
      item.children = withId(item.children);
    }
    return {
      ...item,
      [key]: uuidv4(),
    };
  });
};
