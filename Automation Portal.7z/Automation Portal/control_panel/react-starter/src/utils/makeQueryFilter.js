import React, { useState } from 'react';

export default function makeQueryFilter(useQueryOptions, SelectForm, config) {
  return (props) => {
    const [extraParams, setExtraParams] = useState();
    const { isFetching, data } = useQueryOptions(extraParams);

    const onSearch = (newPayload) => {
      setExtraParams(newPayload);
    };
    return (
      <SelectForm
        option={data}
        isLoading={isFetching}
        onSearch={onSearch}
        config={config}
        {...props}
      />
    );
  };
}
