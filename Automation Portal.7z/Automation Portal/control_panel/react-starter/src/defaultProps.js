import React from 'react';
import { ReactComponent as SuccessCheck } from '@/assets/images/icons/success-check.svg';
import { ReactComponent as InfoSolid } from '@/assets/images/icons/info-solid.svg';
import { ReactComponent as WarningAlert } from '@/assets/images/icons/warning-alert.svg';
import { ReactComponent as ErrorFail } from '@/assets/images/icons/error-fail.svg';

/**
 * Global setting MUI components default props
 */

const muiDefaultProps = {
  MuiTab: {
    disableRipple: true,
  },

  MuiAlert: {
    // change default icon
    iconMapping: {
      success: <SuccessCheck />,
      info: <InfoSolid />,
      warning: <WarningAlert />,
      error: <ErrorFail />,
    },
  },
};

export default muiDefaultProps;
