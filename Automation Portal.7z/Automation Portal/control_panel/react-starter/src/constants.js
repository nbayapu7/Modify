/**
 * App-level constants
 */
export const DEFAULT_PAGE_SIZE = 20;
export const MULTI = 'Multiple';
export const FULL_ACCESS_LIST = ['IAM_ADMIN', 'FCARE_ADMIN'];
export const LIMIT_ACCESS_LIST = ['FCARE_NORMAL', 'IAM_READWRITE'];
export const BLOCKED_LIST = [
  'NO_PRIVILEGE',
  'IAM_READ',
  'IAM_NOPORTAL',
  'IAM_UNDEFINED',
  'IAM_CUSTOMIZED',
];

export const APP_NAME = 'FortiConverter Automation';
export const LEGACY_CLOUDAPP_LIST = ['Salesforce', 'Office365', 'Box', 'Dropbox', 'Google'];
export const CLOUDAPP_LIST = [
  'AWSS3',
  'GoogleCloudStorage',
  'AzureCasb',
  'Webex',
  'ServiceNow',
  'CitrixShareFile',
  'Jira',
  'Confluence',
  'GitHub',
  'Egnyte',
  'FacebookWorkplace',
  'Salesforce', // Will be redesign
  'Google', // will be redesign
  'Office365', // will be redesign
];
export const CLOUDAPP_NAME_MAP = {
  Salesforce: {
    name: 'Salesforce',
  },
  Office365: {
    name: 'Office365',
  },
  Box: {
    name: 'Box',
  },
  Dropbox: {
    name: 'Dropbox',
  },
  Google: {
    name: 'Google Workspace',
  },
  AWSS3: {
    name: 'AWS S3',
  },
  GoogleCloudStorage: {
    name: 'Google Cloud Storage',
  },
  AzureCasb: {
    name: 'Azure Storage',
  },
  Webex: {
    name: 'Webex Teams',
  },
  ServiceNow: {
    name: 'Service Now',
  },
  CitrixShareFile: {
    name: 'Citrix ShareFile',
  },
  Jira: {
    name: 'Jira',
  },
  Confluence: {
    name: 'Confluence',
  },
  GitHub: {
    name: 'GitHub',
  },
  Egnyte: {
    name: 'Egnyte',
  },
  FacebookWorkplace: {
    name: 'Workplace',
  },
};
