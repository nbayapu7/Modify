import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
// import { makeStyles } from '@material-ui/core/styles';
// import classNames from 'classnames';
// import { Button } from '@material-ui/core';
import './sidemenu.css';
import '../../../node_modules/bootstrap/dist/css/bootstrap.css';

// const useStyles = makeStyles({
//   menu: {
//     flex: '0 0 200px',
//     overflowY: 'auto',
//     /* Hide scrollbar for Chrome, Safari and Opera */
//     '&::-webkit-scrollbar': {
//       display: 'none',
//     },
//     scrollbarWidth: 'none' /* Firefox */,
//   },
// });

const SideMenu = ({ updateBreadText }) => {
  // const classes = useStyles();
  const history = useHistory();
  const [pressed, setPressed] = useState(['', '', '']);
  return (
    // <div className={classes.menu}>
    //   <ul>
    //     <li>
    //       <Link to="/tasks">Tasks</Link>
    //     </li>
    //     <li>
    //       <Link to="/tickets">Tickets</Link>
    //     </li>
    //     <li>
    //       <Link to="/devices">Devices</Link>
    //     </li>
    //   </ul>
    // </div>
    <nav className="MuiList-root jss13 jss21 MuiList-padding">
      <div
        className={`${pressed[0]} MuiListItem-root jss15 jss16  MuiListItem-gutters MuiListItem-button`}
        tabIndex="0"
        role="button"
        aria-disabled="false"
        style={{ marginTop: `${0}px` }}
      >
        <div className="MuiListItemIcon-root jss22 jss20">
          <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z" />
          </svg>
        </div>
        <div className="MuiListItemText-root">
          <span
            onClick={() => {
              setPressed(['jss18', '', '']);
              history.push(`/tasks`);
              updateBreadText('Tasks');
            }}
            className="MuiTypography-root MuiListItemText-primary jss23 MuiTypography-body1 MuiTypography-displayBlock"
          >
            Tasks
          </span>
        </div>
        <span className="MuiTouchRipple-root" />
      </div>
      <div
        className={`${pressed[1]} MuiListItem-root jss15 jss16  MuiListItem-gutters MuiListItem-button`}
        tabIndex="0"
        role="button"
        aria-disabled="false"
        style={{ marginTop: `${16}px` }}
      >
        <div className="MuiListItemIcon-root jss22 jss20">
          <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M19 5v14H5V5h14m1.1-2H3.9c-.5 0-.9.4-.9.9v16.2c0 .4.4.9.9.9h16.2c.4 0 .9-.5.9-.9V3.9c0-.5-.5-.9-.9-.9zM11 7h6v2h-6V7zm0 4h6v2h-6v-2zm0 4h6v2h-6zM7 7h2v2H7zm0 4h2v2H7zm0 4h2v2H7z" />
          </svg>
        </div>
        <div
          onClick={() => {
            setPressed(['', 'jss18', '']);
            history.push(`/tickets`);
            updateBreadText('Tickets');
          }}
          className="MuiListItemText-root"
        >
          <span className="MuiTypography-root MuiListItemText-primary jss23 MuiTypography-body1 MuiTypography-displayBlock">
            Tickets
          </span>
        </div>
      </div>
      <div
        className={`${pressed[2]} MuiListItem-root jss15 jss16  MuiListItem-gutters MuiListItem-button`}
        tabIndex="0"
        role="button"
        aria-disabled="false"
        style={{ marginTop: `${16}px` }}
      >
        <div className="MuiListItemIcon-root jss22 jss20">
          <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z" />
          </svg>
        </div>
        <div
          onClick={() => {
            setPressed(['', '', 'jss18']);
            history.push(`/devices`);
            updateBreadText('Devices');
          }}
          className="MuiListItemText-root"
        >
          <span className="MuiTypography-root MuiListItemText-primary jss23 MuiTypography-body1 MuiTypography-displayBlock">
            Devices
          </span>
        </div>
        {/* <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
         <path d="M7 10l5 5 5-5z"></path>
      </svg>
      <span className="MuiTouchRipple-root"></span> */}
      </div>
      <div
        className="MuiListItem-root jss15 jss16  MuiListItem-gutters MuiListItem-button"
        tabIndex="0"
        role="button"
        aria-disabled="false"
        style={{ marginTop: `${16}px` }}
      >
        {/* <div className="MuiListItemIcon-root jss22 jss20">
          <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
          </svg>
        </div>
        <div className="MuiListItemText-root">
          <span className="MuiTypography-root MuiListItemText-primary jss23 MuiTypography-body1 MuiTypography-displayBlock">
            Admin
          </span>
        </div>
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M7 10l5 5 5-5z" />
        </svg>
        <span className="MuiTouchRipple-root" /> */}
      </div>
    </nav>
  );
};

export default SideMenu;
