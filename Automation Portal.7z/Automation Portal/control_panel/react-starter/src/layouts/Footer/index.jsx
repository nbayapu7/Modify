import React from 'react';
import { useHistory } from 'react-router-dom';
import { Button } from '@material-ui/core';

const Footer = () => {
  const history = useHistory();
  return (
    <div>
      footer (remove if no need, will not affect layout){' '}
      <Button
        variant="outlined"
        color="primary"
        size="small"
        onClick={() => history.push('/theme')}
      >
        Theme Overview
      </Button>
    </div>
  );
};

export default Footer;
