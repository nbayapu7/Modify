import SideMenu from './SideMenu';
import Footer from './Footer';

export { Footer, SideMenu };
