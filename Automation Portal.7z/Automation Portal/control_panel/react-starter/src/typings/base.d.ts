type BaseResponse<T> = {
  code: number;
  httpCode: number;
  msg: string;
  data: T;
};

type ListApiResponse<T> = {
  datas: T[];
  limit: number;
  skip: number;
  totalCount: number;
  totalPage: number;
};

type ListApiPagination = {
  skip?: number;
  limit?: number;
};

type TimePair = {
  startTime: number;
  endTime: number;
};
interface LoadableData<T> {
  data?: T;
  loading: boolean;
}
