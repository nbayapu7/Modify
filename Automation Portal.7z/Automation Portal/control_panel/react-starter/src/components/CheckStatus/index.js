import React from 'react';
import styled from 'styled-components';
import Success from './assets/success.svg';

const StatusWrapper = styled.div`
  display: flex;
`;

const CheckMark = styled.div`
  position: relative;
  top: 8px;
  display: inline-block;
  width: 24px;
  height: 24px;
`;

const ErrorMark = styled.div`
  display: inline-block;
  width: 23px;
  height: 23px;
  border-radius: 50%;
  background-color: #db3545;
  color: #fff;
  text-align: center;
  line-height: 23px;
  font-size: 20px;
  font-weight: 600;
`;

const StatusMessageGroup = styled.div`
  margin-left: 16px;
`;

const MessageRow = styled.div`
  font-size: 16px;
`;

const ErrorMessage = styled.span`
  color: #db3545;
`;

const CheckStatus = React.memo((props) => {
  const { status, isAdding } = props;

  return (
    <>
      {status ? (
        <StatusWrapper>
          <CheckMark>
            <img src={Success} style={{ width: '24px' }} />
          </CheckMark>
          <StatusMessageGroup>
            <MessageRow>{`FortiCASB is ${
              isAdding ? 'adding' : 'updating'
            } this account. This process may take 15 min.`}</MessageRow>
            <MessageRow>
              You can check whether it is successfully added in Overview {'>'} Dashboard.
            </MessageRow>
          </StatusMessageGroup>
        </StatusWrapper>
      ) : (
        <StatusWrapper>
          <ErrorMark>×</ErrorMark>
          <StatusMessageGroup>
            <MessageRow>{`This account has NOT been ${
              isAdding ? 'added' : 'updated'
            } to FortiCASB.`}</MessageRow>
            <MessageRow>
              Please refer to following error message:
              <br /> <ErrorMessage>[sample error message]</ErrorMessage>
            </MessageRow>
          </StatusMessageGroup>
        </StatusWrapper>
      )}
    </>
  );
});

export default CheckStatus;
