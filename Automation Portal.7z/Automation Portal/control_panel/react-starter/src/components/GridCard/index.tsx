import React from 'react';
import Skeleton from '@material-ui/lab/Skeleton';
import { Grid, GridProps, Typography, TypographyProps } from '@material-ui/core';
import { makeStyles, createStyles } from '@material-ui/core/styles';

export interface GridCardProps extends GridProps {
  renderTitle: string | React.ReactNode;
  height?: number;
  actions?: React.ReactNode;
  loading?: boolean;
}

const useStyles = makeStyles(() =>
  createStyles({
    root: {
      position: 'relative',
      lineHeight: 1.5,
      overflow: 'hidden',
    },
    card: {
      backgroundColor: '#fff',
      borderRadius: 4,
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      overflow: 'auto',
    },
    header: {
      height: 56,
      padding: 16,
    },
    title: {
      fontSize: 16,
      fontWeight: 'bold',
      color: '#252525',
    },
    actions: {
      position: 'absolute',
      top: 16,
      right: 16,
    },
    body: {
      flex: 1,
      overflow: 'auto',
    },
    loadingBody: {
      padding: 24,
      height: '100%',
      overflow: 'hidden',
    },
  }),
);

const variants = [
  'h1',
  'h3',
  'body1',
  'caption',
  'caption',
  'caption',
] as TypographyProps['variant'][];

const GridCard: React.FC<GridCardProps> = ({
  loading = false,
  height = 'auto',
  renderTitle,
  actions,
  children,
  ...gridProps
}) => {
  const classes = useStyles();

  return (
    <Grid item {...gridProps} className={classes.root}>
      <div className={classes.card} style={{ height }}>
        <div className={classes.header}>
          <div className={classes.title}>{renderTitle}</div>
          <div className={classes.actions}>{actions}</div>
        </div>
        <div className={classes.body}>
          {loading ? (
            <div className={classes.loadingBody}>
              {variants.map((variant) => (
                <Typography component="div" key={variant} variant={variant}>
                  <Skeleton animation="wave" />
                </Typography>
              ))}
            </div>
          ) : (
            children
          )}
        </div>
      </div>
    </Grid>
  );
};

export default GridCard;
