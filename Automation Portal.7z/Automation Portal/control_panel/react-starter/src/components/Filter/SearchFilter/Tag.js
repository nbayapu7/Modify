import React, { forwardRef } from 'react';
import Chip from '@material-ui/core/Chip';
import { withStyles } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';
import { ACTION_TYPE } from './constant';

const TagChip = withStyles(() => ({
  clickableColorSecondary: {
    fontSize: '12px',
    backgroundColor: '#ebf6ff',
    '&.MuiChip-clickable.MuiChip-outlinedSecondary:hover': {
      backgroundColor: '#ebf6ff',
    },
    '&.MuiChip-clickable.MuiChip-outlinedSecondary:focus': {
      backgroundColor: '#ebf6ff',
    },
  },
  deleteIconOutlinedColorSecondary: {
    '&:hover': {
      color: '#4A4A4A',
    },
    color: '#4A4A4A',
  },
  deleteIconOutlinedColorPrimary: {
    '&:hover': {
      color: '#4A4A4A',
    },
    color: '#4A4A4A',
  },
  outlined: {
    border: '1px solid #f2f2f2',
  },
  outlinedPrimary: {
    color: '#4A4A4A',
    borderRadius: '2px',
    backgroundColor: '#f2f2f2',
    fontSize: '12px',
    border: '1px solid #f2f2f2',
  },
  outlinedSecondary: {
    color: '#4A4A4A',
    borderRadius: '2px',
    border: '1px solid #2474b5',
    backgroundColor: '#ebf6ff',
  },
  root: {
    margin: 2,
    maxWidth: 400,
  },
  label: {
    fontSize: '14px',
  },
}))(
  forwardRef((props, ref) => (
    <Chip variant="outlined" size="small" clickable color="primary" {...props} ref={ref} />
  )),
);

/**
 *
 * @param {*} value support [string], [{name:'string',....}],string
 */
const stringifyValue = (value) => {
  if (Array.isArray(value)) {
    return value
      .map((item) => (typeof item === 'string' || item instanceof String ? item : item.name))
      .join(', ');
  }
  if (typeof value === 'string' || value instanceof String) {
    return value;
  }
  if (typeof value === 'object') {
    return value?.name || '';
  }
  return 'This value no default stringfy';
};
const converFilter2Label = (key, value) =>
  value === undefined ? (
    <span>
      <strong>{key}</strong>
    </span>
  ) : (
    <span>
      <strong>{key}: </strong>
      {stringifyValue(value)}
    </span>
  );

//= ======================== Tag component =========================================//
const Tag = ({ name, value, onClick, highlight }, ref) => {
  const { EDIT, DELETE } = ACTION_TYPE;
  const label = converFilter2Label(name, value);
  return (
    <Tooltip title={label}>
      <TagChip
        label={label}
        onDelete={(e) => onClick(DELETE, e)}
        onClick={(e) => onClick(EDIT, e)}
        {...(highlight ? { color: 'secondary' } : null)}
        innerRef={ref}
      />
    </Tooltip>
  );
};

export default forwardRef(Tag);
