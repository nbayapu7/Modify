export const FILTER_TYPE = {
  STRING: 'STRING',
  GROUP: 'GROUP',
  ARRAY: 'ARRAY',
};

export const ACTION_TYPE = {
  ADD: 'ADD',
  EDIT: 'EDIT',
  DELETE: 'DELETE',
};

export const CSS_DATA = {
  singleHeight: 36,
  dropdownWidth: 250,
};
