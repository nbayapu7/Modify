import React, { useCallback, useState } from 'react';
import SearchIcon from '@material-ui/icons/Search';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import { Button, Popper } from '@material-ui/core';
import Tags from './Tags';
import { CSS_DATA, ACTION_TYPE } from './constant';

const useStyles = makeStyles((theme) =>
  createStyles({
    container: {
      display: 'flex',
      alignItems: 'flex-start',
      backgroundColor: '#FFF',
      width: '100%',
      borderRadius: '4px',
      marginBottom: '8px',
    },
    anchorBox: {
      flexGrow: 1,
      position: 'relative',
      background: 'white',
      border: 0,
      borderRadius: '4px',
      // maxWidth: "calc(100% - 90px)",
    },
    // dropdownBox: {
    //   position: "absolute",
    //   zIndex: "20",
    //   minWidth: theme.SearchFilter?.dropdownWidth || CSS_DATA.dropdownWidth,
    //   maxWidth: "100%",
    //   background: "white",
    //   marginTop: 1,
    //   padding: "8px 16px",
    //   fontSize: "12px",
    //   borderRadius: "2px",
    //   boxShadow: "0 2px 6px 0 rgba(37, 37, 37, 0.16)",
    // },
    dropdownPopper: {
      maxHeight: '400px',
      marginTop: '4px',
      overflowY: 'auto',
      background: 'white',
      minWidth: theme.SearchFilter?.minWidth || CSS_DATA.dropdownWidth,
      padding: '8px 8px',
      borderRadius: '2px',
      boxShadow: '0 2px 6px 0 rgba(37, 37, 37, 0.16)',
      zIndex: 99,
    },
    buttonRoot: {
      flexShrink: 0,
      height: theme.SearchFilter?.height || CSS_DATA.singleHeight,
      background: theme.primary || '#2474b5',
      color: 'white',
      fontSize: '14px',
      boxShadow: 'none',
      marginLeft: '0px !important',
      // marginLeft: "8px !important",
      '&:hover': {
        background: theme.primaryHover || '#4c92c3',
      },
      borderTopLeftRadius: 0,
      borderBottomLeftRadius: 0,
      textTransform: 'capitalize',
    },
    buttonRootOutlined: {
      flexShrink: 0,
      height: theme.SearchFilter?.height || CSS_DATA.singleHeight,
      background: 'white',
      color: theme.primary || '#2474b5',
      borderColor: theme.primary || '#2474b5',
      fontSize: '14px',
      marginLeft: '0px !important',
      // marginLeft: "8px !important",
      '&:hover': {
        background: theme.lightGray || 'white',
        border: 0,
      },
      textTransform: 'capitalize',
    },
    outlinedPrimary: {
      border: 0,
    },
    outlined: {
      border: 0,
      '&$disabled': {
        border: 0,
        cursor: 'not-allowed',
      },
    },
    disabled: {},
  }),
);

/**
 * SearchFilter is a display only function componnet.
 * It fill display current filters chip, the dropdown, and submit button. This component will not process data
 *
 * This component main function is to combine Tags, dropdown and button.
 * Will pass props to certain components
 *
 * Api includes
 * * for button
 * @param {string} submitLabel is the text label in button
 * @param {function trigger() {}} onSubmit is a callback triger function, pass nothing in data.
 *
 * for dropdown,
 * @param {jsx} dropdown is the JSX code for dropdown Content
 *
 * for Tags, check Tags API for details
 *  filter, onAction is callback, extra.
 *
 * other props will pass to Tags
 *
 */

function SearchFilter({
  filter = {},
  onAction,
  onSubmit,
  // submitLabel = "Search",
  onSave,
  showSaveLabel = false,
  saveLabel = 'Save Search',
  extra,
  dropdown,

  ...props
}) {
  const classes = useStyles();
  const [anchorEl, setAnchor] = useState();

  const setDropdownAnchor = useCallback((node) => {
    node && setAnchor(node);
  }, []);

  // const setDropdownAnchor = useRef(null);

  return (
    <div className={classes.container}>
      <div className={classes.anchorBox}>
        <Tags
          filter={filter}
          callback={onAction}
          extra={extra}
          {...props}
          focusRef={setDropdownAnchor}
        />
        <Popper
          open={!!dropdown}
          anchorEl={anchorEl}
          placement="bottom-start"
          transition
          // modifiers={{
          //   offset: {
          //     enabled: true,
          //     offset: `0, ${Math.round(CSS_DATA.singleHeight / 2)}`,
          //   },
          // }}
          className={classes.dropdownPopper}
        >
          {dropdown}
        </Popper>
      </div>

      {showSaveLabel && (
        <Button
          color="primary"
          variant="outlined"
          onClick={() => onSave()}
          disabled={Object.entries(filter).length === 0}
          classes={{
            root: classes.buttonRootOutlined,
            outlinedPrimary: classes.outlinedPrimary,
            outlined: classes.outlined,
            disabled: classes.disabled,
          }}
        >
          {saveLabel}
        </Button>
      )}
      <Button variant="contained" onClick={() => onSubmit()} classes={{ root: classes.buttonRoot }}>
        <SearchIcon style={{ width: '30px', height: '21px', color: '#FFFFFF' }} />
        {/* {submitLabel} */}
      </Button>
    </div>
  );
}

SearchFilter.ACTION_TYPE = ACTION_TYPE;
export default SearchFilter;
