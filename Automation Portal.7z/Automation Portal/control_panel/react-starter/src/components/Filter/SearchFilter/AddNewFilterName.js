import React from 'react';
import Collapse from '@material-ui/core/Collapse';
import WarningIcon from '@material-ui/icons/Warning';
import { FormUnit, LabelRow, LabelString, StyledFormControl, StyledOutlinedInput } from '../Page';

export const Required = () => <span style={{ color: 'red' }}>*</span>;

export default function AddNewFilterName({ newFilterName, handleFilterName, error }) {
  return (
    <>
      <FormUnit style={{ marginBottom: '16px' }}>
        <LabelRow>
          <LabelString>
            Name this Saved Search <Required />
          </LabelString>
        </LabelRow>
        <StyledFormControl>
          <StyledOutlinedInput
            id="newFilterName"
            name="newFilterName"
            value={newFilterName}
            onChange={(e) => handleFilterName(e)}
          />
        </StyledFormControl>
      </FormUnit>

      {error && (
        <Collapse style={{ marginTop: '8px' }} in>
          <div
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              padding: '8px 20px 8px 8px',
              backgroundColor: '#fef8e7',
            }}
          >
            <WarningIcon style={{ flex: 1, color: '#f7bb0a' }} fontSize="large" />
            <div
              style={{
                flex: 9,
                fontSize: '12px',
                lineHeight: 1.5,
                color: '#4a4a4a',
              }}
            >
              {error.message}
            </div>
          </div>
        </Collapse>
      )}
    </>
  );
}
