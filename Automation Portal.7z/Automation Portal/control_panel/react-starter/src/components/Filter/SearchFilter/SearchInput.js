import React from 'react';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import Tag from './Tag';
import { CSS_DATA, ACTION_TYPE } from './constant';

const useStyles = makeStyles((theme) =>
  createStyles({
    container: {
      display: 'flex',
      flexGrow: 1,
      border: '1px solid black',
      borderRadius: 4,
      padding: ' 0 2px',
      minHeight: theme.SearchFilter?.height || CSS_DATA.singleHeight,
    },
  }),
);

const SearchInput = ({ filter, callback, addLabel, moreText, InDropdown }) => {
  const classes = useStyles();

  const tagCallback = (name, type) => {
    const targetValue = filter[name];
    const nextFilter = { ...filter };
    delete nextFilter[name];
    callback(nextFilter, type === ACTION_TYPE.EDIT && { name, value: targetValue });
  };

  const handleAdd = () => {
    callback(filter, {});
  };

  return (
    <div className={classes.container}>
      {Object.keys(filter).map((key) => {
        return (
          <Tag
            key={key}
            name={key}
            value={filter[key]}
            onClick={(type) => tagCallback(key, type)}
          />
        );
      })}
      {moreText}
      {InDropdown || <span onClick={handleAdd}> {addLabel}</span>}
    </div>
  );
};

export default SearchInput;
