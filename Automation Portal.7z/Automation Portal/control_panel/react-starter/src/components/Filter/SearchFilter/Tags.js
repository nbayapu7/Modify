import React from 'react';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import Tag from './Tag';
import { CSS_DATA, ACTION_TYPE } from './constant';

const useStyles = makeStyles((theme) =>
  createStyles({
    container: {
      display: 'flex',
      width: '100%',
      flexWrap: 'wrap',
      borderRadius: 4,
      padding: ' 0 2px',
      justifyContent: 'flex-start',
      alignItems: 'center',
      minHeight: theme.SearchFilter?.height || CSS_DATA.singleHeight,
    },
  }),
);

//= ===================== Tags component =================================//

const Tags = ({ filter, callback, extra, highlight, focusRef }) => {
  const classes = useStyles();

  const tagCallback = (name, type, e) => {
    e.stopPropagation();
    const targetValue = filter[name];
    const nextFilter = { ...filter };
    if (type === ACTION_TYPE.DELETE) {
      delete nextFilter[name];
    }
    callback(nextFilter, { name, value: targetValue, action: type });
  };

  const handleContainerClick = () => {
    // if(extra) return;
    callback(filter, { action: ACTION_TYPE.ADD });
  };

  return (
    <div className={classes.container} onClick={handleContainerClick}>
      {Object.keys(filter).map((key) => {
        return (
          <Tag
            key={key}
            name={key}
            value={filter[key]}
            onClick={(type, e) => tagCallback(key, type, e)}
            highlight={key === highlight}
            ref={(tag) => {
              if (key === highlight) {
                focusRef(tag);
              }
            }}
          />
        );
      })}
      <div
        style={{ height: CSS_DATA.singleHeight }}
        ref={(el) => {
          if (!highlight) {
            focusRef(el);
          }
        }}
      >
        {extra}
      </div>
    </div>
  );
};

export default Tags;
