import SearchFilter from './SearchFilter';

export default SearchFilter;
