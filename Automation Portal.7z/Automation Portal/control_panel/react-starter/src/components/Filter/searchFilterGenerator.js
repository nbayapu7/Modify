import React from 'react';
import { Button } from '@material-ui/core';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import useDialog from '@/hooks/useDialog';
import { BaseDialog } from '@/components/Dialog';
import EnhancedSelectType from './SelectForm/EnhancedSelectType';
import AddNewFilterName from './SearchFilter/AddNewFilterName';
import { useStyles } from './SelectForm/common';
import { MultiInput, SelectSingle, SelectMulti } from './SelectForm';
import { CSS_DATA } from './SearchFilter/constant';
import SearchFilter from './SearchFilter';

/**
 *
 * @param {object} filterComponentMap a object map filter name to a object incluede component and group
 * @returns {component} a component of filter that take initData, source, onSumbit, and optional onSave, getFilterList and deleteFilter
 */
const searchFilterGenerator = (filterComponentMap, config, SelectType = EnhancedSelectType) => {
  const { ADD, DELETE } = SearchFilter.ACTION_TYPE;

  return ({ initData, onSubmit, onSave, checkFilterName, filterList, deleteFilter }) => {
    const classes = useStyles();
    const [filter, setFilter] = React.useState({ ...initData }); // keep the filter data
    const [current, setCurrent] = React.useState(); // control the current modified status and filter, current = { action: one in SearchFilter.ACTION_TYPE, name: 'filterName', value: ,}
    const [newFilterName, setNewFilterName] = React.useState();
    const [generateNewFilter, openNewFilter, closeNewFilter] = useDialog();
    const [error, setError] = React.useState();
    const [isDisabled, setIsDisabled] = React.useState(true);

    // update filter when initData change
    React.useEffect(() => {
      setFilter({ ...initData });
      setCurrent();
    }, [initData, setFilter, setCurrent]);

    /**
     *  current = { action: one in SearchFilter.ACTION_TYPE, name: 'filterName', value: ,}
     */
    const handleSearchFilterAction = React.useCallback(
      (next, editTarget) => {
        const nextFilter = { ...next };
        Object.entries(nextFilter).forEach(([key, value]) => {
          if (!value || value?.length === 0) {
            delete nextFilter[key];
          }
        });
        setFilter(nextFilter);
        setCurrent(editTarget.action !== DELETE && editTarget);
      },
      [setFilter, setCurrent],
    );

    // check if current filter should be remove
    const finishEdit = () => {
      const nextFilter = { ...filter };
      if (current?.name && (!current.value || current.value.length === 0)) {
        delete nextFilter[current.name];
      }
      setFilter(nextFilter);
    };

    const handleFilterName = (e) => {
      if (e.target.value) {
        setIsDisabled(false);
      } else {
        setIsDisabled(true);
      }
      setError();
      setNewFilterName(e.target.value);
    };

    // click save search button
    const handleSaveSearch = () => {
      setNewFilterName();
      setError();
      openNewFilter();
    };

    // create new filter with name
    const handleSaveFilter = async () => {
      if (checkFilterName) {
        const isInvalid = await checkFilterName(newFilterName);
        if (isInvalid) {
          setError(isInvalid);
          return;
        }
      }
      const saveData = { ...filter };
      if (current?.name && (!current.value || current.value.length === 0)) {
        delete saveData[current.name];
      }
      onSave(saveData, newFilterName);
      closeNewFilter();
    };

    const handleSubmit = () => {
      const submitData = { ...filter };
      if (current?.name && (!current.value || current.value.length === 0)) {
        delete submitData[current.name];
      }
      onSubmit(submitData);
    };

    //= ======================== dropdown handle ==================================//
    const handleClickAway = () => {
      finishEdit();
      setCurrent();
    };

    const handleSelectFilterType = (filterType) => {
      setCurrent({
        ...current,
        name: filterType,
        value: filter[filterType],
      });
    };

    const handleSetFilter = (f) => {
      setFilter(f);
      setCurrent();
    };

    /**
     * deal with no matched filter, default is string input.
     * @param {*} e
     */
    const handleInputChange = (e) => {
      setCurrent({
        ...current,
        value: e.target.value,
      });
      setFilter({
        ...filter,
        [current.name]: e.target.value,
      });
    };

    const handleInputEnter = (e) => {
      if (e.charCode === 13) {
        // TODO: remove if chip change at same time
        // setFilter({
        //   ...filter,
        //   [current.name]: current.value,
        // });
        finishEdit();
        setCurrent();
      }
    };

    /** *
     *  common control logic of DrilldownComponent
     */
    // not using
    const onFilterSubmit = () => {
      setFilter({
        ...filter,
        [current.name]: current.value,
      });
      setCurrent();
    };
    // not using
    const onFilterClear = () => {
      const next = { ...filter };
      delete next[current.name];
      setFilter(next);
      setCurrent();
    };

    const onFilterChange = (data, isfinish) => {
      if (isfinish) {
        setFilter({
          ...filter,
          [current.name]: data,
        });
        setCurrent();
      } else {
        // TODO: remove value from current if decide to change chip at same time
        setCurrent({
          ...current,
          value: data,
        });
        // change chip at the same time
        setFilter({
          ...filter,
          [current.name]: data,
        });
      }
    };

    //= =========== dropdown display control ======================//
    const highlight = current?.name;
    let extra = '';
    let inDropdown = '';

    if (current?.name) {
      // add or edit a filter
      if (filterComponentMap[current.name]?.component) {
        // show matched filter in dropdown
        const DropdownComponent = filterComponentMap[current.name].component;
        inDropdown = (
          <ClickAwayListener onClickAway={handleClickAway}>
            <div>
              <div className={classes.subLabelText}>{highlight}: </div>
              <DropdownComponent
                highlight={highlight}
                value={current.value}
                onSubmit={onFilterSubmit}
                onClear={onFilterClear}
                onChange={onFilterChange}
              />
            </div>
          </ClickAwayListener>
        );
        // TODO: remove if input in dropdown
        // if (current.action === ADD) {
        //   extra = <div>{highlight}: </div>;
        // }
      } else {
        // no matched filter, input by default
        // change to input in dropdown
        inDropdown = (
          <ClickAwayListener onClickAway={handleClickAway}>
            <div>
              <div className={classes.subLabelText}>{highlight}: </div>
              <div style={{ padding: '0 8px' }}>
                <input
                  type="text"
                  value={current?.value || ''}
                  onChange={handleInputChange}
                  onKeyPress={handleInputEnter}
                  autoFocus
                  className={classes.input}
                />
              </div>
            </div>
          </ClickAwayListener>
        );
      }
    } else if (current?.action === ADD) {
      // TODO: filter optionList

      const groupOptionlistMap = {};
      const all = [];

      Object.entries(filterComponentMap).forEach(([filterName, filterConfig]) => {
        const { group: grouplist } = filterConfig;
        if (grouplist && grouplist.length > 0) {
          grouplist.forEach((group) =>
            groupOptionlistMap[group]
              ? groupOptionlistMap[group].push(filterName)
              : (groupOptionlistMap[group] = [filterName]),
          );
        } else {
          all.push(filterName);
        }
      });

      let currentGroup;
      Object.keys(filter).forEach((filterName) => {
        const grouplist = filterComponentMap[filterName]?.group;
        if (grouplist?.length > 0) {
          if (!currentGroup) {
            currentGroup = [...grouplist];
          } else {
            currentGroup = currentGroup.filter((item) => grouplist.includes(item));
          }
        }
      });

      let option = [];
      if (currentGroup) {
        currentGroup.forEach((group) => (option = option.concat(groupOptionlistMap[group])));
        option = option.concat(all);
      } else {
        option = Object.keys(filterComponentMap);
      }

      option = [...new Set(option)];
      option.sort();

      // no current.name, chose a filter
      inDropdown = (
        <ClickAwayListener onClickAway={handleClickAway}>
          <div>
            <SelectType
              option={option}
              onChange={handleSelectFilterType}
              onSetFilter={handleSetFilter}
              filterList={filterList}
              deleteFilter={deleteFilter}
            />
          </div>
        </ClickAwayListener>
      );
    } else {
      extra = (
        <div
          style={{
            color: '#a5a5a5',
            cursor: 'pointer',
            paddingLeft: 5,
            height: CSS_DATA.singleHeight,
            display: 'flex',
            flexDirection: 'row',
            fontSize: '14px',
            alignItems: 'center',
          }}
        >
          +Add Filter
        </div>
      );
    }

    //= ============================================

    return (
      <>
        <BaseDialog
          renderTitle=""
          visible={generateNewFilter}
          content={
            <AddNewFilterName
              newFilterName={newFilterName}
              handleFilterName={handleFilterName}
              error={error}
            />
          }
          contentProps={{ style: { borderTop: 0, paddingTop: 0, width: 480 } }}
          footer={
            <>
              <Button
                color="primary"
                variant="contained"
                size="medium"
                onClick={handleSaveFilter}
                disabled={isDisabled}
                classes={{
                  root: classes.buttonContained,
                  disabled: classes.disabled,
                }}
                style={{
                  fontSize: '14px',
                  color: '#fff',
                  backgroundColor: '#2474b5',
                }}
              >
                Done
              </Button>
              <Button
                size="medium"
                onClick={closeNewFilter}
                style={{ marginLeft: 16, fontSize: '14px' }}
              >
                Cancel
              </Button>
            </>
          }
        />
        <SearchFilter
          filter={filter}
          onAction={handleSearchFilterAction}
          extra={extra}
          highlight={highlight}
          onSubmit={handleSubmit}
          onSave={() => handleSaveSearch()}
          dropdown={inDropdown}
          showSaveLabel={config?.showSaveLabel}
        />
      </>
    );
  };
};

// ***** filter generator ***** //
export const makeFilter = (option) => {
  return (props) => <SelectMulti option={option} isLoading={!option} {...props} />;
};

export const makeSingleFilter = (option) => {
  return (props) => <SelectSingle option={option} isLoading={!option} noInput {...props} />;
};

export const makeMultiInput = (noteComponent) => {
  return (props) => <MultiInput noteComponent={noteComponent} {...props} />;
};

export const noteComponent = (name) => {
  return (
    <div
      style={{
        fontSize: 12,
        lineHeight: 1.5,
        color: '#4a4a4a',
        marginBottom: 6,
        marginTop: 15,
        width: 230,
        overflowWrap: 'break-word',
        paddingLeft: '8px',
      }}
    >
      {`Please enter ${name}. You can click Add Another to search multiple ${name}.`}
    </div>
  );
};

export default searchFilterGenerator;
