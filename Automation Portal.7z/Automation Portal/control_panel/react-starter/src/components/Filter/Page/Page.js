import React from 'react';
import { OutlinedInput, FormControl, Grid, Button, Popover } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import styled, { css } from 'styled-components';

export const ContentGrid = withStyles(() => ({
  root: {
    padding: '16px 32px',
    background: 'white',
    flexGrow: 1,
  },
}))(Grid);

export const LogoPopover = withStyles(() => ({
  paper: {
    backgroundColor: '#ffffff',
    width: '245px',
    borderRadius: '4px',
    padding: '24px 16px',
    flexDirection: 'column',
    display: 'flex',
    justifyContent: 'center',
  },
}))(({ children, ...props }) => (
  <Popover
    anchorOrigin={{
      vertical: 'top',
      horizontal: 'left',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'left',
    }}
    {...props}
  >
    {children}
  </Popover>
));

export const BetweenContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`;

export const FlexContainer = styled.div`
  display: flex;
`;

export const CardLayout = styled.div`
  display: flex;
  flex-wrap: wrap;
  flex-direction: row;
  justify-content: flex-start;
  margin-top: 32px;
`;

export const CardContainer = styled.div`
  border-radius: 4px;
  border: solid 1px #e3e3e3;
  margin: 0px 8px 24px 0px;
  width: 360px;
  padding: 16px 16px 0 16px;
  flex-direction: column;
`;

export const CardAddContainer = styled.div`
  border-radius: 4px;
  border: dashed 1px #e3e3e3;
  margin: 0px 0px 24px 0px;
  width: 360px;
  padding: 16px 16px 0 16px;
  flex-direction: column;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const CircleContainer = styled.div`
  height: 64px;
  width: 64px;
  border-radius: 50%;
  background: #ebf6ff;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const CardFoot = styled.div`
  border-top: solid 1px #e3e3e3;
  margin-left: -16px;
  margin-right: -16px;
  display: flex;
  justify-content: space-between;
  padding: 0px 16px;
  align-items: center;
`;

export const AppLogoContainer = styled.div`
  height: 28px;
  width: 28px;
  border-radius: 15px;
  background-color: #f2f2f2;
  margin-right: 4px;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const LabelText = styled.div`
  font-family: Lato;
  font-weight: bold;
  line-height: 1.5;
  font-size: 16px;
  color: #4a4a4a;
  margin-bottom: 16px;
`;

export const LargeText = styled.div`
  font-family: Lato;
  line-height: 1.5;
  font-size: 16px;
  color: #4a4a4a;
  margin-bottom: 16px;
`;

export const MdText = styled.div`
  font-family: Lato;
  line-height: 1.5;
  font-size: 14px;
  color: #4a4a4a;
`;

export const StandText = styled.div`
  font-family: Lato;
  line-height: 1.5;
  font-size: 12px;
  color: #4a4a4a;
`;

export const FormUnit = styled.div`
  margin-bottom: 24px;
  width: 100%;
  max-width: 1000px;
`;

export const LabelRow = styled.div`
  font-size: 14px;
  display: flex;
`;

export const LabelString = styled.div`
  font-weight: 600;
  padding: ${(props) => props.padding || '6px 0'};
  position: relative;
  ${(props) =>
    props.required &&
    css`
      &:after {
        content: ' *';
        position: absolute;
        color: red;
        font-size: 14px;
        margin-left: 4px;
      }
    `}
`;

export const ReportContaier = styled.div`
  margin-top: 16px;
  display: flex;
  flex-direction: column;
`;
// justify-content: start;

export const ImageGrid = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-right: 50px;
`;

export const ImageContainer = styled.div`
  height: 32px;
  border: solid 1px #e3e3e3;
  margin: 8px 0;
`;

export const StyledOutlinedInput = withStyles((theme) => ({
  root: {
    height: '32px',
    width: '100%',
    '&.input': {
      '&:focus': {
        border: '0px',
      },
    },
  },
  input: {
    textOverflow: 'ellipsis',
    fontSize: '16px',
    '&:disabled': {
      backgroundColor: '#f2f2f2',
      borderRadius: '4px',
      color: '#4a4a4a',
      padding: theme.spacing(1),
    },
    '&:focus': {
      border: '0px',
    },
  },
}))((props) => <OutlinedInput labelWidth={0} autoComplete="off" {...props} />);

export const StyledOutlinedToken = withStyles((theme) => ({
  root: {
    height: '32px',
    width: '100%',
    '&.input': {
      '&:focus': {
        border: '0px',
      },
    },
  },
  input: {
    textOverflow: 'inherit',
    fontSize: '16px',
    '&:disabled': {
      backgroundColor: '#f2f2f2',
      borderRadius: '4px',
      color: '#4a4a4a',
      padding: theme.spacing(1),
      paddingRight: '30px',
    },
    '&:focus': {
      border: '0px',
    },
  },
}))((props) => <OutlinedInput labelWidth={0} autoComplete="off" {...props} />);

export const StyledFormControl = withStyles(() => ({}))((props) => (
  <FormControl variant="outlined" fullWidth {...props} />
));

export const StyledButton = withStyles(() => ({
  root: {
    fontSize: '12px',
  },
  outlined: {
    border: '1px solid',
  },
}))((props) => {
  return <Button {...props} variant={props.variant ? props.variant : 'outlined'} />;
});

export const Required = () => <span style={{ color: 'red' }}>*</span>;

export const ErrorMessage = styled.div`
  color: red;
  font-size: 12px;
`;
