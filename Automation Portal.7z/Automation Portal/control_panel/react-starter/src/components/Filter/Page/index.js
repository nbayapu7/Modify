import React from 'react';
import { OutlinedInput, FormControl } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import styled, { css } from 'styled-components';

export const FormUnit = styled.div`
  margin-bottom: 24px;
  width: 100%;
  max-width: 1000px;
`;

export const LabelRow = styled.div`
  font-size: 14px;
  display: flex;
`;

export const LabelString = styled.div`
  font-weight: 600;
  padding: 6px 0;
  position: relative;
  ${(props) =>
    props.required &&
    css`
      &:after {
        content: ' *';
        position: absolute;
        color: red;
        font-size: 14px;
        margin-left: 4px;
      }
    `}
`;

export const StyledOutlinedInput = withStyles((theme) => ({
  root: {
    height: '32px',
    width: '100%',
    '&.input': {
      '&:focus': {
        border: '0px',
      },
    },
  },
  input: {
    textOverflow: 'ellipsis',
    fontSize: '16px',
    '&:disabled': {
      backgroundColor: '#f2f2f2',
      borderRadius: '4px',
      color: '#4a4a4a',
      padding: theme.spacing(1),
    },
    '&:focus': {
      border: '0px',
    },
  },
}))((props) => <OutlinedInput labelWidth={0} autoComplete="off" {...props} />);

export const StyledFormControl = withStyles(() => ({}))((props) => (
  <FormControl variant="outlined" fullWidth {...props} />
));
