import React, { useState, useMemo } from 'react';
import Checkbox from '@material-ui/core/Checkbox';
import SearchIcon from '@material-ui/icons/Search';
import { List } from '@material-ui/core';
import { isString, groupByType } from '../../utils';
import { StyledFormControlLabel, StyledListSubheader, StyledMenuItem, useStyles } from './common';

function SelectMulti({ highlight, value, onChange, option, isLoading, config }) {
  const classes = useStyles();

  const [inputValue, setInput] = useState('');

  const isStringOption = useMemo(
    () => !isLoading && option?.length > 0 && isString(option[0]),
    [option, isLoading],
  );

  const groupByObj = useMemo(() => {
    if (option?.length > 0 && config?.groupBy) {
      return groupByType(option, config.groupBy);
    }
  }, [option, config]);

  const onCheckboxChange = (optionItem, e) => {
    let next = [...(value || [])];
    if (!e.target.checked) {
      next = next.filter(
        (item) => {
          if (isStringOption) {
            return item !== optionItem;
          }
          if (config?.currKey) {
            return item[config.currKey] !== optionItem[config.currKey];
          }
          return item.name !== optionItem.name;
        },
        // isStringOption
        //   ? item !== optionItem
        //   : config?.currKey
        //   ? item[config.currKey] !== optionItem[config.currKey]
        //   : item.name !== optionItem.name,
      );
    } else {
      next.push(isStringOption ? optionItem : { ...optionItem });
    }
    onChange(next);
  };

  const getGroupByList = (type) => {
    return (config?.groupBy ? groupByObj[type] : option || []).filter((optionItem) => {
      if (!inputValue) {
        return true;
      }
      return config?.currKey
        ? optionItem[config.currKey].toLowerCase().includes(inputValue.toLowerCase())
        : (optionItem?.name?.toLowerCase() || optionItem.toLowerCase()).includes(
            inputValue.toLowerCase(),
          );
    });
  };

  return (
    <>
      {option && option.length >= 10 && (
        <div className={classes.inputContainer}>
          <SearchIcon className={classes.searchIcon} />
          <input
            className={classes.input}
            style={{
              backgroundColor: '#fafafa',
              paddingLeft: '30px',
              height: '33px',
              fontSize: '14px',
            }}
            value={inputValue}
            placeholder={`Search ${highlight}`}
            onChange={(e) => setInput(e.target.value)}
          />
        </div>
      )}
      {isLoading ? (
        <div style={{ paddingLeft: '8px', paddingRight: '8px' }}>loading</div>
      ) : (
        <List className={classes.listContainer}>
          {((groupByObj && Object.keys(groupByObj)) || [0]).map((type) => {
            const displayList = getGroupByList(type).sort((a, b) => {
              const curr = isStringOption ? a : a.name;
              const next = isStringOption ? b : b.name;
              if (curr < next) {
                return -1;
              }
              if (curr > next) {
                return 1;
              }
              return 0;
            });
            if (displayList && displayList.length !== 0) {
              return (
                <div key={type} style={{ backgroundColor: '#fff' }}>
                  {config?.groupBy && (
                    <StyledListSubheader disableGutters>{type}</StyledListSubheader>
                  )}
                  {displayList.map((optionItem) => {
                    return !isStringOption ? (
                      <StyledMenuItem
                        className={
                          config?.component
                            ? classes.selectMultiMenuItemWithCom
                            : classes.selectMultiMenuItem
                        }
                        key={config?.currKey ? optionItem[config.currKey] : optionItem.name}
                        disableGutters
                      >
                        <StyledFormControlLabel
                          control={
                            <Checkbox
                              color="default"
                              className={classes.checkBoxRoot}
                              checked={
                                !!(
                                  value &&
                                  value.findIndex((select) =>
                                    config?.currKey
                                      ? select[config.currKey] === optionItem[config.currKey]
                                      : select.name === optionItem.name,
                                  ) > -1
                                )
                              }
                              onChange={(e) => onCheckboxChange(optionItem, e)}
                              name={config?.currKey ? optionItem[config.currKey] : optionItem.name}
                            />
                          }
                          className={classes.formControlLableRoot}
                          marginBottom="0px"
                          marginRight="0px"
                          fontSize="14px"
                          label={
                            config?.component ? (
                              <config.component data={optionItem} />
                            ) : (
                              optionItem.name
                            )
                          }
                        />
                      </StyledMenuItem>
                    ) : (
                      <StyledMenuItem
                        key={optionItem}
                        className={classes.selectMultiMenuItem}
                        disableGutters
                      >
                        <StyledFormControlLabel
                          control={
                            <Checkbox
                              color="default"
                              className={classes.checkBoxRoot}
                              checked={
                                !!(value && value.findIndex((select) => select === optionItem) > -1)
                              }
                              onChange={(e) => onCheckboxChange(optionItem, e)}
                              name={optionItem}
                            />
                          }
                          className={classes.formControlLableRoot}
                          marginBottom="0px"
                          marginRight="0px"
                          fontSize="14px"
                          label={optionItem}
                        />
                      </StyledMenuItem>
                    );
                  })}
                </div>
              );
            }
            return null;
          })}
        </List>
      )}
    </>
  );
}

export default SelectMulti;
