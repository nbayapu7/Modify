import React, { useState, useMemo } from 'react';
import SearchIcon from '@material-ui/icons/Search';
import List from '@material-ui/core/List';
import ListItemText from '@material-ui/core/ListItemText';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import { useStyles, StyledListSubheader, StyledMenuItem, StyledListItemIcon } from './common';
import { isString } from '../../utils';

function SelectSingle({ highlight, option, onDelete, title, onChange, isLoading, noInput }) {
  const classes = useStyles();

  const [inputValue, setInput] = useState('');

  const isStringOption = useMemo(
    () => !isLoading && option?.length > 0 && isString(option[0]),
    [option, isLoading],
  );

  const onInputChange = (nextInputValue) => {
    setInput(nextInputValue);
  };

  return isLoading ? (
    <div style={{ paddingLeft: '8px', paddingRight: '8px' }}>loading</div>
  ) : (
    <List
      className={classes.listContainer}
      component="nav"
      aria-labelledby={title || 'select'}
      subheader={
        title && (
          <StyledListSubheader component="div" id="nested-list-subheader" disableGutters>
            {title}
          </StyledListSubheader>
        )
      }
    >
      {!noInput && (
        <div className={classes.inputContainer}>
          <SearchIcon className={classes.searchIcon} />
          <input
            className={classes.input}
            style={{
              backgroundColor: '#fafafa',
              paddingLeft: '30px',
              height: '33px',
              fontSize: '14px',
            }}
            value={inputValue}
            placeholder={`Search ${highlight}`}
            onChange={(e) => onInputChange(e.target.value)}
          />
        </div>
      )}

      {(option || [])
        .filter((optionItem) => {
          if (!inputValue) {
            return true;
          }
          return (optionItem?.name?.toLowerCase() || optionItem.toLowerCase()).includes(
            inputValue.toLowerCase(),
          );
        })
        .map((optionItem) => (
          <StyledMenuItem
            disableGutters
            className={classes.selectMultiMenuItem}
            key={isStringOption ? optionItem : optionItem.name}
            onClick={() => onChange(optionItem)}
          >
            <ListItemText
              primary={isStringOption ? optionItem : optionItem.name}
              primaryTypographyProps={{
                style: { fontSize: 14, fontFamily: 'Lato' },
              }}
            />
            {onDelete && (
              <StyledListItemIcon>
                <DeleteForeverIcon
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(optionItem);
                  }}
                />
              </StyledListItemIcon>
            )}
          </StyledMenuItem>
        ))}
    </List>
  );
}

export default SelectSingle;
