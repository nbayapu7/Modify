import React from 'react';
import Divider from '@material-ui/core/Divider';
import SelectSingle from './SelectSingle';

const EnhancedSelectType = ({
  onChange,
  onSetFilter,
  option,
  filterList,
  deleteFilter,
  ...props
}) => {
  // const [filterList, setFilterList] = useState();

  // const getFiltersFunction = () => {
  //   if (!getFilterList || !deleteFilter) {
  //     // stop loading
  //     setFilterList([]);
  //     return;
  //   }
  //   getFilterList()
  //     .then((res) => {
  //       setFilterList(res);
  //     })
  //     .catch(() => {
  //       setFilterList([]);
  //     });
  // };

  const deleteFunction = (filterObj) => {
    // if (!getFilterList || !deleteFilter) {
    //   return;
    // }
    // setFilterList();
    deleteFilter(filterObj);
  };

  const selectSavedFilter = (filterObj) => {
    onSetFilter(filterObj.filter || filterObj);
  };

  // useEffect(() => {
  //   getFiltersFunction();
  // }, []);

  return !filterList ? (
    <div>loading...</div>
  ) : (
    <>
      {filterList.length > 0 && (
        <div style={{ backgroundColor: '#fff' }}>
          <SelectSingle
            title="Saved search"
            option={filterList}
            onChange={selectSavedFilter}
            onDelete={deleteFunction}
            noInput
          />
          <Divider style={{ marginBottom: 8 }} />
        </div>
      )}
      <SelectSingle title="Filters" onChange={onChange} option={option} noInput {...props} />
    </>
  );
};

export default EnhancedSelectType;
