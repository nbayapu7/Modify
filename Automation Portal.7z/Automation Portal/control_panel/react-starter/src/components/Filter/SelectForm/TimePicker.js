import React, { useState } from 'react';
import MenuItem from '@material-ui/core/MenuItem';
import FormGroup from '@material-ui/core/FormGroup';
import { convertTime } from '../../utils/convertTime';
import CustomTime from './CustomTime';
import { useStyles } from './common';

function TimePicker({ value, onChange, isLoading }) {
  const classes = useStyles();
  const [openCustom, setOpenCustom] = useState(false);
  const options = ['Last 24 hours', 'Last 7 days', 'Last 30 days', 'Last 90 days', 'Customize'];

  // choose one option of TiePicker, then return obj{name:"", startTime: "", endTime: ""}
  const onClickItem = (item) => {
    const next = convertTime(item);
    if (next) {
      onChange(next, true);
    } else if (value && !value.name.includes('[')) {
      onChange(null);
      setOpenCustom(true);
    } else {
      setOpenCustom(true);
    }
  };

  const onCancel = () => {
    setOpenCustom(false);
  };

  return (
    <>
      {openCustom ? (
        <CustomTime
          value={value}
          onChange={onChange}
          onCancel={onCancel}
          maxRange={365}
          setOpenCustom={setOpenCustom}
        />
      ) : (
        <>
          {isLoading ? (
            <div style={{ paddingLeft: '8px', paddingRight: '8px' }}>loading</div>
          ) : (
            <FormGroup>
              {options.map((option) => (
                <MenuItem
                  disableGutters
                  className={classes.menuItemRoot}
                  key={option}
                  selected={
                    (value && value.name === option) ||
                    (value && option === 'Customize' && value.name.includes('['))
                  }
                  onClick={() => onClickItem(option)}
                >
                  {option}
                </MenuItem>
              ))}
            </FormGroup>
          )}
        </>
      )}
    </>
  );
}

export default TimePicker;
