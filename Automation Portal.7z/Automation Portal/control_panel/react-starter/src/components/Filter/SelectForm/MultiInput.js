import React, { useState } from 'react';
import MultiRowInput from '@/components/MultiRowInput';

export default function MultiInput({ value, onChange, noteComponent }) {
  const initObj = { name: '' };
  const [values, setValues] = useState(value || []);
  const handleRowsChange = (data) => {
    setValues(data);
    const newData = data.filter((item) => item.name !== '');
    onChange(newData);
  };

  return (
    <>
      <MultiRowInput
        values={values}
        style={{ padding: '0 8px' }}
        onChange={handleRowsChange}
        addComponent={
          <div
            style={{
              cursor: 'pointer',
              fontSize: '12px',
              color: '#2474b5',
              lineHeight: 1.5,
              padding: '0 8px',
            }}
          >
            + Add Another
          </div>
        }
        initRow={initObj}
        notification={noteComponent}
      >
        <input
          type="text"
          name="name"
          style={{
            marginBottom: 5,
            width: 225,
            borderRadius: 4,
            border: 'solid 1px #e3e3e3',
          }}
        />
      </MultiRowInput>
    </>
  );
}
