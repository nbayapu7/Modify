import React, { useState, useMemo } from 'react';
import { List, Checkbox, IconButton } from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import DeleteIcon from '@material-ui/icons/Delete';
import { StyledFormControlLabel, useStyles, StyledMenuItem } from './common';

/**
 *
 * @param {Array[object {name: string}]} value - only support list of object with name
 */
function SelectMultiAsyncSearch({
  highlight,
  value,
  onChange,
  option,
  isLoading,
  onSearch,
  config,
}) {
  const classes = useStyles();
  const [inputValue, setInput] = useState('');
  const [timer, setTimer] = useState();

  // const isStringOption = useMemo(
  //   () => !isLoading && option?.length > 0 && isString(option[0]),
  //   [option, isLoading]
  // );

  const copyOptionList = useMemo(
    () =>
      (option || []).map((optionItem) => ({
        ...optionItem,
        select:
          value &&
          value.findIndex((selectItem) =>
            config?.currKey
              ? selectItem[config.currKey] === optionItem[config.currKey]
              : selectItem.name === optionItem.name,
          ) > -1,
      })),
    [option, value],
  );

  const onInputChange = (nextInputValue) => {
    setInput(nextInputValue);

    if (timer) {
      clearTimeout(timer);
    }
    setTimer(
      setTimeout(() => {
        onSearch(nextInputValue);
      }, 300),
    );
  };

  const onCheckboxChange = (optionItem, e) => {
    let next = [...(value || [])];
    if (!e.target.checked) {
      next = next.filter((item) =>
        config?.currKey
          ? item[config.currKey] !== optionItem[config.currKey]
          : item.name !== optionItem.name,
      );
    } else {
      next.push({ ...optionItem });
    }
    onChange(next);
  };

  const onDeleteSelect = (selectItem, index) => {
    const next = [...value];
    next.splice(index, 1);
    onChange(next);
  };

  return (
    <>
      {option && option.length >= 10 && (
        <div className={classes.inputContainer}>
          <SearchIcon className={classes.searchIcon} />
          <input
            className={classes.input}
            style={{
              backgroundColor: '#fafafa',
              paddingLeft: '30px',
              height: '33px',
              fontSize: '14px',
            }}
            value={inputValue}
            placeholder={`Search ${highlight}`}
            onChange={(e) => onInputChange(e.target.value)}
          />
        </div>
      )}
      {isLoading ? (
        <div style={{ paddingLeft: '8px', paddingRight: '8px' }}>loading</div>
      ) : (
        <List className={classes.listContainer}>
          {copyOptionList &&
            copyOptionList.map((optionItem) => (
              <StyledMenuItem
                className={
                  config?.component
                    ? classes.selectMultiMenuItemWithCom
                    : classes.selectMultiMenuItem
                }
                key={config?.currKey ? optionItem[config.currKey] : optionItem.name}
                disableGutters
              >
                <StyledFormControlLabel
                  control={
                    <Checkbox
                      color="default"
                      className={classes.checkBoxRoot}
                      checked={optionItem.select}
                      onChange={(e) => onCheckboxChange(optionItem, e)}
                      name={config?.currKey ? optionItem[config.currKey] : optionItem.name}
                    />
                  }
                  className={classes.formControlLableRoot}
                  marginBottom="0px"
                  marginRight="0px"
                  fontSize="14px"
                  label={
                    config?.component ? <config.component data={optionItem} /> : optionItem.name
                  }
                />
              </StyledMenuItem>
            ))}
        </List>
      )}

      {!config?.notShowSelected && (
        <>
          <hr />
          <div style={{ paddingLeft: '8px', paddingRight: '8px' }}>Selected: </div>
          <div>
            {value &&
              value.map((selectItem, index) => (
                <div className={classes.flexContainer} key={selectItem.name}>
                  <div className={classes.mainBox}>{selectItem.name}</div>
                  <IconButton
                    edge="end"
                    aria-label="delete"
                    onClick={() => onDeleteSelect(selectItem, index)}
                  >
                    <DeleteIcon />
                  </IconButton>
                </div>
              ))}
          </div>
        </>
      )}
    </>
  );
}

export default SelectMultiAsyncSearch;
