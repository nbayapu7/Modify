import React, { useState } from 'react';
import { Button, TextField } from '@material-ui/core';
import { formatDate, formatTime, reformatDate } from '../../utils/convertTime';
import { useStyles } from './common';

function CustomTime({ value, onChange, onCancel, setOpenCustom, minRange, maxRange, minGap }) {
  const classes = useStyles();

  // edit custom time range and show last customize records;
  let initStartDate;
  let initStartTime;
  let initEndDate;
  let initEndTime;
  if (value && value.endTime) {
    initStartDate = formatDate(new Date(value.startTime));
    initStartTime = formatTime(new Date(value.startTime));
    initEndDate = formatDate(new Date(value.endTime));
    initEndTime = formatTime(new Date(value.endTime));
  }

  const [selectedStartDate, setSelectedStartDate] = useState(
    initStartDate || formatDate(new Date()),
  );
  const [selectedStartTime, setSelectedStartTime] = useState(
    initStartTime || formatTime(new Date()),
  );
  const [selectedEndDate, setSelectedEndDate] = useState(initEndDate || formatDate(new Date()));
  const [selectedEndTime, setSelectedEndTime] = useState(initEndTime || formatTime(new Date()));
  const [errorMg, setErrorMg] = useState(false);

  const onClickItem = () => {
    // fromate to js date and validate time
    const next = reformatDate(
      selectedStartDate,
      selectedStartTime,
      selectedEndDate,
      selectedEndTime,
      minRange,
      maxRange,
      minGap,
    );
    if (next.message) {
      setErrorMg(next.message);
    } else {
      onChange(next, true);
      if (setOpenCustom) {
        setOpenCustom(false);
      }
      setErrorMg(false);
    }
  };

  const handleStartDateChange = (date) => {
    setSelectedStartDate(date.target.value);
  };

  const handleStartTimeChange = (time) => {
    setSelectedStartTime(time.target.value);
  };

  const handleEndDateChange = (date) => {
    setSelectedEndDate(date.target.value);
  };

  const handleEndTimeChange = (time) => {
    setSelectedEndTime(time.target.value);
  };

  return (
    <>
      <div className={classes.timePickerContainerTop}>
        <TextField
          id="date"
          label="From"
          type="date"
          value={selectedStartDate}
          onChange={handleStartDateChange}
          className={classes.textField}
          InputLabelProps={{
            shrink: true,
          }}
          inputProps={{
            // min: "2019-05-13",
            max: formatDate(new Date()),
          }}
        />
        <TextField
          id="date"
          label=" "
          type="time"
          value={selectedStartTime}
          onChange={handleStartTimeChange}
          className={classes.textField}
          InputLabelProps={{
            shrink: true,
          }}
        />
      </div>
      <div className={classes.timePickerContainer}>
        <TextField
          id="date"
          label="To"
          type="date"
          value={selectedEndDate}
          onChange={handleEndDateChange}
          className={classes.textField}
          InputLabelProps={{
            shrink: true,
          }}
          inputProps={{
            // min: "2019-05-13",
            max: formatDate(new Date()),
          }}
        />
        <TextField
          id="date"
          label=" "
          type="time"
          value={selectedEndTime}
          onChange={handleEndTimeChange}
          className={classes.textField}
          InputLabelProps={{
            shrink: true,
          }}
        />
      </div>
      {errorMg && (
        <div className={classes.errorMessage}>
          error:
          <br />
          {errorMg}
        </div>
      )}
      <div className={classes.submiteContainer}>
        <Button size="small" variant="outlined" onClick={onCancel}>
          Cancel
        </Button>
        <Button color="primary" variant="contained" size="small" onClick={onClickItem}>
          OK
        </Button>
      </div>
    </>
  );
}

export default CustomTime;
