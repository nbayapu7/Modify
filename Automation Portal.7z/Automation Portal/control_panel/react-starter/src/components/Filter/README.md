# Generate a SearchFilter - SearchFilterGenerator

SearchFilterGenerator is  high order component that return a funtional component that renders SearchFilter.

[ziplin design](https://app.zeplin.io/project/5e347f295f010736a520c276/screen/60248b33d37dc4050ddb04ac)

Genertaed searchFilter will support function:
+ select filter type;
+ add or edit a filter;
+ save current filters with a name;
+ save a filter 

## How to make your own filter - generator interface
You could use a basic componentMap object to generater a specific searchFilter component; and use config and SelectType component to do more customized.

```js
const filterComponentMap = {
    'nameForFilter': {
      component: ComponentForFilter,
    }
    'a Filter': {
      component: ComponentForAnotherFilter,
      group: ['groupA']
    },
    'b Filter': {
      component: ComponentForAnotherFilter,
      group: ['groupB'],
    }
    // ....
  }

const config = {
  showSaveLabel: true,
  noCloseIconTag:['Time Range']
}

// has default component : EnhancedSelectType
const SelectType = (
              option // take option list
              onChange // {handleSelectFilterType}

              onSave= //{save current filter}
              getFilterList // {getFilterList}
              onSetFilter // {handleSetFilter}
              deleteFilter // {deleteFilter})
              )=>{
                return ....
              }


const SearchFilter = SearchFilterGenerator(filterComponentMap,config,SelectType);

```
filterComponentMap is required, config and SelectType are optional.

and then use as: 
```js
  // in a react function component
  const submitCallback = (filter)=>{
    //....
  }
  return <SearchFilter 
    initData={filter} 
    onSubmit={submitCallback} 

    checkFilterName ={function}
    onSave = {function}
    getFilterList ={function}
    deleteFilter={function} 
  />
```

***

## filterComponentMap
SearchFilterGenerator take one object as input, key is the filter Name, value should be a object contains component.

The component will map the name as the filter name, so when add or edit certain filter, the dropdown will render the specific componet in map.

<br/>

the data structure should be 

```js
  {
    'nameForFilter': {
      component: ComponentForFilter,
    }
    'a Filter': {
      component: ComponentForAnotherFilter,
      group: ['groupA']
    },
    'b Filter': {
      component: ComponentForAnotherFilter,
      group: ['groupB'],
    }
    // ....
  }
```

Explaination:  when the filter has value for a filter, user will not be able to select filter not in that group. No group specify means the filter can appear in all groups.

<br/>


TODO: discussion

? direct use 
```js
  {
    'nameForFilter': ComponentForFilter,
    'anohterFilter': ComponentForAnotherFilter,
    ....
  }
```

### Sample code

This ExampleSearchFilter is the component for usage;
```js
const FilterA = ({ value, onChange }) => {
  const valueString = JSON.stringify(value);
  // no state function component
  const continueEdit = onChange(value);
  // has state
  const finishEdit = onChange(value, true);

  return (
    <div>
      FilterA option
      <div>value</div>
      <div>{valueString}</div>
    </div>
  );
};

const ExampleSearchFilter = SearchFilterGenerator({
  filterA: {component: FilterA},
});

```

<br/>


### Component For Filter Dropdown

SearchFilter will render the component from filterComponentMap that shares the same name with selected filter in the dropdown. So user can add and edit the filter value in the dropdown.

And the component should support the following interface: 

|props| explanation|
|-|-|
|value| the current value of the filter|
|onChange|the callback function to info SearchFilter change the filter value. onChange(value, isFinish): set isFinish as true will close the dropdown.|
|||

Current component librery provides dropdown filter component type:
+ SelectMulti,  
+ SelectMultiAsyncSearch, 
+ FilterTypeList,
+ TimePicker,

****
## Use SearchFilter
use case: 
```js
const YourContainer = (props)=>{
    // in a react function component
  const [initFilter, setFilter]= useState({
    "A string value filter": "string",
    "A array of string value filter": ['string 1', 'string 2'];
    "A array of object value filter": [
      {name: 'for display 1', others},
      {name: 'object display2', othersKey}
    ]
  })
  const submitCallback = (filter)=>{
    // handle filter
    // fetch new data for table
  }
  return <SearchFilter initData={filter} onSubmit={submitCallback}  />
}
```

** tags depends on filter keys, so filter key should not have empty value.
