import React from 'react';
import styled from 'styled-components';
import Check from './assets/check.svg';

const Container = styled.div`
  display: flex;
  align-items: center;
  flex-direction: row;
  background-color: #fafafa;
  width: 100%;
  padding: 12px 40px;
`;

const StepperContainer = styled.div`
  display: flex;
  align-items: center;
  flex-direction: row;
  color: #808080;
  height: 32px;
  font-size: 14px;
`;

const StepperRoot = styled.div`
  display: flex;
  padding-right: 8px;
`;

const StepperLabel = styled.div`
  width: 24px;
  height: 24px;
  line-height: 24px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: space-around;
  margin-right: 8px;
  border: solid 1px #e3e3e3;
  padding: 0 8px;
  background-color: #fff;
  color: #808080;
  font-size: 14px;
`;

const StepperTitle = styled.div`
  display: inline-block;
  line-height: 24px;
`;

const StepperDashedSeperator = styled.div`
  width: 65px;
  margin: 0 12px 0 4px;
  border-top: 4px dashed #dbdbdb;
  transform: scale(1, 0.25);
`;

const StepperSolidSeperator = styled.div`
  width: 65px;
  margin: 0 12px 0 4px;
  border-top: 1px solid #dbdbdb;
`;

const getContainerStyle = (stepIndex, currentStep, isLastStep) => {
  if (isLastStep) {
    return {
      color: '#4a4a4a',
      opacity: 1,
    };
  }

  if (currentStep === stepIndex + 1) {
    return {
      color: '#4a4a4a',
      opacity: 1,
    };
  }
  if (currentStep > stepIndex) {
    return {
      color: '#4a4a4a',
      opacity: 1,
    };
  }

  return {};
};

const getLabelStyle = (stepIndex, currentStep, isLastStep) => {
  if (isLastStep) {
    return {
      backgroundColor: '#2474b5',
      opacity: 1,
      color: '#fff',
    };
  }

  if (currentStep === stepIndex + 1) {
    return {
      backgroundColor: '#2474b5',
      opacity: 1,
      color: '#fff',
    };
  }
  if (currentStep > stepIndex) {
    return {
      backgroundColor: '#2474b5',
      opacity: 1,
      color: '#fff',
    };
  }

  return {};
};

const getStepperSeperator = (currentStep, k, len) => {
  if (currentStep > k + 1 || len === currentStep) {
    return <StepperSolidSeperator />;
  }

  return <StepperDashedSeperator />;
};

const Stepper = React.memo((props) => {
  const { steps, currentStep } = props;

  return (
    <Container>
      {steps.map((step, k) => {
        return (
          <StepperContainer
            key={k}
            style={getContainerStyle(k, currentStep, steps.length === currentStep)}
          >
            <StepperRoot>
              <StepperLabel style={getLabelStyle(k, currentStep, steps.length === currentStep)}>
                {currentStep > k + 1 || steps.length === currentStep ? (
                  <img src={Check} />
                ) : (
                  step.label
                )}
              </StepperLabel>
              <StepperTitle>{step.title}</StepperTitle>
            </StepperRoot>
            {k < steps.length - 1 ? getStepperSeperator(currentStep, k, steps.length) : null}
          </StepperContainer>
        );
      })}
    </Container>
  );
});

export default Stepper;
