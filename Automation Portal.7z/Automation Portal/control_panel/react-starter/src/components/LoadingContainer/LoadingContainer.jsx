import React from 'react';
import { CircularProgress } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(() => ({
  box: {
    position: 'relative',
  },
  loadingLayer: {
    '&:after': {
      content: '" "',
      overflow: 'hidden',
      opacity: 0.5,
      pointerEvents: 'none',
      userSelect: 'none',
      position: 'absolute',
      top: 0,
      left: 0,
      zIndex: 10,
      width: '100%',
      height: '100%',
      backgroundColor: '#fff',
    },
  },
  loading: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    animation: 'transform 0',
    maxHeight: 300,
  },
}));
const LoadingLayer = ({ loading = true, children }) => {
  const classes = useStyles();
  return (
    <div className={classes.box}>
      {loading && (
        <div className={classes.loadingLayer}>
          <CircularProgress className={classes.loading} size={30} />
        </div>
      )}
      {children}
    </div>
  );
};

export default LoadingLayer;
