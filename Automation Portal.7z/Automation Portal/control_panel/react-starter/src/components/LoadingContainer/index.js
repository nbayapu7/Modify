import LoadingContainer from './LoadingContainer';

export default LoadingContainer;
