import React, { useState, useCallback } from 'react';
import { TableCell, Tooltip } from '@material-ui/core';
import { makeStyles, withStyles, Theme } from '@material-ui/core/styles';
import { FcasbCellProps } from './types';

const StyledTooltip = withStyles((theme: Theme) => ({
  tooltip: {
    color: theme.palette.text.primary,
    fontSize: 14,
    lineHeight: 1.5,
    maxWidth: 320,
    opacity: 1,
    padding: '4px 8px',
    backgroundColor: '#fff',
    borderRadius: 4,
    boxShadow: '0 2px 16px 0 rgba(37, 37, 37, 0.16)',
  },
}))(Tooltip);

const useStyles = makeStyles<Theme>(() => ({
  // root: {
  //   width: 'auto',
  // },
  ellipsisText: {
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
  },

  /* native tooltip
  textWrapper: {
    position: 'relative',
  },
  withTooltip: {
    '&::after': {
      position: 'absolute',
      opacity: 0,
      pointerEvents: 'none',
      content: 'attr(data-tooltip)',
      left: 0,
      top: 'calc(100% + 10px)',
      borderRadius: 3,
      boxShadow: '0 0 5px 2px rgba(100, 100, 100, 0.6)',
      backgroundColor: 'white',
      padding: 8,
      maxWidth: 400,
      zIndex: 100,
      transform: 'translateY(-20px)',
      transition: 'all 150ms cubic-bezier(.25, .8, .25, 1)',
      overflow: 'auto',
    },
    '&:hover::after': {
      opacity: 1,
      transform: 'translateY(0)',
      transitionDuration: '300ms',
    },
  },
  */
}));

const EllipsisText = React.forwardRef<any, any>((props, ref) => (
  //  Spread the props to the underlying DOM element.
  <div {...props} ref={ref}>
    {props.children}
  </div>
));

function FcasbCell<R>(props: FcasbCellProps<R>): React.ReactElement {
  const { field, row, style, align, index, ellipsis = false, render: RenderComponent = '' } = props;
  const value = row[field] || '-';

  const classes = useStyles();
  const [isOverflowing, setOverflowing] = useState(false);

  const measuredRef = useCallback((node) => {
    if (node !== null) {
      // check if text is overflow
      setOverflowing(node.clientWidth < node.scrollWidth || node.clientHeight < node.scrollHeight);
    }
  }, []);
  return (
    <TableCell style={style} align={align} className={classes.root}>
      {RenderComponent === '' && (
        <>
          {ellipsis ? (
            <StyledTooltip placement="bottom" title={value} disableHoverListener={!isOverflowing}>
              <EllipsisText ref={measuredRef} className={classes.ellipsisText}>
                {value}
              </EllipsisText>
            </StyledTooltip>
          ) : (
            value
          )}
        </>
      )}
      {typeof RenderComponent === 'function' && RenderComponent({ row, index })}
      {typeof RenderComponent === 'object' && React.createElement(RenderComponent)}
    </TableCell>
  );
}
export default FcasbCell;

/* TODO: add native css tooltip */
