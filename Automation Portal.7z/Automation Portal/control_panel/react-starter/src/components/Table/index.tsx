import BaseTable from './BaseTable';
import QueryPagination from './QueryPagination';

export { BaseTable, QueryPagination };
export default BaseTable;
