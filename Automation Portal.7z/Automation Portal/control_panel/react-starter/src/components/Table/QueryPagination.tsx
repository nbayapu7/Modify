import React, { useEffect } from 'react';
import { NumberParam, withQueryParams } from 'use-query-params';
import { TablePagination } from '@material-ui/core';
import { DEFAULT_PAGE_SIZE } from '@/constants';
// import { makeStyles } from '@material-ui/core/styles';
import { QueryPaginationProps, PaginationConfigProps } from './types';

// const usePagiStyles = makeStyles(() => ({}));

export const BasePagination: React.FC<PaginationConfigProps> = ({
  skip,
  limit,
  total,
  onSkipChange,
  onChangePage,
  ...rest
}) => {
  const handlePageChange = (e: React.MouseEvent<HTMLButtonElement> | null, page: number) => {
    onSkipChange?.(limit * page);
    onChangePage?.(e, page);
  };
  /* 
    if you see TS error, no worries, will be fixed on @material-ui/cor V5
    see more details here:  https://github.com/mui-org/material-ui/issues/22452
  */
  return (
    <TablePagination
      {...rest}
      component="div"
      count={total}
      page={total > 0 && skip >= 0 ? skip / limit : 0}
      rowsPerPage={limit}
      onChangePage={handlePageChange}
    />
  );
};

export default withQueryParams<any, QueryPaginationProps>(
  {
    skip: NumberParam,
    limit: NumberParam,
  },
  ({ query, setQuery, onChangePage, onChangeRowsPerPage, ...rest }) => {
    const { skip, limit } = query;
    const restProps = rest as any;
    useEffect(() => {
      if (skip === undefined || limit === undefined) {
        setQuery({ skip: 0, limit: DEFAULT_PAGE_SIZE }, 'replaceIn');
      }
      return () => {
        // setQuery({ skip: undefined, limit: undefined });
      };
    }, [query]);
    const handlePageChange = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>, page: number) => {
      setQuery({ skip: page * limit });
      onChangePage?.(e, page);
    };
    const handlePageSizeChange: React.ChangeEventHandler<HTMLTextAreaElement | HTMLInputElement> = (
      e,
    ) => {
      const newLimit = e.target.value;
      setQuery({ limit: newLimit });
      onChangeRowsPerPage?.(e);
    };
    return (
      <>
        {skip !== undefined && limit !== undefined && (
          <BasePagination
            {...restProps}
            skip={skip}
            limit={limit}
            onChangePage={handlePageChange}
            onChangeRowsPerPage={handlePageSizeChange}
          />
        )}
      </>
    );
  },
);
