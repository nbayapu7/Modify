import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { TableCell } from '@material-ui/core';
import sorting from './assets/sorting.svg';
import ascIcon from './assets/asc.svg';
import descIcon from './assets/desc.svg';

const useStyles = makeStyles({
  cell: {
    cursor: 'pointer',
  },
  cellContent: {
    display: 'inline-flex',
    alignItems: 'center',
  },
  sorting: {
    display: 'inline-flex',
    width: '24px',
    height: '24px',
    textAlign: 'center',
    alignItems: 'center',

    '& > img': {
      marginLeft: 10,
    },
  },
});

function SortableHeader({ column, style, asc, desc, onSortChange }) {
  const classes = useStyles();
  const [direction, setDirection] = useState('');

  useEffect(() => {
    if (asc === column.field) {
      setDirection('asc');
    } else if (desc === column.field) {
      setDirection('desc');
    } else {
      setDirection('');
    }
  }, [asc, desc]);
  const sortClicked = () => {
    if (direction === '') {
      // unsort --> desc
      onSortChange({ asc: '', desc: column.field });
    } else if (direction === 'desc') {
      // desc ---> asc
      onSortChange({ asc: column.field, desc: '' });
    } else if (direction === 'asc') {
      // asc --> unsort
      onSortChange({ asc: undefined, desc: undefined });
    }
  };

  return (
    <TableCell style={style} className={classes.cell} align={column.align} onClick={sortClicked}>
      <div className={classes.cellContent}>
        {column.header}
        <div className={classes.sorting}>
          {direction === '' ? (
            <img src={sorting} />
          ) : (
            <img src={direction === 'desc' ? descIcon : ascIcon} />
          )}
        </div>
      </div>
    </TableCell>
  );
}

export default SortableHeader;
