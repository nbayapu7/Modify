import React, { useState, useMemo, useEffect } from 'react';
import classnames from 'classnames';
import {
  Checkbox,
  CheckboxProps,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  IconButton,
} from '@material-ui/core';
import { makeStyles, Theme, withStyles } from '@material-ui/core/styles';
import { isObject } from '@/utils/helper';
import { DEFAULT_PAGE_SIZE } from '@/constants';
import LoadingContainer from '@/components/LoadingContainer';
import CheckedIcon from './assets/checked-checkbox.svg';
import UncheckedIcon from './assets/unchecked-checkbox.svg';
import NotAllCheckedIcon from './assets/not-all-checked.svg';
import ExpandIcon from './assets/expand.svg';
import CollapseIcon from './assets/collapse.svg';
import SortableHeader from './SortableHeader';
import FcasbCell from './FcasbCell';
import { BaseTableProps } from './types';
import QueryPagination, { BasePagination } from './QueryPagination';
import EditRoundedIcon from '@material-ui/icons/EditRounded';
import DeleteRoundedIcon from '@material-ui/icons/DeleteRounded';

const TableCheckBox = withStyles({
  root: {
    padding: 0,
  },
})((props: CheckboxProps) => (
  <Checkbox
    icon={<img src={UncheckedIcon} />}
    checkedIcon={<img src={CheckedIcon} />}
    indeterminateIcon={<img src={NotAllCheckedIcon} />}
    {...props}
  />
));

const useStyles = makeStyles<Theme>((theme: Theme) => ({
  table: {
    backgroundColor: '#fff',
    position: 'relative',
    borderCollapse: 'collapse',
    border: '1px solid #fff',
    width: '100%',
  },
  tableHeadRow: {
    fontWeight: 'bold',
  },
  expandParentRow: {
    backgroundColor: '#f5f5f5',
    border: '1px solid #e3e3e3',
  },
  expandControllerCell: {
    cursor: 'pointer',
    '& .MuiIconButton-sizeSmall': {
      padding: 0,
    },
    '& .expandImg': {
      width: 16,
      height: 16,
    },
  },
  viewMoreLessText: {
    color: theme.palette.primary.main,
  },
  expandRowOpen: {
    border: '1px solid #e3e3e3',
  },
  expandRowCell: {
    paddingBottom: 0,
    paddingTop: 0,
  },
}));

const DEFAULT_PAGINATION_CONFIG = {
  skip: 0, // param.skip for API
  limit: DEFAULT_PAGE_SIZE, // === TablePagination.rowsPerPage
  total: 0, // === TablePagination.count
  rowsPerPageOptions: [], // hide page size controller by default
  enableQuery: false, // use url query params
  onSkipChange: () => {},
};

function clientPager<R>(data: R[], skip: number, limit: number) {
  const start = skip;
  const end = skip + limit;
  return data?.slice(start, end);
}

function BaseTable<R>(props: BaseTableProps<R>): React.ReactElement {
  const classes = useStyles();
  const {
    rowKey = 'id',
    rows,
    columns,
    loading = false,
    pagination: customPagination,
    sort,
    paginationMode = 'sever',
    expandable,
    rowSelection,
    rowOperations,
  } = props;
  /* ------ Table Styling ---- */
  const tableLayout = columns.some((col) => col.ellipsis === true) ? 'fixed' : 'auto';

  /* ------ Sorting ------- */
  const canSort = sort !== undefined && sort.onSortChange;

  /* ------ Pagination ------- */
  const mergedPagination =
    customPagination && isObject(customPagination)
      ? {
          ...DEFAULT_PAGINATION_CONFIG,
          ...customPagination,
        }
      : DEFAULT_PAGINATION_CONFIG;
  const { enableQuery, ...pagination } = mergedPagination;

  /* ------ core Data ------- */
  const displayRows = useMemo<R[]>(() => {
    // 1. check how many rows shoule be shown: (server => row, cient => row.slice)
    const pagedData =
      paginationMode === 'sever' ? rows : clientPager(rows, pagination.skip, pagination.limit);
    // 2. add unique add for table rows if not provided
    if (pagedData.length > 0) {
      if (Object.hasOwnProperty.call(pagedData[0], rowKey)) {
        return pagedData;
      }
      throw new Error('Please provide rowKey');
    }
    return [];
  }, [rows, pagination]);

  /* ------ Start Row Expand ------- */
  const ExpandComponent = expandable?.expandComponent;
  const expandedRowKeys = expandable?.expandedRowKeys ?? [];
  const [expandKeys, setExpandKeys] = useState<string[]>(expandedRowKeys);
  const isExpanded = (key: string) => expandKeys.includes(key);

  const handleExpandRow = (key: string, row: R) => {
    if (isExpanded(key)) {
      setExpandKeys(expandKeys.filter((i) => i !== key));
    } else {
      setExpandKeys([...expandKeys, key]);
    }
    expandable?.onClickExpand?.(key, row, !isExpanded(key));
  };

  const handleEditRow = (key: string, row: R) => {
    console.log('handleEditRow with key ' + key);
    rowOperations?.onClickEdit?.(row);
  };

  const handleDeleteRow = (key: string, row: R) => {
    console.log('handleDeleteRow with key ' + key);
    rowOperations?.onClickDelete?.(row);
  };

  const expandColSpan = useMemo(() => {
    let colSpan = columns.length;
    if (rowSelection) {
      colSpan += 1;
    }
    if (expandable) {
      colSpan += 1;
    }
    return colSpan;
  }, [expandable, rowSelection]);

  useEffect(() => {
    // clear all expand on page change
    if (expandable) {
      setExpandKeys([]);
    }
  }, [pagination.skip]);

  useEffect(() => {
    if (expandable) {
      // get expanded row data from expandKeys
      const expanded = displayRows.filter((item) => isExpanded(item[rowKey].toString()));
      expandable?.onChange?.(expandKeys, expanded);
    }
  }, [displayRows, expandKeys]);

  /* ------ End Row Expand ------- */

  /* ------ Start Row Selection ------- */
  const selectedRowKeys = rowSelection?.selectedRowKeys ?? [];
  const [selKeys, setSelKeys] = useState<string[]>(selectedRowKeys);
  const isSelected = (key: string) => selKeys.includes(key);

  useEffect(() => {
    // clear all selection on page change
    if (rowSelection) {
      setSelKeys([]);
    }
  }, [pagination.skip]);
  useEffect(() => {
    if (rowSelection) {
      // get selected row data from selected keys each time keys changed
      const selectedList = displayRows.filter((item) => isSelected(item[rowKey].toString()));

      rowSelection?.onChange(selKeys, selectedList);
    }
  }, [displayRows, selKeys]);

  const handleCheckAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelKeys(displayRows.map((item: R) => item[rowKey]));
    } else {
      setSelKeys([]);
    }
  };
  const handleCheckboxClick = (e: React.ChangeEvent<HTMLInputElement>, key: string) => {
    if (e.target.checked) {
      setSelKeys([...selKeys, key]);
    } else {
      setSelKeys(selKeys.filter((item) => item !== key));
    }
  };
  /* ----- End Row Selection ------ */

  const [asc, setAsc] = useState(false);
  const localSortHander = (col, data) => {
    const f = col.field;
    if (asc) {
      data.sort((a, b) => (a[f] > b[f] ? 1 : -1));
    } else {
      data.sort((a, b) => (a[f] > b[f] ? -1 : 1));
    }
    setAsc(!asc);
  };

  return (
    <>
      <LoadingContainer loading={loading}>
        <Table className={classes.table} style={{ tableLayout }}>
          <TableHead className={classes.tableHeadRow}>
            <TableRow>
              {/* ----- Row Selection checkbox (CheckALL) ------ */}
              {rowSelection && (
                <TableCell padding="checkbox">
                  <TableCheckBox
                    size="small"
                    color="primary"
                    indeterminate={selKeys.length > 0 && selKeys.length < pagination.limit}
                    checked={displayRows.length > 0 && selKeys.length === displayRows.length}
                    onChange={handleCheckAll}
                    inputProps={{ 'aria-label': 'select all' }}
                  />
                </TableCell>
              )}
              {/* ----- left expand controller header ------ */}
              {expandable?.type === 'left' && <TableCell padding="checkbox" />}

              {/* ----- data columns header ------ */}
              {columns.map((column) =>
                column.sortable && canSort ? (
                  <SortableHeader
                    key={column.field}
                    column={column}
                    style={column.style}
                    asc={sort?.asc ?? ''}
                    desc={sort?.desc ?? ''}
                    // onSortChange={sort?.onSortChange}
                    onSortChange={() => {
                      localSortHander(column, rows);
                    }}
                  />
                ) : (
                  <TableCell key={column.field} style={column.style} align={column.align}>
                    {column.header}
                  </TableCell>
                ),
              )}
              {/* <TableCell>Action</TableCell> */}
              {/* ----- right expand controller header------ */}
              {expandable?.type === 'right' && <TableCell />}
            </TableRow>
          </TableHead>
          <TableBody>
            {displayRows.map((row, index) => {
              const currKeyVal = row[rowKey].toString();
              const labelId = `enhanced-table-checkbox-${index}`;
              return (
                <React.Fragment key={currKeyVal}>
                  <TableRow
                    hover
                    selected={isSelected(currKeyVal)}
                    className={classnames({
                      [classes.expandParentRow]: isExpanded(currKeyVal),
                    })}
                  >
                    {/* ----- Row Selection checkbox ------ */}
                    {rowSelection && (
                      <TableCell padding="checkbox">
                        <TableCheckBox
                          size="small"
                          color="primary"
                          checked={isSelected(currKeyVal)}
                          onChange={(e) => handleCheckboxClick(e, currKeyVal)}
                          inputProps={{ 'aria-labelledby': labelId }}
                        />
                      </TableCell>
                    )}

                    {/* ----- left expand controller ------ */}
                    {expandable && expandable?.type === 'left' && (
                      <TableCell
                        padding="checkbox"
                        className={classes.expandControllerCell}
                        onClick={() => handleExpandRow(currKeyVal, row)}
                      >
                        <IconButton aria-label="expand row" size="small">
                          {expandable?.expandController ? (
                            expandable?.expandController(isExpanded(currKeyVal))
                          ) : (
                            <img
                              className="expandImg"
                              src={isExpanded(currKeyVal) ? CollapseIcon : ExpandIcon}
                            />
                          )}
                        </IconButton>
                      </TableCell>
                    )}

                    {columns.map((column) => (
                      <React.Fragment key={`${currKeyVal}-${column.field}`}>
                        <FcasbCell<R> row={row} index={index} {...column} />
                      </React.Fragment>
                    ))}

                    {/* ----- Append operations ------ */}
                    {/* {rowOperations && (
                    <TableCell>
                      <EditRoundedIcon
                      onClick={() => handleEditRow(currKeyVal, row)}
                      />
                      <DeleteRoundedIcon
                      onClick={() => handleDeleteRow(currKeyVal, row)}
                      />
                    </TableCell>
                    )} */}

                    {/* ----- right expand controller ------ */}
                    {expandable && expandable?.type === 'right' && (
                      <TableCell
                        className={classes.expandControllerCell}
                        onClick={() => handleExpandRow(currKeyVal, row)}
                      >
                        {expandable?.expandController ? (
                          expandable?.expandController(isExpanded(currKeyVal))
                        ) : (
                          <span className={classes.viewMoreLessText}>
                            {isExpanded(currKeyVal) ? 'View Less' : 'View More'}
                          </span>
                        )}
                      </TableCell>
                    )}
                  </TableRow>

                  {/* ----- expand body ------ */}
                  {isExpanded(currKeyVal) && ExpandComponent && (
                    <TableRow className={classes.expandRowOpen}>
                      <TableCell className={classes.expandRowCell} colSpan={expandColSpan}>
                        <ExpandComponent row={row} index={index} />
                      </TableCell>
                    </TableRow>
                  )}
                </React.Fragment>
              );
            })}
          </TableBody>
        </Table>
      </LoadingContainer>
      {customPagination !== false && (
        <>
          {enableQuery ? <QueryPagination {...pagination} /> : <BasePagination {...pagination} />}
        </>
      )}
    </>
  );
}
export default BaseTable;
