import { TablePaginationProps, TableCellProps } from '@material-ui/core';

export interface BaseTableProps<R> {
  // data source
  rows: R[];

  // columns config
  columns: ColumnItem<R>[];

  // pagi config
  pagination?: PaginationConfigProps | false;

  // sort config
  sort?: SortConfig;

  // display loading progress
  loading?: boolean;

  // unique key for data source, default : 'id'
  rowKey: string;

  // row selection config
  rowSelection?: RowSelection<R>;

  // if 'client', you need to pass full list of data into [rows]
  paginationMode?: 'client' | 'server';

  // expand row config
  expandable?: ExpandableConfig<R>;

  // edit and delete onclick
  rowOperations?: rowOperationsConfig<R>;
}

export interface rowOperationsConfig<R> {
  // onclick expand controller
  onClickDelete?: (row: R) => void;

  // onclick expand controller
  onClickEdit?: (row: R) => void;
}

export interface RenderComponent<R> {
  row: R;
  index: number;
}
export interface ColumnItem<R> extends TableCellProps {
  // data key
  field: string;

  // column header
  header: string | React.ReactNode;

  // cell render, if unset, use data[key]
  render?: (props: RenderComponent<R>) => React.ReactNode;

  // style applied in table cell
  style?: React.CSSProperties;

  // sortable
  sortable?: boolean;

  // enable auto ellipsis and show tooltipows,
  // if any of columns has this setting, table-layout will change: 'auto' -> 'fixed'
  ellipsis?: boolean;
}
export interface FcasbCellProps<R> extends ColumnItem<R> {
  row: R;
  index: number;
}

export interface ExpandableConfig<R> {
  // left first col: little triangle / right: 'View More/Less'
  type?: 'left' | 'right';

  // Custom controller render
  // e.g. (isExpand) => (isExpand ? 'Lessss' : 'Mooooore'),
  expandController?: (isExpanded: boolean) => React.ReactNode;

  // current/default Expanded row keys [id1, id2, id3,...]
  expandedRowKeys?: string[]; //

  // expanded row content
  expandComponent?: (props: RenderComponent<R>) => React.ReactElement;

  // onclick expand controller
  onClickExpand?: (key: string, row: R, isExpanded: boolean) => void;

  // when expanded rows changes,
  onChange?: (expandedKeys: string[], expandedRows: R[]) => void;
}

export interface SortChangeParams {
  asc: string;
  desc: string;
}
export interface SortConfig {
  // should be one of column.field
  asc: string;
  desc: string;

  onSortChange: (sortParms: SortChangeParams) => void;
}

export interface RowSelection<R> {
  // single select vs multiple
  // TODO: complete radio selection
  type: 'checkbox' | 'radio';

  // current/default selected row keys [id1, id2, id3,...]
  selectedRowKeys: string[];

  onChange: (selectedKeys: string[], selectedRows: R[]) => void;
}

export type PaginationConfigProps = Partial<TablePaginationProps> & {
  // !important: skip is not 'current page', skip = page * limit
  skip: number;
  limit: number;
  total: number;
  onSkipChange: (skip: number) => void;
};

export type QueryPaginationProps = PaginationConfigProps & {
  query: any;
  setQuery: any;
};
