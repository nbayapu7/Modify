import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { Popover } from '@material-ui/core';

const InfoPopover = withStyles(() => ({
  paper: {
    border: '1px solid #d3d4d5',
    minHeight: 100,
    minWidth: 200,
    padding: '0 16px 16px 16px',
    marginLeft: 4,
    marginRight: 4,
  },
}))(({ anchorPoint, children, ...props }) => (
  <Popover
    anchorOrigin={{
      vertical: 'top',
      horizontal: 'right',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: anchorPoint || 'left',
    }}
    {...props}
  >
    <div
      style={{
        display: 'flex',
        flexDirection: 'row-reverse',
        position: 'relative',
        right: '-10px',
        height: 16,
      }}
    >
      <div style={{ cursor: 'pointer' }} onClick={props.onClose}>
        x
      </div>
    </div>
    {children}
  </Popover>
));

export default InfoPopover;
