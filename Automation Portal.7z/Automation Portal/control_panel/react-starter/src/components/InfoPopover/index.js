import InfoPopover from './InfoPopover';

export default InfoPopover;
