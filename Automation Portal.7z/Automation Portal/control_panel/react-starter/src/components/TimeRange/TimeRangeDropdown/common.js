// import React from 'react';
import { makeStyles, createStyles } from '@material-ui/core/styles';
// import FormControlLabel from '@material-ui/core/FormControlLabel';
// import ListSubheader from '@material-ui/core/ListSubheader';
// import MenuItem from '@material-ui/core/MenuItem';
// import ListItemIcon from '@material-ui/core/ListItemIcon';

export const useStyles = makeStyles((theme) =>
  createStyles({
    inputContainer: {
      width: '100%',
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: '6px',
      marginTop: '6px',
      padding: '0 8px',
    },
    input: {
      width: '100%',
      flex: 1,
      borderRadius: 4,
      border: 'solid 1px #e3e3e3',
    },
    searchIcon: {
      width: '20px',
      height: '20px',
      color: '#4a4a4a',
      zIndex: 99,
      marginRight: '-26px',
    },
    subLabelText: {
      fontSize: 14,
      fontWeight: 'bold',
      lineHeight: 1.5,
      color: '#4a4a4a',
      marginBottom: 10,
      padding: '0 8px',
    },
    flexContainer: {
      width: '100%',
      display: 'flex',
      padding: '0 8px',
    },
    mainBox: {
      width: '100%',
      flex: 1,
      display: 'inline-flex',
      alignItems: 'center',
    },
    actionBox: {
      flex: 0,
    },
    timePickerContainerTop: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 15,
      marginBottom: 20,
      padding: '0 8px',
    },
    timePickerContainer: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 20,
    },
    textField: {
      marginLeft: theme.spacing(1),
      marginRight: theme.spacing(1),
    },
    submiteContainer: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '0 8px',
    },
    errorMessage: {
      color: 'red',
      marginBottom: 20,
      marginLeft: 5,
      maxWidth: 300,
      padding: '0 8px',
    },
    menuItemRoot: {
      fontSize: '14px !important',
      paddingLeft: '8px',
      paddingRight: '8px',
    },
    listContainer: {
      position: 'relative',
      overflow: 'auto',
      paddingTop: 0,
    },
    buttonContained: {
      '&$disabled': {
        opacity: 0.6,
      },
    },
    disabled: {},
    checkBoxRoot: {
      paddingRight: '4px',
      color: '#dbdbdb',
    },
    formControlLableRoot: {
      '& .MuiCheckbox-root.Mui-checked': {
        color: '#106ba3',
      },
    },
    selectMultiMenuItem: {
      paddingLeft: '8px',
      paddingRight: '8px',
      height: '32px',
      overflow: 'unset',
      minHeight: '32px',
    },
    selectMultiMenuItemWithCom: {
      paddingLeft: '8px',
      paddingRight: '8px',
      height: '52px',
      overflow: 'unset',
      minHeight: '32px',
    },
  }),
);
