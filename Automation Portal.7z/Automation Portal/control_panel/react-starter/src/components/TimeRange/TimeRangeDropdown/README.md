

TimeRangeDropdown component is design for display component in a dropdown and share TimeRangeSlect's component.

# Provide
+ {component} TimeRangeDropdown
+ {function} updateTimeValue
+ {function} getTimeValue

<br/>
<br/>

## Data Structure
  props of TimeRangeDropdown
  ```js
  // project time object
    value = {
      key: string,
      name: string, // dispay use
      startTime: timeStamp,
      endTime: timeStamp
    }

    onChange = (next, shouldClose){
      // handle
    }
  ``` 
  \* if using custom time, the endTimeStamp will be the last millisecond of the picked day, which means it could be a future time. StartTimeStamp will be the first milliseconds of the picked day.

<br/>
<br/>

## getTimeValue(value)
\* name is not required.

return is `{startTime, endTime}`

\* custom time will return original time stamp. Other period will return the latest updated time time stamp.

<br/>
<br/>

## updateTimeValue(value)
\* name is not required.

return is a new time object value with latest updated time stamp.

\* custom time will return original time. Other period will return the latest updated time.

<br/>
<br/>



# Dependens on
+ TimeRangeSelect/CustomItmePicker
+ TimeRangeSelect/constants