import React, { useState } from 'react';
import MenuItem from '@material-ui/core/MenuItem';
import FormGroup from '@material-ui/core/FormGroup';
import { Button } from '@material-ui/core';
import { useStyles } from './common';
import { RANGE_DISPLAY_MAP, CUSTOM_LABEL } from '../constants';
import CustomTime from '../TimeRangeSelect/CustomTimePicker';
import { convertOption2Value, convertRange2CustomValue, convertValue2Range } from '../function';

/**
 *
 * @param {object} value defualt could be null
 * @param {string} value.key string
 * @param {string} value.name string for display
 * @param {timeStamp} value.startTime
 * @param {timeStamp} value.endTime
 *
 * @param {function} onChange onChange(nextValue[, shouldClose]);
 */

function TimeRangeDropdown({ value, onChange }) {
  const classes = useStyles();
  const [openCustom, setOpenCustom] = useState(value?.key === 'custom');
  const [range, setRange] = useState(convertValue2Range(value));

  const isValidRange = range.startDate && range.endDate;

  // choose one option of TiePicker, then return obj{name:"", key:"", value:[startTime,endTime]}
  const onSelectPeriodOption = (option) => {
    const next = convertOption2Value(option);
    if (next) {
      onChange(next, true);
    } else {
      setOpenCustom(true);
    }
  };

  const onCancel = () => {
    setOpenCustom(false);
  };

  const handleSubmitCustomRange = () => {
    if (!isValidRange) {
      console.error('time range illegal');
      return;
    }
    onChange(convertRange2CustomValue(range), true);
  };

  return (
    <>
      {openCustom ? (
        <>
          <CustomTime range={range} setRange={setRange} label={CUSTOM_LABEL} />
          <div>
            <Button
              style={{ fontSize: 14 }}
              color="primary"
              variant="contained"
              onClick={handleSubmitCustomRange}
              disabled={!isValidRange}
            >
              Select Date Range
            </Button>
            <Button style={{ fontSize: 14 }} onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </>
      ) : (
        <FormGroup>
          {Object.entries(RANGE_DISPLAY_MAP).map(([option, display]) => (
            <MenuItem
              disableGutters
              className={classes.menuItemRoot}
              key={option}
              selected={value && value.name === display}
              onClick={() => onSelectPeriodOption(option)}
            >
              {display}
            </MenuItem>
          ))}
        </FormGroup>
      )}
    </>
  );
}

export default TimeRangeDropdown;
