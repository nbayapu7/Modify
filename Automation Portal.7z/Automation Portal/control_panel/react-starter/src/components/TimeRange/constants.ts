export const CUSTOM_KEY = 'custom';

export const RANGE_DISPLAY_MAP = {
  '24h': 'Last 24 hour',
  '7d': 'Last 7 days',
  '30d': 'Last 30 days',
  '90d': 'Last 90 days',
  [CUSTOM_KEY]: 'Custom',
};

export const CUSTOM_LABEL = `Max Date Range: 1 Year.`;
