import dayjs from 'dayjs';
import { CUSTOM_KEY, RANGE_DISPLAY_MAP } from './constants';

const formatTime = (dateObj) => {
  return dayjs(dateObj.toDateString()).format('YYYY-MM-DD');
};

const formatCustomTimeDisply = (start, end) => {
  return `[${formatTime(new Date(start))}]-[${formatTime(new Date(end))}]`;
};

export const getTimeValue = ({ key, ...origin }) => {
  let startTime = dayjs().valueOf();
  let endTime = dayjs().valueOf();

  switch (key) {
    case '24h':
      startTime = dayjs().subtract(24, 'hour').valueOf();
      break;
    case '7d':
      startTime = dayjs().subtract(7, 'day').valueOf();
      break;
    case '30d':
      startTime = dayjs().subtract(30, 'day').valueOf();
      break;
    case '90d':
      startTime = dayjs().subtract(90, 'day').valueOf();
      break;
    default:
      startTime = origin.startTime;
      endTime = origin.endTime;
  }
  return { startTime, endTime };
};

export const updateTimeValue = (timeObject) => {
  const { startTime, endTime } = getTimeValue(timeObject);
  const { key } = timeObject;
  return {
    key,
    startTime,
    endTime,
    name: key === CUSTOM_KEY ? formatCustomTimeDisply(startTime, endTime) : RANGE_DISPLAY_MAP[key],
  };
};

// ============= adaptor function to convert data ====================//

/**
 *
 * @param {object} value is {name,key, startTime, endTime}
 *
 * @returns {<RangeWithKey>}  if no value.startTime from input, default as current day
 */
export const convertValue2Range = (value) => {
  const defualtRange = {
    key: 'selection',
    startDate: new Date(),
    endDate: new Date(),
  };
  return {
    ...defualtRange,
    ...(value?.startTime
      ? {
          startDate: new Date(value.startTime),
          endDate: new Date(value.endTime),
        }
      : {}),
  };
};

/**
 * @param {string} selectedPeriod the time period key
 * @returns null if custom or not recognized. And {key, name, startTime, endTime} for recognized key
 */
export const convertOption2Value = (selectedPeriod) => {
  if (selectedPeriod === CUSTOM_KEY) return;
  return {
    key: selectedPeriod,
    name: RANGE_DISPLAY_MAP[selectedPeriod],
    ...getTimeValue({ key: selectedPeriod }),
  };
};

/**
 *
 * @param {RangeWithKey} range
 * @param {Date} range.startDate
 * @param {Date} range.endDate
 *
 * @returns object {key, startTime, endTime, name}
 */
export const convertRange2CustomValue = (range) => {
  const start = new Date(range.startDate);
  const end = new Date(range.endDate);
  end.setHours(23, 59, 59, 999);

  return {
    key: CUSTOM_KEY,
    startTime: start.getTime(),
    endTime: end.getTime(),
    name: formatCustomTimeDisply(start, end),
  };
};
