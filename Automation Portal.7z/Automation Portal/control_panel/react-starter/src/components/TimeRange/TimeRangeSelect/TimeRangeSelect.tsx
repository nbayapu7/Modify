import React, { useState, useEffect } from 'react';
import dayjs from 'dayjs';
import { MenuItem } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import useDialog from '@/hooks/useDialog';
import StyledSelect from './StyledSelect';
import CustomRangeDialog from './CustomRangeDialog';
import { RANGE_DISPLAY_MAP } from '../constants';
import { RangeKey, TimeRangeSelectProps } from './types';
// ReadMore on https://hypeserver.github.io/react-date-range/

const TimeRangeSelect: React.FC<TimeRangeSelectProps> = ({
  defaultValue = '7d', // default: 7day
  onTimeChange,
}) => {
  const [selectedPeriod, setPeriod] = useState<RangeKey>(defaultValue as RangeKey);
  const [customVisible, openCustom, closeCustom] = useDialog();
  const [customRange, setRange] = useState<number[]>([]);

  useEffect(() => {
    let startTime = dayjs().valueOf();
    let endTime = dayjs().valueOf();
    switch (selectedPeriod) {
      case '24h':
        startTime = dayjs().subtract(24, 'hour').valueOf();
        break;
      case '7d':
        startTime = dayjs().subtract(7, 'day').valueOf();
        break;
      case '30d':
        startTime = dayjs().subtract(30, 'day').valueOf();
        break;
      case '90d':
        startTime = dayjs().subtract(90, 'day').valueOf();
        break;
      case 'custom':
        [startTime, endTime] = customRange;
        break;
    }
    onTimeChange({
      key: selectedPeriod,
      startTime,
      endTime,
    });
  }, [selectedPeriod, customRange]);

  const handleClickMenu = (key: string) => {
    if (key !== 'custom') {
      setPeriod(key as RangeKey);
    } else {
      openCustom();
    }
  };

  const handleSubmitCustomRange = ({ startTime, endTime }) => {
    setRange([startTime, endTime]);
    setPeriod('custom');
    closeCustom();
  };

  return (
    <>
      <StyledSelect
        disableUnderline
        IconComponent={ExpandMoreIcon}
        value={selectedPeriod}
        renderValue={(value) =>
          selectedPeriod === 'custom'
            ? `${dayjs(customRange[0]).format('L')} - ${dayjs(customRange[1]).format('L')}`
            : RANGE_DISPLAY_MAP[value as RangeKey]
        }
      >
        {Object.entries(RANGE_DISPLAY_MAP).map(([key, label]) => (
          <MenuItem key={key} value={key} onClick={() => handleClickMenu(key)}>
            {label}
          </MenuItem>
        ))}
      </StyledSelect>
      <CustomRangeDialog
        visible={customVisible}
        onSubmit={handleSubmitCustomRange}
        onCancel={closeCustom}
      />
    </>
  );
};

export default TimeRangeSelect;
