import React, { useState } from 'react';
import dayjs from 'dayjs';
import { Button } from '@material-ui/core';
import { RangeWithKey } from 'react-date-range';
import { BaseDialog } from '@/components/Dialog';
import { CustomRangeDialogProps } from './types';
import CustomTimePicker from './CustomTimePicker';
import { CUSTOM_LABEL } from '../constants';

const CustomRangeDialog: React.FC<CustomRangeDialogProps> = ({
  visible = false,
  defaultValue = [],
  onSubmit,
  onCancel,
}) => {
  const [customRange, setRange] = useState<RangeWithKey>({
    startDate: defaultValue.length > 1 ? new Date(defaultValue?.[0] ?? '') : new Date(),
    endDate: defaultValue.length > 1 ? new Date(defaultValue?.[1] ?? '') : undefined,
    key: 'selection',
  });
  const isValidCustom = customRange.startDate && customRange.endDate;

  const handleSubmitCustomRange = () => {
    if (isValidCustom) {
      onSubmit({
        key: 'custom',
        startTime: dayjs(customRange.startDate).startOf('day').valueOf(),
        endTime: dayjs(customRange.endDate).endOf('day').valueOf(),
      });
    }
  };

  return (
    <BaseDialog
      visible={visible}
      maxWidth="lg"
      title="Custom Date Range"
      content={<CustomTimePicker range={customRange} setRange={setRange} label={CUSTOM_LABEL} />}
      footer={
        <>
          <Button
            style={{ fontSize: 14 }}
            color="primary"
            variant="contained"
            onClick={handleSubmitCustomRange}
          >
            Select Date Range
          </Button>
          <Button style={{ fontSize: 14 }} onClick={onCancel}>
            Cancel
          </Button>
        </>
      }
    />
  );
};

export default CustomRangeDialog;
