import React from 'react';
import dayjs from 'dayjs';
import { DateRange } from 'react-date-range';
import { CustomTimePickerProps } from './types';

const CustomTimePicker: React.FC<CustomTimePickerProps> = ({ range, setRange, label }) => (
  <>
    {label && <div style={{ fontSize: 14, marginBottom: 10 }}>{label}</div>}
    {/* https://github.com/hypeserver/react-date-range#daterangepicker--daterange */}
    <DateRange
      color="2474b5"
      rangeColors={['#2474b5']}
      dateDisplayFormat="MM/dd/yyyy"
      editableDateInputs
      onChange={(ranges: any) => setRange(ranges.selection)}
      moveRangeOnFirstSelection={false}
      ranges={[{ ...range, key: 'selection' }]}
      minDate={dayjs().subtract(1, 'year').toDate()}
      maxDate={new Date()}
    />
  </>
);

export default CustomTimePicker;
