import { withStyles } from '@material-ui/core/styles';
import { Select } from '@material-ui/core';

const StyledSelect = withStyles({
  select: {
    '&:focus': {
      backgroundColor: 'transparent',
    },
  },
  root: {
    fontSize: 14,
    minHeight: 0,
  },
  icon: {
    fontSize: 20,
    top: 'calc(50% - 10px)',
  },
})(Select);

export default StyledSelect;
