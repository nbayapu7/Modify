import { RangeWithKey } from 'react-date-range';
import { RANGE_DISPLAY_MAP } from '../constants';

export type RangeKey = keyof typeof RANGE_DISPLAY_MAP;

export interface RangeChangeParam {
  key: RangeKey;
  startTime: number;
  endTime: number;
}
export type OnTimeChangeFunc = (param: RangeChangeParam) => void;

export interface TimeRangeSelectProps {
  // default range dropdown selection,  default is '7d'
  defaultValue?: RangeKey;

  // Dropdown Change / Custom Dialog Submit
  onTimeChange: OnTimeChangeFunc;
}

export interface CustomRangeDialogProps {
  // control dialog visible
  visible: boolean;

  // default date range on open
  defaultValue?: [number, number];

  /**
   * on Click Dialog Submit Callback
   * @param {Object} range
   * @param {string} range.key 'custom'
   * @param {number} range.startTime start timestamp e.g. 1620109440188
   * @param {number} range.endTime end timestamp e.g. 1620109440188
   */
  onSubmit: (range: RangeChangeParam) => void;

  // on Click Cancel
  onCancel?: () => void;
}

export interface CustomTimePickerProps {
  range: RangeWithKey;
  setRange: (range: RangeWithKey) => void;
  label?: string;
}
