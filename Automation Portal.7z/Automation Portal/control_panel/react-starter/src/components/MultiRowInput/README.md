# MultiRowInput component
This component is designed for edit multiple records.

The following will introduce some interface and attention points. 

For the full demo code, please see TestPage/index in project FortiContainer.

```js
<MultiRowInput
        values={values}
        errors={errors}
        onChange={handleRowsChange}
        addComponent={ <div> add row </div> }
        initRow={initObj}
      >
        <InputUnit name="input2" type="checkbox" style={{ width: 20 }} />
        <span style={{ display: 'inline-flex', alignItems: 'center' }}>someInput</span>
        <InputUnit name="name" style={{ width: 250 }} />
</MultiRowInput>
```

<br/>
<br/>
<br/>

## Basic Functions
This component support edit each field of a row, add row and delete row.

Each object in values array, is a row's data.
Use field's name to match with each row's object key to get value. Any change in the values data will pass out from onChange.

No state in this component. So you can modify the values to change data display, and decide how to handle the change.

Suggest init the values with at lease one empty object in the array.

<br/>
<br/>
<br/>

## Interface

### MultiRowInput
#### Props
| Name         | Type                | Default            | Description                                                                              |
|--------------|---------------------|--------------------|------------------------------------------------------------------------------------------|
| values       | array of object     | must input a array | datas of each rows. use object key to match each field                                   |
| erros        | object of set of id |                    | Use this object key to specify which field and the set to find the id to specify the row |
| onChange     | fucntion            |                    | callback function when edit data. next data is input                                     |
| addComponent | JSX                 | add more           | Use this to customize the button for add a new row                                       |
| initRow      | object              |                    | use this to init for a new row object                                                    |


#### Attentions
1. the values is only controller for the commponent's rows and data. So need to save in the parent component and pass to this component.

2. For errors structure. If there is a field whoes name is 'firstName', and the row with id 'object2' has error in this field. {firstName: new Set().push('object2')}

<br/>
<br/>
<br/>

### Child Component

MultiRowInput will clone its children to fit rows in values, and then pass the data of each row.

Thus, the child component must be able to take care of the following props.

#### Props

| Name     | Type     | Default | Description                                                                                                                         |
|----------|----------|---------|-------------------------------------------------------------------------------------------------------------------------------------|
| name     | string   |         | use this to match with data object key                                                                                              |
| type     | string   | 'text'  | specify the input type. If it is checkbox, will pass data value to and get new value from the attribute checked                     |
| error    | boolean  | false   | if there is corresponding error find in errors, this will be true                                                                   |
| value    |          |         | the data value of the input field                                                                                                   |
| checked  | boolean  | false   | if the type is checkbox, will pass value to this props                                                                              |
| onChange | function |         | callback function when the field is edited, and the function take the event as an input. use the event.target to process data value |

#### Example

```js
const InputUnit = ({ value, error, type = 'text', name, id, onChange, ...props }) => {
  return (
    <StyledFormControl {...props}>
      <StyledOutlinedInput
        name={name}
        id={id}
        value={value}
        onChange={onChange}
        type={type}
        inputProps={{ min: '0', step: '1', max: '100' }}
        error={error}
      />
    </StyledFormControl>
  );
};
const CheckboxUnit = ({ error, checked, type = 'checkbox', name, id, onChange, ...props }) => {
  console.log('checked: ', checked);
  console.log('type: ', type);
  return (
    <StyledFormControl {...props}>
      <Checkbox
        name={name}
        id={id}
        checked={checked}
        onChange={onChange}
        type={type}
        inputProps={{ min: '0', step: '1', max: '100' }}
        error={error}
      />
    </StyledFormControl>
  );
};

```

#### Attention
1. The MultiRowInput component will clone the child component for rows, so please avoid using ref in the child component.

2. Avoid wraping the child components fields together. The MultiRowInput component will only use the first level children's name to match with values' object.

<br/>
<br/>
<br/>

## Data Structure and validate function

### values
values is an array of objects. each object contain the key and value for a row's filed and value.
On edit data will also change in certain object's key's value.

For example, this will have two records. A record contain datas for the field whoes name is 'name', and the field that has the name 'input2'

```js
[
    {
      id: 'id1',
      name: 'first name',
      input2: true,
    },
    {
      id: 'id2',
      name: 'ohter name',
      input2: false,
    },
  ]
```

### errors and validate function

This component will not keep data or auto validate data. Thus, developer will decide when and how to validate data. 

Suggest time point is before submiting data (trigger by submit button), or each time the data change (trigger by onChange callback)

The validate function should generate corrct formatted erros.

erros id an object that take the field's name as key, and the correspond value is a set of ids, or index if no id. 

This is an example that required name field.
```js
const validate = (data) => {
  // console.log(data);
  const nameErrorSet = new Set();
  data.forEach((element, index) => {
    if (!element.name) {
      nameErrorSet.add(element.id || index);
    }
  });
  return {
    name: nameErrorSet,
  };
};

```