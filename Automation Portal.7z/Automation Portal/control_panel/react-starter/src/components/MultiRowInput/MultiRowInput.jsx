import React from 'react';
import cloneDeep from 'lodash.clonedeep';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';

export default function MultiRowInput({
  values,
  onChange,
  children,
  style,
  addComponent,
  notification,
  errors,
  initRow,
}) {
  const onChangeHandle = (e, index, name) => {
    const { target } = e;
    const nextValues = [...values];
    nextValues[index] = {
      ...nextValues[index],
      [name]: target.type === 'checkbox' ? target.checked : target.value,
    };
    onChange(nextValues);
  };

  const deleteHandle = (index) => {
    const nextValues = [...values];
    nextValues.splice(index, 1);
    onChange(nextValues);
  };

  const addRowHandle = () => {
    const nextValues = [...values];
    nextValues.push({
      id: new Date().getTime().toString(),
      ...cloneDeep(initRow),
    });
    onChange(nextValues);
  };

  return (
    <>
      {(values && values.length > 0 ? values : [{}]).map((obj, index) => {
        const id = obj.id || index;
        return (
          <div
            style={{
              width: '100%',
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              ...style,
            }}
            key={id}
          >
            {React.Children.map(children, (child) => {
              if (React.isValidElement(child)) {
                const { name, type } = child.props;
                return React.cloneElement(child, {
                  onChange: (e) => onChangeHandle(e, index, name),
                  ...(type === 'checkbox' ? { checked: !!obj[name] } : { value: obj[name] || '' }),
                  error: !!(errors && errors[name] && errors[name].has(id)),
                });
              }
              return child;
            })}
            {values && values.length > 1 && (
              <div onClick={() => deleteHandle(index)} style={{ cursor: 'pointer', marginLeft: 4 }}>
                <DeleteForeverIcon />
              </div>
            )}
          </div>
        );
      })}
      <div onClick={addRowHandle} style={{ cursor: 'pointer', display: 'inline-block' }}>
        {addComponent || 'add more'}
      </div>
      {notification || ''}
    </>
  );
}
