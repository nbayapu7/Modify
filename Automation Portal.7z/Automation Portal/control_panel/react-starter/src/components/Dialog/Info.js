import React, { forwardRef } from 'react';
import { Button } from '@material-ui/core';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import Typography from '@material-ui/core/Typography';
import Slide from '@material-ui/core/Slide';
import { makeStyles } from '@material-ui/core/styles';
import BaseDialog from './Base';

const useInfoStyles = makeStyles(() => ({
  title: {
    backgroundColor: '#fafafa',
    height: 106,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
}));

const Transition = forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const InfoDialog = ({ title, onOk, onClose, okText = 'OK', cancelText = 'Cancel', ...props }) => {
  const classes = useInfoStyles();
  return (
    <BaseDialog
      TransitionComponent={Transition}
      renderTitle={
        <div className={classes.title}>
          <InfoOutlinedIcon color="primary" style={{ fontSize: 40 }} />
          <Typography variant="body2" color="primary" style={{ fontWeight: 700 }}>
            {title}
          </Typography>
        </div>
      }
      footer={
        <>
          <Button color="primary" variant="contained" size="medium" onClick={onOk}>
            {okText}
          </Button>
          {cancelText.length > 0 && (
            <Button size="medium" onClick={onClose} style={{ marginLeft: 24 }}>
              {cancelText}
            </Button>
          )}
        </>
      }
      {...props}
    />
  );
};

export default InfoDialog;
