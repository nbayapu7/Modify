import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';

const useDialogStyles = makeStyles((theme) => ({
  title: {
    position: 'relative',
    padding: `${theme.spacing(2)}px ${theme.spacing(3)}px`,
    justifyContent: 'space-between',
    alignItems: 'center',
    display: 'flex',
    lineHeight: '30px',
    fontSize: 14,
    fontWeight: 'bold',
  },
  closeButton: {
    padding: theme.spacing(1),
    color: theme.palette.grey[500],
  },
  content: {
    padding: theme.spacing(3),
    borderTop: (props) => (props.dividers.top ? '1px solid #ebebeb' : 'none'),
    borderBottom: (props) => (props.dividers.bottom ? '1px solid #ebebeb' : 'none'),
  },
  footer: {
    margin: 0,
    padding: `${theme.spacing(2)}px ${theme.spacing(3)}px`,
    justifyContent: 'flex-start',
  },
}));

const BaseDialog = (props) => {
  const {
    title,
    renderTitle = '',
    content,
    footer,
    visible,
    dividers = { top: true, bottom: true },
    onClose = undefined,
    titleProps = {},
    contentProps = {},
    ...rest
  } = props;
  const classes = useDialogStyles({ dividers });
  return (
    <Dialog open={visible} onClose={onClose && onClose} {...rest}>
      {renderTitle || (
        <MuiDialogTitle disableTypography className={classes.title} {...titleProps}>
          {title}
          {onClose ? (
            <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
              <CloseIcon />
            </IconButton>
          ) : null}
        </MuiDialogTitle>
      )}
      <MuiDialogContent dividers className={classes.content} {...contentProps}>
        {content}
      </MuiDialogContent>
      {footer && <MuiDialogActions className={classes.footer}>{footer}</MuiDialogActions>}
    </Dialog>
  );
};

export default BaseDialog;
