import React, { forwardRef } from 'react';
import { Button } from '@material-ui/core';
import WarningIcon from '@material-ui/icons/Warning';
import Typography from '@material-ui/core/Typography';
import Slide from '@material-ui/core/Slide';
import { makeStyles } from '@material-ui/core/styles';
import BaseDialog from './Base';

const useAlertStyles = makeStyles(() => ({
  titleBar: {
    backgroundColor: '#fff',
    height: 106,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  warningIcon: {
    marginTop: 36,
    fontSize: 36,
  },
  warningTitle: {
    marginTop: 10,
    fontSize: 14,
    fontWeight: 'bold',
  },
  button: {
    fontSize: 14,
  },
}));

const Transition = forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const AlertDialog = ({ title, onOk, onClose, okText = 'OK', cancelText = 'Cancel', ...props }) => {
  const classes = useAlertStyles();
  return (
    <BaseDialog
      dividers={{ top: false, bottom: true }}
      TransitionComponent={Transition}
      renderTitle={
        <div className={classes.titleBar}>
          <WarningIcon color="secondary" className={classes.warningIcon} />
          <Typography variant="body2" color="secondary" className={classes.warningTitle}>
            {title}
          </Typography>
        </div>
      }
      footer={
        <>
          <Button
            color="secondary"
            variant="contained"
            size="medium"
            className={classes.button}
            onClick={onOk}
          >
            {okText}
          </Button>
          {cancelText.length > 0 && (
            <Button
              size="medium"
              variant="outlined"
              onClick={onClose}
              className={classes.button}
              style={{ marginLeft: 8 }}
            >
              {cancelText}
            </Button>
          )}
        </>
      }
      {...props}
    />
  );
};

export default AlertDialog;
