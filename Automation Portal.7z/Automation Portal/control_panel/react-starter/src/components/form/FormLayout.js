import React from 'react';
import { withStyles, styled } from '@material-ui/core/styles';
import { Grid } from '@material-ui/core';

export const LabelRow = withStyles(() => ({
  root: {
    fontSize: '14px',
    display: 'flex',
    lineHeight: 1.5,
  },
}))((props) => {
  return <Grid {...props} />;
});

export const LabelRowLarge = withStyles(() => ({
  root: {
    fontSize: '16px',
    backgroundColor: '#fafafa',
    marginBottom: '8px',
  },
}))((props) => {
  return <LabelRow {...props} />;
});

export const LabelCol = styled('div')({
  fontSize: '14px',
  lineHeight: 1.5,
  width: '125px',
});
export const FormUnit = withStyles(() => ({
  root: {
    marginBottom: '24px',
    width: '100%',
    maxWidth: (props) => (props.maxWidth ? props.maxWidth : '500px'),
  },
}))((props) => {
  return <Grid {...props} />;
});

export const FormActionRow = withStyles(() => ({
  root: {
    marginTop: '40px',
    display: 'flex',
  },
}))((props) => {
  return <Grid {...props} />;
});

export const FormUnitRow = withStyles(() => ({
  root: {
    display: 'flex',
  },
}))((props) => {
  return <FormUnit {...props} />;
});
