import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import {
  OutlinedInput,
  InputAdornment,
  FormControl,
  Select,
  Button,
  Switch,
  Checkbox,
  Grid,
} from '@material-ui/core';
import { CheckedCheckboxIcon, UncheckedCheckboxIcon } from '../../components/iconLibrary';

export const StyledOutlinedInput = withStyles((theme) => ({
  root: {
    width: '100%',
    height: '32px',
    '&$focused': {
      border: '2px solid #0a84ff',
    },
    '&$focused $notchedOutline': {
      border: 'none',
    },
    '&$error': {
      color: theme.palette.secondary.main,
      border: '2px solid',
      borderColor: theme.palette.secondary.main,
    },
    '&$error $notchedOutline': {
      border: 'none',
    },
  },
  focused: {}, // for custom styles to work
  notchedOutline: {},
  error: {},
  input: {
    height: '16px',
    padding: '8px',
    textOverflow: 'ellipsis',
    fontSize: '16px',
    '&:disabled': {
      backgroundColor: '#f2f2f2',
      borderRadius: '4px',
      color: theme.palette.text.primary,
      backgroundClip: 'padding-box',
    },
  },
}))((props) => <OutlinedInput labelWidth={0} autoComplete="off" notched {...props} />);

// To use StyledNumberInput with react-hook-form:
// <Controller
//   render=((props) => (
//   <StyledNumberInput
//   {...props}
//   onChange={(e) => {props.onChange(e.currentTarget.value);}}/>))
// />
export const StyledNumberInput = withStyles((theme) => ({
  root: {
    width: '100%',
    height: '21px',
    padding: 0,
    borderRadius: '2px',
    '&$error': {
      color: theme.palette.secondary.main,
    },
    '&$error $notchedOutline': {
      border: '1px solid',
      borderColor: theme.palette.secondary.main,
    },
  },
  input: {
    height: '16px',
    padding: 0,
    textOverflow: 'ellipsis',
    fontSize: '14px',
    textAlign: 'center',
    '&:disabled': {
      borderRadius: '2px',
      color: theme.palette.text.primary,
    },
  },
  error: {},
  notchedOutline: {},
}))(({ name, value = 0, min, max, step = 1, ...props }) => {
  return (
    <OutlinedInput
      labelWidth={0}
      autoComplete="off"
      notched
      name={name}
      value={value}
      onChange={(e) => {
        props.onChange(e);
      }}
      {...props}
      startAdornment={
        <InputAdornment position="start">
          <Button
            disabled={props.disabled || (min != null && parseFloat(value) <= min)}
            name={name}
            value={parseFloat(value) - step}
            onClick={(e) => {
              props.onChange(e);
            }}
            style={{
              height: '20px',
              maxWidth: '24px',
              minWidth: '24px',
              padding: 0,
              borderRadius: 0,
              borderRight: '1px solid #e3e3e3',
            }}
          >
            -
          </Button>
        </InputAdornment>
      }
      endAdornment={
        <InputAdornment position="end">
          <Button
            disabled={props.disabled || (max != null && parseFloat(value) >= max)}
            name={name}
            value={parseFloat(value) + step}
            onClick={(e) => {
              props.onChange(e);
            }}
            style={{
              height: '20px',
              maxWidth: '24px',
              minWidth: '24px',
              padding: 0,
              borderRadius: 0,
              borderLeft: '1px solid #e3e3e3',
            }}
          >
            +
          </Button>
        </InputAdornment>
      }
    />
  );
});

export const OutlinedFormControl = (props) => (
  <FormControl variant="outlined" fullWidth {...props} />
);

const OutlinedInputForSelect = withStyles((theme) => ({
  root: {
    width: '100%',
    height: '32px',
    '& $notchedOutline': {
      border: '1px solid #e3e3e3',
    },
    '&$focused $notchedOutline': {
      border: '1px solid #e3e3e3',
    },
    '&$error': {
      color: theme.palette.secondary.main,
    },
    '&$error $notchedOutline': {
      border: '1px solid',
      borderColor: theme.palette.secondary.main,
    },
  },
  focused: {}, // for custom styles to work
  notchedOutline: {},
  error: {},
  input: {
    height: '16px',
    padding: '8px',
    textOverflow: 'ellipsis',
    fontSize: '16px',
    '&:disabled': {
      backgroundColor: '#f2f2f2',
      borderRadius: '4px',
      color: theme.palette.text.primary,
      backgroundClip: 'padding-box',
    },
  },
}))((props) => <OutlinedInput labelWidth={0} autoComplete="off" notched {...props} />);

export const StyledSelect = withStyles(() => ({
  root: {
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    height: '32px',
    width: '100%',
    paddingLeft: '12px',
    paddingTop: '0',
    paddingBottom: 0,
    display: 'inline-flex',
    alignItems: 'center',

    '&:focus': {
      backgroundColor: 'white', // to overwrite
    },
  },
}))((props) => (
  <Select
    variant="outlined"
    input={<OutlinedInputForSelect />}
    MenuProps={{
      anchorOrigin: {
        vertical: 'bottom',
        horizontal: 'left',
      },
      getContentAnchorEl: null,
      style: { marginTop: '4px' },
    }}
    {...props}
  />
));

export const FormButton = withStyles(() => ({
  root: {
    '&:not(:first-child)': {
      marginLeft: '8px',
    },
  },
}))((props) => {
  return <Button {...props} disableRipple variant={props.variant ? props.variant : 'outlined'} />;
});

export const StyledHelperButton = withStyles(() => ({
  root: {
    marginBottom: '24px',
    cursor: 'pointer',
    marginTop: '4px',
    display: 'inline-block',
  },
}))((props) => {
  return <Grid {...props} />;
});

export const GreenSwitch = withStyles((theme) => ({
  root: {
    width: 36,
    height: 20,
    padding: 0,
    margin: 0,
  },
  switchBase: {
    padding: 1,
    '&$checked': {
      transform: 'translateX(16px)',
      color: theme.palette.common.white,
      '& + $track': {
        backgroundColor: theme.palette.success.main,
        opacity: 1,
        border: 'none',
      },
    },
    '&$focusVisible $thumb': {
      color: theme.palette.success.main,
      border: '6px solid #fff',
    },
  },
  thumb: {
    width: 18,
    height: 18,
  },
  track: {
    borderRadius: 20 / 2,
    border: `1px solid ${theme.palette.grey[400]}`,
    backgroundColor: theme.palette.grey[50],
    opacity: 1,
    transition: theme.transitions.create(['background-color', 'border']),
  },
  checked: {},
  focusVisible: {},
}))(({ classes, ...props }) => {
  return (
    <Switch
      focusVisibleClassName={classes.focusVisible}
      disableRipple
      classes={{
        root: classes.root,
        switchBase: classes.switchBase,
        thumb: classes.thumb,
        track: classes.track,
        checked: classes.checked,
      }}
      {...props}
    />
  );
});

export const PrimaryCheckbox = withStyles(() => ({
  root: {
    padding: 0,
    marginRight: '6px',
  },
}))(({ ...props }) => {
  return (
    <Checkbox
      color="primary"
      icon={<UncheckedCheckboxIcon style={{ height: '16px', width: '16px' }} />}
      checkedIcon={<CheckedCheckboxIcon style={{ height: '16px', width: '16px' }} />}
      {...props}
    />
  );
});
