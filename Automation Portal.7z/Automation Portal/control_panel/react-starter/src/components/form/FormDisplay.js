import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { FormHelperText, Grid } from '@material-ui/core';

export const REQUIRED_ERROR_MSG = 'This field is required';

export const LabelText = withStyles((theme) => ({
  root: {
    fontWeight: 'bold',
    marginBottom: '4px',
    position: 'relative',
    color: theme.palette.common.black,
    fontSize: '14px',
    lineHeight: 1.5,
    '&::after': {
      content: (props) => (props.required ? '"*"' : ''),
      position: 'absolute',
      color: theme.palette.secondary.main,
      fontSize: '14px',
      marginLeft: '4px',
    },
  },
}))((props) => {
  return <Grid {...props} />;
});

export const StyledHelperText = withStyles((theme) => ({
  root: {
    margin: '4px 0 0 0',
    fontSize: '12px',
    lineHeight: '18px',
    color: theme.palette.text.primary,
    '&$error': {
      color: theme.palette.secondary.main,
    },
  },
  error: {}, // for custom styles to work
}))((props) => <FormHelperText {...props} />);
