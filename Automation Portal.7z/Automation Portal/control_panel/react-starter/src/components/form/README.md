# CASB Form Elements

Elements are placed in files titled according to its type. <br>

[Design Link](https://zpl.io/ad3zZen)

| Name                                               | Description                                       | Type    | Material UI Component                 |
| -------------------------------------------------- | ------------------------------------------------- | ------- | ------------------------------------- |
| REQUIRED_ERROR_MSG                                 | error message string                              | Display | -                                     |
| LabelText                                          | form label                                        | Display | Grid                                  |
| StyledHelperText                                   | text below, error message below                   | Display | FormHelperText                        |
| StyledOutlinedInput                                | text input                                        | Input   | OutlinedInput                         |
| StyledNumberInput                                  | number input with +, - buttons on left and right. | Input   | Button, InputAdornment, OutlinedInput |
| OutlinedFormControl                                |                                                   | Input   | FormControl                           |
| StyledSelect (and its input element, not exported) | dropdown selection                                | Input   | OutlinedInput, Select                 |
| FormButton                                         | button                                            | Input   | Button                                |
| StyledHelperButton                                 | button below                                      | Input   | Grid                                  |
| GreenSwitch                                        |                                                   | Input   | Switch                                |
| PrimaryCheckbox                                    |                                                   | Input   | Checkbox                              |
| LabelRow                                           | label in form layout 1                            | Layout  | Grid                                  |
| LabelRowLarge                                      | larger LabelRow with a light gray bg              | Layout  | Grid                                  |
| LabelCol                                           | label in form layout 2                            | Layout  | -                                     |
| FormUnit                                           | defines margins in-between form units             | Layout  | Grid                                  |
| FormActionRow                                      | defines margin above action buttons               | Layout  | Grid                                  |
| FormUnitRow                                        | similar to FormUnit, but in a row                 | Layout  | Grid                                  |
