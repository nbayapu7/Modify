import React from 'react';
import Alert from '@material-ui/lab/Alert';
import InfoIcon from '@material-ui/icons/Info';
import WarningIcon from '@material-ui/icons/Warning';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';

import { withStyles, makeStyles } from '@material-ui/core/styles';
import { AlertIcon } from '../iconLibrary/index';

const useStyles = makeStyles(() => ({
  infoRoot: {
    color: '#2474b5',
    width: '22px',
    height: '22px',
  },
}));

const StyledAlert = withStyles((theme) => ({
  root: {
    margin: '0px 0px 0',
    borderWidth: '1px',
    borderStyle: 'solid',
  },
  icon: {
    marginRight: '16px',
  },
  standardInfo: {
    color: theme.charcoal,
    borderColor: '#2474b5',
    backgroundColor: '#e7f3ff',
  },
  standardSuccess: {
    color: theme.charcoal,
    borderColor: '#2aa645',
    backgroundColor: '#eaf6ec',
  },
  standardWarning: {
    color: theme.charcoal,
    borderColor: '#f7bb0a',
    backgroundColor: '#fef8e7',
  },
  standardError: {
    color: theme.charcoal,
    borderColor: '#db3545',
    backgroundColor: '#ffeff0',
  },
}))(Alert);

const AlertMessage = ({ children, ...props }) => {
  const classes = useStyles();
  return (
    <StyledAlert
      iconMapping={{
        info: <InfoIcon classes={{ root: classes.infoRoot }} />,
        warning: <WarningIcon />,
        error: <AlertIcon style={{ width: '21px', height: '19px' }} />,
        success: <CheckCircleIcon />,
      }}
      {...props}
    >
      {children}
    </StyledAlert>
  );
};

export default AlertMessage;
