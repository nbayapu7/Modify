import React from 'react';
import { ReactComponent as SuccessCheck } from '@/assets/images/icons/success-check.svg';
import { ReactComponent as ErrorFail } from '@/assets/images/icons/error-fail.svg';
import { ReactComponent as InfoSolid } from '@/assets/images/icons/info-solid.svg';

import sortingImg from '@/assets/images/icons/sorting.svg';
import checkedCheckbox from '@/assets/images/icons/checked-checkbox.svg';
import uncheckedCheckbox from '@/assets/images/icons/unchecked-checkbox.svg';

export const GreenCheck = (props) => <SuccessCheck {...props} />;

export const FailIcon = (props) => <ErrorFail {...props} />;

export const InfoSolidIcon = InfoSolid;
export const SortingIcon = (props) => <img src={sortingImg} {...props} />;
export const CheckedCheckboxIcon = (props) => <img src={checkedCheckbox} {...props} />;
export const UncheckedCheckboxIcon = (props) => <img src={uncheckedCheckbox} {...props} />;
