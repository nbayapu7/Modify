import React from 'react';
import { makeStyles } from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import BarIcon from './assets/empty-state-data-icon.svg';

interface EmptyElProps {
  size?: 'small' | 'large';
  icon?: 'search' | 'bar' | React.ReactNode;
  title?: string | React.ReactNode;
  desc?: string | React.ReactNode | string[];
  footer?: React.ReactNode;
}
interface EmptyProps extends EmptyElProps {
  show?: boolean;
}

const useStyles = makeStyles({
  root: {
    backgroundColor: '#fff',
    width: '100%',
    height: '100%',
    display: 'flex',
    flexFlow: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconBox: (props: EmptyElProps) => ({
    width: props.size === 'large' ? 120 : 64,
    height: props.size === 'large' ? 120 : 64,
    backgroundColor: '#efefef',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  }),
  icon: (props: EmptyElProps) => ({
    fontSize: props.size === 'large' ? 48 : 30,
    color: '#c9c9c9',
  }),
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    lineHeight: '30px',
    marginBottom: 8,
  },
  desc: (props: EmptyElProps) => ({
    fontSize: props.size === 'large' ? 16 : 12,
    color: '#808080',
    display: 'flex',
    flexFlow: 'column',
    alignItems: 'center',
    lineHeight: props.size === 'large' ? '24px' : '18px',
  }),
  footer: {
    marginTop: 60,
  },
});

const EmptyEl: React.FC<EmptyElProps> = (props) => {
  const {
    icon = 'search',
    size = 'large',
    title,
    desc = 'No data to show at this moment',
    footer,
  } = props;
  const classes = useStyles({ icon, size, title, desc, footer });
  return (
    <div className={classes.root}>
      <div className={classes.iconBox}>
        {icon === 'search' && <SearchIcon className={classes.icon} />}
        {icon === 'bar' && <img src={BarIcon} />}
        {React.isValidElement(icon) && icon}
      </div>

      {/* only large size component has bold title */}
      {size === 'large' && title && <div className={classes.title}>{title}</div>}

      {Array.isArray(desc) ? (
        desc.map((p: string | React.ReactNode, index: number) => (
          <div key={index} className={classes.desc}>
            {p}
          </div>
        ))
      ) : (
        <div className={classes.desc}>{desc}</div>
      )}

      {footer && <div className={classes.footer}>{footer}</div>}
    </div>
  );
};

const Empty: React.FC<EmptyProps> = (props) => {
  const { children, show = false, ...restProps } = props;
  const isContainer = children && show !== undefined;
  if (!isContainer) {
    return <EmptyEl {...restProps} />;
  }
  return <>{show ? <EmptyEl {...restProps} /> : children}</>;
};

export default Empty;
