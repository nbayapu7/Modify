import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

export const AntTabs = withStyles((theme) => ({
  root: {
    borderBottom: '1px solid #e8e8e8',
    position: 'initial',
    top: 0,
    background: 'white',
    paddingLeft: 16,
    height: 48,
  },
  indicator: {
    backgroundColor: theme.palette.common.black,
  },
}))(Tabs);

export const AntTab = withStyles((theme) => ({
  root: {
    textTransform: 'none',
    minWidth: 72,
    fontSize: 14,
    height: 48,
    marginRight: 24,
    '&:hover': {
      color: theme.palette.text.primary,
      opacity: 1,
    },
    '&$selected': {
      color: theme.palette.common.black,
      fontWeight: 'bold',
    },
    '&:focus': {
      color: theme.palette.text.primary,
    },
  },
  selected: {},
}))(Tab);

export function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div role="tabpanel" hidden={value !== index} id={`simple-tabpanel-${index}`} {...other}>
      {value === index && children}
    </div>
  );
}
