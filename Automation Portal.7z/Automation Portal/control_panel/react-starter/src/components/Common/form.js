import React from 'react';
import { withStyles, styled } from '@material-ui/core/styles';
import CancelIcon from '@material-ui/icons/Cancel';
import {
  OutlinedInput,
  InputAdornment,
  FormControl,
  Select,
  Button,
  InputBase,
  Switch,
  Checkbox,
  FormHelperText,
  Grid,
} from '@material-ui/core';
import RadioGroup from '@material-ui/core/RadioGroup';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import { CheckedCheckboxIcon, UncheckedCheckboxIcon } from '../iconLibrary';

export const REQUIRED_ERROR_MSG = 'This field is required';

export const StyledOutlinedInput = withStyles((theme) => ({
  root: {
    width: '100%',
    height: '32px',
    '&$focused': {
      border: '2px solid #0a84ff',
    },
    '&$focused $notchedOutline': {
      border: 'none',
    },
    '&$error': {
      color: theme.palette.secondary.main,
      border: '2px solid',
      borderColor: theme.palette.secondary.main,
    },
    '&$error $notchedOutline': {
      border: 'none',
    },
  },
  focused: {}, // for custom styles to work
  notchedOutline: {},
  error: {},
  input: {
    height: '16px',
    padding: '8px',
    textOverflow: 'ellipsis',
    fontSize: '16px',
    '&:disabled': {
      backgroundColor: '#f2f2f2',
      borderRadius: '4px',
      color: '#4a4a4a',
      backgroundClip: 'padding-box',
    },
  },
}))((props) => <OutlinedInput labelWidth={0} autoComplete="off" notched {...props} />);

// To use StyledNumberInput with react-hook-form:
// <Controller
//   render=((props) => (
//   <StyledNumberInput
//   {...props}
//   onChange={(e) => {props.onChange(e.currentTarget.value);}}/>))
// />
export const StyledNumberInput = withStyles((theme) => ({
  root: {
    width: '100%',
    height: '21px',
    padding: 0,
    borderRadius: '2px',
    '&$error': {
      color: theme.palette.secondary.main,
    },
    '&$error $notchedOutline': {
      border: '1px solid',
      borderColor: theme.palette.secondary.main,
    },
  },
  input: {
    height: '16px',
    padding: 0,
    textOverflow: 'ellipsis',
    fontSize: '14px',
    textAlign: 'center',
    '&:disabled': {
      borderRadius: '2px',
      color: theme.palette.text.primary,
    },
  },
  error: {},
  notchedOutline: {},
}))(({ name, value = 0, min, max, step = 1, ...props }) => {
  return (
    <OutlinedInput
      labelWidth={0}
      autoComplete="off"
      notched
      name={name}
      value={value}
      onChange={(e) => {
        props.onChange(e);
      }}
      {...props}
      startAdornment={
        <InputAdornment position="start">
          <Button
            disabled={props.disabled || (min != null && parseFloat(value) <= min)}
            name={name}
            value={parseFloat(value) - step}
            onClick={(e) => {
              props.onChange(e);
            }}
            style={{
              height: '20px',
              maxWidth: '24px',
              minWidth: '24px',
              padding: 0,
              borderRadius: 0,
              borderRight: '1px solid #e3e3e3',
            }}
          >
            -
          </Button>
        </InputAdornment>
      }
      endAdornment={
        <InputAdornment position="end">
          <Button
            disabled={props.disabled || (max != null && parseFloat(value) >= max)}
            name={name}
            value={parseFloat(value) + step}
            onClick={(e) => {
              props.onChange(e);
            }}
            style={{
              height: '20px',
              maxWidth: '24px',
              minWidth: '24px',
              padding: 0,
              borderRadius: 0,
              borderLeft: '1px solid #e3e3e3',
            }}
          >
            +
          </Button>
        </InputAdornment>
      }
    />
  );
});

export const StyledOutlinedToken = withStyles((theme) => ({
  root: {
    height: '32px',
    width: '100%',
    '&.input': {
      '&:focus': {
        border: '0px',
      },
    },
  },
  input: {
    textOverflow: 'inherit',
    fontSize: '16px',
    '&:disabled': {
      backgroundColor: '#f2f2f2',
      borderRadius: '4px',
      color: '#4a4a4a',
      padding: theme.spacing(1),
      paddingRight: '30px',
    },
    '&:focus': {
      border: '0px',
    },
  },
}))((props) => <OutlinedInput labelWidth={0} autoComplete="off" {...props} />);

export const StyledFormControl = withStyles((theme) => ({}))((props) => (
  <FormControl variant="outlined" fullWidth {...props} />
));

const OutlinedInputForSelect = withStyles((theme) => ({
  root: {
    width: '100%',
    height: '32px',
    '& $notchedOutline': {
      border: '1px solid #e3e3e3',
    },
    '&$focused $notchedOutline': {
      border: '1px solid #e3e3e3',
    },
    '&$error': {
      color: theme.palette.secondary.main,
    },
    '&$error $notchedOutline': {
      border: '1px solid',
      borderColor: theme.palette.secondary.main,
    },
  },
  focused: {}, // for custom styles to work
  notchedOutline: {},
  error: {},
  input: {
    height: '16px',
    padding: '8px',
    textOverflow: 'ellipsis',
    fontSize: '16px',
    '&:disabled': {
      backgroundColor: '#f2f2f2',
      borderRadius: '4px',
      color: '#4a4a4a',
      backgroundClip: 'padding-box',
    },
  },
}))((props) => <OutlinedInput labelWidth={0} autoComplete="off" notched {...props} />);

export const StyledSelect = withStyles((theme) => ({
  root: {
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    height: '32px',
    width: '100%',
    paddingLeft: '12px',
    paddingTop: '0',
    paddingBottom: 0,
    display: 'inline-flex',
    alignItems: 'center',

    '&:focus': {
      backgroundColor: 'white', // to overwrite
    },
  },
}))((props) => (
  <Select
    variant="outlined"
    input={<OutlinedInputForSelect />}
    MenuProps={{
      anchorOrigin: {
        vertical: 'bottom',
        horizontal: 'left',
      },
      getContentAnchorEl: null,
      style: { marginTop: '4px' },
    }}
    {...props}
  />
));

export const StyledInputBase = withStyles((theme) => ({
  root: {
    width: '100%',
    maxWidth: (props) => props.maxWidth || theme.inputMaxWidth,
    position: 'relative',
    borderRadius: '4px',
    border: '1px solid #ccc',
  },
  input: {
    '&:disabled': {
      backgroundColor: '#f2f2f2',
      borderRadius: '4px',
      color: '#4a4a4a',
      padding: theme.spacing(1),
    },
  },
}))((props) => <InputBase variant="outlined" {...props} />);

export const StyledButton = withStyles((theme) => ({
  root: {
    fontSize: '14px',
    height: '32px',
    padding: '5px 10px',
    '&:not(:first-child)': {
      marginLeft: '8px',
    },
    '&:disabled': {
      opacity: '60%',
    },
  },
  sizeLarge: {
    fontSize: '16px',
    height: '40px',
    padding: '8px 16px',
  },
  sizeSmall: {
    fontSize: '12px',
    height: '24px',
    padding: '3px 8px',
  },
  outlinedPrimary: {
    borderColor: theme.primary,
    '&:hover': {
      backgroundColor: '#ebf6ff',
    },
    '&:disabled': {
      color: theme.primary,
      borderColor: theme.primary,
    },
  },
  contained: {
    boxShadow: 'none',
    '&:hover': {
      boxShadow: 'none',
    },
  },
  containedPrimary: {
    boxShadow: 'none',
    '&:hover': {
      boxShadow: 'none',
    },
    '&:disabled': {
      color: 'white',
      backgroundColor: theme.primary,
    },
  },
  text: {
    padding: '0',
    height: '21px',
    '&:hover': {
      backgroundColor: 'white',
      boxShadow: 'none',
    },
  },
  textSizeSmall: {
    height: '18px',
  },
  textSecondary: {
    '&:disabled': {
      color: theme.secondary,
    },
  },
}))((props) => {
  return <Button {...props} disableRipple variant={props.variant ? props.variant : 'outlined'} />;
});

export const StyledHelperButton = withStyles(() => ({
  root: {
    marginBottom: '24px',
    cursor: 'pointer',
    marginTop: '4px',
    display: 'inline-block',
  },
}))((props) => {
  return <Grid {...props} />;
});

export const StyledRadioButton = withStyles((theme) => ({
  root: {},
}))((props) => {
  return <RadioGroup {...props} />;
});

export const StyledCancelIcon = withStyles((theme) => ({
  root: {
    height: '16px',
    width: '16px',
    color: theme.palette.secondary.main,
    marginRight: '8px',
  },
}))((props) => {
  return <CancelIcon {...props} />;
});

export const StyledCheckIcon = withStyles((theme) => ({
  root: {
    height: '16px',
    width: '16px',
    color: theme.greenColor,
    marginRight: '8px',
  },
}))((props) => {
  return <CheckCircleIcon {...props} />;
});

export const LabelRow = withStyles((theme) => ({
  root: {
    fontSize: '14px',
    display: 'flex',
    lineHeight: 1.5,
  },
}))((props) => {
  return <Grid {...props} />;
});

export const LabelRowLarge = withStyles((theme) => ({
  root: {
    fontSize: '16px',
    backgroundColor: theme.lightGray,
    marginBottom: '8px',
  },
}))((props) => {
  return <LabelRow {...props} />;
});

export const LabelCol = styled('div')({
  fontSize: '14px',
  lineHeight: 1.5,
  width: '125px',
});

export const LabelText = withStyles((theme) => ({
  root: {
    fontWeight: 'bold',
    marginBottom: '4px',
    position: 'relative',
    color: theme.tabColor,
    fontSize: '14px',
    lineHeight: 1.5,
    '&::after': {
      content: (props) => (props.required ? '"*"' : ''),
      position: 'absolute',
      color: theme.palette.secondary.main,
      fontSize: '14px',
      marginLeft: '4px',
    },
  },
}))((props) => {
  return <Grid {...props} />;
});

export const FormUnit = withStyles((theme) => ({
  root: {
    marginBottom: '24px',
    width: '100%',
    maxWidth: (props) => (props.maxWidth ? props.maxWidth : '500px'),
  },
}))((props) => {
  return <Grid {...props} />;
});

export const FormActionRow = withStyles((theme) => ({
  root: {
    marginTop: '40px',
    display: 'flex',
  },
}))((props) => {
  return <Grid {...props} />;
});

export const FormUnitRow = withStyles((theme) => ({
  root: {
    display: 'flex',
  },
}))((props) => {
  return <FormUnit {...props} />;
});

// export const InfoContent = styled.div`
//   display: flex;
//   flex-direction: row;
//   align-items: center;
//   margin-bottom: 32px;
//   justify-content: space-between;
//   padding-right: 32px;
// `;
export const InfoContent = styled('div')({
  fontSize: '14px',
  lineHeight: 1,
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  marginBottom: '32px',
  justifyContent: 'space-between',
  paddingRight: '32px',
});

export const MessageWithIconRow = ({ message, status }) => {
  return (
    <InfoContent>
      <div>{message}</div>
      <FormActionRow>
        {status ? (
          <>
            <StyledCancelIcon />
            <div>{status}</div>
          </>
        ) : (
          <StyledCheckIcon />
        )}
      </FormActionRow>
    </InfoContent>
  );
};

export const GreenSwitch = withStyles((theme) => ({
  root: {
    width: 36,
    height: 20,
    padding: 0,
    margin: 0,
  },
  switchBase: {
    padding: 1,
    '&$checked': {
      transform: 'translateX(16px)',
      color: theme.palette.common.white,
      '& + $track': {
        backgroundColor: theme.greenColor,
        opacity: 1,
        border: 'none',
      },
    },
    '&$focusVisible $thumb': {
      color: theme.greenColor,
      border: '6px solid #fff',
    },
  },
  thumb: {
    width: 18,
    height: 18,
  },
  track: {
    borderRadius: 20 / 2,
    border: `1px solid ${theme.palette.grey[400]}`,
    backgroundColor: theme.palette.grey[50],
    opacity: 1,
    transition: theme.transitions.create(['background-color', 'border']),
  },
  checked: {},
  focusVisible: {},
}))(({ classes, ...props }) => {
  return (
    <Switch
      focusVisibleClassName={classes.focusVisible}
      disableRipple
      classes={{
        root: classes.root,
        switchBase: classes.switchBase,
        thumb: classes.thumb,
        track: classes.track,
        checked: classes.checked,
      }}
      {...props}
    />
  );
});

export const PrimaryCheckbox = withStyles((theme) => ({
  root: {
    padding: 0,
    marginRight: '6px',
  },
}))(({ ...props }) => {
  return (
    <Checkbox
      color="primary"
      icon={<UncheckedCheckboxIcon style={{ height: '16px', width: '16px' }} />}
      checkedIcon={<CheckedCheckboxIcon style={{ height: '16px', width: '16px' }} />}
      {...props}
    />
  );
});

export const Required = () => <span style={{ color: 'red' }}>*</span>;

export const StyledHelperText = withStyles((theme) => ({
  root: {
    margin: '4px 0 0 0',
    fontSize: '12px',
    lineHeight: '18px',
    color: '#4a4a4a',
    '&$error': {
      color: theme.palette.secondary.main,
    },
  },
  error: {}, // for custom styles to work
}))((props) => <FormHelperText {...props} />);
