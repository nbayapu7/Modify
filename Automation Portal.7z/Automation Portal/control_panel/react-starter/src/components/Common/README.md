# Common components usage 

## 1. form

There are two formats of form structure. one is label and input in the same row,
and the othre is label and input in different rows. By default, in both formate, form unit will take the whole line width.

