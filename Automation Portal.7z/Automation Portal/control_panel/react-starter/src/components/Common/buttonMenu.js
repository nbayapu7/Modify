import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { Menu, Popover } from '@material-ui/core';
import { useAnchol } from 'utils/hooks';
import { StyledInfoOutlinedIcon, InfoSolidIcon } from 'app/components/iconLibrary';

export const StyledDropdownMenu = withStyles((theme) => ({
  paper: {
    border: '1px solid #d3d4d5',
    marginTop: '4px',
  },
}))(({ anchorPoint, ...props }) => (
  <Menu
    elevation={0}
    getContentAnchorEl={null}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: anchorPoint || 'center',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: anchorPoint || 'center',
    }}
    {...props}
  />
));

export const InfoPopover = withStyles((theme) => ({
  paper: {
    padding: '8px',
    marginLeft: 4,
    marginRight: 4,
    borderRadius: '8px',
    width: 320,
    fontSize: 14,
    lineHeight: 1.5,
    boxShadow: '0 2px 6px 0 rgba(37, 37, 37, 0.16)',
  },
}))(({ anchorPoint, children, ...props }) => (
  <Popover
    anchorOrigin={{
      vertical: 'top',
      horizontal: 'right',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: anchorPoint || 'left',
    }}
    {...props}
  >
    {/* <div
      style={{
        display: 'flex',
        flexDirection: 'row-reverse',
        position: 'relative',
        right: '-10px',
        height: 16,
      }}
    >
      <div onClick={props.onClose} style={{ cursor: 'pointer' }}>
        x
      </div>
    </div> */}
    {children}
  </Popover>
));

export const InfoPopoverComponent = ({
  style,
  children,
  className,
  iconFilled = false,
  ...props
}) => {
  const [anchorElCap, handleInfoOpen, handleInfoClose] = useAnchol(null);
  const Icon = iconFilled ? InfoSolidIcon : StyledInfoOutlinedIcon;

  return (
    <>
      <Icon
        style={{
          cursor: 'pointer',
          marginLeft: 4,
          color: '#4a4a4a',
          height: '14px',
          width: '14px',
          ...props.style,
        }}
        className={className}
        onClick={handleInfoOpen}
      />
      <InfoPopover
        open={!!anchorElCap}
        anchorEl={anchorElCap}
        onClose={handleInfoClose}
        disableRestoreFocus
      >
        {children}
      </InfoPopover>
    </>
  );
};
