import React from 'react';
import _ from 'lodash';
import { DeleteIcon } from '../iconLibrary';

/**
 * @param {array} data is array of object, and function will assign a id to it if there is no id exist.
 * @returns {array} withId, new array of object with id for each object.
 */

export const prepareId = (data) =>
  data.map((element) => ({
    id: new Date().getTime().toString(),
    ...element,
  }));

export default function MultiRowInput({
  values,
  config,
  onChange,
  children,
  style,
  addComponent,
  errors,
  initRow,
  ...props
}) {
  // console.log('children: ', children);

  const onChangeHandle = (e, index, name) => {
    const { target } = e;
    const nextValues = [...values];
    nextValues[index] = {
      ...nextValues[index],
      [name]: target.type === 'checkbox' ? target.checked : target.value,
    };
    onChange(nextValues);
  };

  const deleteHandle = (index) => {
    const nextValues = [...values];
    nextValues.splice(index, 1);
    onChange(nextValues);
  };
  const addRowHandle = () => {
    const nextValues = [...values];
    nextValues.push({ id: new Date().getTime().toString(), ..._.cloneDeep(initRow) });
    onChange(nextValues);
  };

  return (
    <>
      {(values && values.length > 0 ? values : [{}]).map((obj, index) => {
        const id = obj.id || index;
        return (
          <div
            style={{ width: '100%', display: 'flex', justifyItems: 'center', ...style }}
            key={id}
          >
            {React.Children.map(children, (child) => {
              if (React.isValidElement(child)) {
                const { name, type } = child.props;
                return React.cloneElement(child, {
                  onChange: (e) => onChangeHandle(e, index, name),
                  ...(type === 'checkbox' ? { checked: !!obj[name] } : { value: obj[name] || '' }),
                  error: !!(errors && errors[name] && errors[name].has(id)),
                });
              }
              return child;
            })}
            {values.length > 1 && (
              <div
                onClick={() => deleteHandle(index)}
                style={{ lineHeight: '32px', cursor: 'pointer' }}
              >
                <DeleteIcon />
              </div>
            )}
          </div>
        );
      })}
      <div onClick={addRowHandle} style={{ cursor: 'pointer', display: 'inline-block' }}>
        {addComponent || 'add more'}
      </div>
    </>
  );
}
