import React from 'react';
import { Container, Grid, Backdrop, Tabs, Tab, CircularProgress, Link } from '@material-ui/core';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import styled from 'styled-components';

export const PageContainer = withStyles((theme) => ({
  root: {
    padding: '0 16px',
    display: 'flex',
    flexDirection: 'column',
  },
}))(Container);

export const HeaderGrid = withStyles((theme) => ({
  root: {
    marginTop: '24px',
    marginBottom: '16px',
    padding: '0',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
}))(Grid);

export const ContentGrid = withStyles((theme) => ({
  root: {
    padding: (props) => props.padding || 0,
    background: 'white',
    flexGrow: 1,
  },
}))(Grid);

export const GroupGrid = withStyles((theme) => ({
  root: {
    padding: (props) => props.padding || 0,
    background: 'white',
    flexGrow: 1,
    border: 'solid 1px #e3e3e3',
    borderRadius: '4px',
    marginBottom: '16px',
  },
}))(Grid);

export const PopGrid = withStyles((theme) => ({
  root: {
    padding: '16px',
    background: '#fafafa',
    borderRadius: '4px',
    border: 'solid 1px #e3e3e3',
    flexGrow: 1,
  },
}))(Grid);

export const CommandGrid = withStyles((them) => ({
  root: {
    padding: '16px',
    margin: '16px 40px 40px 40px',
    background: '#fafafa',
    border: 'solid 1px #e3e3e3',
    borderRadius: '4px',
    maxHight: '240px',
    display: 'flex',
    flexDirection: 'column',
  },
}))(Grid);

export const LeftGrid = withStyles((theme) => ({
  root: {
    padding: '40px',
  },
}))((props) => <Grid item sm={8} {...props} />);

export const RightGrid = withStyles((theme) => ({
  root: {
    paddingTop: '40px',
    paddingLeft: '24px',
    paddingRight: '58px',
    paddingBottom: '40px',

    background: theme.lightGray,
  },
}))((props) => <Grid item sm={4} {...props} />);

export const FullGrid = withStyles((theme) => ({
  root: {
    padding: '40px',
  },
}))((props) => <Grid item sm={12} {...props} />);

export const FlexContainer = styled.div`
  display: flex;
`;
export const BorderDiv = styled.div`
  border: 1px solid #dbdbdb;
  border-radius: 4px;
  padding: 16px;
`;

export const ContentUnit = styled.div`
  margin-bottom: 16px;
`;
export const ContentSection = styled.div`
  margin-bottom: 32px;
`;
export const ContentBreak = styled.div`
  margin-bottom: 8px;
`;

export const StyledBackdrop = withStyles((theme) => ({
  root: {
    zIndex: 999,
  },
}))(Backdrop);

export const StyledTabs = withStyles((theme) => ({
  root: {
    borderBottom: '1px solid #e8e8e8',
  },
  indicator: {
    backgroundColor: theme.tabColor,
  },
}))(Tabs);

export const StyledTab = withStyles((theme) => ({
  root: {
    textTransform: 'none',
    minWidth: 72,
    fontWeight: theme.typography.fontWeightRegular,
    marginRight: theme.spacing(4),
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(','),
    '&:hover': {
      color: theme.tabColor,
      opacity: 1,
    },
    '&$selected': {
      color: theme.tabColor,
      fontWeight: 'bold',
    },
    '&:focus': {
      color: theme.tabColor,
    },
  },
  selected: {},
}))((props) => <Tab disableRipple {...props} />);

export const DescriptionGrid = withStyles((theme) => ({
  root: {
    textAlign: (props) => props.align || (props.isTitle === true ? 'right' : 'left'),
    fontWeight: (props) => (props.isTitle === true || props.isBold === true ? 'bold' : 'normal'),
    fontSize: (props) => (props.size === 'small' ? 12 : 16),
    color: '#4a4a4a',
  },
}))(({ isTitle, isBold, ...rest }) => <Grid item {...rest} />);

export const Description = ({
  title = '',
  content = '',
  grid = [3, 9],
  isTitle = true,
  isBold,
  ...props
}) => {
  // gird type must be [title(Num), content(Num)]
  const _grid = grid.length !== 2 ? [3, 9] : grid;
  return (
    <>
      <DescriptionGrid isTitle={isTitle} xs={_grid[0]} isBold={isBold} {...props}>
        {title}
      </DescriptionGrid>
      <DescriptionGrid xs={_grid[1]} {...props}>
        {content}
      </DescriptionGrid>
    </>
  );
};

export const PopContent = ({ title, content, ...props }) => {
  return (
    <PopGrid>
      {title && (
        <ContentUnit className="bold" style={{ fontSize: '14px' }}>
          {title}
        </ContentUnit>
      )}
      {content}
    </PopGrid>
  );
};

const useStyles = makeStyles((theme) => ({
  box: {
    position: 'relative',
  },
  loadingLayer: {
    '&:after': {
      content: '" "',
      overflow: 'hidden',
      opacity: 0.5,
      pointerEvents: 'none',
      userSelect: 'none',
      position: 'absolute',
      top: 0,
      left: 0,
      zIndex: 10,
      width: '100%',
      height: '100%',
      backgroundColor: '#fff',
    },
  },
  loading: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    animation: 'transform 0',
    maxHeight: 300,
  },
}));
export const LoadingLayer = ({ loading = true, children }) => {
  const classes = useStyles();
  return (
    <div className={classes.box}>
      {loading && (
        <div className={classes.loadingLayer}>
          <CircularProgress className={classes.loading} size={30} />
        </div>
      )}
      {children}
    </div>
  );
};

export const StyledLink = withStyles((theme) => ({
  root: {
    textDecorationColor: theme.primary,
  },
  underlineNone: {
    color: '#4a4a4a',
    '&:hover': {
      color: theme.primary,
    },
  },
}))(({ underline = 'hover', target = '_blank', rel = 'noreferrer', ...props }) => (
  <Link underline={underline} target={target} rel={rel} {...props} />
));
