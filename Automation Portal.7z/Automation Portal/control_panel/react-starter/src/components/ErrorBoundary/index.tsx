/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import * as React from 'react';

export interface IState {
  hasError: boolean;
  errorMessage: string;
  errorInfo: any;
}

class ErrorBoundary extends React.Component<Record<string, unknown>, IState> {
  public static getDerivedStateFromError() {
    return { hasError: true };
  }

  constructor(props: Record<string, unknown>) {
    super(props);
    this.state = {
      hasError: false,
      errorMessage: '',
      errorInfo: '',
    };
  }

  public componentDidCatch(error: any, info: any) {
    // TOTO: record error
    this.setState({
      errorMessage: error,
      errorInfo: info,
    });
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div>
          <h1>Something went wrong.</h1>
          <h2>{this.state.errorMessage.toString()}</h2>
          <pre>{this.state.errorInfo && this.state.errorInfo.componentStack}</pre>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
