import React, { useState } from 'react';
import { writeStorage, useLocalStorage } from '@rehooks/local-storage';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import { setCommentRange } from 'typescript';
import { SettingsPhoneTwoTone } from '@material-ui/icons';
import Alert from '../Alert';

const InfoMessage = ({ content, severity, onClose, storageKey, ...props }) => {
  // const [storage] = useLocalStorage(window.location.pathname);
  const [close, setClose] = useState(false);

  const handleClose = () => {
    // writeStorage(window.location.pathname, { showInfo: false });
    setClose(true);
    props.setShow({ display: 'none' });
  };

  // return !onClose || storage?.showInfo !== false || !close ? (
  return !onClose || !close ? (
    <Alert
      severity={severity}
      action={
        onClose ? (
          <IconButton aria-label="close" color="inherit" size="small" onClick={handleClose}>
            <CloseIcon style={{ width: '16px', height: '16px' }} />
          </IconButton>
        ) : (
          ''
        )
      }
    >
      {content}
    </Alert>
  ) : null;
};

export default InfoMessage;
