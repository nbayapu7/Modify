import React from 'react';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import CancelIcon from '@material-ui/icons/Cancel';
import yellow from '@material-ui/core/colors/yellow';
import { makeStyles, withStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  flex: {
    display: 'flex',
  },
  left: {
    display: 'inline-flex',
    alignItems: 'center',
  },
  content: {
    paddingLeft: 16,
  },
  greenColor: {
    color: theme.greenColor,
  },
  yellowColor: {
    color: yellow[600],
  },
  redColor: {
    color: theme.redColor,
  },
}));

export const GreenCheckContent = ({ children, iconSize, ...props }) => {
  const classes = useStyles();
  return (
    <div className={classes.flex}>
      <div className={classes.left} {...props}>
        <CheckCircleIcon
          className={classes.greenColor}
          style={{ width: iconSize || 24, height: iconSize || 24 }}
        />
      </div>
      <div className={classes.content}>{children} </div>
    </div>
  );
};

export const YellowCheckContent = ({ children, iconSize, ...props }) => {
  const classes = useStyles();
  return (
    <div className={classes.flex}>
      <div className={classes.left} {...props}>
        <CheckCircleIcon
          className={classes.yellowColor}
          style={{ width: iconSize || 24, height: iconSize || 24 }}
        />
      </div>
      <div className={classes.content}>{children} </div>
    </div>
  );
};

export const RedCancelContent = ({ children, iconSize, ...props }) => {
  const classes = useStyles();
  return (
    <div className={classes.flex}>
      <div className={classes.left} {...props}>
        <CancelIcon
          className={classes.redColor}
          style={{ width: iconSize || 24, height: iconSize || 24 }}
        />
      </div>
      <div className={classes.content}>{children} </div>
    </div>
  );
};
