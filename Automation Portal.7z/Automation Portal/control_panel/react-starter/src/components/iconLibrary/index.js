/* eslint-disable jsx-a11y/alt-text */
import React from 'react';
import styled from 'styled-components';
import withStyles from '@material-ui/core/styles/withStyles';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import IconButton from '@material-ui/core/IconButton';
import SearchIcon from '@material-ui/icons/Search';
import alert from '../../assets/images/alert.svg';
import aws from '../../assets/images/aws.png';
import azure from '../../assets/images/azure.png';
import googleCloud from '../../assets/images/google_cloud.png';
import harbor from '../../assets/images/harbor.png';
import openshift from '../../assets/images/openshift.png';
import private_cloud from '../../assets/images/private_cloud.png';
import deleteImg from '../../assets/images/delete.png';
import sortingImg from '../../assets/images/sorting.svg';
import imageDetailImg from '../../assets/images/image_detail_button.svg';
import statusYellow from '../../assets/images/status-yellow-8-8.svg';
import statusRed from '../../assets/images/status-red-8-8.svg';
import statusGrey from '../../assets/images/status-grey-icon.svg';
import statusGreen from '../../assets/images/status-green-8-8.svg';
import leftMenuExpand from '../../assets/images/left-menu-expand.png';
import alertIcon from '../../assets/images/alertIcon.svg';
import infoOutlined from '../../assets/images/info-outline.svg';
import infoSolid from '../../assets/images/info-solid.svg';
import checkedCheckbox from '../../assets/images/checked-checkbox.svg';
import uncheckedCheckbox from '../../assets/images/unchecked-checkbox.svg';

export const Init = <img src={statusGrey} />;
export const Healthy = <img src={statusGreen} />;
export const Unhealthy = <img src={statusRed} />;
export const Warning = <img src={statusYellow} />;

export const On = <img src={statusGreen} />;
export const OffByUser = <img src={statusRed} />;
export const OffBySystem = <img src={statusRed} />;

export const AWS = <img src={aws} />;
export const Azure = <img src={azure} />;
export const GoogleCloud = <img src={googleCloud} />;
export const Harbor = <img src={harbor} />;
export const OpenShift = <img src={openshift} />;
export const PrivateCloud = <img src={private_cloud} />;
export const LeftMenuExpand = <img src={leftMenuExpand} />;
export const SuccessDot = <img style={{ height: '8px', width: '8px' }} src={statusGreen} />;
export const FailDot = <img style={{ height: '8px', width: '8px' }} src={statusRed} />;
export const CancelDot = <img style={{ height: '8px', width: '8px' }} src={statusGrey} />;
export const CriticalRiskSquare = (
  <div style={{ height: '8px', width: '8px', background: '#992530' }} />
);
export const HighRiskSquare = (
  <div style={{ height: '8px', width: '8px', background: '#db3545' }} />
);
export const MediumRiskSquare = (
  <div style={{ height: '8px', width: '8px', background: '#df8410' }} />
);
export const LowRiskSquare = <div style={{ height: '8px', width: '8px', background: '#f7bb0a' }} />;
export const InfoRiskSquare = (
  <div style={{ height: '8px', width: '8px', background: '#2aa645' }} />
);
export const Alert = <img src={alert} />;

// which format is better??
export const DeleteIcon = (props) => <img src={deleteImg} {...props} />;
export const SortingIcon = (props) => <img src={sortingImg} {...props} />;
export const ImageDetailIcon = (props) => <img src={imageDetailImg} {...props} />;
export const AlertIcon = (props) => <img src={alertIcon} {...props} />;
export const StyledInfoOutlinedIcon = (props) => <img src={infoOutlined} {...props} />;
export const InfoSolidIcon = (props) => <img src={infoSolid} {...props} />;
export const CheckedCheckboxIcon = (props) => <img src={checkedCheckbox} {...props} />;
export const UncheckedCheckboxIcon = (props) => <img src={uncheckedCheckbox} {...props} />;

// must be all lowercase for the key
const mapping = {
  alert: Alert,
  aws: AWS,
  aws_ecr: AWS,
  ecr: AWS,
  azure: Azure,
  acr: Azure,
  gcr: GoogleCloud,
  googlecloud: GoogleCloud,
  google_cloud: GoogleCloud,
  harbor: Harbor,
  success: SuccessDot,
  fail: FailDot,
  cancel: CancelDot,
  openshift: OpenShift,
  unknown: '-',
  initializing: Init,
  healthy: Healthy,
  unhealthy: Unhealthy,
  warning: Warning,
  /* status for FCAS */
  /* Task */
  green: Healthy,
  red: Unhealthy,
  yellow: Warning,
  /* Device */
  offline: Init,
  idling: Healthy,
  preparing: Warning,
  ready: Healthy,
  imported: Healthy,
  error: Unhealthy,
  occupied: Unhealthy,
  /* ************** */
  on: On,
  off_by_user: OffByUser,
  off_by_system: OffBySystem,
  private_cloud: PrivateCloud,
  left_menu_expand: LeftMenuExpand,
  critical_risk: CriticalRiskSquare,
  high_risk: HighRiskSquare,
  medium_risk: MediumRiskSquare,
  low_risk: LowRiskSquare,
  info_risk: InfoRiskSquare,
};

const blankImage = (
  // https://css-tricks.com/snippets/html/base64-encode-of-1x1px-transparent-gif/
  <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" />
);

export default function getImage(str) {
  return mapping[str.toString().toLowerCase()] || blankImage;
}

export const PlatformIcon = styled.div`
  display: flex;
  flex-direction: row;
  align-items: inherit;
  & > img {
    width: 20px;
    // height: 20px;
    margin-right: 8px;
  }
`;

export const PlatformWidget = ({ platform, text }) => (
  <PlatformIcon>
    {getImage(platform)}
    {text}
  </PlatformIcon>
);

export const LeftMenuIcon = withStyles({
  root: {
    '& > img': {
      height: (props) => props.height || '14px',
      width: (props) => props.width || '14px',
      objectFit: 'contain',
      transform: (props) => props.rotateTransform || null,
    },
  },
})(ListItemIcon);

export const Icon = withStyles({
  root: {
    minWidth: '16px',
    marginRight: '10px',
  },
})(ListItemIcon);

export const StyledSearchIcon = withStyles({
  iconButton: {
    padding: '4px',
    '&:disabled': {
      color: '#4a4a4a',
    },
  },
})(({ classes }) => (
  <IconButton className={classes.iconButton} aria-label="search" disabled>
    <SearchIcon />
  </IconButton>
));
