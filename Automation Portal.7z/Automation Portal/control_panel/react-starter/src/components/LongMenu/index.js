import LongMenu from './LongMenu';

export default LongMenu;