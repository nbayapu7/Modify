function capitalize(str) {
  return str.slice(0, 1).toUpperCase() + str.slice(1).toLowerCase();
}

function groupBy(key) {
  return function group(array) {
    return array.reduce((ans, obj) => {
      const property = obj[key] === 'DLP' ? obj[key] : capitalize(obj[key]);
      ans[property] = ans[property] || [];
      ans[property].push(obj);
      return ans;
    }, {});
  };
}

/**
 *
 * @param {Array} data array with object
 * @param {String} key groupby key of object
 * @return {Object} key = groupby, value = array of subObj with one certain type
 */
const groupByType = (data, key) => {
  const groupByKey = groupBy(key);
  const obj = groupByKey(data);
  const sortedObj = {};
  Object.keys(obj)
    .sort()
    .forEach((type) => {
      sortedObj[type] = obj[type];
    });
  return sortedObj;
};

export default groupByType;
