export default function isString(item) {
  return typeof item === 'string' || item instanceof String;
}
