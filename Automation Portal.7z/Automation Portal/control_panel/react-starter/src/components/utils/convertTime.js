/**
 *
 * @param {string} timeName Last # days or Customize
 * @return {Boolean} fasle: Customize Case; True: object with name, start/endTime
 */
export function convertTime(timeName) {
  const startDt = new Date();
  const endDt = new Date();
  if (timeName === 'Last 24 hours') {
    return {
      name: 'Last 24 hours',
      startTime: startDt.setDate(endDt.getDate() - 1),
      endTime: endDt.getTime(),
    };
  }
  if (timeName === 'Last 7 days') {
    return {
      name: 'Last 7 days',
      startTime: startDt.setDate(endDt.getDate() - 7),
      endTime: endDt.getTime(),
    };
  }
  if (timeName === 'Last 30 days') {
    return {
      name: 'Last 30 days',
      startTime: startDt.setDate(endDt.getDate() - 30),
      endTime: endDt.getTime(),
    };
  }
  if (timeName === 'Last 90 days') {
    return {
      name: 'Last 90 days',
      startTime: startDt.setDate(endDt.getDate() - 90),
      endTime: endDt.getTime(),
    };
  }
  return false;
}

export function default24TimePicker() {
  const startDt = new Date();
  const endDt = new Date();
  return {
    name: 'Last 24 hours',
    startTime: startDt.setDate(endDt.getDate() - 1),
    endTime: endDt.getTime(),
  };
}

// format timestamp to yyyy-mm-dd
export function formatDate(date) {
  let month = `${date.getMonth() + 1}`;
  let day = `${date.getDate()}`;
  const year = date.getFullYear();

  if (month.length < 2) month = `0${month}`;
  if (day.length < 2) day = `0${day}`;

  return [year, month, day].join('-');
}

// format timestamp to hh:mm
export function formatTime(time) {
  const hour = `0${time.getHours()}`.slice(-2);
  const minute = `0${time.getMinutes()}`.slice(-2);

  return [hour, minute].join(':');
}

// format yyyy-mm-dd to timestamp
export function datetimeToTimestamp(datetime) {
  const a = datetime.split(' ');
  const d = a[0].split('-');
  const t = a[1].split(':');
  const date = new Date();
  date.setUTCFullYear(d[0], d[1] - 1, d[2]);
  date.setUTCHours(t[0], t[1], t[2], 0);

  return date.getTime();
}

// verify time validation minRang: days, maxRang: days, minGap: minutes
export function verifyTime(startTime, endTime, minRange, maxRange, minGap) {
  let minR;
  let maxR;
  let minMinute;
  if (typeof minRange === 'number' && minRange) {
    minR = minRange;
  } else {
    minR = 0;
  }

  if (typeof maxRange === 'number' && maxRange) {
    maxR = maxRange;
  } else {
    maxR = 90;
  }

  if (typeof minGap === 'number' && minGap) {
    minMinute = minGap;
  } else {
    minMinute = 0;
  }

  // mintues
  const totalRange = Math.floor((endTime - startTime) / (60 * 1000));
  if (totalRange < 0) {
    return { message: 'End time should be later than start time!' };
  }
  if (totalRange === 0) {
    return { message: 'The start time cannot equal to end time!' };
  }
  if (totalRange < minR * 24 * 60 - 1) {
    return {
      message: `Exceeds the minimal interval! The minimal range is ${minR} days!`,
    };
  }
  if (totalRange < maxR * 24 * 60) {
    if (totalRange < minMinute - 1) {
      return {
        message: `Exceeds the minimal mintues interval! The minimal minutes range is ${minMinute} mintues!`,
      };
    }
    return false;
  }
  return {
    message: `Exceeds the maximum interval! The maximum range is ${maxR} days!`,
  };
}

// reformat to new Date()
/**
 *
 * @param {string} startDate yyyy-mm-dd
 * @param {string} startTime hh:mm
 * @param {string} endDate yyyy-mm-dd
 * @param {string} endTime hh:mm
 * @param {number} minRange minimal interval days, eg: 7
 * @param {number} maxRange maximum interval days
 * @param {number} minGap minimal interval minutes, eg: 30
 */
export function reformatDate(startDate, startTime, endDate, endTime, minRange, maxRange, minGap) {
  const start = startDate.split('-');
  const newStartDate = [start[1], start[2], start[0]].join('-');
  const end = endDate.split('-');
  const newEndDate = [end[1], end[2], end[0]].join('-');
  const displayTime = `[${[newStartDate, startTime].join(' ')}] - [${[newEndDate, endTime].join(
    ' ',
  )}]`;
  const newStartTime = [startTime, '00'].join(':');
  const newEndTime = [endTime, '00'].join(':');
  const startDateTime = [startDate, newStartTime].join(' ');
  const endDateTime = [endDate, newEndTime].join(' ');
  const startTimestamp = new Date(startDateTime).getTime();
  const endTimestamp = new Date(endDateTime).getTime();
  const message = verifyTime(startTimestamp, endTimestamp, minRange, maxRange, minGap);
  if (message) {
    return message;
  }
  return {
    name: displayTime,
    startTime: startTimestamp,
    endTime: endTimestamp,
  };
}

// minDateTime, params: interval
export function minDateTime(days) {
  const endDate = new Date();
  const newDate = new Date(endDate.getTime() - days * (24 * 60 * 60 * 1000));
  const minDate = `${newDate.getFullYear()}-${newDate.getMonth() + 1}-${newDate.getDate()}`;
  return minDate;
}
