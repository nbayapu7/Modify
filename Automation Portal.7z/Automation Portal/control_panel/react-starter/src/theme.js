import { createMuiTheme } from '@material-ui/core/styles';
import LatoFonts from '@/assets/fonts/Lato';
import defaultProps from './defaultProps';

const FcasbColor = {
  primary: '#2474b5',
  secondary: '#DB3545',
  textPrimary: '#4a4a4a',
  textDark: '#252525',
  textSecondary: '#808080',
  success: '#2AA645',
  warning: '#F7BB0A',
  border: '#e3e3e3',
};

const ButtonSmall = {
  fontSize: 12,
  padding: '3px 10px',
};
const ButtonLarge = {
  fontSize: 16,
  padding: '8px 16px',
};

export default createMuiTheme({
  palette: {
    common: {
      black: FcasbColor.textDark,
    },
    primary: {
      main: FcasbColor.primary,
    },
    secondary: {
      main: FcasbColor.secondary,
    },
    success: {
      main: FcasbColor.success,
    },
    warning: {
      main: FcasbColor.warning,
    },
    error: {
      main: FcasbColor.secondary,
    },
    text: {
      primary: FcasbColor.textPrimary,
      secondary: FcasbColor.textSecondary,
    },
    background: {
      default: '#f1f1f1',
    },
  },
  typography: {
    fontFamily: 'Lato, sans-serif',
    color: FcasbColor.textPrimary,
    button: {
      textTransform: 'none',
    },
  },
  props: defaultProps,
  overrides: {
    MuiCssBaseline: {
      '@global': {
        '@font-face': [...LatoFonts],
      },
    },
    MuiButton: {
      root: {
        fontSize: 14,
        lineHeight: 1.5,
        color: FcasbColor.textPrimary,
        borderRadius: 4,
        padding: '6px 8px',
      },
      textSizeSmall: ButtonSmall,
      textSizeLarge: ButtonLarge,

      // contained
      containedSizeSmall: ButtonSmall,
      containedSizeLarge: ButtonLarge,

      // outlined
      outlined: {
        border: '1px solid #e3e3e3',
        '&:hover': {
          backgroundColor: '#ebf6ff',
          borderColor: 'transparent',
        },
      },
      outlinedSizeSmall: ButtonSmall,
      outlinedSizeLarge: ButtonLarge,
      outlinedPrimary: {
        color: FcasbColor.primary,
        '&:hover': {
          backgroundColor: '#ebf6ff',
          borderColor: FcasbColor.primary,
        },
      },
      outlinedSecondary: {
        color: FcasbColor.primary,
        border: '1px solid #e3e3e3',
        backgroundColor: '#fff',

        '&:hover': {
          backgroundColor: '#ebf6ff',
          borderColor: '#e3e3e3',
        },
      },
    },
    MuiAlert: {
      root: {
        lineHeight: 1.5,
        marginBottom: 16,
      },
      outlinedInfo: {
        backgroundColor: '#e7f3ff',
        border: `1px solid ${FcasbColor.primary}`,

        '& .MuiAlert-icon path': {
          fill: FcasbColor.primary,
        },
      },
      outlinedSuccess: {
        backgroundColor: '#eaf6ec',
        border: `1px solid ${FcasbColor.success}`,

        '& .MuiAlert-icon path': {
          fill: FcasbColor.success,
        },
      },
      outlinedError: {
        backgroundColor: '#ffeff0',
        border: `1px solid ${FcasbColor.secondary}`,

        '& .MuiAlert-icon path': {
          fill: FcasbColor.secondary,
        },
      },
      outlinedWarning: {
        backgroundColor: '#fef8e7',
        border: `1px solid ${FcasbColor.warning}`,

        '& .MuiAlert-icon path': {
          fill: FcasbColor.warning,
        },
      },
      message: {
        padding: '3px 0',
        color: FcasbColor.textPrimary,
      },
      icon: {
        marginRight: 16,
        padding: '6px 0',

        '& > svg': {
          fontSize: 16,
        },
      },
    },
    MuiTableContainer: {
      root: {
        boxShadow: 'none',
      },
    },
    MuiTableRow: {
      root: {
        '&$selected': {
          backgroundColor: '#ebf6ff',
          border: '1px solid #e3e3e3',

          '&:hover': {
            backgroundColor: '#ebf6ff',
          },
        },
      },
      hover: {
        backgroundColor: 'f5f5f5',
        '&:hover': {
          border: '1px solid #e3e3e3',
        },
      },
    },
    MuiTableCell: {
      root: {
        // borderBottomColor: variableMap.boderColor,
        padding: '4px 8px',
      },
      head: {
        fontWeight: 700,
        fontSize: 14,
        color: FcasbColor.textPrimary,
        padding: 8,
        lineHeight: 1.5,
        whiteSpace: 'nowrap',
      },
      body: {
        fontSize: 14,
        padding: '9px 8px',
        color: FcasbColor.textPrimary,
      },
      paddingCheckbox: {
        width: 32,
        padding: '4px 8px',
        textAlign: 'center',
      },
    },
    MuiLinearProgress: {
      colorPrimary: {
        // backgroundColor: variableMap.boderColor,
      },
    },
    MuiPopover: {
      paper: {
        boxShadow:
          '0px 2px 2px -1px rgb(0 0 0 / 10%), 0px 4px 5px 1px rgb(0 0 0 / 4%), 0px 3px 14px 2px rgb(0 0 0 / 6%)',
      },
    },
    MuiSvgIcon: {
      fontSizeInherit: {
        fontSize: 16,
      },
      fontSizeSmall: {
        fontSize: 14,
      },
      fontSizeLarge: {
        fontSize: 18,
      },
    },
  },
  MuiListItemText: {
    primary: {
      fontSize: 14,
    },
  },
});
