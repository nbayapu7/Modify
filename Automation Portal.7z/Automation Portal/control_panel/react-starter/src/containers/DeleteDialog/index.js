import React, { forwardRef } from 'react';
import { FormUnit, LabelRow, LabelText } from '../../components/Common/form';

const DeleteDialog = forwardRef((props, ref) => {
  const { msg } = props;
  return (
    <FormUnit>
      <LabelRow>
        <LabelText>{msg}</LabelText>
      </LabelRow>
    </FormUnit>
  );
});

export default DeleteDialog;
