import React, { forwardRef, useImperativeHandle, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import Collapse from '@material-ui/core/Collapse';
import FileCopyIcon from '@material-ui/icons/FileCopy';
import WarningIcon from '@material-ui/icons/Warning';
import {
  FormUnit,
  LabelRow,
  LabelText,
  Required,
  StyledFormControl,
  StyledOutlinedInput,
  StyledSelect,
  OutlinedInputForSelect,
  StyledOutlinedToken,
  StyledHelperText,
} from '../../components/Common/form';
import { Link, MenuItem, TextareaAutosize } from '@material-ui/core';

import { fetchList } from '../App/constants';

const DeliverDialog = forwardRef((props, ref) => {
  const { setComments, task, newItem, setNewItem, deviceconfig } = props;
  // const deviceListRes = useQuery('deviceList123', fetchList('api/devices?status=Idling'), {refetchInterval: 5000,});
  // const ticketListRes = useQuery('ticketList123', fetchList('api/tickets'), {refetchInterval: 5000,});
  // console.log("deviceListRes fetching: " + deviceListRes.data);
  const [status, setStatus] = useState('');
  const [c, setC] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    var cc;
    if (name == 'status') {
      setStatus(value);

      if (value == 'Service Delivered') {
        cc = 'Dear Customer, please be noted that your configuration is now delivered.';
        setC('Dear Customer, please be noted that your configuration is now delivered.');
      } else {
        cc = c;
      }
    }
    console.log(cc, status);
    if (name == 'comments') setC(value);
    setNewItem({
      ...newItem,
      [name]: value,
      comments: cc ?? c,
    });
    console.log('end: ', newItem);
  };
  return (
    <>
      {task ? (
        <FormUnit>
          <LabelRow>
            <LabelText>Edit exist task</LabelText>
          </LabelRow>
        </FormUnit>
      ) : (
        <>
        <FormUnit>
          <LabelRow>
            <LabelText>Configuration File:</LabelText>
          </LabelRow>
          <Link component="button" variant="body2">
            {' '}
            {deviceconfig}{' '}
          </Link>
        </FormUnit>
          <FormUnit>
          <LabelRow>
            <LabelText>
              Change Status <Required />
            </LabelText>
          </LabelRow>
          <StyledFormControl>
            <StyledSelect name={'status'} value={status} onChange={handleChange}>
              <MenuItem value={'New'}> New </MenuItem>
              <MenuItem value={'In Progress'}> In Progress </MenuItem>
              <MenuItem value={'Pending Customer Feedback'}> Pending Customer Feedback </MenuItem>
              <MenuItem value={'Received Customer Feedback'}> Received Customer Feedback </MenuItem>
              <MenuItem value={'On Hold'}> On Hold </MenuItem>
              <MenuItem value={'Service Delivered'}> Service Delivered </MenuItem>
              <MenuItem value={'Pending Close Confirmation'}> Pending Close Confirmation </MenuItem>
              <MenuItem value={'Closed'}> Closed </MenuItem>
              <MenuItem value={'Re-Opened'}> Re-Opened </MenuItem>
            </StyledSelect>
          </StyledFormControl>
          </FormUnit>
          <FormUnit>
          <LabelRow>
            <LabelText>
              Comments <Required />
            </LabelText>
          </LabelRow>
          <StyledFormControl>
            <TextareaAutosize name={'comments'} rows={3} onChange={handleChange} value={c} />
          </StyledFormControl>
        </FormUnit>
        </>
      )}
    </>
  );
});

export default DeliverDialog;
