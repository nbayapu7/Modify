import React, { useState, useEffect, useMemo } from 'react';
// import { useParams } from 'react-router-dom';
// import { useQueryParams, NumberParam, StringParam, JsonParam, withDefault } from 'use-query-params';
import EditRoundedIcon from '@material-ui/icons/EditRounded';
import DeleteRoundedIcon from '@material-ui/icons/DeleteRounded';
import AirportShuttleRoundedIcon from '@material-ui/icons/AirportShuttleRounded';
import { makeStyles } from '@material-ui/core/styles';
import ErrorBoundary from '@/components/ErrorBoundary';
import InfoMessage from '@/components/InfoMessage';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import FcasbTable from '@/components/Table';
import { Button } from '@material-ui/core';
import { LabelRow } from '@/components/Common/form';
import { useDialog } from '../../hooks';
import { BaseDialog } from '@/components/Dialog';
import TaskDiaglog from '../TaskDiaglog';
import DeviceDialog from '../DeviceDialog';
import DeliverDialog from '../DeliverDialog';
import '../../../node_modules/bootstrap/dist/css/bootstrap.css';
import './aa.css';
import axios from 'axios';
import DeleteDialog from '../DeleteDialog';
import LongMenu from '@/components/LongMenu'

const useStyles = makeStyles({
  tableBox: {
    backgroundColor: '#fff',
  },
});
const token =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lc3RhbXAiOjE2MjE3MDIyNDksInVzZXIiOiJhZG1pbiJ9.bCjdoBbU0I4uH8fKsCsVqJZU-zDRlnNApnHSNRTgqjI';
const AppAlert = ({ metadata }) => {
  const classes = useStyles();

  // append actions
  const firstText = metadata.queryKey == 'qry_device' ? 'Edit Device' : 'Deliver Task';
  const secondText = metadata.queryKey == 'qry_device' ? 'Delete Device' : 'Delete Task';
  const action = {
    field: '',
    header: 'Action',
    sortable: false,
    render: ({ row }) => (<LongMenu firstAction={[firstText, () => firstAction(row)]} secondAction={[secondText, () => deleteCallback(row)]}></LongMenu>),
  }

  const editIcon = (row) => (<EditRoundedIcon
    style={{ cursor: 'pointer', marginRight: 10 }}
    onClick={() => {
      const curDevice = {};
      for (const [k, v] of Object.entries(metadata.formData)) {
        curDevice[k] = row[k];
      }
      setDid(row.id);
      setUpdateDeviceItem(curDevice);
      openUpdateDeviceDialog();
      console.log(row);
    }}
  />);

  const deliverIcon = (row) => (<AirportShuttleRoundedIcon
    style={{ cursor: 'pointer', marginRight: 10 }}
    onClick={() => {
      setTid(row.ticketid);
      setTaskid(row.id);
      setConfigfile(row.targetconfig);
      openDeliverDialog();
    }}
  />);

  const editCallback = (row) => {
    const curDevice = {};
    for (const [k, v] of Object.entries(metadata.formData)) {
      curDevice[k] = row[k];
    }
    setDid(row.id);
    setUpdateDeviceItem(curDevice);
    openUpdateDeviceDialog();
    console.log(row);
  }

  const deliverCallback = (row) => {
    setTid(row.ticketid);
    setTaskid(row.id);
    setConfigfile(row.targetconfig);
    openDeliverDialog();
  }

  const deleteCallback = (row) => {
    handleDeleteRow(row);
  }

  const deleteIcon = (row) => (<DeleteRoundedIcon style={{ cursor: 'pointer', marginRight: 10 }} onClick={() => handleDeleteRow(row)} />);
  const firstAction = metadata.queryKey == 'qry_device' ? editCallback : deliverCallback;
  const action1 = {
    field: '',
    header: 'Action',
    sortable: false,
    render: ({ row }) => (
      <>
        {metadata.queryKey == 'qry_device' ? (
          <EditRoundedIcon
            style={{ cursor: 'pointer' }}
            onClick={() => {
              const curDevice = {};
              for (const [k, v] of Object.entries(metadata.formData)) {
                curDevice[k] = row[k];
              }
              setDid(row.id);
              setUpdateDeviceItem(curDevice);
              openUpdateDeviceDialog();
              console.log(row);
            }}
          />
        ) : (
          <></>
        )}

        {metadata.queryKey == 'qry_task' ? (
          <>
            <AirportShuttleRoundedIcon
              style={{ cursor: 'pointer' }}
              onClick={() => {
                setTid(row.ticketid);
                setTaskid(row.id);
                setConfigfile(row.targetconfig);
                openDeliverDialog();
              }}
            />
          </>
        ) : (
          <></>
        )}

        <DeleteRoundedIcon style={{ cursor: 'pointer' }} onClick={() => handleDeleteRow(row)} />
      </>
    ),
  };
  useEffect(() => {
    if (metadata.queryKey == 'qry_device' || metadata.queryKey == 'qry_task')
      metadata.columns.splice(metadata.colCount, metadata.colCount, action);
  }, []);

  const [tid, setTid] = useState('');
  const [taskid, setTaskid] = useState('');
  const [comments, setComments] = useState('');
  const [did, setDid] = useState('');
  const [configfile, setConfigfile] = useState('');
  // metadata.columns.push(action);

  const fetchRuningTask = async () => {
    const res = await fetch(metadata.apiUrl, {
      method: 'get',
      headers: new Headers({
        Authorization: 'Bearer ' + token,
        'Content-Type': 'application/json',
      }),
    });
    const data = await res.json();
    data.sort((a, b) => (a.id > b.id ? 1 : -1));
    return data;
  };

  const handleDeleteRow = (row) => {
    const item = metadata.queryKey == 'qry_task' ? 'task' : 'device';
    setDeleteId(row.id);
    setDeleteTitle('Delete ' + item + ' ' + row.id);
    openDeleteDialog();
  };

  /* Data fetching & mutation */
  const queryClient = useQueryClient();
  const mutation = useMutation(
    async (n) => {
      await axios.post(metadata.apiUrl, n, {
        headers: {
          Authorization: 'Bearer ' + token,
          'Content-Type': 'application/json',
        },
      });
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries(metadata.queryKey);
      },
    },
  );
  const updateDeviceMutation = useMutation(
    async (n) => {
      await axios.put(metadata.apiUrl + '/' + did, n, {
        headers: {
          Authorization: 'Bearer ' + token,
          'Content-Type': 'application/json',
        },
      });
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries(metadata.queryKey);
      },
    },
  );

  const deleteMutatoin = useMutation(
    async () => {
      const api = metadata.queryKey == 'qry_task' ? 'api/tasks' : 'api/devices';
      await axios.delete(api + '/' + deleteId, {
        headers: {
          Authorization: 'Bearer ' + token,
          'Content-Type': 'application/json',
        },
      });
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries(metadata.queryKey);
      },
    },
  );

  const deliverMutation = useMutation(
    async (n) => {
      await axios.post('api/tickets' + '/' + tid, n, {
        headers: {
          Authorization: 'Bearer ' + token,
          'Content-Type': 'application/json',
        },
      });
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('qry_ticket');
      },
    },
  );
  const { isFetching, data, isLoading } = useQuery(metadata.queryKey, fetchRuningTask, {
    refetchInterval: 10000,
  });

  const [taskDiaglog, openTaskDiaglog, closeTaskDiaglog] = useDialog();
  const [deviceDialog, openDeviceDiaglog, closeDeviceDiaglog] = useDialog();
  const [updateDeviceDialog, openUpdateDeviceDialog, closeUpdateDeviceDialog] = useDialog();
  const [deliverDialog, openDeliverDialog, closeDeliverDialog] = useDialog();
  const [deleteDialog, openDeleteDialog, closeDeleteDialog] = useDialog();
  const [task, setTask] = useState();
  const [deleteTitle, setDeleteTitle] = useState('');
  const [deleteId, setDeleteId] = useState();

  const [modal, setModal] = useState(false);
  const [newItem, setNewItem] = useState({});
  const [newDeviceItem, setNewDeviceItem] = useState({});
  const [updateDeviceItem, setUpdateDeviceItem] = useState({});
  const [deliverItem, setDeliverItem] = useState({ status: '', comments: '' });

  const handleOpenNewTask = () => {
    //setTaskId({ id: 0 });
    setTask();
    openTaskDiaglog();
  };


  const handleCloseNewTask = () => {
    closeTaskDiaglog();
  };

  const handleSubmitTask = () => {

    if (metadata.queryKey == 'qry_device') {
      var copy = Object.assign({}, newDeviceItem);
      for (let [key, val] of Object.entries(copy)) {
        if (numlist.includes(key)) {
          copy[key] = parseInt(val);
        }
      }
      mutation.mutate(copy);
      console.log(copy);
    }
    if (metadata.queryKey == 'qry_task') {
      console.log(newItem);
      mutation.mutate(newItem);
    }
    closeTaskDiaglog();
    // submitTask(task);
  };

  const handleUpdateDevice = () => {
    if (metadata.queryKey == 'qry_device') {
      var copy = Object.assign({}, updateDeviceItem);
      for (let [key, val] of Object.entries(copy)) {
        if (numlist.includes(key)) {
          copy[key] = parseInt(val);
        }
      }

      updateDeviceMutation.mutate(copy);
      console.log(copy);
    }
    closeUpdateDeviceDialog();
  };

  const handleDeliverTask = () => {
    // useEffect(() => {
    //   // var copy = Object.assign({}, deliverItem);
    //   // copy["ticketid"] = tid;
    //   // copy["taskid"] = taskid;
    //   // // copy["comments"] = comments;
    //   // copy["configfile"] = configfile;
    //   // console.log("copy is", copy);
    //   // // deliverMutation.mutate(copy);
    //   // // closeDeliverDialog();
    // }, [deliverItem]);
    var copy = Object.assign({}, deliverItem);
    copy['ticketid'] = tid;
    copy['taskid'] = taskid;
    copy['configfile'] = configfile;
    console.log('copy is', copy);
    deliverMutation.mutate(copy);
    closeDeliverDialog();
  };

  const deleteTask = async (id) => {
    const res = await fetch(metadata.apiUrl + '/' + id, {
      method: 'delete',
      headers: new Headers({
        Authorization: 'Bearer ' + token,
        'Content-Type': 'application/json',
      }),
    });

    return res.json();
  };

  const onClickDelete = (e) => {
    console.log('index.jsx delete id ' + e.id);
    deleteTask(e.id);
  };

  const onClickEdit = (e) => {
    openTaskDiaglog();
    console.log('index.jsx edit id ' + e.id);
  };

  const [show, setShow] = useState({ display: 'none' });

  const skipList = ['deviceid', 'deviceuuid'];
  const numlist = ['mgmt_port', 'telnet_port', 'tftp_port', 'line'];
  const showSelected = metadata.queryKey === 'qry_task' ? '' : 'none';
  return (
    <ErrorBoundary>
      <p style={show}>
        <InfoMessage
          setShow={setShow}
          onClose
          severity="info"
          content={
            <div style={{ position: 'relative', top: '12%' }}>You have 4 notifications!!!</div>
          }
        />
      </p>
      {metadata.formData ? (
        <p align="right">
          <Button color="primary" variant="contained" onClick={handleOpenNewTask}>
            {'+ ADD NEW'}
          </Button>
        </p>
      ) : null}
      <BaseDialog
        title={
          <LabelRow style={{ fontWeight: 'bold' }}>
            {metadata.queryKey == 'qry_task' ? 'New Task' : 'New Device'}
          </LabelRow>
        }
        fullWidth
        visible={taskDiaglog}
        content={
          metadata.queryKey == 'qry_task' ? (
            <TaskDiaglog
              // deviceListRes={deviceListRes}
              setNewItem={setNewItem}
              newItem={newItem}
              task={task}
            />
          ) : (
            <DeviceDialog
              setNewItem={setNewDeviceItem}
              newItem={newDeviceItem}
              formData={metadata.formData}
            />
          )
        }
        footer={
          <>
            <Button
              color="primary"
              variant="contained"
              size="medium"
              onClick={handleSubmitTask}
              style={{ fontSize: '14px' }}
            >
              {metadata.queryKey == 'qry_task' ? 'Add new task' : 'Add new device'}
            </Button>
            <Button
              size="medium"
              onClick={handleCloseNewTask}
              style={{ marginLeft: 16, fontSize: '14px' }}
            >
              Cancel
            </Button>
          </>
        }
      />

      {/* Update device */}
      <BaseDialog
        title={<LabelRow style={{ fontWeight: 'bold' }}>{'Update device ' + did}</LabelRow>}
        fullWidth
        visible={updateDeviceDialog}
        content={
          <DeviceDialog
            setNewItem={setUpdateDeviceItem}
            newItem={updateDeviceItem}
            did={did}
            formData={metadata.formData}
          />
        }
        footer={
          <>
            <Button
              color="primary"
              variant="contained"
              size="medium"
              onClick={handleUpdateDevice}
              style={{ fontSize: '14px' }}
            >
              Update device
            </Button>
            <Button
              size="medium"
              onClick={closeUpdateDeviceDialog}
              style={{ marginLeft: 16, fontSize: '14px' }}
            >
              Cancel
            </Button>
          </>
        }
      />

      <BaseDialog
        title={
          <LabelRow style={{ fontWeight: 'bold' }}>
            {metadata.queryKey == 'qry_task' ? 'New Task' : 'New Device'}
          </LabelRow>
        }
        fullWidth
        visible={deviceDialog}
        content={
          <DeviceDialog
            setNewItem={setNewDeviceItem}
            newItem={newDeviceItem}
            formData={metadata.formData}
          />
        }
        footer={
          <>
            <Button
              color="primary"
              variant="contained"
              size="medium"
              onClick={handleSubmitTask}
              style={{ fontSize: '14px' }}
            >
              Add new device
            </Button>
            <Button
              size="medium"
              onClick={closeDeviceDiaglog}
              style={{ marginLeft: 16, fontSize: '14px' }}
            >
              Cancel
            </Button>
          </>
        }
      />
      <BaseDialog
        title={
          <LabelRow style={{ fontWeight: 'bold' }}>{'Deliver to Service Ticket ' + tid}</LabelRow>
        }
        fullWidth
        visible={deliverDialog}
        content={
          <DeliverDialog
            setComments={setComments}
            setNewItem={setDeliverItem}
            newItem={deliverItem}
            deviceconfig={configfile}
          />
        }
        footer={
          <>
            <Button
              color="primary"
              variant="contained"
              size="medium"
              onClick={handleDeliverTask}
              style={{ fontSize: '14px' }}
            >
              Deliver task
            </Button>
            <Button
              size="medium"
              onClick={closeDeliverDialog}
              style={{ marginLeft: 16, fontSize: '14px' }}
            >
              Cancel
            </Button>
          </>
        }
      />

      <BaseDialog
        title={<LabelRow style={{ fontWeight: 'bold' }}>{deleteTitle}</LabelRow>}
        fullWidth
        visible={deleteDialog}
        content={<DeleteDialog msg={'Are you true you want to ' + deleteTitle.toLowerCase()} />}
        footer={
          <>
            <Button
              color="secondary"
              variant="contained"
              size="medium"
              onClick={() => {
                deleteMutatoin.mutate();
                closeDeleteDialog();
              }}
              style={{ fontSize: '14px' }}
            >
              Delete
            </Button>
            <Button
              size="medium"
              onClick={closeDeleteDialog}
              style={{ marginLeft: 16, fontSize: '14px' }}
            >
              Cancel
            </Button>
          </>
        }
      />
      <div className={classes.tableBox} style={{ padding: `${35}px` }}>
        <FcasbTable
          loading={isFetching}
          rowKey={metadata.rowKey}
          columns={metadata.columns}
          // columns={copyColumns}
          rows={data ?? []}
          sort={{
            asc: true,
            desc: false,
            onSortChange: (asc) => { },
          }}
          pagination={{
            total: data?.length ?? 0,
            enableQuery: true,
          }}
          rowOperations={{
            onClickDelete: onClickDelete,
            onClickEdit: onClickEdit,
          }}
        />
      </div>
    </ErrorBoundary>
  );
};
export default AppAlert;
