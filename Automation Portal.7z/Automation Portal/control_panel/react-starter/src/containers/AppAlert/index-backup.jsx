import React, { useState, useMemo } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { useQueryParams, NumberParam, StringParam, JsonParam, withDefault } from 'use-query-params';
import { makeStyles } from '@material-ui/core/styles';
import ErrorBoundary from '@/components/ErrorBoundary';
import { useQuery } from 'react-query';
import FcasbTable from '@/components/Table';
import searchFilterGenerator, {
  makeMultiInput,
  makeFilter,
  noteComponent,
} from '@/components/Filter/searchFilterGenerator';
import {
  getAppAlertListApi,
  getRunningTasksListApi,
  getActivityListApi,
} from '@/services/alert/api';
import { useAppFilterList, useFilterActivityList } from '@/services/filter/query';
import { DEFAULT_PAGE_SIZE } from '@/constants/';
import { updateTimeValue, TimeRangeDropdown } from '@/components/TimeRange';
import { SelectMulti } from '@/components/Filter/SelectForm';
import makeQueryFilter from '@/utils/makeQueryFilter';

import { AlertTypeList, checkFilterName } from './filterConfig';
import { getRunningTasksList } from '../../services/filter/query';
import { Button } from '@material-ui/core';
import '../../../node_modules/bootstrap/dist/css/bootstrap.css';
import './aa.css';

const queryToParams = (filter = {}) => {
  const { timeRange, ...rest } = filter;
  return {
    ...rest,
    startTime: timeRange?.startTime,
    endTime: timeRange?.endTime,
  };
};

const useStyles = makeStyles({
  tableBox: {
    backgroundColor: '#fff',
  },
});

const columns = [
  { field: 'task_id', header: 'Task ID', sortable: true },
  { field: 'ticket_num', header: 'Ticket Number', sortable: true },
  { field: 'device_sn', header: 'Device SN', sortable: true },
  { field: 'worker_id', header: 'Worker ID', sortable: true },
  { field: 'assigned_to', header: 'Assigned To', sortable: true },
  { field: 'status', header: 'Status', sortable: true },
];

const AppAlert = () => {
  const classes = useStyles();
  const { appKey } = useParams();
  const [selected, setSelected] = useState([]);
  const [expanded, setExpand] = useState([]);

  // const { data: filterList } = useAppFilterList(appKey, 'alert');
  // const { data: activityList } = useFilterActivityList(appKey);
  // const data = getRunningTasksList();

  // const [query, setQuery] = useQueryParams({
  //   skip: withDefault(NumberParam, 0),
  //   limit: withDefault(NumberParam, DEFAULT_PAGE_SIZE),
  //   asc: StringParam,
  //   desc: StringParam,
  //   filter: JsonParam,
  // });

  // const { filter, ...pageQuery } = query;
  // const apiParams = {
  //   service: appKey,
  //   ...pageQuery,
  //   ...queryToParams(filter),
  // };

  // const { isFetching, data } = useQuery({
  //   queryKey: ['RuningTasksList'],
  //   queryFn: () => getRunningTasksListApi("haha"),
  //   keepPreviousData: true,
  // });

  const fetchRuningTask = async () => {
    const res = await fetch('http://localhost:8111/tasks/running');
    return res.json();
  };

  // const { isFetching, data, isLoading} = useQuery('RuningTasksList', () => {
  //   // alert('api called');
  //   axios.get('http://localhost:8111/tasks/running', {
  //     headers: {
  //       // service: "hahaha",
  //       // "Access-Control-Allow-Headers": "timeZone,Access-Control-Allow-Origin, Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers",
  //       // "Access-Control-Allow-Origin": "*",
  //     },
  //   });
  // });
  const { isFetching, data, isLoading } = useQuery('RuningTasksList', fetchRuningTask);
  console.log('isLoading: ', isLoading);
  console.log('Data:         ', data?.length);

  const onFilterSearch = (filterData) => {
    const newFilterUrl = { ...filter };
    newFilterUrl.alertType = filterData['Alert Type']?.map((item) => item.name);

    newFilterUrl.timeRange = filterData['Time Range']
      ? {
          key: filterData['Time Range'].key,
          startTime: filterData['Time Range'].startTime,
          endTime: filterData['Time Range'].endTime,
        }
      : undefined;
    newFilterUrl.activity = filterData['Activity']?.map((item) => item.id);
    // setQuery({
    //   skip: 0,
    //   filter: newFilterUrl,
    // });
  };

  // const Filter = useMemo(
  //   () =>
  //     searchFilterGenerator(
  //       {
  //         'Alert ID': {
  //           component: makeMultiInput(noteComponent('Id')),
  //         },
  //         'Time Range': { component: TimeRangeDropdown },
  //         'Object Name': {},
  //         'Alert Type': {
  //           component: makeFilter(AlertTypeList),
  //         },
  //         Activity: {
  //           component: makeQueryFilter(() => useFilterActivityList(appKey), SelectMulti, {
  //             groupBy: 'category',
  //           }),
  //         },
  //       },
  //       {
  //         showSaveLabel: true,
  //       },
  //     ),
  //   [appKey],
  // );

  // conver query-params to filter initData
  // const filterInitData = useMemo(() => {
  //   const initData = {};
  //   if (filter?.alertType) {
  //     initData['Alert Type'] = AlertTypeList.filter((item) => filter.alertType.includes(item.name));
  //   }
  //   if (filter?.timeRange) {
  //     initData['Time Range'] = updateTimeValue(filter.timeRange);
  //   }
  //   if (filter?.activity) {
  //     initData['Activity'] = activityList?.filter((item) => filter?.activity.includes(item.id));
  //   }
  //   return initData;
  // }, [filter, data]);

  const [modalInputName, setModalInputName] = useState('');
  const [modal, setModal] = useState(false);
  const [state, setState] = useState({
    firstName: '',
    lastName: '',
  });

  const handleChange = (e) => {
    const value = e.target.value;
    setState({
      ...state,
      [e.target.name]: value,
    });
  };

  const handleSubmit = (e) => {
    // this.setState({ name: this.state.modalInputName });
    alert(JSON.stringify(state));
    // modalClose();
  };

  const modalOpen = () => {
    setModal(true);
  };

  const modalClose = () => {
    setModalInputName('');
    setModal(false);
  };

  return (
    <ErrorBoundary>
      {/* <Filter
        initData={filterInitData}
        onSubmit={onFilterSearch}
        onSave={(filterObj, filterName) => console.info(filterObj, filterName)}
        checkFilterName={checkFilterName(filterList)}
        filterList={filterList}
      /> */}

      <div className={classes.tableBox}>
        <p align="right">
          <Button color="secondary" variant="outlined" onClick={(e) => modalOpen(e)}>
            New Task
          </Button>
        </p>
        <Modal show={modal} handleClose={(e) => modalClose(e)}>
          <h2>Hello Modal</h2>
          <div className="form-group">
            {Object.entries(state).map(([key, value]) => (
              <div>
                <label>Enter {key}:</label>
                <input
                  type="text"
                  value={state[key]}
                  name={key}
                  onChange={(e) => handleChange(e)}
                  className="form-control"
                />
              </div>
            ))}
            {/* <label>Enter Name:</label>
            <input
              type="text"
              value={modalInputName}
              name="modalInputName"
              onChange={e => handleChange(e)}
              className="form-control"
            /> */}
          </div>
          <div className="form-group">
            <Button color="secondary" variant="contained" onClick={(e) => handleSubmit(e)}>
              Save
            </Button>
          </div>
        </Modal>
        <FcasbTable
          loading={isFetching}
          rowKey="task_id"
          columns={columns}
          rows={data ?? []}
          pagination={{
            // total: data?.totalCount ?? 0,
            total: data?.length ?? 0,
            enableQuery: true,
          }}
          // sort={{
          //   asc: pageQuery.asc,
          //   desc: pageQuery.desc,
          //   onSortChange: ({ asc, desc }) => setQuery({ asc, desc }),
          // }}

          // expandable={{
          //   type: 'left',
          //   expandedRowKeys: expanded,
          //   expandComponent: ({ row }) => row.object,
          //   onChange: (expandedKeys) => setExpand(expandedKeys),
          // }}

          rowSelection={{
            selectedKeys: selected,
            onChange: (selectedKeys) => setSelected(selectedKeys),
          }}
        />
      </div>
    </ErrorBoundary>
  );
};

const Modal = ({ handleClose, show, children }) => {
  const showHideClassName = show ? 'modal d-block' : 'modal d-none';

  return (
    <div className={showHideClassName}>
      <div className="modal-container">
        {children}
        <a className="modal-close" onClick={handleClose}>
          close
        </a>
      </div>
    </div>
  );
};

export default AppAlert;
