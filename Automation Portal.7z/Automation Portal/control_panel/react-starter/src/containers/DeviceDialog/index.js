import React, { forwardRef, useImperativeHandle, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import Collapse from '@material-ui/core/Collapse';
import FileCopyIcon from '@material-ui/icons/FileCopy';
import WarningIcon from '@material-ui/icons/Warning';
import {
  FormUnit,
  LabelRow,
  LabelText,
  Required,
  StyledFormControl,
  StyledOutlinedInput,
  StyledSelect,
  OutlinedInputForSelect,
  StyledOutlinedToken,
  StyledHelperText,
} from '../../components/Common/form';
import { MenuItem } from '@material-ui/core';

import { fetchList } from '../App/constants';

const DeviceDialog = forwardRef((props, ref) => {
  const { task, newItem, setNewItem, formData } = props;
  const handleChange = (e) => {
    setNewItem({
      ...newItem,
      [e.target.name]: e.target.value,
    });
  };
  return (
    <>
      {task ? (
        <FormUnit>
          <LabelRow>
            <LabelText>Edit exist task</LabelText>
          </LabelRow>
        </FormUnit>
      ) : (
        Object.entries(formData ?? {}).map(([key, val]) => {
          return (
            <FormUnit>
              <LabelRow>
                <LabelText>
                  {val[0]} <Required />
                </LabelText>
              </LabelRow>
              <StyledFormControl>
                <StyledOutlinedInput
                  id={key}
                  name={key}
                  value={newItem[key]}
                  onChange={handleChange}
                />
              </StyledFormControl>
            </FormUnit>
          );
        })
      )}
    </>
  );
});

export default DeviceDialog;
