import React from 'react';

export default function Loading() {
  return <div>this is loading</div>;
}
