import React, { forwardRef, useImperativeHandle, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import Collapse from '@material-ui/core/Collapse';
import FileCopyIcon from '@material-ui/icons/FileCopy';
import WarningIcon from '@material-ui/icons/Warning';
import {
  FormUnit,
  LabelRow,
  LabelText,
  Required,
  StyledFormControl,
  StyledOutlinedInput,
  StyledSelect,
  OutlinedInputForSelect,
  StyledOutlinedToken,
  StyledHelperText,
} from '../../components/Common/form';
import { MenuItem } from '@material-ui/core';

import { fetchList } from '../App/constants';

const TaskDiaglog = forwardRef((props, ref) => {
  const { task, newItem, setNewItem } = props;
  const deviceListRes = useQuery('deviceList123', fetchList('api/devices?status=Idling'), {
    refetchInterval: 5000,
  });
  const ticketListRes = useQuery('ticketList123', fetchList('api/tickets?status=New'), {
    refetchInterval: 5000,
  });
  // console.log("deviceListRes fetching: " + deviceListRes.data);
  const [device, setDevice] = useState('');
  const [ticket, setTicket] = useState('');
  const handleChange = (type) => {
    return (e) => {
      if (type == 'device') {
        const values = e.target.value.split('::');
        setNewItem({
          ...newItem,
          ['deviceid']: parseInt(values[1]),
          ['deviceuuid']: values[2],
        });
        setDevice(e.target.value);
      } else if (type == 'ticket') {
        const values = e.target.value.split('::');
        setNewItem({
          ...newItem,
          ['ticketid']: parseInt(values[0]),
        });
        setTicket(e.target.value);
      } else {
        setNewItem({
          ...newItem,
          [e.target.name]: e.target.value,
        });
      }
    };
  };
  return (
    <>
      {task ? (
        <FormUnit>
          <LabelRow>
            <LabelText>Edit exist task</LabelText>
          </LabelRow>
        </FormUnit>
      ) : (
        <>
          <FormUnit>
            <LabelRow>
              <LabelText>
                Task Name <Required />
              </LabelText>
            </LabelRow>
            <StyledFormControl>
              <StyledOutlinedInput
                id="taskName"
                name="name"
                value={newItem['name']}
                onChange={handleChange('other')}
              />
            </StyledFormControl>
          </FormUnit>
          <FormUnit>
            <LabelRow>
              <LabelText>
                Ticket Number <Required />
              </LabelText>
            </LabelRow>
            <StyledFormControl>
              <StyledSelect value={ticket} onChange={handleChange('ticket')}>
                {(ticketListRes.data ?? []).map((item) => {
                  const value = item.id + '::' + item.subject;
                  return <MenuItem value={value}> {item.id} </MenuItem>;
                })}
              </StyledSelect>
            </StyledFormControl>
          </FormUnit>
          <FormUnit>
            <LabelRow>
              <LabelText>
                Device Name <Required />
              </LabelText>
            </LabelRow>
            <StyledFormControl>
              <StyledSelect value={device} onChange={handleChange('device')}>
                {(deviceListRes.data ?? []).map((item) => {
                  const value = item.name + '::' + item.id + '::' + item.uuid;
                  return <MenuItem value={value}> {item.name} </MenuItem>;
                })}
              </StyledSelect>
            </StyledFormControl>
          </FormUnit>
          <FormUnit>
            <LabelRow>
              <LabelText>
                Device Access <Required />
              </LabelText>
            </LabelRow>
            <StyledFormControl>
              <StyledOutlinedInput id="deviceInfo" name="note" value={'https://10.160.15.112'} />
            </StyledFormControl>
          </FormUnit>
        </>
      )}
    </>
  );
});

export default TaskDiaglog;
