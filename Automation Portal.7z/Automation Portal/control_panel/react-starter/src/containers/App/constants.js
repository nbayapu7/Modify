import React, { Suspense, lazy, useState } from 'react';
import EditRoundedIcon from '@material-ui/icons/EditRounded';
import DeleteRoundedIcon from '@material-ui/icons/DeleteRounded';
import Box from "@material-ui/core/Box";
import { palette } from '@material-ui/system';
import DynamicFont from 'react-dynamic-font';
import { Link } from '@material-ui/core';
import Moment from 'react-moment';
import 'moment-timezone';
import styled from 'styled-components';
import getImage from '../../components/iconLibrary';

Moment.globalFormat = 'MM/DD/YYYY hh:mm:ss z';

const StatusIcon = styled.div`
  display: flex;
  align-items: center;
  & > img {
    width: 12px;
    height: 12px;
    margin-right: 8px;
  }
`;

export const TASK_METADATA = {
  columns: [
    { field: 'id', header: 'ID', sortable: true },
    { field: 'name', header: 'Name', sortable: true },
    {
      field: 'ticketid',
      header: 'Ticket',
      sortable: true,
      render: ({ row }) => (
        <Link component="button" variant="body2">
          {' '}
          {row.ticketid}{' '}
        </Link>
      ),
    },
    { field: 'sourcemodel', header: 'Source Model', sortable: true },
    { field: 'devicename', header: 'Device', sortable: true },
    {
      field: 'targetconfig',
      header: 'Config',
      sortable: true,
      render: ({ row }) => (
        <Link>
          {' '}
          {row.targetconfig}{' '}
        </Link>
      ),
    },
    {
      field: 'status',
      header: 'Status',
      // style: { width: 240 },
      sortable: true,
      render: ({ row }) => {
        const iconKey = row.status.includes('Failed')
          ? 'error.contrastText'
          : row.status.includes('Service Delivered')
            ? 'success.contrastText'
            : 'warning.contrastText';
        const bgColor = row.status.includes('Failed')
          ? 'error.main'
          : row.status.includes('Service Delivered')
            ? 'success.main'
            : 'warning.main';
        return (
          <StatusIcon>
            {/* {getImage(iconKey)} */}
            {/* {row.status} */}
            <Box borderRadius={5} bgcolor="primary.main" bgcolor={bgColor} color={iconKey} p={1}>
              <DynamicFont content={row.status} />
            </Box>
          </StatusIcon>
        );
      },
    },
    {
      field: 'updated_at',
      header: 'Last Updated',
      sortable: true,
      render: ({ row }) => (
        <Moment unix tz="America/Los_Angeles">
          {parseInt(row.updated_at) / 1000}
        </Moment>
      ),
    },
  ],
  colCount: 9,
  rowKey: 'id',
  queryKey: 'qry_task',
  formData: {
    ticket_num: '',
    device_sn: '',
    worker_id: '',
    assigned_to: '',
  },
  apiUrl: 'api/tasks',
};

export const TICKET_MATADATA = {
  columns: [
    { field: 'id', header: 'ID', sortable: true, style: { width: 120 } },
    { field: 'subject', header: 'Subject', sortable: true },
    {
      field: 'version',
      header: 'Version',
      sortable: true,
      render: ({ row }) => <>{row.version + '.' + row.patch}</>,
    },
    { field: 'sourcemodel', header: 'Source Model', sortable: true },
    { field: 'targetmodel', header: 'Target Model', sortable: true },
    {
      field: 'sourceconfig',
      header: 'Source config',
      sortable: true,
      render: ({ row }) => (
        // <Link style={{align: 'left'}} component="button" variant="body2">
        <Link>
          {' '}
          {row.sourceconfig}{' '}
        </Link>
      ),
    },
    {
      field: 'status',
      header: 'Status',
      style: { flex: 1 },
      sortable: true,
      render: ({ row }) => {
        const iconKey = row.status.includes('New')
          ? 'secondary.contrastText'
          : row.status.includes('Service Delivered')
            ? 'success.contrastText'
            : 'warning.contrastText';
        const bgColor = row.status.includes('New')
          ? 'info.main'
          : row.status.includes('Service Delivered')
            ? 'success.main'
            : 'warning.main';
        return (
          <StatusIcon>
            {/* {getImage(iconKey)} */}
            {/* {row.status} */}
            <Box borderRadius={5} bgcolor="primary.main" bgcolor={bgColor} color={iconKey} p={1}>
              <DynamicFont content={row.status} />
            </Box>
          </StatusIcon>
        );
      },
    },
    {
      field: 'created',
      header: 'Created At',
      sortable: true,
      render: ({ row }) => (
        <Moment unix tz="America/Los_Angeles">
          {parseInt(row.created) / 1000}
        </Moment>
      ),
    },
    {
      field: 'updated',
      header: 'Updated At',
      sortable: true,
      render: ({ row }) => (
        <Moment unix tz="America/Los_Angeles">
          {parseInt(row.updated) / 1000}
        </Moment>
      ),
    },
  ],
  rowKey: 'id',
  queryKey: 'qry_ticket',
  apiUrl: 'api/tickets',
};

export const DEVICE_METADATA = {
  columns: [
    { field: 'id', header: 'ID', sortable: true },
    { field: 'name', header: 'Name', sortable: true },
    { field: 'model', header: 'Model', sortable: true },
    { field: 'sn', header: 'Serial Number', sortable: true },
    { field: 'mgmt_ip', header: 'Mgmt IP', sortable: true },
    {
      field: 'mgmt_port',
      header: 'Ports',
      sortable: false,
      render: ({ row }) => {
        return row.mgmt_port + '|' + row.telnet_port + '|' + row.tftp_port;
      },
    },
    { field: 'username', header: 'Username', sortable: true },
    { field: 'lab', header: 'Lab', sortable: true },
    {
      field: 'status',
      header: 'Status',
      sortable: true,
      render: ({ row }) => (
        <StatusIcon>
          {getImage(row.status)}
          {row.status[0].toUpperCase() + row.status.slice(1).toLowerCase()}
        </StatusIcon>
      ),
    },
  ],
  colCount: 9,
  rowKey: 'id',
  queryKey: 'qry_device',
  formData: {
    name: ['Device Name', ''],
    model: ['Model', ''],
    mgmt_ip: ['Management IP', ''],
    mgmt_port: ['Management Port', ''],
    telnet_port: ['Telnet Port', ''],
    tftp_port: ['TFTP Port', ''],
    line: ['Line', ''],
    lab: ['Lab', ''],
  },
  apiUrl: 'api/devices',
};
const token =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0aW1lc3RhbXAiOjE2MjE3MDIyNDksInVzZXIiOiJhZG1pbiJ9.bCjdoBbU0I4uH8fKsCsVqJZU-zDRlnNApnHSNRTgqjI';
export const fetchList = (url) => {
  return async () => {
    const res = await fetch(url, {
      method: 'get',
      headers: new Headers({
        Authorization: 'Bearer ' + token,
        'Content-Type': 'application/json',
      }),
    });
    return res.json();
  };
};

export const ARROW_SVG =
  "data:image/svg+xml,%3C?xml version='1.0' encoding='utf-8'?%3E %3C!-- Generator: Adobe Illustrator 25.0.1, SVG Export Plug-In . SVG Version: 6.00 Build 0) --%3E %3Csvg version='1.1' id='Layer_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 100 100' style='enable-background:new 0 0 100 100;' xml:space='preserve'%3E %3Cpolygon points='49,75 89.3,35 8.7,35 '/%3E %3C/svg%3E";

