import React, { Suspense, lazy, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import { Switch, Route, Redirect } from 'react-router-dom';
import { SideMenu } from '@/layouts';
import styled from 'styled-components';
import { Dropdown } from 'react-bootstrap';
import { TASK_METADATA, TICKET_MATADATA, DEVICE_METADATA, ARROW_SVG } from './constants';
import useToken from '../Login/useToken';
import Login from '../Login/login.component';
import './app.css';

const useStyles = makeStyles({
  body: {
    height: '100vh',
    display: 'flex',
    flexDirection: 'column',
  },
  topbar: {
    flex: '0 0 50px',
    width: '100%',
    background: 'white',
  },
  area: {
    flex: 1,
    width: '100%',
    display: 'flex',
    flexGrow: 1,
    overflow: 'hidden',
    '&.column': {
      flexDirection: 'column',
    },
  },
  bar: {
    flex: '0 0 50px',
    width: '100%',
    background: 'yellow',
  },

  menu: {
    flex: '0 0 200px',
    overflowY: 'auto',
    /* Hide scrollbar for Chrome, Safari and Opera */
    '&::-webkit-scrollbar': {
      display: 'none',
    },
    scrollbarWidth: 'none' /* Firefox */,
  },
  content: {
    flex: 1,
    background: '#F1F1F1',
    overflow: 'auto',
    padding: 16,
  },
});

const StatusIcon = styled.div`
  display: flex;
  align-items: center;
  & > img {
    width: 12px;
    height: 12px;
    margin-right: 8px;
  }
`;

/* Basic page
   https://webpack.js.org/guides/code-splitting/#prefetchingpreloading-modules
   (need to be preload/prefetch), please use inline magic comments
*/
const Loading = lazy(() => import(/* webpackPrefetch: true */ '@/containers/Loading'));
const ErrorPage = lazy(() => import(/* webpackPrefetch: true */ '@/containers/ErrorPage'));

// Page containers
const AppAlert = lazy(() => import('@/containers/AppAlert'));

const App = () => {
  const classes = useStyles();
  const [breadText, setBreadText] = useState('Tasks');

  const { token, setToken } = useToken();
  // if (!token[0]) {
  //   return <Login setToken={setToken} />;
  // }

  return (
    <div className={classes.body}>
      <div className={classes.topbar + ' eXyJQF_topbar'}>
        <div className="left-box" style={{ width: `${200}px` }}>
          <img className="fortinet-bar-logo" src={require('./ficon.png')} />
        </div>
        <DropDownText email={token[1]} />
      </div>

      <div className="hydCZI">
        <div className="egxBzc">
          <div className="productText">
            <div style={{ lineHeight: `${16}px`, fontSize: `${16}px`, marginBottom: `${4}px` }}>
              FortiConverter
            </div>
            <div style={{ lineHeight: `${12}px`, fontSize: `${12}px`, fontWeight: 300 }}>
              Version 0.1
            </div>
          </div>
        </div>
        <div className="breadOuter">
          <div style={{ color: 'white', display: 'inline-block' }}>
            <div className="eCYgOy">Automation</div>
            &gt; &nbsp;
          </div>
          <div style={{ color: 'white', display: 'inline-block' }}>
            <div className="eCYgOy">{breadText}</div>
            &nbsp;
          </div>
        </div>
      </div>

      <div className={`${classes.area} column`}>
        <div className={classes.area}>
          <SideMenu updateBreadText={setBreadText} />
          <Suspense fallback={<div>Loading Page...</div>}>
            <Container maxWidth={false} disableGutters className={classes.content}>
              <Switch>
                <Route path="/" render={() => <Redirect to="/tasks" />} exact />
                <Route
                  path="/tasks"
                  component={() => <AppAlert metadata={TASK_METADATA} />}
                  exact
                />
                <Route
                  path="/tickets"
                  component={() => <AppAlert metadata={TICKET_MATADATA} />}
                  exact
                />
                <Route
                  path="/devices"
                  component={() => <AppAlert metadata={DEVICE_METADATA} />}
                  exact
                />
                <Route path="*" component={ErrorPage} />
                <Route component={Loading} />
                {/* <Redirect to="/app" /> */}
              </Switch>
            </Container>
          </Suspense>
        </div>
        {/* <Footer /> */}
      </div>
    </div>
  );
};

const DropDownText = ({ email }) => {
  const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
    <div
      ref={ref}
      onClick={(e) => {
        e.preventDefault();
        onClick(e);
      }}
    >
      <div className="topbar-label" style={{ fontSize: `${12}px` }}>
        {email}
      </div>
      <img className="arrow" src={ARROW_SVG} />
      {/* {children} */}
    </div>
  ));

  // forwardRef again here!
  // Dropdown needs access to the DOM of the Menu to measure it
  const CustomMenu = React.forwardRef(
    ({ children, style, className, 'aria-labelledby': labeledBy }, ref) => {
      const [value, setValue] = useState('');

      return (
        <div ref={ref} style={style} className={className} aria-labelledby={labeledBy}>
          <ul className="list-unstyled">
            {React.Children.toArray(children).filter(
              (child) => !value || child.props.children.toLowerCase().startsWith(value),
            )}
          </ul>
        </div>
      );
    },
  );

  return (
    <div className="right-box with-dropdown-box">
      <Dropdown>
        <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components">
          {' '}
        </Dropdown.Toggle>
        <Dropdown.Menu as={CustomMenu}>
          <Dropdown.Item eventKey="1">My Profile</Dropdown.Item>
          <Dropdown.Item eventKey="2">Security Credentials</Dropdown.Item>
          <Dropdown.Item eventKey="3">Notifications</Dropdown.Item>
          <Dropdown.Item
            onClick={() => {
              sessionStorage.clear();
              window.location.reload();
            }}
            eventKey="4"
          >
            Logout
          </Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
};

export default App;
