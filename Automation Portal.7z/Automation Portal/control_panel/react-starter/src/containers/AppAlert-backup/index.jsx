import React, { useState, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import { useQueryParams, NumberParam, StringParam, JsonParam, withDefault } from 'use-query-params';
import { makeStyles } from '@material-ui/core/styles';
import ErrorBoundary from '@/components/ErrorBoundary';
import { useQuery } from 'react-query';
import FcasbTable from '@/components/Table';
import searchFilterGenerator, {
  makeMultiInput,
  makeFilter,
  noteComponent,
} from '@/components/Filter/searchFilterGenerator';
import { getAppAlertListApi } from '@/services/alert/api';
import { useAppFilterList, useFilterActivityList } from '@/services/filter/query';
import { DEFAULT_PAGE_SIZE } from '@/constants/';
import { updateTimeValue, TimeRangeDropdown } from '@/components/TimeRange';
import { SelectMulti } from '@/components/Filter/SelectForm';
import makeQueryFilter from '@/utils/makeQueryFilter';

import { AlertTypeList, checkFilterName } from './filterConfig';

const queryToParams = (filter = {}) => {
  const { timeRange, ...rest } = filter;
  return {
    ...rest,
    startTime: timeRange?.startTime,
    endTime: timeRange?.endTime,
  };
};

const useStyles = makeStyles({
  tableBox: {
    backgroundColor: '#fff',
  },
});

const columns = [
  {
    field: 'alertType',
    header: 'Alert Type',
  },
  {
    field: 'policyName',
    header: 'Policy Name',
    sortable: true,
  },
  {
    field: 'object',
    header: 'Object',
  },
  { field: 'severity', header: 'Severity', sortable: true },
  { field: 'createTime', header: 'Created', sortable: true },
  { field: 'updateTime', header: 'Last Update', sortable: true },
];

const AppAlert = () => {
  const classes = useStyles();
  const { appKey } = useParams();
  const [selected, setSelected] = useState([]);
  const [expanded, setExpand] = useState([]);

  const { data: filterList } = useAppFilterList(appKey, 'alert');
  const { data: activityList } = useFilterActivityList(appKey);

  const [query, setQuery] = useQueryParams({
    skip: withDefault(NumberParam, 0),
    limit: withDefault(NumberParam, DEFAULT_PAGE_SIZE),
    asc: StringParam,
    desc: StringParam,
    filter: JsonParam,
  });
  const { filter, ...pageQuery } = query;
  const apiParams = {
    service: appKey,
    ...pageQuery,
    ...queryToParams(filter),
  };
  const { isFetching, data } = useQuery({
    queryKey: ['AppAlertList', apiParams],
    queryFn: () => getAppAlertListApi(apiParams),
    keepPreviousData: true,
  });

  const onFilterSearch = (filterData) => {
    const newFilterUrl = { ...filter };
    newFilterUrl.alertType = filterData['Alert Type']?.map((item) => item.name);

    newFilterUrl.timeRange = filterData['Time Range']
      ? {
          key: filterData['Time Range'].key,
          startTime: filterData['Time Range'].startTime,
          endTime: filterData['Time Range'].endTime,
        }
      : undefined;
    newFilterUrl.activity = filterData['Activity']?.map((item) => item.id);
    setQuery({
      skip: 0,
      filter: newFilterUrl,
    });
  };

  const Filter = useMemo(
    () =>
      searchFilterGenerator(
        {
          'Alert ID': {
            component: makeMultiInput(noteComponent('Id')),
          },
          'Time Range': { component: TimeRangeDropdown },
          'Object Name': {},
          'Alert Type': {
            component: makeFilter(AlertTypeList),
          },
          Activity: {
            component: makeQueryFilter(() => useFilterActivityList(appKey), SelectMulti, {
              groupBy: 'category',
            }),
          },
        },
        {
          showSaveLabel: true,
        },
      ),
    [appKey],
  );

  // conver query-params to filter initData
  const filterInitData = useMemo(() => {
    const initData = {};
    if (filter?.alertType) {
      initData['Alert Type'] = AlertTypeList.filter((item) => filter.alertType.includes(item.name));
    }
    if (filter?.timeRange) {
      initData['Time Range'] = updateTimeValue(filter.timeRange);
    }
    if (filter?.activity) {
      initData['Activity'] = activityList?.filter((item) => filter?.activity.includes(item.id));
    }
    return initData;
  }, [filter, activityList]);

  return (
    <ErrorBoundary>
      <Filter
        initData={filterInitData}
        onSubmit={onFilterSearch}
        onSave={(filterObj, filterName) => console.info(filterObj, filterName)}
        checkFilterName={checkFilterName(filterList)}
        filterList={filterList}
      />

      <div className={classes.tableBox}>
        <FcasbTable
          loading={isFetching}
          rowKey="id"
          columns={columns}
          rows={data?.data ?? []}
          pagination={{
            total: data?.totalCount ?? 0,
            enableQuery: true,
          }}
          sort={{
            asc: pageQuery.asc,
            desc: pageQuery.desc,
            onSortChange: ({ asc, desc }) => setQuery({ asc, desc }),
          }}
          expandable={{
            type: 'left',
            expandedRowKeys: expanded,
            expandComponent: ({ row }) => row.object,
            onChange: (expandedKeys) => setExpand(expandedKeys),
          }}
          rowSelection={{
            selectedKeys: selected,
            onChange: (selectedKeys) => setSelected(selectedKeys),
          }}
        />
      </div>
    </ErrorBoundary>
  );
};
export default AppAlert;
