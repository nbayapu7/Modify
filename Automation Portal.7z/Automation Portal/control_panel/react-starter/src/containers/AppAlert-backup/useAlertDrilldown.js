import { useParams, useHistory } from 'react-router-dom';

const useAlertDrilldown = () => {
  const history = useHistory();
  const { appKey } = useParams();

  const drilldown = ({ timeRange = {}, severity = [], alertType = [] }, targetAppKey = null) => {
    const filterObj = {};
    if (Object.keys(timeRange)) {
      filterObj.timeRange = timeRange;
    }
    if (severity.length > 0) {
      filterObj.severity = severity;
    }
    if (alertType.length > 0) {
      filterObj.alertType = alertType;
    }
    history.push({
      pathname: `/app/${targetAppKey || appKey}/alert`,
      search: `?filter=${encodeURIComponent(JSON.stringify(filterObj))}`,
    });
  };
  return drilldown;
};

export default useAlertDrilldown;
