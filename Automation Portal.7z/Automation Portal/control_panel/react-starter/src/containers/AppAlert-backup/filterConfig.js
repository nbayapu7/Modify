export const AlertTypeList = [
  { name: 'Data Analysis', id: 'Data Analysis' },
  { name: 'Threat Protection', id: 'Threat Protection' },
  { name: 'Compliance', id: 'Compliance' },
];

/**
 *
 * @param {string} newFilterName
 * @param {array} filterList  existing saved list
 * @returns {object} a obj with key: message, value: errorMessage
 */
export const checkFilterName = async (newFilterName, filterList) => {
  if (!newFilterName) {
    return { message: 'the filter name is required' };
  }
  if (!/^[0-9a-zA-Z. _-]{1,24}$/.test(newFilterName)) {
    return {
      message:
        'The filter name may exceeds the maxLength and only allows following characters: a-z, A-Z, 0-9, ., -, _, and space.',
    };
  }
  let error;
  filterList.forEach((item) => {
    if (item.name === newFilterName) {
      error = { message: 'duplicateName, please choose another name' };
    }
  });
  return error;
};
