import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import './login.css';
import '../../../node_modules/bootstrap/dist/css/bootstrap.css';

async function login(creds) {
  // return fetch('http://localhost:8111/login', {
  return fetch('login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(creds),
  }).then((data) => data.json());
}

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
    };
  }

  setUserInfo(event, key) {
    const obj = {};
    obj[key] = event.target.value;
    this.setState(obj);
  }

  handleLogin = async (e) => {
    e.preventDefault();
    const res = await login({
      email: this.state.email,
      password: this.state.password,
    });
    if ('token' in res) {
      this.props.setToken(res.token, res.email);
    } else {
      alert(res.err);
    }
  };

  render() {
    return (
      <div className="App">
        <nav className="navbar navbar-expand-lg navbar-light fixed-top">
          <div className="container">
            <Link className="navbar-brand" to="/sign-in">
              Fcon AS
            </Link>
            <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul className="navbar-nav ml-auto">
                <li className="nav-item">
                  <Link className="nav-link" to="/sign-in">
                    Login
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <div className="auth-wrapper">
          <div className="auth-inner">
            <form onSubmit={this.handleLogin}>
              <h3>Sign In</h3>

              <div className="form-group">
                <label>Email address</label>
                <input
                  type="email"
                  className="form-control"
                  placeholder="Enter email"
                  onInput={(e) => {
                    this.setUserInfo(e, 'email');
                  }}
                />
              </div>

              <div className="form-group">
                <label>Password</label>
                <input
                  type="password"
                  className="form-control"
                  placeholder="Enter password"
                  onInput={(e) => {
                    this.setUserInfo(e, 'password');
                  }}
                />
              </div>

              <div className="form-group">
                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="customCheck1" />
                  <label className="custom-control-label" htmlFor="customCheck1">
                    Remember me
                  </label>
                </div>
              </div>

              <button type="submit" className="btn btn-primary btn-block">
                Login
              </button>
              {/* <p className="forgot-password text-right">
                Forgot <a href="#">password?</a>
              </p> */}
            </form>
          </div>
        </div>
      </div>
    );
  }
}

Login.propTypes = {
  setToken: PropTypes.func.isRequired,
};
