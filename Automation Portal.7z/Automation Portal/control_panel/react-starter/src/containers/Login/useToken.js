import { useState } from 'react';

// export default function useToken() {
//   const getToken = () => {
//     return sessionStorage.getItem('token');
//   };
//   const [token, setToken] = useState(getToken());

//   const saveToken = (t) => {
//     sessionStorage.setItem('token', t);
//     setToken(t);
//   };

//   return {
//     setToken: saveToken,
//     token,
//   };
// }

export default function useToken() {
  const getToken = () => {
    return [sessionStorage.getItem('token'), sessionStorage.getItem('email')];
  };
  const [token, setToken] = useState(getToken());

  const saveToken = (t, e) => {
    sessionStorage.setItem('token', t);
    sessionStorage.setItem('email', e);
    setToken([t, e]);
  };

  return {
    setToken: saveToken,
    token,
  };
}
