import { useQuery } from 'react-query';
import { getAppFilterListApi, getActivityListApi } from './api';

export const useAppFilterList = (appKey, source, options = {}) =>
  useQuery({
    queryKey: ['AppFilterList', appKey, source],
    queryFn: () => getAppFilterListApi(appKey),
    staleTime: Infinity,
    select: (data) => {
      const filterList = data.filter((item) => item.source === source);
      const newFilterList = [];
      filterList.forEach((filterObj) => {
        const newFilterObj = { ...filterObj };
        const initFilter = JSON.parse(filterObj.filter);
        const newFilter = {};
        const timeObj = {};
        Object.keys(initFilter).forEach((item) => {
          if (
            !Array.isArray(initFilter[item]) ||
            (Array.isArray(initFilter[item]) && initFilter[item].length > 0)
          ) {
            // ***auditLog*** //
            if (item === 'id') {
              newFilter['Id'] = initFilter[item];
            }
            if (item === 'selectAuditOperateObject') {
              newFilter['Operation'] = initFilter[item];
            }
            if (item === 'selectAuditModuleObject') {
              newFilter['Module'] = initFilter[item];
            }
            if (item === 'selectAuditVendorObject') {
              newFilter['Vendor'] = initFilter[item];
            }
            if (item === 'isSuccess') {
              newFilter['Result'] = initFilter[item] ? 'Success' : 'Fail';
            }
            // *** alert *** //
            if (item === 'alertId') {
              newFilter['Alert ID'] = initFilter[item];
            }
            if (item === 'selectPolicyObject') {
              newFilter['Policy'] = initFilter[item];
            }
            if (item === 'selectSeverityObject') {
              newFilter['Severity'] = initFilter[item];
            }
            if (item === 'selectCountryObject') {
              newFilter['Country/Region'] = initFilter[item];
            }
            if (item === 'selectAlertTypeObject') {
              newFilter['Alert Type'] = initFilter[item];
            }
            // *** activity *** //
            if (item === 'activityId') {
              newFilter['Activity ID'] = initFilter[item];
            }
            if (item === 'ipList') {
              const newIPList = [];
              initFilter[item].forEach((ip) => {
                newIPList.push({ name: ip['text'] });
              });
              newFilter['IP Address'] = newIPList;
            }
            // *** alert/activity common *** //
            if (item === 'selectUserObject') {
              newFilter['User'] = initFilter[item];
            }
            if (item === 'selectActivityObject') {
              newFilter['Activity'] = initFilter[item];
            }
            if (item === 'object' && initFilter[item]) {
              newFilter['Object Name'] = initFilter[item];
            }
            // *** common ***//
            if (item === 'selectedHistoryPeriod') {
              timeObj['name'] = initFilter[item].displayTime;
            }
            if (item === 'selectedPeriod') {
              timeObj['startTime'] = new Date(
                initFilter[item]?.startTime || initFilter[item]?.start_dt,
              ).getTime();
              timeObj['endTime'] = new Date(
                initFilter[item]?.endTime || initFilter[item]?.end_dt,
              ).getTime();
            }
          }
        });
        if (timeObj && Object.keys(timeObj).length !== 0) {
          newFilter['Time Range'] = timeObj;
        }
        newFilterObj['filter'] = newFilter;
        newFilterList.push(newFilterObj);
        newFilterList.sort((a, b) => a.name.localeCompare(b.name));
      });
      return newFilterList;
    },
    ...options,
  });

export const useFilterActivityList = (appKey) =>
  useQuery({
    queryKey: ['FilterActivityList', appKey],
    queryFn: () => getActivityListApi(appKey),
    staleTime: Infinity,
    cacheTime: Infinity,
  });

export const getRunningTasksList = () =>
  useQuery({
    queryKey: ['RuningTasksList'],
    // queryFn: () => getActivityListApi(appKey),
    queryFn: () => getRunningTasksListApi('haha'),
    staleTime: Infinity,
    cacheTime: Infinity,
  });
