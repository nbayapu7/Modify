import * as api from './api';
import * as query from './query';

export default {
  api,
  query,
};
