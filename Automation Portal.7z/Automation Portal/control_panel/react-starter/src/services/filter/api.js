import axios from 'axios';

export const getAppFilterListApi = (appKey) =>
  axios.get('/api/v1/filter/list', {
    headers: {
      service: appKey,
    },
  });

export const getActivityListApi = (appKey) =>
  axios.get('/api/v1/event', {
    headers: {
      service: appKey,
    },
  });

export const getRunningTasksListApi = () => {
  alert('api called');
  axios.get('http://localhost:8111/tasks/running', {
    headers: {
      service: 'hahaha',
    },
  });
};
