import axios from 'axios';
import { AlertListParams, AlertListRes } from './types';

export const getAppAlertListApi = (params: AlertListParams): Promise<AlertListRes> =>
  axios.post('/api/v1/alert/list', params);
