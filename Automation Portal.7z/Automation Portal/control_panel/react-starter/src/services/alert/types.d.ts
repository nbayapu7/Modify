export type AlertRowItem = {
  alertType: string;
  applicationId: string;
  buId: number;
  companyId: string;
  contextName: string;
  createTime: number;
  defineType: string;
  displayOperation: string;
  eventId: string;
  eventIdList: string[];
  geoLocationList: GeoLocationItem[];
  id: string;
  matches: number;
  object: string;
  objectId: string;
  objectType: string;
  policyCode: string;
  policyId: string;
  policyName: string;
  resultDesc: string;
  service: string;
  severity: string;
  timestampUUID: string;
  updateTime: number;
  user: string;
  userId: string;
  userName: string;
  violationActivity: string;
};

export type GeoLocationItem = {
  city: string;
  countryCode: string;
  countryName: string;
  geonameId: string;
  ip: string;
};

export type AlertListRes = {
  data: AlertRowItem[];
  limit: number;
  skip: number;
  totalCount: number;
  totalPage: number;
};

export type AlertListParams = Partial<{
  activity: number[];
  alertType: string[];
  asc: string;
  city: any[];
  desc: string;
  endTime: number;
  id: string;
  idList: string;
  objectIdList: string[];
  policy: any[];
  service: string;
  severity: any[];
  startTime: number;
  status: any[];
  user: any[];
}> &
  ListApiPagination;
