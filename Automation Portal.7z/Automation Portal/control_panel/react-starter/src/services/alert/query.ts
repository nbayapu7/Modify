import { useQuery, UseQueryOptions, UseQueryResult } from 'react-query';
import { getAppAlertListApi } from './api';
import { AlertListParams, AlertListRes } from './types';

/**
 * Fetching app alert
 * @param {object} params  request payload
 * @param {object} options https://react-query.tanstack.com/reference/useQuery
 * @returns UseQueryResult
 */
export const useAppAlertList = (
  params: AlertListParams,
  options?: UseQueryOptions<AlertListRes>,
): UseQueryResult<AlertListRes> =>
  useQuery({
    queryKey: ['AppAlertList', params],
    queryFn: () => getAppAlertListApi(params),
    keepPreviousData: true,
    ...options,
  });
