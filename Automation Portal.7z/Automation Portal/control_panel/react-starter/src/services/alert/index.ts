import * as api from './api';
import * as query from './query';
import * as types from './types';

export default {
  api,
  query,
  types,
};
