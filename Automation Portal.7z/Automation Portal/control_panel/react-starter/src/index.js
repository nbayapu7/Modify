import React from 'react';
import ReactDOM from 'react-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
// import { ReactQueryDevtools } from 'react-query/devtools';
import { ThemeProvider } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import { HashRouter as Router, Route } from 'react-router-dom';
import { createBrowserHistory } from 'history';
import dayjs from 'dayjs';
import localizedFormat from 'dayjs/plugin/localizedFormat';
import theme from '@/theme';
import { QueryParamProvider, transformSearchStringJsonSafe } from 'use-query-params';
import '@/utils/axios';
import '@/styles/main.less';
import App from './containers/App';

dayjs.extend(localizedFormat);

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
      staleTime: 5 * 1000,
    },
  },
});

const customHistory = createBrowserHistory();
const queryStringifyOptions = {
  transformSearchString: transformSearchStringJsonSafe,
};
ReactDOM.render(
  <ThemeProvider theme={theme}>
    <QueryClientProvider client={queryClient}>
      <Router history={customHistory}>
        <QueryParamProvider ReactRouterRoute={Route} stringifyOptions={queryStringifyOptions}>
          <CssBaseline />
          <App />
        </QueryParamProvider>
      </Router>
      {/* <ReactQueryDevtools initialIsOpen /> */}
    </QueryClientProvider>
  </ThemeProvider>,
  document.getElementById('root'),
);
