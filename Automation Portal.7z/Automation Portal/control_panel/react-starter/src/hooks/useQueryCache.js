import { useEffect } from 'react';
import { useQuery } from 'react-query';

/**
 * this function wrap the useQuery
 * if config pass enabled: false, will not auto fetch at first.
 * if config pass enabled: true, will force to fetch at first.
 * if config not pass enabled: will fetch if no cache
 *
 * @param {*} queryKey
 * @param {*} queryFn
 * @param {*} config
 * @returns useQuery return
 */
export default function useQueryCache(queryKey, queryFn, config = {}) {
  const query = useQuery(queryKey, queryFn, {
    enabled: false,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    ...config,
  });
  useEffect(() => {
    // if use pass enabled: false, will not auto fetch at first.
    if (query.isIdle && !(Object.hasOwnProperty.call(config, 'enabled') && !config.enabled)) {
      query.refetch();
    }
  }, []);
  return query;
}
