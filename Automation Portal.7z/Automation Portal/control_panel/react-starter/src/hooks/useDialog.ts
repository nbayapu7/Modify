import { useState } from 'react';

const useDialog = (initVisible = false): [boolean, () => void, () => void] => {
  const [visible, setVisible] = useState(initVisible || false);
  const open = () => {
    setVisible(true);
  };
  const close = () => {
    setVisible(false);
  };

  return [visible, open, close];
};
export default useDialog;
