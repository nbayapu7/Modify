export type AnchorE = null | HTMLElement;
export declare const useAnchol: (
  ancholElInit: AnchorE,
) => [AnchorE, () => void, () => void, boolean];
