import { useState } from 'react';

export const useAnchol = (ancholElInit) => {
  const [anchorEl, setAncholEl] = useState(ancholElInit || null);
  const open = (event) => {
    setAncholEl(event.currentTarget);
  };
  const close = () => {
    setAncholEl(null);
  };

  return [anchorEl, open, close, Boolean(anchorEl)];
};
