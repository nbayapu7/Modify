const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const mockServer = require('./mock/server');
const { proxyPort, proxyContext } = require('./package.json');

const isMockMode = process.env.MOCK === 'true';
const app = express();

// const target = 'https://qa1.staging.forticasb.com';
const target = 'http://localhost:8111';
const token = {
  accountId: 'test2432@qatest.com',
  webAccessToken: {
    token_type: 'bearer',
    expires: 1620875887275,
    access_token:
      'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJiIjoie30iLCJhcyI6InBhc3N3b3JkIG9ubHkiLCJjIjowLCJ0IjoxNjIwODcyMjg3Mjc1LCJzZXJ2aWNlIjpbIkZDQVNCIl0sInNjb3BlIjoiV0VCIiwiaXNzIjoiZmF1dGgtc2VydmVyIiwiZXhwIjoxNjIwODc1ODg3LCJhaWQiOiJ0ZXN0MjQzMkBxYXRlc3QuY29tIn0.wQ9Yilahk7M23oKhGzzMnleetw9Btl5OKEdPgaXX6xc',
    refresh_token:
      'e9fEZRaq3yZx6hIoOFVbMwLhzJMXeGD4Xsd27GJeVE35LZlm7N7vBQx39rcD5p_Je6rK8b4Sq0umF2ajcRqr7zvisn0QKKRNHHqj6I3JQkpSteQ51xD7JMXk9oNa4aLMmBlAQaRirfP2hZP4WsAZZ1PQRQP2AusOFOySDSzVOvK9s9j6O-49KJ-T7oVfsaAlJoERUZjn1KQB1fyWviJ1x2__QsH0IoxgetdVfqbwQERQcOjJx7m-2qlmlQjR92zVR3BSEKxRU3eH1w5-MQB8JcpAOBS6ofzwQTE1_6V8ChyHz5a_QKNPqijWwqNA5AvXbtkk5lGSVlBIAhSqOBYtJV8mUm_HYS7SGHHRwopAy92anK4cjdtTuBUxSaxIs_ST',
  },
  authStatus: 'password only',
  loginType: 'NORMAL',
};

/**
 * Mock Server Config
 */
if (isMockMode) {
  mockServer(app);
  // eslint-disable-next-line no-console
  console.log(`🚀🚀 Mock Server is running 🚀🚀`);
}

const devProxy = createProxyMiddleware(proxyContext, {
  target,
  logLevel: 'silent',
  changeOrigin: true,
  cookieDomainRewrite: 'localhost',
  secure: false,
  rejectUnauthorized: false,
  onProxyReq: (proxyReq, req, res) => {
    /**
     * The 'changeOrigin: true' should change Origin to target, but it doesn't work. I don't know the reason yet.
     * Workaround solution: set the Origin to target manually.
     */
    proxyReq.setHeader('Origin', target);

    if (req.headers && req.originalUrl.includes('/client/v1/token?loginId=')) {
      res.json(token);
    }
    if (req.headers && req.originalUrl === '/static/v1/siteMap') {
      res.json({
        global: 'http://localhost:3000',
      });
    }
    if (req.headers && req.originalUrl === '/client/v1/token/refresh') {
      proxyReq.setHeader('Content-Type', 'application/x-www-form-urlencoded');
      return;
    }
    proxyReq.setHeader('Content-Type', 'application/json');
    proxyReq.setHeader('buid', '6384');
    proxyReq.setHeader('companyid', '6');
  },
});

app.use('*', devProxy);
// app.use('/devices', createProxyMiddleware({ target: 'http://10.160.53.227:5000', changeOrigin: true ,}));
app.listen(proxyPort);
