# FortiCASB

## Getting Started

```jsx
yarn

yarn start
```

1. Open [http://localhost:3000](http://localhost:3000/#/login?loginId=123)
2. Copy login token from [https://qa1.staging.forticasb.com/](https://qa1.staging.forticasb.com/) and pasted into proxy.js
3. Manually type in ?loginId=123 in URL and refresh page
4. Done

## Start in Mock Mode


```jsx
yarn start:mock
```

## Languages & Tools


- React@v17
- JavaScript & TypeScript
- Webpack@v5
- Eslint&Prettier
- [Material UI](https://material-ui.com/)
- [MockJS](http://mockjs.com/examples.html)
- [Echart@v5](https://echarts.apache.org/en/index.html)
- [DayJS](https://day.js.org/docs/en/installation/installation)
- [React Query](https://react-query.tanstack.com/overview)
- [useQueryParams](https://github.com/pbeshai/use-query-params)

## Folder Structure

```jsx
FCASB-CLIENT
├── .eslintrc.js                           # eslint config for JS & TS
├── .gitignore
├── nodemon.json
├── tsconfig.json
├── yarn.lock
├── package.json                           # Prettier/lint-staged settings
├── /config                              
│   └── webpack.{env}.js                   # Webpack config
├── /mock                                  # Mock server router + data
└── /src
	  ├── index.js  
	  ├── index.html
	  ├── theme.js                           # mui theme override
	  ├── constants.js                       # project-wide constants
    │
    ├── /assets                            # static resource
    │   ├── /images
    │       ├── /icons                     # custom icons (.svg/.png)
    │       ├── /logo       
    │       ├── other-images.png                    
    │   ├── /fonts             
    │      
    ├── /components                        # project-wide components
    │   ├── /ComponentName
    │       ├── /assets
    │       ├── ComponentName.jsx          # main component 
    │       ├── SubComponentName.jsx       # child component
    │       ├── index.js                   # export main component
    │       └── README.md                  # api/demo/usage/example
    │   └── /TSCompoentName
    │       ├── TSCompoentName.tsx
    │       ├── index.ts
    │       └── tyes.d.ts                  # api/description
    │
    ├── /service                           # api + query
    │   ├── /alert                         # api namesapce, follow backend api naming
    │       ├── api.js/ts                  # pure api request
    │       ├── query.js/ts                # react-query mgmt
    │       ├── (types.d.ts)                                
    │      
    ├── /layouts                           # Header/Menu/Page ...    
    │    
    ├── /containers
    │   └── /ContainersName              # describe page(at least two words) 
    │       ├── index.js                 # entry
		│       ├── /components              # container-wide child components
    │
    ├── /hooks                       
    │
    ├── /utils      
    │       ├── helper.js                # simple utils func
    │       ├── complexUtil.js                               
    │         
    ├── /styles
    │       ├── app.less                 # gloabl styling
    │       ├── main.less                # entry and 3rd part styles
    │
    └── /typings
```

---

# Naming

## File & Folder

### Containers

- **Multiple(2~3)  + Noun +  Camel-Case**

```
|- containers
      |- AppDashboard/
      |- PolicyCompliance/
      |- DocumentDetails/
```

## Variable

- lower camel case
- *ID*, *URL* —> ALL CAPS

```
// good
  let userInfo
  let customerID
  let fortiURL = 'http://qa1.foticasb.com'
  let maxAge = 99
  let userListTotal = 2222
  let orderNew

// bad
  let pinyin
  let flag = false
  let class = ''
  let delete = ''
  let asdf = 'zhangsan'
  let objUser = {}
  let Maxage = 100
  let find = null
  let item123 = ''
  let ComputeReSult
```

## Naming in loop

### Simple Loop

you can use:   *i, j, k, len, index, item, value, key*

```
for (let i = 0, len = userList.length; i < len; i++)
```

### Nested Loop

lower camel case renaming    e.g. userItem userIndex scoreItem

```
for (let userIndex = 0, userLength = userLists.length; ...) {
    for (let scoreIndex = 0, scoreLength = userLists[userIndex].scoreLists.length; ...) {
        userLists[userIndex][scoreIndex]
    }
}
```

## Constants

1. Noun
2. ALL CAPS
3. Underscore between words

```
const PI = Math.PI
const USER_AGE_MAX = 100
const DIALOG_TYPE_MAP = {}
```

## Functions

1. v+n
2. lowerCamelCase

### How to choose v.
People can predict return values just by looking at the name.

| v.   | meaning   | return value                                     | 栗子           |
|------|--------|--------------------------------------------|----------------|
| is   | IsOrNot | boolean                                    | isValid        |
| has  | HaveOrNot | boolean                                    | hasChild       |
| can  | CanOrCan't | boolean                                    | canUpgrade     |
| get  | get SomeValue | non-boolean                           | getUserList    |
| set  | set SomeValue | no return/ success/fail status/ chain object | setUserAddress |

其他常用动词: init, clear, format, go。建议优先使用上述动词

### Event Handler

Use handle/on + Event description

```
const handleInputChange = () => {}
const onFormSubmit = () => {}
const onDialogClose = () => {}
```

### Services/API

***create:*** createSomethingApi 

***change***: updateSomethingApi 

***delete***: removeSomethingApi 

***query***: getSomeDataApi

```
const getUserListApi = () => axios.get('/some/url')
const createPlanApi = () => axios.post('/***')
```

### Services/query

use + SomeKey + (List/Data/Status...)

```jsx
const api = getUserListApi;

const query = useUserList = () => 
	useQuery({ 
			queryKey: ['UserList', ...someOtherKeys],
			queryFn: getUserListApi,
			staleTime: 30000
	})
```