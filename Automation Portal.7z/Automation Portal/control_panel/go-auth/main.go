package main

import (
	"fmt"
	"gin-server/src/controller"
	"gin-server/src/dto"
	"gin-server/src/middleware"
	"gin-server/src/service"
	"log"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

type Config struct {
	DBHost         string `mapstructure:"DB_HOST"`
	DBPort         string `mapstructure:"DB_PORT"`
	DBName         string `mapstructure:"DB_NAME"`
	DBUser         string `mapstructure:"DB_USER"`
	DBPassword     string `mapstructure:"DB_PASSWD"`
	DBTimezone     string `mapstructure:"DB_TIMEZONE"`
	TaskEndpoint   string `mapstructure:"TASK_ENDPOINT"`
	TicketEndpoint string `mapstructure:"TICKET_ENDPOINT"`
	DeviceEndpoint string `mapstructure:"DEVICE_ENDPOINT"`
	ServerAddress  string `mapstructure:"SERVER_ADDRESS"`
}

// LoadConfig reads configuration from file or environment variables.
func LoadConfig(path string) (config Config, err error) {
	viper.AddConfigPath(path)
	viper.SetConfigName("app")
	viper.SetConfigType("env")

	viper.AutomaticEnv()

	err = viper.ReadInConfig()
	if err != nil {
		return
	}

	err = viper.Unmarshal(&config)
	return
}

func main() {
	// Initial log output file
	var logfilename string
	logfilename = time.Now().UTC().Format("2006-01-02T15:04:05.999Z") + ".log"
	f, err := os.OpenFile(logfilename, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		log.Fatalf("error opening file: %v", err)
	}
	defer f.Close()

	log.SetFlags(log.LUTC | log.Ldate | log.Ltime | log.Lmicroseconds)
	log.SetOutput(f)
	log.Println("Go-auth server started....")

	config, err := LoadConfig(".")
	if err != nil {
		log.Fatal("cannot load config:", err)
	} else {
		log.Println("DB_HOST", config.DBHost)
		log.Println("DB_PORT", config.DBPort)
		log.Println("DB_NAME", config.DBName)
		log.Println("DB_USER", config.DBUser)
		log.Println("DB_PASSWD", config.DBPassword)
		log.Println("DB_TIMEZONE", config.DBTimezone)
		log.Println("TASK_ENDPOINT", config.TaskEndpoint)
		log.Println("TICKET_ENDPOINT", config.TicketEndpoint)
		log.Println("DEVICE_ENDPOINT", config.DeviceEndpoint)
		log.Println("SERVER_ADDRESS", config.ServerAddress)
	}

	// open postgres database connection
	dsn := fmt.Sprintf("host=%s port=%s user=%s "+
		"password=%s dbname=%s sslmode=disable TimeZone=%s",
		config.DBHost, config.DBPort, config.DBUser, config.DBPassword,
		config.DBName, config.DBTimezone)
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if !db.Migrator().HasTable(&dto.User{}) {
		db.Migrator().CreateTable(&dto.User{})
		fmt.Print("Table Users created")
	}
	if err != nil {
//		panic(err)
	}
	loginSvc := service.LoginInfo{}
	jwtSvc := service.JWTAuthSvc()
	contr := controller.LoginHandler(&loginSvc, jwtSvc, db)

	r := gin.New()
	// r.Use(middleware.AuthorizeJWT())
	r.Use(middleware.CORSMiddleware())
	r.POST("/login", func(ctx *gin.Context) {
		fmt.Println("Hello Login")
		if token, email := contr.Login(ctx); token != "" {
			ctx.JSON(http.StatusOK, gin.H{
				"token": token,
				"email": email,
			})
		} else {
			ctx.JSON(http.StatusUnauthorized, gin.H{
				"err": "Invalid creds, unauthorized",
			})
		}
	})

	api := r.Group("/api")
	{
		taskHost := config.TaskEndpoint
		ticketHost := config.TicketEndpoint
		deviceHost := config.DeviceEndpoint
		api.GET("/tasks", func(c *gin.Context) { RP(c, taskHost, "/api/tasks", "") })
		api.POST("/tasks", func(c *gin.Context) { RP(c, taskHost, "/api/tasks/new", "") })
		api.POST("/tickets/:tid", func(c *gin.Context) { RP(c, ticketHost, "/api/tickets", "tid") })
		api.GET("/tickets", func(c *gin.Context) { RP(c, ticketHost, "/api/tickets", "") })
		api.GET("/devices", func(c *gin.Context) { RP(c, deviceHost, "/api/devices", "") })
		api.POST("/devices", func(c *gin.Context) { RP(c, deviceHost, "/api/devices/new", "") })
		api.PUT("/devices/:did", func(c *gin.Context) { RP(c, deviceHost, "/api/devices", "did") })
		api.DELETE("/devices/:did", func(c *gin.Context) { RP(c, deviceHost, "/api/devices", "did") })
		api.DELETE("/tasks/:tid", func(c *gin.Context) { RP(c, taskHost, "/api/tasks", "tid") })
	}
	r.Run(config.ServerAddress)
}

func RP(c *gin.Context, target string, apiURL string, param string) {
	remote, _ := url.Parse(target)
	proxy := httputil.NewSingleHostReverseProxy(remote)
	if param != "" {
		apiURL = apiURL + "/" + c.Param(param)
	}
	c.Request.URL.Path = apiURL
	fmt.Println(c.Request.URL.Path)
	proxy.ServeHTTP(c.Writer, c.Request)
}
