package service

type LoginSvc interface {
	Login(email string, password string) bool
}

type LoginInfo struct {
	email    string
	password string
}

func (info *LoginInfo) Login(email string, password string) bool {
	return info.email == email && info.password == password
}
