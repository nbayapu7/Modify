package service

import (
	"fmt"
	"os"
	"time"

	"github.com/dgrijalva/jwt-go"
	"github.com/jinzhu/gorm"
)

type User struct {
	gorm.Model
}

type JWTSvc interface {
	GenToken(email string, isUser bool) string
	ValidateToken(token string) (*jwt.Token, error)
}

type authCustomClaims struct {
	Name string `json:"name"`
	User bool   `json:"user"`
	jwt.StandardClaims
}

type jwtServices struct {
	secretKey string
	issure    string
}

func JWTAuthSvc() JWTSvc {
	return &jwtServices{
		secretKey: getSecretKey(),
		issure:    "abc",
	}
}

func getSecretKey() string {
	var secret string
	if secret = os.Getenv("SECRET"); secret == "" {
		secret = "secret"
	}
	return secret
}

func (service *jwtServices) GenToken(email string, isUser bool) string {
	claims := &authCustomClaims{
		email,
		isUser,
		jwt.StandardClaims{
			ExpiresAt: time.Now().Add(time.Hour * 48).Unix(),
			Issuer:    service.issure,
			IssuedAt:  time.Now().Unix(),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	if encoded, err := token.SignedString([]byte(service.secretKey)); err != nil {
		panic(err)
	} else {
		return encoded
	}
}

func (service *jwtServices) ValidateToken(encodedToken string) (*jwt.Token, error) {
	return jwt.Parse(encodedToken, func(token *jwt.Token) (interface{}, error) {
		if _, isvalid := token.Method.(*jwt.SigningMethodHMAC); !isvalid {
			return nil, fmt.Errorf("invalid token, arg: %s", token.Header["alg"])
		}
		return []byte(service.secretKey), nil
	})
}
