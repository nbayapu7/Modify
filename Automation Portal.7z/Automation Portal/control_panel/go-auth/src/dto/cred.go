package dto

type LoginCreds struct {
	Email    string `form:"email"`
	Password string `form:"password"`
}
