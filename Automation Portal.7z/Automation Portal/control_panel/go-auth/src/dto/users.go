package dto

import "gorm.io/gorm"

type User struct {
	gorm.Model
	Id        int64
	Email     string
	Password  string
	Firstname string
	Lastname  string
	Role      string
}
