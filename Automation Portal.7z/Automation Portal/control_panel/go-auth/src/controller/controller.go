package controller

import (
	"gin-server/src/dto"
	"gin-server/src/service"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type LoginController interface {
	Login(ctx *gin.Context) (string, string)
}

type loginController struct {
	loginSvc service.LoginSvc
	jwtSvc   service.JWTSvc
	dbSvc    *gorm.DB
}

func LoginHandler(loginSvc service.LoginSvc, jwtSvc service.JWTSvc, dbSvc *gorm.DB) LoginController {
	return &loginController{
		loginSvc: loginSvc,
		jwtSvc:   jwtSvc,
		dbSvc:    dbSvc,
	}
}

func (contr *loginController) Login(ctx *gin.Context) (string, string) {
	var cred dto.LoginCreds
	if err := ctx.ShouldBind(&cred); err != nil {
		return "no data found", ""
	}
	user := dto.User{Email: cred.Email}
	rst := contr.dbSvc.First(&user)
	if rst.RowsAffected < 1 {
		return "User not exsit", ""
	}
	isAuthenticated := user.Email == cred.Email && user.Password == cred.Password
	if isAuthenticated {
		return contr.jwtSvc.GenToken(cred.Email, true), cred.Email
	}
	return "", ""
}
